CREATE TABLE IF NOT EXISTS `apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apiurl` varchar(255) NOT NULL,
  `stopurl` varchar(255) NOT NULL,
  `methods` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `attacklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `port` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `method` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `sid` int(11) NOT NULL,
  `apiurl` varchar(255) NOT NULL,
  `stopurl` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `blacklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(100) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `btc_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `package` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `transaction_hash` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `commands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `command` varchar(255) NOT NULL,
  `stopCmd` varchar(255) NOT NULL,
  `method` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(30) NOT NULL,
  `group` varchar(50) NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


INSERT INTO `methods` (`id`, `method`, `group`, `desc`) VALUES
(1, 'UDP', 'layer4', '0');


CREATE TABLE IF NOT EXISTS `news` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `detail` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `mbt` int(11) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `length` int(11) NOT NULL,
  `concurrents` int(11) NOT NULL,
  `methods` varchar(255) NOT NULL,
  `public` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


INSERT INTO `packages` (`id`, `name`, `price`, `mbt`, `unit`, `length`, `concurrents`, `methods`, `public`) VALUES
(1, 'Test Package', 10, 300, 'Months', 1, 1, '["UDP"]', 2);


CREATE TABLE IF NOT EXISTS `pp_payments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `paid` float NOT NULL,
  `plan` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `user` int(15) NOT NULL,
  `email` varchar(60) NOT NULL,
  `tid` varchar(30) NOT NULL,
  `date` int(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(50) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(255) NOT NULL,
  `methods` varchar(255) NOT NULL,
  `response` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteurl` varchar(200) NOT NULL,
  `sitetitle` varchar(200) NOT NULL,
  `sitemail` varchar(200) NOT NULL,
  `contact` varchar(200) NOT NULL,
  `paypal` varchar(200) NOT NULL,
  `btc` varchar(255) NOT NULL,
  `skypeapi` varchar(255) NOT NULL,
  `trialseconds` int(11) NOT NULL,
  `custompackages` int(1) NOT NULL,
  `custompbase` int(11) NOT NULL,
  `mailingtype` varchar(30) NOT NULL,
  `smtphost` varchar(200) NOT NULL,
  `smtpuser` varchar(200) NOT NULL,
  `smtppass` varchar(200) NOT NULL,
  `smtpport` int(11) NOT NULL,
  `homepage` longtext NOT NULL,
  `tos` longtext NOT NULL,
  `cpmerchant` varchar(100) NOT NULL,
  `cpipnsecret` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


INSERT INTO `settings` (`id`, `siteurl`, `sitetitle`, `sitemail`, `contact`, `paypal`, `btc`, `skypeapi`, `trialseconds`, `custompackages`, `custompbase`, `mailingtype`, `smtphost`, `smtpuser`, `smtppass`, `smtpport`, `homepage`, `tos`, `cpmerchant`, `cpipnsecret`) VALUES
(1, '127.0.0.1', 'Booter', 'info@woopza.com', 'contact@woopza.com', 'your@paypal.com', '123456789123456', 'http://skypeapi.com/resolve.php?name=', 30, 0, 5, 'php', '', '', '', 0, '<h1>Welcome to Booter!</h1>\r\n\r\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni <em>dolores eos qui ratione voluptatem</em> sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et <strong>dolore magnam aliquam</strong> quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\r\n', '1. test <br> 2. test', '', '');


CREATE TABLE IF NOT EXISTS `ticketreplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `author` int(1) NOT NULL,
  `reply` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(20) NOT NULL,
  `senderid` int(1) NOT NULL,
  `title` varchar(35) NOT NULL,
  `details` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


INSERT INTO `tickets` (`id`, `department`, `senderid`, `title`, `details`, `date`, `status`) VALUES
(1, 'General Inquire', 1, 'Test Ticket', 'Ticket information here.', 1429835212, 2);


CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  `package` int(11) NOT NULL,
  `maxboot` int(11) NOT NULL,
  `expire` int(11) NOT NULL,
  `status` varchar(1000) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;


INSERT INTO `users` (`ID`, `username`, `password`, `email`, `rank`, `package`, `maxboot`, `expire`, `status`) VALUES
(1, 'admin', '57ba2b608d3a69f3bff6a58efac8b172057bf800f7332ba8efee8d595e87db2dba2759a515251e6953554bc77bb558e4a40ae867d204b58c4454ace0f328a617', 'admin@woopza.com', 1, 1, 300, 2147483647, '0'),
(2, 'test', 'ce5fa4b75ef491664c0a42a28fc0d7393e180c3a99aec2ce9a333c4bb9d176b6c27446bd07fd11f86a74430538826e871ab52a852a2eb0756edfae7a932e4d0e', 'test@woopza.com', 0, 0, 0, 0, '0');
