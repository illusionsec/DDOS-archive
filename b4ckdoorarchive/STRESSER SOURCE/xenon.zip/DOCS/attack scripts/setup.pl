#!/usr/bin/perl
# Asylum.

print "Would you like to install the required packages? [Y/n]\n";
chomp($req=<STDIN>);
if(lc ($req) eq "y" || $req eq ""){
	print "Installing required packages...\n";
	sleep(2);
	system("sudo yum install httpd mod_ssl");
	system("sudo /sbin/chkconfig httpd on");
	system("sudo yum install php-mysql php-devel php-gd php-pecl-memcache php-pspell php-snmp php-xmlrpc php-xml");
	system("sudo /usr/sbin/apachectl restart");
	system("sudo yum install make");
	system("sudo yum install gcc");
	print "\nInstalling required packages completed!\n";
}

print "Would you like to install SSH2? [Y/n]\n";
chomp($ssh=<STDIN>);
if(lc ($ssh) eq "y" || $ssh eq ""){
	print "Installing SSH2...\n";
	sleep(2);
	system("yum install gcc php-devel php-pear libssh2 libssh2-devel");
	system("pecl install -f ssh2");
	system("touch /etc/php.d/ssh2.ini");
	system("echo extension=ssh2.so > /etc/php.d/ssh2.ini");
	system("setsebool -P httpd_can_network_connect 1");
	system("/etc/init.d/httpd restart");
	print "\nChecking...\n";
	system("php -m | grep ssh2");
	print "If you see \"ssh2\" then it has been successfully installed!\n";
}

print "Would you like to compile the scripts? [Y/n]\n";
chomp($scripts=<STDIN>);

if(lc ($scripts) eq "y" || $scripts eq ""){
	print "Compiling...\n";
	sleep(2);
	system("gcc amp.c -pthread -o amp");
	system("chmod +x amp");
	system("gcc arme.c -pthread -o arme");
	system("chmod +x arme");
	system("gcc essyn.c -pthread -o essyn");
	system("chmod +x essyn");
	system("gcc lag.c -pthread -o lag");
	system("chmod +x lag");
	system("gcc rudy.c -pthread -o rudy");
	system("chmod +x rudy");
	system("gcc scloud.c -pthread -o scloud");
	system("chmod +x scloud");
	system("gcc slow.c -pthread -o slow");
	system("chmod +x slow");
	system("gcc tcp.c -pthread -o tcp");
	system("chmod +x tcp");
	print "\nCompiling completed!\n";
}