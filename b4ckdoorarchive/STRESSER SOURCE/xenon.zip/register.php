﻿<?php
ob_start();
include 'engine/config.php';
include 'engine/init.php';

if ($user -> LoggedIn())
{
	header('location: index.php');
	die();
}

function generateRandomString($length = 20) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Xenon Boostrap Admin Panel" />
	<meta name="author" content="Woopza.com" />

	<title><?php echo $web_title;?>Register</title>

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">
	<link rel="stylesheet" href="assets/css/fonts/linecons/css/linecons.css">
	<link rel="stylesheet" href="assets/css/fonts/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/xenon-core.css">
	<link rel="stylesheet" href="assets/css/xenon-forms.css">
	<link rel="stylesheet" href="assets/css/xenon-components.css">
	<link rel="stylesheet" href="assets/css/xenon-skins.css">
	<link rel="stylesheet" href="assets/css/custom.css">
	<script src='https://www.google.com/recaptcha/api.js'></script>

	<script src="assets/js/jquery-1.11.1.min.js"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->


</head>
<body class="page-body login-page">

	
	<div class="login-container">
	
		<div class="row">
			
			<div class="col-sm-6">
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
	
	
						// Validation and Ajax action
						$("form#register").validate({
							rules: {
								username: {
									required: true
								},
								
								email: {
									required: true
								},
	
								passwd: {
									required: true
								},
								
								rpasswd: {
									required: true
								}
							},
	
							messages: {
								username: {
									required: 'Please enter your username.'
								},
								
								email: {
									required: 'Please enter your e-mail address.'
								},
	
								passwd: {
									required: 'Please enter your password.'
								},
								
								rpasswd: {
									required: 'Please enter your password confirmation.'
								}
							},
						});
	
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
	
				<div class="errors-container">
					<?php
						if (isset($_POST['registerBtn']))
						{
							$captcha = $_POST['g-recaptcha-response'];
							$response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=6Lca1gQTAAAAAKaqHJFUftGnMsKgMwNN0DvNwH_3&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);
							if($response.success==false || !($captcha))
							{
								echo '<div class="alert alert-block alert-danger fade in"><button type="button" class="close close-sm" data-dismiss="alert"><i class="fa fa-times"></i></button><strong>Oops!</strong> Invalid captcha code entered.</div>';
							} else {
								$username = $_POST['username'];
								$password = $_POST['passwd'];
								$repeat = $_POST['rpasswd'];
								$email = $_POST['email'];
								$terms = $_POST['terms'];
								$errors = array();
								if (empty($username) || empty($password) || empty($repeat) || empty($email))
								{
									$errors[] = 'Please fill in all required fields.';
								}
								$checkUsername = $odb -> prepare("SELECT * FROM `users` WHERE `username`= :username");
								$checkUsername -> execute(array(':username' => $username));
								$countUsername = $checkUsername -> rowCount();
								if ($countUsername != 0)
								{
								$errors[] = 'The username you have entered is already in use.';
								}
								$checkEmail = $odb -> prepare("SELECT * FROM `users` WHERE `email`= :email");
								$checkEmail -> execute(array(':email' => $email));
								$countEmail = $checkEmail -> rowCount();
								if ($countEmail0 != 0)
								{
									$errors[] = 'The email you have entered is already in use.';
								}
									if (strlen($_POST['passwd']) < 4) {
									$errors[] = 'The username you have entered is too short.';
									}
									if (strlen($_POST['username']) > 15) {
									$errors[] = 'The username you have entered is too long.';
									}
								if (!filter_var($email, FILTER_VALIDATE_EMAIL))
								{
									$errors[] = 'You have entered an invalid e-mail address.';
								}
								if (!ctype_alnum($username))
								{
									$errors[] = 'The username you have entered is invalid.';
								}
								if ($password != $repeat)
								{
									$errors[] = 'The passwords you have entered does not match.';
								}
								if ($terms != 'agree')
								{
									$errors[] = 'You have to agree t.o.s before using our service.';
								}
								if (empty($errors))
								{
									$sha = hash("sha512", $password);
									$activation = generateRandomString();
									$insertUser = $odb -> prepare("INSERT INTO `users` VALUES(NULL, :username, :password, :email, 0, 0, 0, 0, 0)");
									$insertUser -> execute(array(':username' => $username, ':password' => $sha, ':email' => $email));
									//Send mail here
									
									echo '<div class="alert alert-success fade in"><button type="button" class="close close-sm" data-dismiss="alert"><i class="fa fa-times"></i></button><strong>Success!</strong> You have registered your account successfully! Redirecting..</div><meta http-equiv="refresh" content="3;url=login.php">';
								}
								else
								{
									echo '<div class="alert alert-block alert-danger fade in"><button type="button" class="close close-sm" data-dismiss="alert"><i class="fa fa-times"></i></button><strong>Oops!</strong><br />';
									foreach($errors as $error)
									{
										echo '- '.$error.'<br />';
									}
									echo '</div>';
								}
							}
						}
					?>
				</div>
	
				<form method="post" role="form" id="register" class="login-form fade-in-effect">
	
					<div class="login-header">
						<a href="index.php" class="logo">
							<img src="assets/images/logo@2x.png" alt="" width="80" />
							<span>registration</span>
						</a>
	
						<p>create your account for free!</p>
					</div>
	
	
					<div class="form-group">
						<label class="control-label" for="username"></label>
						<input type="text" class="form-control input-dark" name="username" id="username" placeholder="Username" autocomplete="off" autofocus/>
					</div>
					
					<div class="form-group">
						<label class="control-label" for="email"></label>
						<input type="email" class="form-control input-dark" name="email" id="email" placeholder="E-Mail Address" autocomplete="off" />
					</div>
	
					<div class="form-group">
						<label class="control-label" for="passwd"></label>
						<input type="password" class="form-control input-dark" name="passwd" id="passwd" placeholder="Password" autocomplete="off" />
					</div>
					
					<div class="form-group">
						<label class="control-label" for="rpasswd"></label>
						<input type="password" class="form-control input-dark" name="rpasswd" id="rpasswd" placeholder="Confirm Password" autocomplete="off" />
					</div>
					
					<div class="form-group">
						<center><div class="g-recaptcha" data-sitekey="6Lca1gQTAAAAAGP9B2AKD5QGAYivmyvDtDdxlA48"></div></center>
					</div>
					
					<div class="form-group">
						<div class="checkbox">
							<label>
								<input type="checkbox" name="terms" value="agree">
								By registering, I agree to your <a href="tos.php" target="_blank">Terms of Service</a>.
							</label>
						</div>
					</div>
	
					<div class="form-group">
						<button type="submit" name="registerBtn" class="btn btn-dark  btn-block text-left">
							<i class="fa-plus"></i>
							Register
						</button>
					</div>
	
					<div class="login-footer">
							<a href="login.php">Already have an account ? Login here!</a>
							
							<div class="info-links">
							<a href="tos.php">Terms of Service</a> -
							<a href="#">Privacy Policy</a>
						</div>
	
					</div>
	
				</form>
			</div>
	
		</div>
	
	</div>



	<!-- Bottom Scripts -->
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/TweenMax.min.js"></script>
	<script src="assets/js/resizeable.js"></script>
	<script src="assets/js/joinable.js"></script>
	<script src="assets/js/xenon-api.js"></script>
	<script src="assets/js/xenon-toggles.js"></script>
	<script src="assets/js/jquery-validate/jquery.validate.min.js"></script>
	<script src="assets/js/toastr/toastr.min.js"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="assets/js/xenon-custom.js"></script>

</body>
</html>