﻿<?php
ob_start(); 
require_once 'engine/config.php';
require_once 'engine/init.php';

if (!($user -> LoggedIn()))
{
	header('Location: login.php');
	die();
}
if ($user -> IsBanned($odb))
{
	header('Location: logout.php');
	die();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
	header('location: packages.php');
	die();
}
$id = $_GET['id'];
$checkIfExists = $odb -> prepare("SELECT * FROM `packages` WHERE `id` = :package");
$checkIfExists -> execute(array(':package' => $id));
if($checkIfExists -> rowCount() == 0) 
{
	header('location: packages.php');
	die();
}
$getInfo = $odb->prepare("select public from `packages` where `id` = :id");
$getInfo->execute(array(":id" => $id));
$Info = $getInfo->fetch(PDO::FETCH_ASSOC);
if($Info['public'] != '2')
{
	header('location: packages.php');
	die;
}
$SQLGetInfo = $odb -> prepare("SELECT * FROM `packages` WHERE `id` = :id AND `public` = 2 LIMIT 1");
$SQLGetInfo -> execute(array(':id' => $id));
$packageInfo = $SQLGetInfo -> fetch(PDO::FETCH_ASSOC);
$name = $packageInfo['name'];
$price = $packageInfo['price'];
$maxboot = $packageInfo['mbt'];
$unit = $packageInfo['unit'];
$length = $packageInfo['length'];
$concurrents = $packageInfo['concurrents'];
$methods = json_decode($packageInfo['methods'], true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	<meta name="author" content="Woopza.com" />

	<title><?php echo $web_title;?>Dashboard</title>

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">
	<link rel="stylesheet" href="assets/css/fonts/linecons/css/linecons.css">
	<link rel="stylesheet" href="assets/css/fonts/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/xenon-core.css">
	<link rel="stylesheet" href="assets/css/xenon-forms.css">
	<link rel="stylesheet" href="assets/css/xenon-components.css">
	<link rel="stylesheet" href="assets/css/xenon-skins.css">
	<link rel="stylesheet" href="assets/css/custom.css">

	<script src="assets/js/jquery-1.11.1.min.js"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->


</head>
<div class="page-loading-overlay">
	<div class="loader-2"></div>
</div>
<body class="page-body">
	
	<div class="page-container">
			
		<?php include 'templates/sidebar.php'; ?>
	
		<div class="main-content">
					
			<?php include 'templates/navbar.php'; ?>
			
			<div class="row">
			
				<div class="col-sm-12">
					<div class="panel panel-default">
						<div class="panel-heading hidden-print">Make payment for <?php echo $name; ?></div>
						<div class="panel-body">
							
							<section class="invoice-env">
							
								<!-- Invoice header -->
								<div class="invoice-header">
									
									<!-- Invoice Options Buttons -->
									<div class="invoice-options hidden-print">
										<a href="paypal.php?id=<?php echo $id; ?>" class="btn btn-block btn-info btn-icon btn-icon-standalone btn-icon-standalone-right text-left">
											<i class="fa-paypal"></i>
											<span>Pay with Paypal</span>
										</a>
										<form method="post" action="https://www.coinpayments.net/index.php">
										<input type="hidden" name="cmd" value="_pay">
										<input type="hidden" name="reset" value="1">
										<input type="hidden" name="merchant" value="<?php echo $gsettings -> getMerchant($odb); ?>">
										<input type="hidden" name="item_name" value="<?php echo $name; ?>">
										<input type="hidden" name="item_number" value="<?php echo $_SESSION['ID'];?>">
										<input type="hidden" name="custom" value="<?php echo $id."_".$_SESSION['ID'];?>">
										<input type="hidden" name="currency" value="USD">
										<input type="hidden" name="allow_currencies" value="BTC">
										<input type="hidden" name="amountf" value="<?php echo $price;?>">
										<input type="hidden" name="quantity" value="1">
										<input type="hidden" name="allow_quantity" value="0">
										<input type="hidden" name="want_shipping" value="0">
										<input type="hidden" name="success_url" value="http://<?php echo $gsettings -> getSiteUrl($odb);?>/index.php?payment=success">
										<input type="hidden" name="cancel_url" value="http://<?php echo $gsettings -> getSiteUrl($odb);?>/index.php?payment=canceled">
										<input type="hidden" name="ipn_url" value="http://<?php echo $gsettings -> getSiteUrl($odb);?>/engine/coinpayments.php">
										<input type="hidden" name="allow_extra" value="0">
										<button type="submit" class="btn btn-block btn-warning btn-icon btn-icon-standalone btn-icon-standalone-right btn-single text-left">
											<i class="fa-bitcoin"></i>
											<span>Pay with Bitcoin</span>
										</button>
										</form>
									</div>
									
									<!-- Invoice Data Header -->
									<div class="invoice-logo">
									
										<a href="#" class="logo">
											<img src="assets/images/logo-white-bg.png" class="img-responsive" />
										</a>
																				
									</div>
									
								</div>
								
								<!-- Invoice Entries -->
								<table class="table table-bordered">
									<thead>
										<tr class="no-borders">
											<th>Qty</th>
											<th>Length</th>
											<th class="text-center">Allowed Methods</th>
											<th class="text-center">Max Boot</th>
											<th class="text-center">Price</th>
										</tr>
									</thead>
									
									<tbody>
										<tr>
											 <td>1</td>			
											<td><?php echo $length.' '.$unit; ?></td>
											<td class="text-center"><?php echo implode(", ", $methods); ?></td>
											<td class="text-center"><?php echo $maxboot; ?> Seconds</td>
											<td class="text-center">$ <?php echo $price; ?></td>
										</tr>
									</tbody>
								</table>

								<div class="invoice-totals">
									
									<div class="invoice-subtotals-totals">
										<span>
											Sub - Total amount: 
											<strong>$<?php echo $price; ?></strong>
										</span>
										
										<hr />
										
										<span>
											Grand Total: 
											<strong>$<?php echo $price; ?></strong>
										</span>
									</div>
																
								</div>
								
							</section>
							
						</div>
					</div>
				</div>
							
				<div class="clearfix"></div>
				
			</div>
			
			<?php include 'templates/footer.php'; ?>
		</div>
		
	</div>
	

	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="assets/css/fonts/meteocons/css/meteocons.css">

	<!-- Bottom Scripts -->
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/TweenMax.min.js"></script>
	<script src="assets/js/resizeable.js"></script>
	<script src="assets/js/joinable.js"></script>
	<script src="assets/js/xenon-api.js"></script>
	<script src="assets/js/xenon-toggles.js"></script>


	<!-- Imported scripts on this page -->
	<script src="assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="assets/js/jvectormap/regions/jquery-jvectormap-world-mill-en.js"></script>
	<script src="assets/js/xenon-widgets.js"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="assets/js/xenon-custom.js"></script>

</body>
</html>