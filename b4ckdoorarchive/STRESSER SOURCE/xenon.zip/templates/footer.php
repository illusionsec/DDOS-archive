<footer class="main-footer sticky footer-type-1">
				
<div class="footer-inner">

	<div class="footer-text">
		&copy; 2015 All rights reserved.
		Powered by <a href="http://woopza.com/" target="_blank"><strong>Woopza Products</strong></a>
	</div>
	
	
	<!-- Go to Top Link, just add rel="go-top" to any link to add this functionality -->
	<div class="go-up">
	
		<a href="#" rel="go-top">
			<i class="fa-angle-up"></i>
		</a>
		
	</div>
	
</div>

</footer>