<div class="sidebar-menu toggle-others fixed">
		
			<div class="sidebar-menu-inner">
				
				<header class="logo-env">
		
					<!-- logo -->
					<div class="logo">
						<a href="index.php" class="logo-expanded">
							<img src="assets/images/logo@2x.png" width="80" alt="" />
						</a>
		
						<a href="index.php" class="logo-collapsed">
							<img src="assets/images/logo-collapsed@2x.png" width="40" alt="" />
						</a>
					</div>
		
					<!-- This will toggle the mobile menu and will be visible only on mobile devices -->
					<div class="mobile-menu-toggle visible-xs">
						<a href="#" data-toggle="user-info-menu">
							<i class="fa-bell-o"></i>
							<span class="badge badge-success">7</span>
						</a>
		
						<a href="#" data-toggle="mobile-menu">
							<i class="fa-bars"></i>
						</a>
					</div>
		
					
				</header>
				
				
						
				<ul id="main-menu" class="main-menu">
					<li class="<?php CheckPageA('index.php'); ?>">
						<a href="index.php">
							<i class="fa-desktop"></i>
							<span class="title">Dashboard</span>
						</a>
					</li>
					<li class="<?php CheckPageA('hub.php'); ?>">
						<a href="hub.php">
							<i class="fa-flash"></i>
							<span class="title">HUB</span>
						</a>
					</li>
					<li class="<?php CheckPageB('skyperesolver.php') || CheckPageB('isup.php') || CheckPageB('domainresolver.php') || CheckPageB('iplogger.php'); ?>">
						<a href="#">
							<i class="fa-arrows"></i>
							<span class="title">Tools</span>
						</a>
						<ul>
							<li class="<?php CheckPageA('skyperesolver.php'); ?>">
								<a href="skyperesolver.php">
									<span class="title">Skype Resolver</span>
								</a>
							</li>
							<li class="<?php CheckPageA('isup.php'); ?>">
								<a href="isup.php">
									<span class="title">Is Up or Down</span>
								</a>
							</li>
							<li class="<?php CheckPageA('domainresolver.php'); ?>">
								<a href="domainresolver.php">
									<span class="title">Domain Resolver</span>
								</a>
							</li>
							<li class="<?php CheckPageA('iplogger.php'); ?>">
								<a href="iplogger.php">
									<span class="title">IP Logger</span>
								</a>
							</li>
						</ul>
					</li>
					<li class="<?php CheckPageA('packages.php') || CheckPageA('order.php'); ?>">
						<a href="packages.php">
							<i class="fa-shopping-cart"></i>
							<span class="title">Purchase</span>
						</a>
					</li>
					<li class="<?php CheckPageB('newticket.php') || CheckPageB('tickets.php') || CheckPageB('viewticket.php'); ?>">
						<a href="#">
							<i class="fa-support"></i>
							<span class="title">Help Desk</span>
						</a>
						<ul>
							<li class="<?php CheckPageA('newticket.php'); ?>">
								<a href="newticket.php">
									<span class="title">Send Ticket</span>
								</a>
							</li>
							<li class="<?php CheckPageA('tickets.php'); ?>">
								<a href="tickets.php">
									<span class="title">View Tickets</span>
								</a>
							</li>
						</ul>
					</li>
					<?php if ($user -> IsAdmin($odb)) {?>
					<li>
						<a href="admin/index.php">
							<i class="fa-coffee"></i>
							<span class="title">Administration</span>
						</a>
					</li>
					<?php } ?>
				</ul>
				
			</div>
		
		</div>