-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2014 at 08:24 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `faggot`
--

-- --------------------------------------------------------

--
-- Table structure for table `2step_logs`
--

CREATE TABLE IF NOT EXISTS `2step_logs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `adminlogs`
--

CREATE TABLE IF NOT EXISTS `adminlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `page` varchar(200) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blacklist`
--

CREATE TABLE IF NOT EXISTS `blacklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(15) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fe`
--

CREATE TABLE IF NOT EXISTS `fe` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `type` varchar(1) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forgot_logs`
--

CREATE TABLE IF NOT EXISTS `forgot_logs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `IP` varchar(20) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ipbanned`
--

CREATE TABLE IF NOT EXISTS `ipbanned` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IP` varchar(50) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `iplogs`
--

CREATE TABLE IF NOT EXISTS `iplogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `logged` varchar(15) NOT NULL,
  `date` int(11) NOT NULL,
  `city` varchar(500) NOT NULL,
  `country` varchar(50) NOT NULL,
  `isp` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `loginlogss`
--

CREATE TABLE IF NOT EXISTS `loginlogss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `date` int(11) NOT NULL,
  `results` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `city` varchar(500) NOT NULL,
  `hostname` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `logins_failed`
--

CREATE TABLE IF NOT EXISTS `logins_failed` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 NOT NULL,
  `ip` varchar(15) CHARACTER SET latin1 NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) NOT NULL,
  `ip` varchar(70) NOT NULL,
  `port` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `method` varchar(10) NOT NULL,
  `date` int(11) NOT NULL,
  `servers` varchar(500) NOT NULL,
  `otime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `sender` varchar(30) NOT NULL,
  `messagefloat` varchar(20) NOT NULL DEFAULT 'plane plane-',
  `time` int(128) NOT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `methods`
--

CREATE TABLE IF NOT EXISTS `methods` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(900) NOT NULL,
  `tag` varchar(900) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `detail` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `paid` float NOT NULL,
  `plan` int(11) NOT NULL,
  `user` int(15) NOT NULL,
  `username` varchar(17) NOT NULL,
  `email` varchar(60) NOT NULL,
  `tid` varchar(30) NOT NULL,
  `method` varchar(200) NOT NULL,
  `date` int(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payments_pending`
--

CREATE TABLE IF NOT EXISTS `payments_pending` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `unpaid` float NOT NULL,
  `plan` int(11) NOT NULL,
  `user` int(15) NOT NULL,
  `email` varchar(60) NOT NULL,
  `tid` varchar(30) NOT NULL,
  `method` varchar(200) NOT NULL,
  `date` int(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE IF NOT EXISTS `plans` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `mbt` int(11) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `length` int(11) NOT NULL,
  `price` float NOT NULL,
  `concurrent` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `registerlogs`
--

CREATE TABLE IF NOT EXISTS `registerlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) CHARACTER SET latin1 NOT NULL,
  `ip` varchar(15) CHARACTER SET latin1 NOT NULL,
  `date` int(11) NOT NULL,
  `country` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `lastUsed` int(32) NOT NULL,
  `power` varchar(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `lastip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `siteconfig`
--

CREATE TABLE IF NOT EXISTS `siteconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant` varchar(1000) CHARACTER SET latin1 NOT NULL,
  `ipnsecret` varchar(5000) CHARACTER SET latin1 NOT NULL DEFAULT '7BN86S9K8AOMB',
  `stresser` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `skype` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `http` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `cloudflare` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `iplogger` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `phonegeo` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `fe` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `geolocation` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `support` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `apimanager` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `servers` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `website` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `cloudflare_set` int(1) NOT NULL,
  `bootername_1` varchar(800) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Booter',
  `bootername_2` varchar(800) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Name',
  `rotation` int(1) NOT NULL DEFAULT '0',
  `preloader` int(1) NOT NULL DEFAULT '0',
  `tos` varchar(10000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'T.O.S.',
  `site_forgot` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'http://localhost.com',
  `email_forgot` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'admin@localhost.com',
  `paypal` int(1) NOT NULL DEFAULT '0',
  `coinpayments` int(1) NOT NULL DEFAULT '0',
  `redirect` int(1) NOT NULL DEFAULT '0',
  `redirect_site` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'http://localhost.com/',
  `paypal_email` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `skypeapi` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `slider` int(1) NOT NULL DEFAULT '0',
  `subject_forgot` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `bitcoin` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `bitcoin_set` int(1) NOT NULL,
  `logo` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `siteconfig`
--

INSERT INTO `siteconfig` (`id`, `merchant`, `ipnsecret`, `stresser`, `skype`, `http`, `cloudflare`, `iplogger`, `phonegeo`, `fe`, `geolocation`, `support`, `apimanager`, `servers`, `website`, `cloudflare_set`, `bootername_1`, `bootername_2`, `rotation`, `preloader`, `tos`, `site_forgot`, `email_forgot`, `paypal`, `coinpayments`, `redirect`, `redirect_site`, `paypal_email`, `skypeapi`, `slider`, `subject_forgot`, `key`, `bitcoin`, `bitcoin_set`, `logo`) VALUES
(1, 'MERCHANT ID', '7BN86S9K8AOMB', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 0, 'Booter', 'Name', 1, 1, 'T.O.S.', 'http://localhost/', 'admin@localhost.com', 1, 0, 0, 'http://localhost.com/', 'admin@localhost.com', '', 1, 'Reset Password', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `skypeblacklist`
--

CREATE TABLE IF NOT EXISTS `skypeblacklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `skype` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `priority` varchar(50) NOT NULL,
  `department` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `lastreply` varchar(10) NOT NULL,
  `read` int(1) NOT NULL DEFAULT '0',
  `time` int(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  `membership` int(11) NOT NULL,
  `expire` int(11) NOT NULL,
  `status` varchar(1000) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `apikey` varchar(128) NOT NULL,
  `lastip` varchar(20) NOT NULL,
  `lastlogin` int(11) NOT NULL,
  `lastact` int(11) NOT NULL,
  `security_question` varchar(500) NOT NULL DEFAULT '0',
  `answer_question` varchar(500) NOT NULL DEFAULT '0',
  `ip_address` varchar(35) NOT NULL,
  `ip_address_api` varchar(25) NOT NULL,
  `log_redirect` varchar(60) NOT NULL DEFAULT 'http://google.com',
  `code_account` varchar(5) NOT NULL DEFAULT '0',
  `code` varchar(15) NOT NULL DEFAULT '0',
  `reset` varchar(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
