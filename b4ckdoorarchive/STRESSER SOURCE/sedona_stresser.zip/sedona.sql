-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 14, 2013 at 04:29 PM
-- Server version: 5.1.68-cll
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aptcode_legend`
--

-- --------------------------------------------------------

--
-- Table structure for table `attacks`
--

CREATE TABLE IF NOT EXISTS `attacks` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `port` int(8) NOT NULL,
  `time` int(10) NOT NULL,
  `method` varchar(255) NOT NULL,
  `uid` bigint(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `live_chat`
--

CREATE TABLE IF NOT EXISTS `live_chat` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` bigint(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `suid` bigint(255) NOT NULL,
  `ruid` bigint(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_read` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `read` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `length` varchar(255) NOT NULL,
  `max_attack_time` int(255) NOT NULL,
  `max_concurrent` int(255) NOT NULL,
  `res_skype` int(1) NOT NULL,
  `res_cf` int(1) NOT NULL,
  `res_tiny` int(1) NOT NULL,
  `res_steam` int(1) NOT NULL,
  `xbl_check` int(1) NOT NULL,
  `price` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pub_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payment-errors`
--

CREATE TABLE IF NOT EXISTS `payment-errors` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `data` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `payment-return-logs`
--

CREATE TABLE IF NOT EXISTS `payment-return-logs` (
  `id` bigint(255) NOT NULL,
  `data` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `trans_id` varchar(255) NOT NULL,
  `pay_email` varchar(255) NOT NULL,
  `uid` bigint(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `pid` bigint(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `custom_uri` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_attack` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `uid` bigint(255) NOT NULL,
  `unique` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `uid`, `unique`, `date`) VALUES
(20, 17, '505cbe6cec74b8ad462dca5604522e00', '2013-05-12 22:33:55'),
(19, 17, '1a84b5b858518e1ed8fddad6be1968e8', '2013-05-12 22:28:54'),
(18, 15, '9c28a4aef3ee93aebec1733df9e66ff4', '2013-05-12 22:25:42'),
(17, 15, '7a09bb66433959bf9ec3ac1879562efd', '2013-05-12 22:24:01'),
(16, 1, '63519f62107d24dfcea6b2038cd16200', '2013-05-11 01:37:55'),
(15, 1, '3c673bebf28301ece77e9bc498bd1b0d', '2013-05-11 01:32:07'),
(14, 16, '3bb2aac7696882115a9791c201cb39ee', '2013-05-11 01:24:03'),
(13, 15, 'd5e0ff5d053c8643ec75c4497142410c', '2013-05-11 00:12:59'),
(12, 15, '461fdd42c4d9e6779f5fe1b0c48e6e50', '2013-05-10 20:56:02'),
(11, 1, '8543a931b93cb0ad9f2092ae67ad4e07', '2013-05-10 20:44:48'),
(21, 17, '30dda8069976cbf48d79bab7131530e0', '2013-05-12 22:34:12'),
(22, 17, '4a0308e82830190ab127c8f0e26a1728', '2013-05-12 22:36:20'),
(23, 15, 'd3664c4c7230b6e353b7de1eba0dd616', '2013-05-12 22:38:39'),
(24, 15, '6e5a249a81931528e76b8ba91bd78253', '2013-05-12 22:40:18'),
(25, 15, 'e7b90600320826a9b2e52c2b5a5b17a0', '2013-05-12 22:40:50'),
(26, 1, 'ec10a36230aa9b92197f65d870c6edcd', '2013-05-12 22:41:11'),
(27, 1, '763638e1a7d2476ae0c87826b8a96fa7', '2013-05-12 22:47:01'),
(28, 1, '1eccfd3d7ff26b3e781e1d4f5d8998a6', '2013-05-12 22:48:23'),
(29, 15, 'bf2b6c4c5d1ae0a6a73146ad6fb442bb', '2013-05-12 23:25:54'),
(30, 1, '938bb0aafff7aec1280dd3e2beaf8c87', '2013-05-12 23:28:22'),
(31, 15, 'df851373176aeea13762206f0452cad2', '2013-05-12 23:28:39'),
(32, 18, 'e3c48c798fbf6b4079a44c27f891b76c', '2013-05-12 23:32:49'),
(33, 18, '16b7d7685b9471a35bc7c6902a37aeb3', '2013-05-12 23:39:38'),
(34, 15, 'd6b0dc0981680621dd5b90d0bbd690d4', '2013-05-12 23:39:59'),
(35, 17, '45f2b51adccbf466bccac9df668b80e6', '2013-05-12 23:40:01'),
(36, 15, '7a99a4d571a06f2a4a9fbd026ed959b3', '2013-05-13 00:17:19'),
(37, 18, '2d8f5eba36f67a5c530c143a4d6c1757', '2013-05-13 00:17:29'),
(38, 15, 'b9a9b5f46a0300faf495cd935350e1ba', '2013-05-13 00:17:44'),
(39, 18, '3e48d4d74568ec1fd81b526f40f783c6', '2013-05-13 00:18:05'),
(40, 15, 'bb2661f5803ebf3388ffd84b38fe94a0', '2013-05-13 00:18:20'),
(41, 1, 'd649a58bd1c70b9654ec7f13db8c7326', '2013-05-13 00:52:16'),
(42, 19, '6c43bb71e9a61d6dc1fac1d09ce42b52', '2013-05-13 01:54:13'),
(43, 1, 'cccfdf76730720bbd85d7ae9c0b2c314', '2013-05-13 01:55:07'),
(44, 15, '4fadf1b5ed0b75953ab1ea18d100646b', '2013-05-13 01:55:58'),
(45, 15, 'a27835bf2e728486a2233edb9021b936', '2013-05-13 02:05:17'),
(46, 15, '62e54a9410d55d9ea1da9e6d3d11efac', '2013-05-13 02:33:08'),
(47, 17, '1143f06b2cf060d825930b02796e5d5c', '2013-05-13 06:03:58'),
(48, 17, '3e6e13b409185b34147f001538db82fd', '2013-05-13 09:40:42'),
(49, 17, '95284aa5a8c2fbd9cb35579346c156e2', '2013-05-13 20:43:58'),
(50, 17, '5f9ca6b8a27fc3660571e438c9697244', '2013-05-14 00:25:13'),
(51, 20, '1f84e71ed0c60596f0d28266778835c6', '2013-05-14 00:29:05'),
(52, 17, '3b07ec0de48da492a793a863cf19cc8c', '2013-05-14 00:29:24'),
(53, 17, '084d02854578970d8309a6077e4de516', '2013-05-14 03:00:06'),
(54, 17, 'b23f0029132cf5dbd4ae66359188a81a', '2013-05-14 03:00:22'),
(55, 17, '4ed801dbb484cf69828cafee665a1f17', '2013-05-14 09:48:54'),
(56, 17, 'b8dda50114128625687d28c87873c48e', '2013-05-14 11:25:11'),
(57, 17, '75ebb97f557f869056b152111b5b38e1', '2013-05-14 11:26:00'),
(58, 17, '09e176a8e9eb98ed114a2dea1db3d0e8', '2013-05-14 19:53:05'),
(59, 20, '9ef5c0b1c6dc5e2ae02f99a4e84406d1', '2013-05-14 19:53:35'),
(60, 17, '4c023440e5d12af956635a4e8d287bc7', '2013-05-14 19:55:31'),
(61, 17, 'fdccbffd4321a53cd1c0e23557d0f631', '2013-05-14 20:17:33'),
(62, 17, '5fc4a0eaa75d6cebbba4842fb2604c82', '2013-05-14 20:18:10'),
(63, 17, 'a2ce0205f5bed2788d6e3baed5154477', '2013-05-14 20:18:30'),
(64, 20, '0a96a07e978942267d68a8374bf58ec7', '2013-05-14 20:18:50'),
(65, 17, '07f417418f6be4fa94d935ad57a9dbd2', '2013-05-14 20:20:10'),
(66, 20, '826d00df361d31309820dd17b84adff3', '2013-05-14 20:21:32'),
(67, 17, '4ee3ce8c74b732d1e561eecf6e9b29a5', '2013-05-14 20:35:34'),
(68, 20, 'babe9aafc9ba71dda7189f825f3c0aad', '2013-05-14 20:36:25'),
(69, 21, '00c4679f4bd4b4eee40122e0606c554d', '2013-05-14 20:36:55'),
(70, 17, 'b447f5d548915af6dc3568ae77591020', '2013-05-14 20:55:02'),
(71, 17, '0eee17a93a025a71f455d0ca72d320f5', '2013-05-14 21:49:55'),
(72, 1, '93965b24dce0fd3180850a82bb0cae2b', '2013-05-14 22:00:30'),
(73, 3, 'a90f04590c62063793adcd7179cd7785', '2013-05-14 22:24:07'),
(74, 3, '53b71f622f335b04148bbb2931ced223', '2013-05-14 22:25:05');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `group` bigint(255) NOT NULL,
  `ident` varchar(255) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `group`, `ident`, `val`) VALUES
(1, 0, 'default-uri', '/scriptdir/attack.sh'),
(2, 0, 'paypal-email', 'main@aptcode.net'),
(3, 0, 'skype-api-url', 'legelnd.com/asdpaisd');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `priority` int(2) NOT NULL,
  `open` int(1) NOT NULL DEFAULT '1',
  `update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tickets_reply`
--

CREATE TABLE IF NOT EXISTS `tickets_reply` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `tid` bigint(255) NOT NULL,
  `uid` bigint(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tos`
--

CREATE TABLE IF NOT EXISTS `tos` (
  `tos` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tos`
--

INSERT INTO `tos` (`tos`) VALUES
('This is the default Terms of Service message! You may edit this to how ever you would like!');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `reg-date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last-login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reg-ip` varchar(255) NOT NULL,
  `last-ip` varchar(255) NOT NULL,
  `pay_email` varchar(255) NOT NULL,
  `trans_id` varchar(255) NOT NULL,
  `package` bigint(255) NOT NULL,
  `level` bigint(255) NOT NULL DEFAULT '0',
  `salt` varchar(255) NOT NULL,
  `expiry` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
