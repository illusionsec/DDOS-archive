<?php
require_once('global.php');
require($conf['pages']['header'] . 'header.php');
include_once($page->read());
include_once($conf['pages']['index'] . 'footer.php');
?>