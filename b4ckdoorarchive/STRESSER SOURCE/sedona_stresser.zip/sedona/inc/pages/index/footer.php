<!-- JS -->
<script src="js/jquery.js"></script> <!-- jQuery -->
<script src="js/funcs.js"></script> <!-- jQuery -->
<script src="js/bootstrap.js"></script> <!-- Bootstrap -->
<script src="js/jquery-ui-1.10.2.custom.min.js"></script> <!-- jQuery UI -->
<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
<script src="js/jquery.rateit.min.js"></script> <!-- RateIt - Star rating -->
<script src="js/jquery.prettyPhoto.js"></script> <!-- prettyPhoto -->

<!-- jQuery Flot -->
<script src="js/excanvas.min.js"></script>
<script src="js/jquery.flot.js"></script>
<script src="js/jquery.flot.resize.js"></script>
<script src="js/jquery.flot.pie.js"></script>
<script src="js/jquery.flot.stack.js"></script>

<script src="js/sparklines.js"></script> <!-- Sparklines -->
<script src="js/jquery.cleditor.min.js"></script> <!-- CLEditor -->
<script src="js/bootstrap-datetimepicker.min.js"></script> <!-- Date picker -->
<script src="js/jquery.toggle.buttons.js"></script> <!-- Bootstrap Toggle -->
<script src="js/filter.js"></script> <!-- Filter for support page -->
<script src="js/custom.js"></script> <!-- Custom codes -->
<script src="js/charts.js"></script> <!-- Custom chart codes -->

<script type="text/javascript">
  $(function() {
    $( "#master2" ).slider({
      value:15,
      min: 0,
      max: <?php if($uinfo['level'] != 5) { echo $users->pack_info($uinfo['package'])['max_attack_time']; } else { echo 1000; } ?>,
      step: 1,
      slide: function( event, ui ) {
        $( "#amount" ).html( ui.value + ' sec' );
      }
    });
    $( "#amount" ).html( $( "#master2" ).slider( "value" ) + ' sec' );
  });
  </script>
  <script>run_live_chat(0);</script>