<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
$uinfo = $users->info_id($_SESSION['id']);
?>
<title><?php echo $conf['name']; ?> - Account Profile of <?php echo $uinfo['username']; ?></title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Account</h2>
	</div>
	<div class="matter">
		<div class="container-fluid">
			<table class="table table-bordered span5">
				<h3>Account Info</h3>
				<tr>
					<td>Package:</td>
					<td>
						<?php
							echo '<strong>'.$users->getPackName($uinfo['package']).'</strong>';
						?>
					</td>
					<tr>
						<td>Level:</td>
						<td><?php echo $core->int_level($uinfo['level']); ?></td>
					</tr>
					<tr>
						<td>PayPal Email:</td>
						<td><?php echo $uinfo['pay_email']; ?></td>
					</tr>
				</tr>
			</table>
		</div><br>
		<div class="container-fluid">
			<table class="table table-bordered span5">
				<h3>Change Password</h3>
				<tr>
					<td><input type="password" placeholder="New Password" style="height:35px;" id="chpass_1"></td>
				</tr>
				<tr>
					<td><input type="password" placeholder="New Password (Again)" style="height:35px;" id="chpass_2"></td>
				</tr>
				<tr>
					<td><input type="submit" value="Change" onclick="chpass($(this));" data-loading-text="Working..." id="chpass_sub" class="btn btn-success"></td>
				</tr>
			</table>
		</div>
	</div>
</div>