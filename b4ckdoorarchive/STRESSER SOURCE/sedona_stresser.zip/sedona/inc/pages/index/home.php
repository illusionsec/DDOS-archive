<?php

?>
<title><?php echo $conf['name']; ?> - Home</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Welcome back <i><?php echo $users->info_id($_SESSION['id'])['username']; ?></i>!</h2>
	</div>
	<div class="matter">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					<ul class="today-datas">
						<li class="bblue">
							<div class="pull-left">
								<i class="icon-signal"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->total_attacks(); ?></span>
								Total Attacks
							</div>
							<div class="clearfix"></div>
							
						</li>
						<li class="bgreen">
							<div class="pull-left">
								<i class="icon-group"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $users->total_users(); ?></span>
								Total Users
							</div>
							<div class="clearfix"></div>
							
						</li>
						<li class="bred">
							<div class="pull-left">
								<i class="icon-upload"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->total_servs() + $core->total_servs('offline'); ?></span>
								Total Servers
							</div>
							<div class="clearfix"></div>
							
						</li>
					</ul>
				</div>
			</div>
			<br><br>
			
			<div class="widget wblue span9">
				<div class="widget-head">
					<div class="pull-left">Instant Messaging</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-hover" id="live_chat_area">
						
					</table>
					<?php if($uinfo['level'] == 5) { ?>
					<table class="table">
						<tr>
							<td><input type="text" style="height: 35px; width: 100%" placeholder="Send Message" id="live_chat_msg"></td>
						</tr>
					</table> <?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>