<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
if($uinfo['level'] < 2) {
	$users->redirect('index.php');
	die();
}
?>
<title><?php echo $conf['name']; ?> - Hub</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Hub <small>Launch attacks</small></h2>
	</div>
	<div class="matter">
		<div class="container-fluid">
			<div class="widget wblue span9">
				<div class="widget-head">
					<div class="pull-left">Find your Target</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-bordered">
						<tr>
							<td>Host to IP:</td>
							<td><input type="text" style="height: 35px;" id="host2IP" placeholder="Host or IP"></td>
							<td><input type="submit" class="btn btn-inverse" onclick="h2ip($('#host2IP').val(), $('#host2IP'), $(this));" data-loading-text="Resolving..." value="Resolve"></td>
						</tr>
						<tr style="display:none;" id="outputTr">
							<td></td>
							<td id="hostOutput"></td>
							<td></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="clearfix"></div>
			<br>
			<div class="widget wgreen span9">
				<div class="widget-head">
					<div class="pull-left">Send Attack</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-bordered">
						<tr>
							<td>IP Address:</td>
							<td><input type="text" style="height: 35px;" id="hubIP" placeholder="<?php echo $_SERVER['HTTP_CF_CONNECTING_IP']; ?>"> <i class="icon-exclamation-sign" id="hosterror" style="display:none; color: red;"></i></td><td></td>
						</tr>
						<tr>
							<td>Port:</td>
							<td><input type="number" style="height: 35px;" id="hubPort" min="0" placeholder="80"></td><td></td>
						</tr>
						<tr>
							<td>Time:</td>
							<td><div id="master2" class="slider-blue ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" aria-disabled="false"></div></td>
							<td id="amount" style="text-align: center;"></td>
						</tr>
						<tr>
							<td>Method:</td>
							<td>
								<select id="hubMethod">
									<option value="udp">UDP</option>
									<option value="ssyn">SSYN</option>
									<option value="http">HTTP</option>
								</select>
							</td>
						</tr>
						<tr>
							<td></td>
							<td>
								<button type="button" class="btn btn-success btn-large" onclick="send_attack($(this));"><i class="icon-arrow-right"></i> Send Attack</button>
								<span style="display: none; color: red;" id="finalout"></span>
							</td>
							<td></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>