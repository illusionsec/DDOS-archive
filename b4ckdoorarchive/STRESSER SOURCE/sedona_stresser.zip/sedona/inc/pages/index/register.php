<?php
if($_SESSION['id']) {
	$users->redirect('index.php');
}
?>
<title><?php echo $conf['name']; ?> - Register</title>
<div class="mainbar">
	<h2 class="page-head">Register <small>Create an account at <?php echo $conf['name']; ?></small></h2>
	<div class="matter">
		<div class="admin-form">
			<div class="container-fluid">
				<div class="row-fluid">
					<div style="width: 150%; margin-left: -25%;">
						<div class="widget wblue">
							<div class="widget-head"><i class="icon-plus-sign"></i> Register Account</i></div>
							<div class="widget-content">
								<div id="show_reg_success" class="alert alert-success" style="display: none;"><center>Registration success! Redirecting...</center></div>
								<div class="padd">
									<table class="table">
										<tr>
											<td>Username:</td>
											<td><input type="text" name="newacct_uname" id="newacct_uname" placeholder="Username" style="height: 35px;"> <span id="uerror" style="display:none;"><i class="icon-exclamation-sign"></i></span></td>
										</tr>
										<tr>
											<td>Password:</td>
											<td id="p1" style="width: 55%;"><input type="password" name="newacct_pass" id="newacct_pass" placeholder="Password" style="height: 35px;"> <span id="perror" style="display:none;"><i class="icon-exclamation-sign"></i></span></td>
										</tr>
										<tr>
											<td>Password (again):</td>
											<td id="p2"><input type="password" name="newacct_pass2" id="newacct_pass2" placeholder="Password (again)" style="height: 35px;"> <span id="p2error" style="display:none;"><i class="icon-exclamation-sign"></i></span></td>
										</tr>
										<tr>
											<td>Email Address:</td>
											<td><input type="text" name="newacct_email" id="newacct_email" placeholder="Email Address" style="height: 35px;"> <span id="eerror" style="display:none;"><i class="icon-exclamation-sign"></i></span></td>
										</tr>
										<tr>
											<td>Email Address (again):</td>
											<td><input type="text" name="newacct_email2" id="newacct_email2" placeholder="Email Address (again)" style="height: 35px;"> <span id="e2error" style="display:none;"><i class="icon-exclamation-sign"></i></span></td>
										</tr>
										<tr>
											<td></td>
											<td><input type="submit" class="btn btn-primary" onclick="register();" value="Create Account" name="newacct_submit" data-loading-text="Registering..." id="newacct_submit"></td>
										</tr>
									</table>
								</div>
							</div>
							<div class="widget-foot">
								Already have an account? <a href="index.php?page=login">Login</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>