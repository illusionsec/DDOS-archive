<?php
if ($_POST['geolocate']) {
	$ip = $_POST['geolocateip'];
	if (empty($ip)) {
		$show = 1;
	} elseif (!filter_var($ip, FILTER_VALIDATE_IP)) {
		$show = 1;
	} else {
		$json = file_get_contents("http://freegeoip.net/json/$ip");
		$info = json_decode($json);
		$show = 2;
	}
}
?>
<html>
	<head>
		<title>Geolocation</title>
	</head>
	<body>
		<div class="mainbar">
			<div class="container-fluid">
				<h2 class="page-header">Geolocator <small>Find information about an IP Address!</small></h2>
			</div>
			<div class="container-fluid">
			<?php
			switch ($show) {
				case 1:
					echo '<div class="alert alert-error">An error has occurred! Please check your form input and try again!</div>';
					break;
				case 2:
					?>
					<table class="table table-striped">
						<tr>
							<td>IP Address</td>
							<td><strong><?php echo $info->{"ip"}; ?></strong></td>
						</tr>
						<tr>
							<td>Country Name</td>
							<td><strong><?php echo $info->{"country_name"}; ?></strong></td>
						</tr>
						<tr>
							<td>Region Name</td>
							<td><strong><?php echo $info->{"region_name"}; ?></strong></td>
						</tr>
						<tr>
							<td>City</td>
							<td><strong><?php echo $info->{"city"}; ?></strong></td>
						</tr>
						<tr>
							<td>Zipcode</td>
							<td><strong><?php echo $info->{"zipcode"}; ?></strong></td>
						</tr>
						<tr>
							<td>Areacode</td>
							<td><strong><?php echo $info->{"areacode"}; ?></strong></td>
						</tr>		
					</table>
					<?php
					break;
			}
			?>
				<form action="" method="POST">
					<table class="table">
						<tr>
							<td>IP Address</td>
							<td><input type="text" name="geolocateip" style="height: 30px;"></td>
						</tr>
						<tr>
							<td></td>
							<td><input type="submit" name="geolocate" class="btn btn-success" value="Geolocate"></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</body>
</html>