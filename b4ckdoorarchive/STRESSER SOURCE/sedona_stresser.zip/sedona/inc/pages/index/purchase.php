<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
// my code stuff brings all the booters to the yard
$p1 = $core->total_packs();
$p2 = $p1 / 2; // get first half the amount
$p2 = round($p2, 0, PHP_ROUND_HALF_UP); // round up... always...
$p3 = $p1 - $p2; // last half
if($uinfo['level'] >= 2) {
	$users->redirect('index.php');
	die();
}

?>
<div class="mainbar">
	<h2 class="page-head">Purchase <small>Buy an account plan</small></h2>
	<div class="matter">
		<div class="pull-left">
			<div class="container-fluid">
				<?php
					$q = $dbc->query("SELECT * FROM `packages` LIMIT $p2, $p3");
					while($row = $dbc->fetch_array($q)) {
						?>
							<div class="widget wblue span4">
								<div class="widget-head"><?php echo $row['name']; ?></div>
								<div class="widget-content">
									<table class="table">
										<tr>
											<td>Max. Attack Time:</td>
											<td><?php echo $row['max_attack_time']; ?> sec(s)</td>
										</tr>
										<tr>
											<td>Max. Concurrent Attacks:</td>
											<td><?php echo $row['max_concurrent']; ?></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_skype']); ?> disabled">Skype</button></td>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_cf']); ?> disabled">CloudFlare</button></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_tiny']); ?> disabled">TinyChat</button></td>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_steam']); ?> disabled">Steam</button></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['xbl_check']); ?> disabled">Xbox Checker</button></td>
											<td></td>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td><?php echo nl2br($row['pub_desc']); ?></td>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td>Price:</td>
											<td>$<?php echo $row['price']; ?> every <?php echo $row['length']; ?></td>
										</tr>
										<tr>
											<td></td>
											<td>
												<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
													<input type="hidden" name="cmd" value="_xclick">
													<input type="hidden" name="business" value="TCYTJHA6BU2EQ"><!-- #CHANGEME# -->
													<input type="hidden" name="lc" value="US">
													<input type="hidden" name="currency_code" value="USD">
													<input type="hidden" name="button_subtype" value="gift">
													<input type="hidden" name="no_shipping" value="1">
													<input type="hidden" name="rm" value="1">
													<input type="hidden" name="item_number" value="<?php echo $_SESSION['id']; ?>">
													<input type="hidden" name="item_name" value="<?php echo $row['id']; ?>">
													<input type="hidden" name="amount" value="<?php echo $row['price']; ?>">
													<input type="submit" class="btn btn-success" value="Purchase">
												</form>
											</td>
										</tr>
									</table>
								</div>
							</div>
						<?php
					}
				?>
			</div>
		</div>
		
		<div class="pull-left">
			<div class="container-fluid">
				<?php
					$q = $dbc->query("SELECT * FROM `packages` LIMIT 0, $p2");
					while($row = $dbc->fetch_array($q)) {
						?>
							<div class="widget wblue span4">
								<div class="widget-head"><?php echo $row['name']; ?></div>
								<div class="widget-content">
									<table class="table">
										<tr>
											<td>Max. Attack Time:</td>
											<td><?php echo $row['max_attack_time']; ?> sec(s)</td>
										</tr>
										<tr>
											<td>Max. Concurrent Attacks:</td>
											<td><?php echo $row['max_concurrent']; ?></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_skype']); ?> disabled">Skype</button></td>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_cf']); ?> disabled">CloudFlare</button></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_tiny']); ?> disabled">TinyChat</button></td>
											<td><button class="btn btn-<?php echo $core->int_res($row['res_steam']); ?> disabled">Steam</button></td>
										</tr>
										<tr>
											<td><button class="btn btn-<?php echo $core->int_res($row['xbl_check']); ?> disabled">Xbox Checker</button></td>
											<td></td>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td><?php echo nl2br($row['pub_desc']); ?></td>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td>Price:</td>
											<td>$<?php echo $row['price']; ?> every <?php echo $row['length']; ?></td>
										</tr>
										<tr>
											<td></td>
											<td>
												<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
													<input type="hidden" name="cmd" value="_xclick">
													<input type="hidden" name="business" value="TCYTJHA6BU2EQ"><!-- #CHANGEME# -->
													<input type="hidden" name="lc" value="US">
													<input type="hidden" name="currency_code" value="USD">
													<input type="hidden" name="button_subtype" value="gift">
													<input type="hidden" name="no_shipping" value="1">
													<input type="hidden" name="rm" value="1">
													<input type="hidden" name="item_number" value="<?php echo $_SESSION['id']; ?>">
													<input type="hidden" name="item_name" value="<?php echo $row['id']; ?>">
													<input type="hidden" name="amount" value="<?php echo $row['price']; ?>">
													<input type="submit" class="btn btn-success" value="Purchase">
												</form>
											</td>
										</tr>
									</table>
								</div>
							</div>
						<?php
					}
				?>
			</div>
		</div>
	</div>
</div>