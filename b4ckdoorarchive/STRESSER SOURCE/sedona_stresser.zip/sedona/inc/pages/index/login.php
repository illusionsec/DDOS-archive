<?php

?>
<title><?php echo $conf['name']; ?> - Login</title>
<div class="mainbar">
	<h2 class="page-head">Login <small>Login to your account</small></h2>
	<div class="matter">
		<div class="admin-form">
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<div class="widget wblue">
							<div class="widget-head"><i class="icon-lock"></i> Login</i></div>
							<div class="widget-content">
								<div class="padd">
									<form class="form-horizontal" id="loginForm">
										<div class="control-group">
											<label class="control-label" for="loginUser">Username</label>
											<div class="controls">
												<input type="text" id="loginUser" style="height: 30px;" placeholder="Username">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="loginPass">Password</label>
											<div class="controls">
												<input type="password" id="loginPass" style="height: 30px;" placeholder="Password">
											</div>
										</div>
										<div class="control-group">
											<div class="controls">
												<button type="button" id="loginsub" onclick="login();" class="btn btn-primary" data-loading-text="Logging in...">Login</button>
											</div>
										</div>
										<center>
											<div id="loginOutput"></div>
										</center>
									</form>
								</div>
							</div>
							<div class="widget-foot">
								Need an account? <a href="index.php?page=register">Register</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>