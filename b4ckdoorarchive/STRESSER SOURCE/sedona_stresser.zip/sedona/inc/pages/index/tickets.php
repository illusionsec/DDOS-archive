<?php
/*
	Ticket Module (http://aptcode.net)
*/
if(!defined('LEGENDARY')) {
	die('Access Denied');
}

if ($_POST['submitTicket']) {
	$ticketSubject = $_POST['subject'];
	$ticketContent = $_POST['ticket'];
	$ticketPriority = $_POST['priority'];
	switch ($ticketPriority) {
		case 1:
			$ticketPriority = 1;
			break;
		case 2:
			$ticketPriority = 2;
			break;
		case 3:
			$ticketPriority = 3;
			break;
		case 4:
			$ticketPriority = 4;
			break;
	}
	if (empty($ticketSubject) || empty($ticketContent)) {
		$display = 1;
	} else {
		$tickets->createNew($ticketSubject, $ticketContent, $ticketPriority, $_SESSION['id']);
		$display = 2;
	}
}
?>
<html>
	<head>
		<title>Ticket System</title>
	</head>
	<body>
		<div class="mainbar">
			<div class="container-fluid">
				<h2 class="page-header">Ticket System <small>Submit and view tickets!</small></h2>
			</div>
			<div class="container-fluid">
				<!-- MESSAGES -->
				<?php
				switch ($display) {
					case 1:
						echo '<div class="alert alert-danger">Something went wrong! Please check your input and try to submit your ticket again!</div>';
						break;
					case 2:
						echo '<div class="alert alert-success">Your ticket has been submitted! You will receive a response soon!</div>'.$uid;
						break;
				}
				?>
				<!-- TICKET CREATE -->
				<form action="" method="POST">
					<table class="table table-striped">
						<tr>
							<td>Ticket Subject: &nbsp;<input type="text" name="subject" style="height: 30px;" placeholder="Ticket Subject"></td>
						</tr>
						<tr>
							<td>
							Priority: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<select name="priority">
								<option value="1">Low</option>
								<option value="2">Medium</option>
								<option value="3">High</option>
								<option value="4">Critical</option>
							</select>
							</td>
						</tr>
						<tr>
							<td>
								<textarea style="height: 400px;width:98.4%;" name="ticket" placeholder="Your issue/quesiton here"></textarea>
							</td>
						</tr>
						<tr>
							<td><input type="submit" name="submitTicket" class="btn btn-success" value="Submit Ticket"></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</body>
</html>