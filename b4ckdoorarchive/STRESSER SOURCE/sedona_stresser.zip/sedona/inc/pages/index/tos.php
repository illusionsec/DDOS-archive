<?php

?>
<title><?php echo $conf['name']; ?> Terms of Service</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Terms of Service <small>The legal stuff.</small></h2>
	</div>
	<div class="container-fluid">
		<?php echo nl2br($tos->getTos()); ?>
	</div>
</div>