<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
if($uinfo['level'] <= 2) {
	$users->redirect('index.php');
	die();
}
?>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Resolvers <small>Multiple ways to find your target</small></h2>
	</div>
	<div class="matter">
		<div class="container-fluid">
			<div class="widget wblue span5">
				<div class="widget-head">
					<div class="pull-left">Skype Resolver</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-bordered">
						<tr>
							<td>Skype Username:</td>
							<td><input type="text" style="height: 35px;" id="skype2IP" placeholder="Skype"></td>
							<td><input type="submit" class="btn btn-inverse" onclick="skype2ip($('#skype2IP').val(), $('#skype2IP'), $(this));" value="Resolve"></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="widget wblue span5">
				<div class="widget-head">
					<div class="pull-left">Cloudflare Resolver</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-bordered">
						<tr>
							<td>Domain:</td>
							<td><input type="text" style="height: 35px;" id="cf2IP" placeholder="Domain"></td>
							<td><input type="submit" class="btn btn-inverse" onclick="cf2ip($('#cf2IP').val(), $('#cf2IP'), $(this));" value="Resolve"></td>
						</tr>
					</table>
				</div>
			</div>
			
			<div class="clearfix"></div>
			<br><br><br>
			
			<div class="widget wblue span10">
				<div class="widget-head">
					<div class="pull-left">Xbox LIVE Checker</div>
					<div class="widget-icons pull-right">
						<a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="widget-content referrer">
					<table class="table table-bordered">
						<tr>
							<td>Gamertag:</td>
							<td><input type="text" style="height: 35px;" id="xblcheck" placeholder="Gamertag"></td>
							<td><input type="submit" class="btn btn-inverse" onclick="xblcheck($('#xblcheck').val(), $('#xblcheck'), $(this));" data-loading-text="Checking..." value="Check"></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>