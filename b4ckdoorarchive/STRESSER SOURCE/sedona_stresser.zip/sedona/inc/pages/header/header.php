<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/global.php');
$uinfo = $users->info_id($_SESSION['id']);
$session->verify();
include_once($conf['themes'] . $theme['this'] . '/headerinclude.php');
include_once($conf['themes'] . $theme['this'] . '/nav.php');
?>