<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
?>
<html>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a href="index.php" class="brand"><?php echo $name['booter']; ?><span class="bold"> <?php echo $set; ?></span></a>
				<ul class="nav pull-right">
					<?php
						if($session->verify() == true) {
							?>
								<li><a href="index.php?page=account"><i class="icon-user"></i> <?php echo $uinfo['username']; ?></a></li>
							<?php
							if($uinfo['level'] == 5) {
								?>
									<li><a href="admin"><i class="icon-off"></i> Admin</a></li>
								<?php
							}
						}
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="content">
		<div class="sidebar">
			<div class="sidebar-dropdown">
				<a href="#">Navigation</a>
			</div>
			<div class="sidebar-inner">
				<?php if($session->verify() == true) { ?>
					<ul class="navi">
						<li class="nblue"><a href="index.php"><i class="icon-th-large"></i> Dashboard</a></li>
						<?php
							if($uinfo['level'] >= 2) {
						?>
								<li class="nblue"><a href="index.php?page=hub"><i class="icon-desktop"></i> Hub</a></li>
								<li class="nblue"><a href="index.php?page=resolvers"><i class="icon-refresh"></i> Resolvers</a></li>
								<li class="nblue"><a href="index.php?page=geo"><i class="icon-globe"></i> Geolocator</a></li>
						<?php
							} else {
								?>
									<li class="nblue"><a href="index.php?page=purchase"><i class="icon-money"></i> Purchase</a></li>
								<?php
							}
						?>
						<li class="nblue"><a href="index.php?page=tos"><i class="icon-list"></i> Terms of Service</a></li>
						<li class="nblue"><a href="index.php?page=tickets"><i class="icon-user"></i> Ticket System</a></li>
						<li class="nred"><a href="index.php?page=logout"><i class="icon-share-alt"></i> Logout</a></li>
						<li><br></li> <li><br></li> <li><br></li> <li><br></li> <li><br></li>
					</ul>
					<ul class="today-datas">
						<li class="bblue" style="width: 85%;">
							<div class="pull-left">
								<i class="icon-globe"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->run_attacks(); ?></span>
								Running Attacks
							</div>
							<div class="clearfix"></div>
						</li>
						<li class="bblue" style="width: 85%;">
							<div class="pull-left">
								<i class="icon-upload"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->total_servs(); ?></span>
								Online Servers
							</div>
							<div class="clearfix"></div>
						</li>
					</ul>
				<?php } else { ?>
					<ul class="navi">
						<li class="nblue"><a href="index.php?page=login"><i class="icon-user"></i> Login</a></li>
						<li class="nblue"><a href="index.php?page=register"><i class="icon-plus"></i> Register</a></li>
						<li class="nblue"><a href="index.php?page=tos"><i class="icon-list"></i> Terms of Service</a></li>
					</ul>
				<?php }?>
			</div>
		</div>
</body>
</html>