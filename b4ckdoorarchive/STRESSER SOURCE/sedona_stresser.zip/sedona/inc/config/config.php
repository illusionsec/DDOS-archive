<?php
/*
	AptCode Inc.
	Global Configuration
	
	Xeon -- 4/7/13
*/

$db['host'] = 'localhost';
$db['user'] = '';
$db['pass'] = '';
$db['name'] = '';


?>