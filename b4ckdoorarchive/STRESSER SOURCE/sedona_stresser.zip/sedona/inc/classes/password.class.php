<?php
/*
	Mario's gay file.
*/
class Password {
	function create($input) {
		$char = 'ABCDEFGHIJKLMOPQRSTUVXWYZabcdefghijklmnopqrstuvwxyz0123456789'; 
		$qc = strlen($char); 
		$qc--;
		$salt = '$6$rounds=5000$'; 
			for($x=1;$x<=13;$x++){ 
				$pos = rand(0,$qc); 
				$salt .= substr($char, $pos,1); 
			}
		$salt .= '$';
		$pass = crypt($input, $salt);
		$data['pass'] = md5(sha1($pass));
		$data['salt'] = $salt;
		return $data;
	}
	function compare($dbpass, $userpass, $salt) {
		$userpass = crypt($userpass, $salt);
		$userpass = md5(sha1($userpass));
		if($dbpass != $userpass) {
			return false;
		} else {
			return true;
		}
	}
}
?>