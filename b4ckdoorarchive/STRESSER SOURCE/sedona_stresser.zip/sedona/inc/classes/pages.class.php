<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/global.php');
class Page {
	function __construct($db, $pages) {
		$this->db = new DB($db);
		$this->pages = $pages;
		$this->user = new User($db);
	}
	
	function read() {
		$cur_page = $_GET['page'];
		return $this->get_page($cur_page);
	}
	function get_page($p) {
		switch($p) {
			default:
				return $this->pages['index'] . '404.php';
				break;
			case 'login':
				return $this->pages['index'] . 'login.php';
				break;
			case 'purchase':
				return $this->pages['index'] . 'purchase.php';
				break;
			case '':
				return $this->pages['index'] . 'home.php';
				break;
			case 'logout':
				session_destroy();
				$this->user->redirect('index.php');
				break;
			case 'hub':
				return $this->pages['index'] . 'hub.php';
				break;
			case 'resolvers':
				return $this->pages['index'] . 'resolvers.php';
				break;
			case 'register':
				return $this->pages['index'] . 'register.php';
				break;
			case 'account':
				return $this->pages['index'] . 'account.php';
				break;
			case 'tos':
				return $this->pages['index'] . 'tos.php';
				break;
			case 'geo':
				return $this->pages['index'] . 'geo.php';
				break;
			case 'tickets':
				return $this->pages['index'] . 'tickets.php';
				break;
		}
	}
}
?>