<?php


class DB {
	function __construct($db) {
		$this->error = new Error();
		$this->mysqli = new mysqli($db['host'], $db['user'], $db['pass'], $db['name']);
		if($this->mysqli->connect_error) {
			$this->error->connect_error();
		}
	}
	function query($i) {
		return $this->mysqli->query($i);
	}
	function fetch_array($i) {
		return $i->fetch_array(MYSQLI_ASSOC);
	}
	function num($i) {
		return $i->num_rows;
	}
}
?>