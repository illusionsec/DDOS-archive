<?php

class Session {
	function __construct($db) {
		$this->error = new Error();
		//$this->users = new User($db);
		$this->db = new DB($db);
		$this->xlog = new xLog($db);
	}
	function redirect($url) {
		die('<script>location.replace("' . $url . '");</script>');
	}
	function verify() {
		$param = $_GET['page'];
		if(!$_SESSION['id']) {
			if($param == 'login' || $param == 'register' || $param == 'tos') {
				// do nothing, at login page
			} else {
				$this->redirect('index.php?page=login');
			}
		} else {
			$csess = $this->db->query("SELECT * FROM `sessions` WHERE `uid`='$_SESSION[id]' ORDER BY `date` DESC LIMIT 1");
			if($this->db->num($csess) == 0) {
				session_start();
				session_destroy();
				return false;
			}
			$csess = $this->db->fetch_array($csess);
			if($csess['unique'] != $_SESSION['unique']) {
				session_start();
				session_destroy();
				return false;
			}
			return true;
		}
	}
	function gen_id($uid) {
		$char = 'ABCDEFGHIJKLMOPQRSTUVXWYZabcdefghijklmnopqrstuvwxyz0123456789'; 
		$qc = strlen($char); 
		$qc--;
		$sid = NULL;
			for($x=1;$x<=13;$x++){ 
				$pos = rand(0,$qc); 
				$sid .= substr($char, $pos,1); 
			}
		$sid = md5($uid . $sid);
		return $sid;
	}
	function exists($type, $val) {
		switch($type) {
			case 'uid':
				$q = "`id`='$val'";
				break;
			case 'username':
				$q = "`username`='$val'";
				break;
			case 'email':
				$q = "`email`='$val'";
				break;
		}
		$q1 = $this->db->query("SELECT * FROM `users` WHERE $q LIMIT 1");
		if($this->db->num($q1) != 0) {
			return true;
		} else {
			return false;
		}
	}
	function create($uid) {
		$uid = $this->xlog->filter($uid);
		// make sure uid exists:
		if($this->exists('uid', $uid) == true) {
			$unique = $this->gen_id($uid);
			$this->db->query("INSERT INTO `sessions` (`uid`, `unique`, `date`) VALUES ('$uid', '$unique', NOW())");
			$_SESSION['id'] = $uid;
			$_SESSION['unique'] = $unique;
			return true;
		} else {
			return false;
		}
	}
}
?>