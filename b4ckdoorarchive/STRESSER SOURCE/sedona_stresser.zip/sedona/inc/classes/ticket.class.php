<?php
class Tickets {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function createNew($subject,$content,$priority,$id) {
		$ip = $_SERVER['REMOTE_ADDR'];
		echo ("INSERT INTO `tickets` (`uid`, `ip`, `date`, `subject`, `message`, `priority`) VALUES ('$id', '$ip', NOW(), '$subject', '$content', '$priority')");
	}
}
?>