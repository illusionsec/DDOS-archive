<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}

class User {
	function __construct($db) {
		$this->db = new DB($db);
		$this->password = new Password();
		$this->session = new Session($db);
	}
	function redirect($url) {
		die('<script>location.replace("' . $url . '");</script>');
	}
	function is_banned($uid) {
		return false;
	}
	function info_id($uid) {
		$uinfo = $this->db->query("SELECT * FROM `users` WHERE `id`='$uid' LIMIT 1");
		return $this->db->fetch_array($uinfo);
	}
	function pack_info($pid) {
		$pinfo = $this->db->query("SELECT * FROM `packages` WHERE `id`='$pid' LIMIT 1");
		return $this->db->fetch_array($pinfo);
	}
	function total_users() {
		return $this->db->num($this->db->query("SELECT * FROM `users`"));
	}
	function total_msg($uid) {
		return $this->db->num($this->db->query("SELECT * FROM `messages`"));
	}
	function exists($type, $val) {
		switch($type) {
			case 'uid':
				$q = "`id`='$val'";
				break;
			case 'username':
				$q = "`username`='$val'";
				break;
			case 'email':
				$q = "`email`='$val'";
				break;
		}
		$q1 = $this->db->query("SELECT * FROM `users` WHERE $q LIMIT 1");
		if($this->db->num($q1) != 0) {
			return true;
		} else {
			return false;
		}
	}
	function exists2($name, $email) {
		$num = $this->db->num($this->db->query("SELECT * FROM `users` WHERE `username`='$name' OR `email`='$email' LIMIT 1"));
		if($num != 0) {
			return true;
		} else {
			return false;
		}
	}
	function login($uname, $pass) {
		// first, get a username:
		$uinfo = $this->db->query("SELECT * FROM `users` WHERE `username`='$uname' LIMIT 1");
		// see if it exists:
		if($this->db->num($uinfo) == 0) {
			return 'user-not-exists';
		} else {
			$uinfo = $this->db->fetch_array($uinfo);
		}
		// get salt and db password:
		$salt = $uinfo['salt'];
		$dbpass = $uinfo['password'];
		//compare them to user's input:
		if($this->password->compare($dbpass, $pass, $salt) == true) {
			// password verified!
		} else {
			return 'pass-auth-failed';
		}
		if($this->is_banned($uinfo['id']) == true) {
			// user is banned D:
			return 'user-banned';
		}
		$this->session->create($uinfo['id']);
		$this->db->query("UPDATE `users` SET `last-login`=NOW()");
		die('user-auth-success');
	}
	function register($user, $email, $pass) {
		$pass = $this->password->create($pass);
		$salt = $pass['salt'];
		$pass = $pass['pass'];
		$this->db->query("INSERT INTO `users` (`username`, `password`, `email`, `reg-date`, `pay_email`, `package`, `level`, `salt`) VALUES ('$user', '$pass', '$email', NOW(), '$email', '0', '1', '$salt')");
	}
	function getPackName($package) {
		$query = $this->db->query("SELECT * FROM packages WHERE id='$package'");
		$returned = $this->db->fetch_array($query);
		return $returned['name'];
	}
	
}
?>