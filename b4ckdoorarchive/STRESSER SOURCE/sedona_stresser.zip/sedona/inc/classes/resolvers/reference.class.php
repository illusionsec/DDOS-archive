<?php

class Host2IP {
	function __construct($db) {
		$this->db = new DB($db);
		$this->core = new Core($db);
	}
	function check_perms($uid) {
		return $this->core->check_perms($uid, 'skype');
		if($this->core->check_perms($uid, 'skype') == true) {
		
		} else { }
		$apilink = $this->db->fetch_array($this->db->query("SELECT * FROM `settings` WHERE `ident`='skype-api-url'"))['val'];
	}
}
?>