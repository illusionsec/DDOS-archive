<?php

class XBChecker {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function get_status($username) {
		$profile = json_decode(file_get_contents('http://www.xboxleaders.com/api/profile.json?gamertag='.$username));
		$profile = $profile->Data;
		if($profile->isOnline == 1) {
			return 'Online';
		} else {
			return 'Offline';
		}
	}
}
?>