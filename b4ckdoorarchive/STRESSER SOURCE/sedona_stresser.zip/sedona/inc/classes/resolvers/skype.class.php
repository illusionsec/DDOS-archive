<?php

class SkypeResolver {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function get_ip($username) {
		$str = $this->skypeurl();
		$str .= $username;
		$output = file_get_contents($str);
		return $output;
	}
	function skypeurl() {
		return $this->db->fetch_array($this->db->query("SELECT * FROM `settings` WHERE `ident`='skype-api-url'"))['val'];
	}
}
?>