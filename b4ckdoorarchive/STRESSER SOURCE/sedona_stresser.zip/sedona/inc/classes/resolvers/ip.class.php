<?php
class IP {
	function __construct($db) {
		$this->db = new DB($db);
		$this->core = new Core($db);		
	}
	function getIp($host) {
		if(empty($host)) {
			return ('Please enter a hostname.');
		} else {
			$ip = gethostbyname($host);
			return $ip;
		}
	}
}

?>