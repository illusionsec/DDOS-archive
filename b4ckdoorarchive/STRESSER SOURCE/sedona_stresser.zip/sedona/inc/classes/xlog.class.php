<?php

class xLog {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function filter($i) {
		$i = str_replace('<', '&lt;', $i);
		$i = str_replace('>', '&rt;', $i);
		$i = addslashes($i);
		return $i;
	}
}
?>