<?php

class Error {
	function __construct() {
		
	}
	function internal_error() {
		die('An internal error has occurred');
	}
	function connect_error() {
		die('MySQLi Connection Error');
	}
}
?>