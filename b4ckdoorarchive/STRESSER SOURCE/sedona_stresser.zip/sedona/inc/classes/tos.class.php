<?php
class Tos {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function getTos() {
		$query = $this->db->query("SELECT * FROM tos");
		$returned = $this->db->fetch_array($query);
		$tos_db = $returned['tos'];
		//$tos_db = nl2br($returned['tos']);
		//return preg_replace('<br />', '&nbsp;', $tos_db);
		return $tos_db;
	}
	function updateTos($tos) {
		$query = $this->db->query("UPDATE tos SET tos='$tos'");
	}
}
?>