<?php
class Tickets {
	function __construct($db) {
		$this->db = new DB($db);
	}
	function createNew($subject, $content, $priority, $id) {
		$ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
		$query = $this->db->query("INSERT INTO `tickets` (`uid`, `ip`, `date`, `subject`, `message`, `priority`) VALUES ('$id', '$ip', NOW(), '$subject', '$content', '$priority')");
	}
}
?>