function login() {
	logins = 1;
	$('#loginsub').button('loading');
	u = $('#loginUser').val();
	p = $('#loginPass').val();
	$.post('js_handler.php', {logins:logins, u:u, p:p}, function(data) {
		if(data == 'empty-field') {
			$('#loginOutput').show();
			$('#loginOutput').html('<div class="alert alert-important"><i class="icon-warning-sign"></i> <span style="color: red;">Please fill in all fields!</span></div>');
			$('#loginsub').button('reset');
			ofade_time($('#loginOutput'), 3000);
		} else if(data == 'invalid-info') {
			$('#loginOutput').show();
			$('#loginOutput').html('<div class="alert alert-important"><i class="icon-warning-sign"></i> <span style="color: red;">Invalid Login!</span></div>');
			$('#loginsub').button('reset');
			ofade_time($('#loginOutput'), 3000);
		} else if(data == 'user-auth-success') {
			$('#loginOutput').show();
			$('#loginOutput').html('<div class="alert alert-success"><i class="icon-ok-sign"></i> <span style="color: green;">Login success! Redirecting...</span></div>');
			$('#loginsub').hide();
			setTimeout(function() {
				location.replace('index.php');
			}, 1500);
		}
	});
}


function ofade_time(item, time) {
	setTimeout(function() {
		item.fadeOut();
	}, time)
}
function create_serv(item) {
	$('#outputwin').hide();
	ip = $('#aservip').val();
	uri = $('#aservuri').val();
	addserv = 1;
	$(item).button('loading');
	$.post('js_handler.php', {ip:ip, uri:uri, addserv:addserv}, function(data) {
		$('#outputwin').slideDown();
		switch(data) {
			case 'empty-field':
				$('#outputwin').html('<span style="color: red;"><i class="icon-warning-sign"></i> IP Required!</span>');
				$(item).button('reset');
				break;
			case 'success':
				location.replace('');
				break;
		}
	});
}
function view_user(uid) {
	$.post('inc/modals/view_user.php', {uid:uid}, function(data) {
		$('#userModal').html(data);
		$('#userModal').modal('show');
	});
}
function save_user(uid) {
	$('#userSub').button('loading');
	pack = $('#userPackage').val();
	level = $('#userLevel').val();
	suser = 1;
	$.post('js_handler.php', {suser:suser, level:level, pack:pack, uid:uid}, function(data) {
		alert(data);
		$('#userSub').button('reset');
	});
}
function alter_setting(sid) {
	ident = $('#setting-ident-' + sid).val();
	val = $('#setting-val-' + sid).val();
	alterset = 1;
	$.post('js_handler.php', {alterset:alterset, ident:ident, val:val, sid:sid}, function(data) {
		location.replace('');
	});
}