<?php
require_once('init.php');
if($uinfo['level'] != 5) {
	$error->internal_error();
}
if($_POST['addserv']) {
	$ip = $xlog->filter($_POST['ip']);
	$uri = $xlog->filter($_POST['uri']);
	if(empty($ip)) {
		die('empty-field');
	}
	$def_uri = $dbc->fetch_array($dbc->query("SELECT * FROM `settings` WHERE `ident`='default-uri' LIMIT 1"))['val'];
	if($uri == NULL) {
		$uri = $def_uri;
	}
	$dbc->query("INSERT INTO `servers` (`ip`, `custom_uri`, `date`, `online`) VALUES ('$ip', '$uri', NOW(), '1')");
	die('success');
}
if($_POST['suser']) {
	$level = $xlog->filter($_POST['level']);
	$pack = $xlog->filter($_POST['pack']);
	$uid = $xlog->filter($_POST['uid']);
	if ($level = 1) { $level = 2; }
	$dbc->query("UPDATE users SET package ='$pack', level='$level' WHERE id ='$uid'");
	sleep(1);
	echo 'Updated user.';
}
if($_POST['alterset']) {
	$ident = $_POST['ident'];
	$val = $_POST['val'];
	$sid = $_POST['sid'];
	if($sid == '' || $ident == '') {
		die();
	}
	if($sid == 'new') {
		$dbc->query("INSERT INTO `settings` (`group`, `ident`, `val`) VALUES ('0', '$ident', '$val');");
	} else {
		$dbc->query("UPDATE `settings` SET `ident`='$ident', `val`='$val' WHERE `id`='$sid' LIMIT 1");
	}
}
?>
