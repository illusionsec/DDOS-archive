<?php
require('init.php');
include_once($conf['admin']['pages'] . 'base.php');
include_once($conf['admin']['pages'] . 'footer.php');
?>