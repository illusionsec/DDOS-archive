<?php

class AdminPage {
	function __construct($db, $pages) {
		$this->db = new DB($db);
		$this->pages = $pages;
		$this->user = new User($db);
	}
	
	function read() {
		$cur_page = $_GET['page'];
		return $this->get_page($cur_page);
	}
	function get_page($p) {
		switch($p) {
			case 'settings':
				return $this->pages . 'settings.php';
				break;
			case 'servers':
				return $this->pages . 'servers.php';
				break;
			case 'packs':
				return $this->pages . 'packages.php';
				break;
			case 'users':
				return $this->pages . 'users.php';
				break;
			case 'settings':
				return $this->pages . 'settings.php';
				break;
			case 'tosconfig':
				return $this->pages . 'tos.php';
				break;
			case 'tickets':
				return $this->pages . 'tickets.php';
				break;
		}
	}
}
?>