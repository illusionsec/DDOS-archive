<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
?>
<html>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a href="index.php" class="brand">AptCode <span class="bold">Admin</span></a>
				<ul class="nav pull-right">
					<?php
						if($session->verify() == true) {
							
							if($uinfo['level'] == 5) {
								?>
									<li><a href="../"><i class="icon-arrow-left"></i> Return</a></li>
								<?php
							}
						}
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="content">
		<div class="sidebar">
			<div class="sidebar-dropdown">
				<a href="#">Navigation</a>
			</div>
			<div class="sidebar-inner">
				<?php if($session->verify() == true) { ?>
					<ul class="navi">
						<li class="nblue"><a href="index.php"><i class="icon-th-large"></i> Dashboard</a></li>
						<li class="nblue"><a href="index.php?page=servers"><i class="icon-desktop"></i> Servers</a></li>
						<li class="nblue"><a href="index.php?page=users"><i class="icon-user"></i> Users</a></li>
						<li class="nblue"><a href="index.php?page=packs"><i class="icon-list"></i> Packages</a></li>
						<li class="nblue"><a href="index.php?page=settings"><i class="icon-cog"></i> Settings</a></li>
						<li class="nblue"><a href="index.php?page=tickets"><i class="icon-file"></i> Tickets</a></li>
						<li class="nblue"><a href="index.php?page=tosconfig"><i class="icon-quote-left"></i> ToS Config</a></li>
						<li><br></li> <li><br></li> <li><br></li> <li><br></li> <li><br></li>
					</ul>
					<ul class="today-datas">
						<li class="bblue" style="width: 85%;">
							<div class="pull-left">
								<i class="icon-globe"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->run_attacks(); ?></span>
								Running Attacks
							</div>
							<div class="clearfix"></div>
						</li>
						<li class="bblue" style="width: 85%;">
							<div class="pull-left">
								<i class="icon-upload"></i>
							</div>
							<div class="datas-text pull-right">
								<span class="bold"><?php echo $core->total_servs(); ?></span>
								Online Servers
							</div>
							<div class="clearfix"></div>
						</li>
					</ul>
				<?php } else { ?>
					<ul class="navi">
						<li class="nblue"><a href="index.php?page=login"><i class="icon-user"></i> Login</a></li>
						<li class="nblue"><a href="index.php?page=purchase"><i class="icon-money"></i> Purchase</a></li>
						<li class="nblue"><a href="index.php?page=tos"><i class="icon-list"></i> Terms of Service</a></li>
					</ul>
				<?php }?>
			</div>
		</div>
</body>
</html>