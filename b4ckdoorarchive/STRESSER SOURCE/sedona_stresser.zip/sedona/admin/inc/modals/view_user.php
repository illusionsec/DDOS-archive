<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/global.php');
$uid = $xlog->filter($_POST['uid']);
$user_info = $users->info_id($uid);
if($users->info_id($_SESSION['id'])['level'] != 5) {
	$error->internal_error();
}
?>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
	<h3 id="myModalLabel">Viewing <?php echo $user_info['username']; ?></h3>
</div>
<div class="modal-body">
	<p>
		<form action="" method="POST">
		<table class="table">
			<tr>
				<td>Package:</td>
				<td><select id="userPackage">
					<option value="<?php echo $user_info['package']; ?>"><?php
						if($user_info['package'] == 0) {
							echo 'None';
						} else {
							echo $users->pack_info($user_info['package'])['name'] . ' ($' . $users->pack_info($user_info['package'])['price'] . ' every ' . $users->pack_info($user_info['package'])['length']. ')';
						}
					?></option>
					<?php
						$q = $dbc->query("SELECT * FROM `packages` ORDER BY `price` ASC");
						while($row = $dbc->fetch_array($q)) {
							?>
								<option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?> ($<?php echo $row['price']; ?> every <?php echo $row['length']; ?>)</option>
							<?php
						}
					?>
				</select></td>
			</tr>
			<tr>
				<td>Level:</td>
				<td><select id="userLevel">
					<option value="2">User</option>
					<option value="0">Banned</option>
					<option value="5">Admin</option>
				</select><br><small>(giving a user a package will activate them)</small></td>
			</tr>
		</table>
	</p>
</div>
<div class="modal-footer">
	<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	<button type="submit" id="userSub" onclick="save_user('<?php echo $user_info['id']; ?>');" data-loading-text="Saving..." class="btn btn-primary">Save changes</button>
</div>
</form>