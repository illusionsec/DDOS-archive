<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
?>
<title><?php echo $conf['name']; ?> Admin - Dashboard</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Dashboard <small>Statistical overview and alerts</small></h2>
	</div>
	<div class="container-fluid" id="admin-alerts">
		<?php
			if($core->total_servs() == 0) {
				?>
					<div class="alert alert-error">
						<b class="bold">Alert:</b>
							You currently have no servers set up! Attacks will not function without any servers. To set up a server, please
							go <a href="index.php?page=servers">here</a>
					</div>
				<?php
			}
			if($core->total_packs() == 0) {
				?>
					<div class="alert alert-error">
						<b class="bold">Alert:</b>
							There are no packages available. Users will not be able to purchase access. To set up a package, please go <a href="index.php?page=packs">here</a>
					</div>
				<?php
			}
			if($core->total_servs('offline') != 0) {
				?>
					<div class="alert alert-error">
						<b class="bold">Alert:</b>
							You have <b class="bold"><?php echo $core->total_servs('offline'); ?></b> server<?php if($core->total_servs('offline') > 1) { echo 's'; } ?>  offline! Go <a href="index.php?page=servers">here</a> to see which ones.
					</div>
				<?php
			}
		?>
		<h3>Tickets Statistics <small><a href="index.php?page=tickets">View Tickets</a></small></h3>
		<table class="table">
			<tr>
				<td>Open: <span class="badge badge-important"><?php echo $core->tickets('open'); ?></span></td>
				<td>Closed: <span class="badge badge-info"><?php echo $core->tickets('closed'); ?></span></td>
				<td>Total: <span class="badge badge-inverse"><?php echo $core->tickets('all'); ?></span></td>
			</tr>
		</table>
	</div><br>
	<?php
		if($dbc->num($dbc->query("SELECT * FROM `payments`")) != 0) {
			?>
				<div class="widget wgreen span9">
					<div class="widget-head">Recent Payments</div>
					<div class="widget-content">
						<table class="table table-hover">
							<?php
								$q = $dbc->query("SELECT * FROM `payments` ORDER BY `date` DESC LIMIT 10");
								while($row = $dbc->fetch_array($q)) {
									?>
										<tr>
											<td><?php echo $row['pay_email']; ?></td>
											<td><?php echo $row['trans_id']; ?></td>
											<td>$ <?php echo $row['amount']; ?></td>
										</tr>
									<?php
								}
							?>
						</table>
					</div>
				</div>
			<?php
		}
	?>
</div>