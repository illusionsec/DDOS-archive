<?php
if(!defined('LEGENDARY_ADMIN')) {
	die('Access Denied');
}
require('header.php');
if($_GET['page']) { include_once($page->read()); } else { include_once($conf['admin']['pages'] . 'dash.php'); }
?>