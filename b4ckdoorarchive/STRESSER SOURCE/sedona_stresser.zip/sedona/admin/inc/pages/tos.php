<?php
if ($_POST['updatetos']) {
	$tos->updateTos($_POST['tos']);
	$messages = 1;
}
?>
<title><?php echo $conf['name']; ?> Admin - ToS Config</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">ToS Config <small>Edit what your Terms of Service says.</small></h2>
	</div>
	<div class="container-fluid">
		<?php
		switch ($messages) {
			case 1:
				?>
					<div class="alert alert-success">Updated ToS Successfully! View it <a href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/index.php?page=tos">here</a></div>
				<?php
				break;
		}
		?>
		<form action="" method="POST">
			<table class="table">
				<tr>
					<td>
						<textarea style="height: 400px;width:98.4%;" name="tos"><?php echo $tos->getTos(); ?></textarea>
					</td>
				</tr>
			</table>
			<input type="submit" class="btn btn-primary" value="Update ToS" name="updatetos" id="updatetos">
		</form>
	</div>
</div>