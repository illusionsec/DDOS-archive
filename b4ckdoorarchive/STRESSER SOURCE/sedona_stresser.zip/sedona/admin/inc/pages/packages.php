<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
if($_GET['action'] == 'add') {
	echo 'test';
} else {

if($_POST['add_pack']) {
	$core->create_package($_POST);
}
if($_POST['delete']) {
	$core->del_pack($_POST['del_pack']);
}
?>
<title><?php echo $conf['name']; ?> Admin - Servers</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Packages <small>View, edit, and add packages</small></h2>
	</div>
	<div class="container-fluid" id="admin-alerts">
		<div class="pull-left">
			<a href="#" onclick="$('#addpackage').slideDown();" class="btn btn-inverse"><i class="icon-plus-sign"></i> Add Package</a>
		</div>
		<div class="clearfix"></div><br>
		<div class="container-fluid" style="display: none;" id="addpackage">
			<div class="widget wblue">
				<div class="widget-head"><i class="icon-plus"></i> Add Package</div>
				<div class="widget-content">
					<table class="table">
					<form action="" method="POST">
						<tr>
							<td>Package Name:</td>
							<td><input type="text" style="height: 35px;" name="pack_name" placeholder="Package Name"></td>
						</tr>
						<tr>
							<td>Package Description:</td>
							<td><textarea name="pack_desc" placeholder="Description" style="height: 100px; width: 90%;"></textarea></td>
						</tr>
						<tr>
							<td>Maximum Attack Time (seconds):</td>
							<td><input type="number" style="height: 35px;" name="pack_maxattack" value=100></td>
						</tr>
						<tr>
							<td>Maximum Concurrent Attacks:</td>
							<td><input type="number" style="height: 35px;" name="pack_maxconc" value=3></td>
						</tr>
						<tr>
							<td>Term:</td>
							<td>
								<input type="number" style="height: 35px; width: 10%;" name="pack_termnum" value=1>
								<select name="pack_term">
									<option value="day">Day</option>
									<option value="month">Month</option>
									<option value="year">Year</option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Price:</td>
							<td><input type="number" style="height: 35px;" name="pack_price" value=5></td>
						</tr>
						<tr>
							<td>
								Skype Resolver: <input type="checkbox" value=1 name="skyperes">
							</td>
							<td>
								CloudFlare Resolver: <input type="checkbox" value=1 name="cfres">
							</td>
						</tr>
						<tr>
							<td>
								TinyChat Resolver: <input type="checkbox" value=1 name="tinyres">
							</td>
							<td>
								Xbox LIVE Checker: <input type="checkbox" value=1 name="xboxres">
							</td>
						</tr>
						<tr>
							<td>
								Steam Resolver: <input type="checkbox" value=1 name="steamres">
							</td><td></td>
						</tr>
						<tr>
							<td></td>
							<td><input type="submit" name="add_pack" value="Create Package" class="btn btn-primary"></td>
						</tr>
					</form>
					</table>
				</div>
			</div>
		</div>
		
		<table class="table table-hover">
			<?php
				$q = $dbc->query("SELECT * FROM `packages`");
				if($dbc->num($q) == 0) {
					echo '<center><h3>No Packages to Display!</h3></center>';
				}
				while($row = $dbc->fetch_array($q)) {
					?>	
						<form action="" method="POST">
						<tr>
							<td><?php echo $row['name']; ?></td>
							<td><i class="icon-time"></i> <?php echo $row['max_attack_time']; ?> sec</td>
							<td>$<?php echo $row['price']; ?> /<?php echo $row['length']; ?></td>
							<input type="hidden" name="del_pack" value="<?php echo $row['id']; ?>">
							<td><input type="submit" class="btn btn-danger" name="delete" value="Remove"></td>
						</tr>
						</form>
					<?php
				}
			?>
		</table>
	</div>
</div>
<?php } ?>