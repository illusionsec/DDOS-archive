<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
?>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Settings <small>Administrative Settings</small></h2>
	</div>
	<div class="matter">
		<div class="container-fluid">
			<b class="bold">* Note:</b> The settings in this area are to be used by advanced users only! Tampering with current settings could cause issues with
			current features. Only alter settings that you know need changed!<br><br>
			<table class="table table-hover">
				<th>Identifier</th>
				<th>Value</th><th></th>
				<?php
					$q = $dbc->query("SELECT * FROM `settings`");
					while($row = $dbc->fetch_array($q)) {
						?>
							<tr>
								<td><input type="text" style="height: 35px;" value="<?php echo $row['ident']; ?>" id="setting-ident-<?php echo $row['id']; ?>"></td>
								<td><input type="text" style="height: 35px;" value="<?php echo $row['val']; ?>" id="setting-val-<?php echo $row['id']; ?>"></td>
								<td><input type="submit" id="alterbtn" onclick="alter_setting('<?php echo $row['id']; ?>'); $(this).button('loading');" class="btn btn-primary" value="Alter" data-loading-text="Working..."></td>
							</tr>
						<?php
					}
				?>
				<tr>
					<td><input type="text" id="setting-ident-new" placeholder="New Setting Identifier" style="height: 35px;"></td>
					<td><input type="text" style="height: 35px;" placeholder="New Setting Value" id="setting-val-new"></td>
					<td><input type="submit" id="alterbtn" onclick="alter_setting('new'); $(this).button('loading');" class="btn btn-primary" value="Create Setting" data-loading-text="Working..."></td>
				</tr>
			</table>
		</div>
	</div>
</div>