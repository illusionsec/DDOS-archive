<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}


?>
<div class="mainbar">
	<h2 class="page-head">Users <small>Manage Users</small></h2>
	<div class="matter">
		<div class="container-fluid">
			<table class="table table-hover">
			<?php
				$q = $dbc->query("SELECT *, DATE_FORMAT(`last-login`, '%b %e, at %r') as ndate FROM `users` ORDER BY `reg-date` ASC");
				while($row = $dbc->fetch_array($q)) {
					?>
						<tr onclick="view_user('<?php echo $row['id']; ?>');">
							<td><?php echo $row['username']; ?></td>
							<td><span class="badge badge-info" rel="tooltip" title="Last Login"><?php echo $row['ndate']; ?></span></td>
							<td>
								<?php
									if($row['level'] == 0) {
										echo '<span class="badge badge-important">Inactive';
									} elseif($row['level'] == 1) {
										echo '<span class="badge badge-default">' . $core->int_level($row['level']);
									} elseif($row['level'] == 2) {
										echo '<span class="badge badge-success">' . $core->int_level($row['level']);
									} elseif($row['level'] >= 5) {
										echo '<span class="badge badge-warning">' . $core->int_level($row['level']);
									}
								?>
								</span>
							</td>
						</tr>
					<?php
				}
			?>
			</table>
		</div>
	</div>
</div>
<div id="userModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	
</div>