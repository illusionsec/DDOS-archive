<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
if($_POST['delete']) {
	$core->del_serv($_POST['del_serv']);
}
?>
<title><?php echo $conf['name']; ?> Admin - Servers</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Servers <small>View, edit, and add servers</small></h2>
	</div>
	<div class="container-fluid" id="admin-alerts">
		<div class="pull-left">
			<a href="#add_servModal" data-toggle="modal" role="button" class="btn btn-inverse"><i class="icon-plus-sign"></i> Add Server</a>
		</div>
		<div class="clearfix"></div><br>
		<table class="table table-hover">
			<?php
				$q = $dbc->query("SELECT *, DATE_FORMAT(date, '%b %e, at %r') as ndate, DATE_FORMAT(last_attack, '%b %e, at $r') as natt FROM `servers`");
				if($dbc->num($q) == 0) {
					echo '<center><h3>No Servers to Display!</h3></center>';
				}
				while($row = $dbc->fetch_array($q)) {
					?>
						<form action="" method="post">
						<tr>
							<td><?php echo $row['ip']; ?></td>
							<td><?php echo $row['custom_uri']; ?></td>
							<td><span class="badge badge-inverse" rel="tooltip" title="Last Attack">
								<?php
									if($row['last_attack'] == 0) {
										echo 'Never';
									} else {
										echo $row['natt'];
									}
								?>
							</span></td>
							<td><span class="badge badge-info" rel="tooltip" title="Date Added">
								<?php
									echo $row['ndate'];
								?>
							</span></td>
							<td>
								<?php
									if($row['online'] == 1) {
										echo '<span class="badge badge-success">Online</span>';
									} else {
										echo '<span class="badge badge-default">Offline</span>';
									}
								?>
							</td>
							<input type="hidden" name="del_serv" value="<?php echo $row['id']; ?>">
							<td><input type="submit" class="btn btn-danger" name="delete"></td>
							</form>
						</tr>
					<?php
				}
			?>
		</table>
		
		<br><br><br>
		<p>
			<b class="bold">Server Guidelines:</b><br>
			This source is designed to accept multiple different attack scripts with multiple different servers. In order
			for attacks to work correctly, it is important that you define the CORRECT custom URI. The hub included in this source
			will interperet URI's on it's own. URI's should be in this
			format:<br><br>
			<b class="bold">/path/to/script/handler.ext?ip={IP}&port={PORT}&time={TIME}&method={METHOD}</b>
		</p>
	</div>
</div>
<div id="add_servModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
			<h3 id="myModalLabel">Add Server</h3>
	  </div>
	  <div class="modal-body">
			<p>
				<table class="table">
					<tr>
						<td>IP/Host:</td>
						<td><input type="text" id="aservip" style="height: 35px;" placeholder="IP/Host"></td>
					</tr>
					<tr>
						<td>Custom URI:</td>
						<td><input type="text" id="aservuri" style="height: 35px;" placeholder="Custom URI"></td>
						<td><small style="font-size: 7pt;">* If not set, default URI will be inserted</small></td>
					</tr>
				</table>
			</p>
	  </div>
	  <div class="modal-footer">
			<div id="outputwin" class="pull-left"></div>
			<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
			<button class="btn btn-primary" data-loading-text="Creating..." onclick="create_serv($(this));">Create Server</button>
	  </div>
</div>