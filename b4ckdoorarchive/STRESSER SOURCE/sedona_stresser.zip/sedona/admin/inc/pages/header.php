<?php
include_once($conf['themes'] . $theme['this'] . '/headerinclude.php');
include_once($conf['themes'] . $theme['this'] . '/nav.php');
?>