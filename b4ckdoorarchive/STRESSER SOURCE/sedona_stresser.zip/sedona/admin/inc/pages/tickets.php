<?php
if(!defined('LEGENDARY')) {
	die('Access Denied');
}
?>
<title><?php echo $conf['name']; ?> Admin - Tickets</title>
<div class="mainbar">
	<div class="container-fluid">
		<h2 class="page-header">Tickets <small>Customer support requests</small></h2>
	</div><br>
	<table class="table table-striped">
		<?php
			$q = $dbc->query("SELECT *, DATE_FORMAT(date, '%b %e, %r') as ndate FROM `tickets` WHERE `open`='1' ORDER BY `date` DESC");
			while($row = $dbc->fetch_array($q)) {
				?>
					<tr>
						<td><?php echo $row['subject']; ?></td>
						<td><?php echo $users->info_id($row['uid'])['username']; ?></td>
						<td><?php echo $row['ndate']; ?></td>
					</tr>
				<?php
			}
			if($dbc->num($q) == 0) {
				echo '<center><h2>No Tickets to Display!</h2></center>';
			}
		?>
	</table>
</div>