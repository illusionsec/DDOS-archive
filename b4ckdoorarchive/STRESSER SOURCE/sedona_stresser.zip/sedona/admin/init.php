<?php
require('../global.php');
define('LEGENDARY_ADMIN', true);
$uinfo = $users->info_id($_SESSION['id']);
$session->verify($_SESSION['id']);
if($uinfo['level'] != 5) {
	$error->internal_error();
}
$conf['admin'] = array(
					'pages' => 'inc/pages/',
					'classes' => 'inc/classes/'
				);
include_once($conf['admin']['classes'] . 'pages.admin.php');
$page = new AdminPage($db, $conf['admin']['pages']);
?>