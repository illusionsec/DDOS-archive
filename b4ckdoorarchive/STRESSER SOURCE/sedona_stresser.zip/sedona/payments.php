<?php
//Original source: https://cms.paypal.com/cms_content/US/en_US/files/developer/IPN_PHP_41.txt
//Modified sample code by Codex-m: http://www.php-developer.org
//License: Refer to license.txt
//Target implementation: Paypal IPN implementation for digital downloads such as ebooks, mp3, etc
//read the post from PayPal system and add 'cmd'
//VERSION 1.0 REVISED ON AUGUST 6, 2012
//TO INCORPORATE SOME PAYPAL IPN CODE UPDATES
//PAYPAL RECOMMENDED IPN CODE FOR PHP VERSION 5.2
//Refer to readme.txt for details
//WORKING DEMO HERE: http://www.php-developer.org/paypal_ipn_demo/
//Use your Paypal Sandbox buyer account to test.

$req = 'cmd=' . urlencode('_notify-validate');

foreach ($_POST as $key => $value) {
	$value = urlencode(stripslashes($value));
	$req .= "&$key=$value";
}
//NEW CODE: using Curl instead of fsockopen
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.paypal.com/cgi-bin/webscr');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: www.paypal.com'));
$res = curl_exec($ch);

//assign posted variables to PHP variables
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$customeripaddress=$_POST['custom'];
$user_id=$_POST['item_number'];
$productname=$_POST['item_name'];
$invoice = $_POST['invoice'];

//Connect to MySQL database
require($_SERVER['DOCUMENT_ROOT'] . '/global.php');
//Check if any error occured
if(curl_errno($ch))
{
//HTTP ERROR occurred
//Log error to database for troubleshooting
$log='http error='.curl_error($ch);
$log = $xlog->filter($log);
$dbc->query("INSERT INTO `payment-return-logs` (`data`, `date`) VALUES ('$log', NOW())");
}
else {
//NO HTTP ERROR OCCURRED, CLEAN
//CHECK IF VERIFIED
if (strcmp ($res, "VERIFIED") == 0) {

//log success to database
$log='Verified IPN Transaction';
$log = $xlog->filter($log);
$dbc->query("INSERT INTO `payment-return-logs` (`data`, `date`) VALUES ('$log', NOW())");

//IPN transaction is VERIFIED
//check that txn_id has not been previously processed
//query the database
$txn_id = $xlog->filter($txn_id);
if (!($fetch = $dbc->fetch_array($dbc->query("SELECT `trans_id` FROM `payments` WHERE `trans_id`='$txn_id'")))) {

//no records found, transaction ID is new
//proceed with the rest of validation
// check that receiver_email is your Primary PayPal email
if ($receiver_email == $dbc->fetch_array($dbc->query("SELECT * FROM `settings` WHERE `ident`='paypal-email'"))['val']) {
$receiver_email = $xlog->filter($receiver_email);
}
else {
die($dbc->query("INSERT INTO `payment-errors` (`data`, `date`) VALUES ('ERROR: Invalid Paypal Seller Email address.', NOW());"));
}

/*check if payment currency is USD
if ($payment_currency=='USD') {
$payment_currency = $xlog->filter($payment_currency);
}
else {
die('ERROR: Incorrect currency');
} */

//check if the payment amount is correct
//retrieve the product price in the MySQL database for the purchased product 
$productname = $xlog->filter($productname);
$result = $dbc->query("SELECT `price` FROM `packages` WHERE `id`='$productname'");
$row = $dbc->fetch_array($result);
$productprice = $row['price'];
if ($payment_amount==$productprice) {
$payment_amount = $xlog->filter($payment_amount);
}
else {
die($dbc->query("INSERT INTO `errors` (`data`, `date`) VALUES ('ERROR: Incorrect payment amount', NOW());"));
}

/*check if the payment_status is Completed
if ($payment_status=='Completed') {
$payment_status = $xlog->filter($payment_status);
}
else {
die(mysql_query("INSERT INTO `errors` (`data`, `date`) VALUES ('ERROR: Payment status not completed -- $payment_status', NOW());"));
} */



//Set download status to incomplete because the user still need to download bought material
$downloadstatus='incomplete';
$downloadstatus = $xlog->filter($downloadstatus);

//run the licensing stuff :P


//Log validated IPN records to MySQL database
$result = $dbc->query("SELECT * FROM `packages` WHERE `id`='$productname'");
$row = $dbc->fetch_array($result);
$dbc->query("INSERT INTO `payments` (`trans_id`, `pay_email`, `uid`, `date`, `status`, `amount`, `currency`, `receiver`, `pid`, `invoice`) VALUES ('$txn_id', '$payer_email', '$user_id', NOW(), '$payment_status', '$payment_amount', '$payment_currency', '$receiver_email', '$productname', '$invoice')");
$exp = strtoupper($row['length']);
$dbc->query("INSERT INTO `payment-errors` (`data`, `date`) VALUES ('UPDATE \`users\` SET \`level\`=\'2\', \`expiry\`=DATE_ADD(NOW(), INTERVAL $exp) WHERE \`id\`=\'$user_id\' LIMIT 1', NOW())");
$dbc->query("UPDATE `users` SET `level`='2', `expiry`=DATE_ADD(NOW(), INTERVAL $exp) WHERE `id`='$user_id' LIMIT 1");

}
else {

//transaction ID already exist in the database
//could not process request
//You can alternatively log this transaction to your database for investigation and monitoring purposes
die('Could not process request-transaction ID already exist');
}
}
else if (strcmp ($res, "INVALID") == 0) {

//Invalid IPN transaction
//You can alternatively log this transaction to your database for troubleshooting purposes
$log='Invalid IPN transaction';
$log = $xlog->filter($log);
$dbc->query("INSERT INTO `payment-return-logs` (`data`, `date`) VALUES ('$log', NOW())");
}
}

//close the connection
curl_close($ch);
?>
