<?php
/*
	AptCode Inc.
*/
$set = 'Stresser'; // Booter or Stresser? <---
$name['booter'] = 'Sedona'; # Dont add "Stresser" or "Booter" to this. That is configured in the above config.
?>