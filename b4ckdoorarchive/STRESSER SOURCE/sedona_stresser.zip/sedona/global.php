<?php
/*
	AptCode has a very large ePenis.
	AptCode Inc.
	Global Configuration
	
	Xeon -- 4/7/13
*/

require('inc/config/config.php');
define('LEGENDARY', true);

session_start();
$conf['pages'] = array(
					'index' => 'inc/pages/index/',
					'header' => 'inc/pages/header/'
				);
$conf['classes'] = 'inc/classes/';


include_once($conf['classes'] . 'db.class.php');
include_once($conf['classes'] . 'users.class.php');
include_once($conf['classes'] . 'session.class.php');
include_once($conf['classes'] . 'error.class.php');
include_once($conf['classes'] . 'pages.class.php');
include_once($conf['classes'] . 'password.class.php');
include_once($conf['classes'] . 'xlog.class.php');
include_once($conf['classes'] . 'core.class.php');
include_once($conf['classes'] . 'tos.class.php');
include_once($conf['classes'] . 'tickets.class.php');

include_once($conf['classes'] . 'resolvers/ip.class.php');
include_once($conf['classes'] . 'resolvers/skype.class.php');
include_once($conf['classes'] . 'resolvers/xbox.class.php');
include_once($conf['classes'] . 'resolvers/cloudflare.api.php');

include_once('config.php');

$dbc = new DB($db);
$users = new User($db);
$session = new Session($db);
$xlog = new xLog($db);
$page = new Page($db, $conf['pages']);
$error = new Error();
$password = new Password();
$core = new Core($db);
$h2ip = new IP($db);
$skype = new SkypeResolver($db);
$xbl = new XBChecker($db);
$cfres = new CloudflareAPI();
$tos = new Tos($db);
$tickets = new Tickets($db);

$conf['themes'] = 'inc/templates/';
$theme['this'] = 'default'; // default theme!

$conf['name'] = 'AptCode Stresser';
$core->check_online();
?>