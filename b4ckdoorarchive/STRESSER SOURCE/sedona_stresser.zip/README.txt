AptCode: http://www.hackforums.net/member.php?action=profile&uid=1797707
mario553: http://www.hackforums.net/member.php?action=profile&uid=1262462

=== TABLE OF CONTENTS ===
-------------------------

() Installation
() Administrator Account
() Configuring Servers
() Configuring Packages
() Configuring Settings
() Guidelines
	- Server Guidelines
	- Settings Guidelines


:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installation:
-------------

- Upload the contents of "Sedona" to your website's document root.
- Edit "config.php" to your liking.
- Edit "inc/config/config.php" with your database information
- Import "sedona.sql" into your database

CONGRATULATIONS! Sedona is now installed on your server! Next Step: Admin Account


Administrator Account:
----------------------

- Feel free to truncate the current users database
- Browse to Sedona on your site, register an account
- Using PHPMyAdmin, go to the `users` table
- Find your account username, and edit the `level` to '5'
- Login to Sedona with your username and password


Configuring Servers:
--------------------

- Navigate to the Sedona Admin Panel "/admin/"
- Click on the "Servers" tab, or the link in the alert on your Admin Dashboard
- Click "Add Server"
- Enter the IP or URL of your server/API (must accept connections on port 80, and have httpd installed)
- Enter the URI of your script (see server guidelines section)
- Click "Create Server"
- Sedona will now check if the server is online and accepting connections


Configuring Packages:
---------------------

- Navigate to the Sedona Admin Panel "/admin/"
- Click on the "Packages" tab, or the link in the alert on your Admin Dashboard
- Click "Add Package"
- Enter the details of your package on the form that scrolls down
- Click "Create Package"


Configuring Settings:
---------------------

- For help, see the settings guidelines section
- Enter a setting identifier, this must not be blank
- Enter a setting value, this may be blank
- Click "Create Setting"
OR IF ALTERING:
- Alter the values you need, click "Alter"


=== GUIDELINES ===
------------------

* Server Guidelines:
--------------------

Sedona uses URI's and hosts to interact with servers. This means that our system is very versatile. You can use
anything from a PHP shell to an API with Sedona. However, the configuration of servers takes some knowledge of how
the script is going to work. When you issue an attack, the script will loop through your servers and add parameters
to the end of your URI. This means that you must enter your URI in the correct format, otherwise the server will be
useless. Please use this format for URI's: handler.ext?ip={IP}&port={PORT}&time={TIME}&method={METHOD}


* Settings Guidelines:
----------------------

Sedona is an extendable source. Using our settings feature, you can create plugins quickly without altering database
schematics or adding/removing tables. Depending on your plugin features, however, you may be required to add or remove
tables. For reading settings, simply fetch the setting value by the identifier from the `settings` database.