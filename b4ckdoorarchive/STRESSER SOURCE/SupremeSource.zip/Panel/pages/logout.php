<?php
ob_start();

unset($_SESSION['username']);
unset($_SESSION['ID']);
session_destroy();
header('location: index.php?page=login');
?>