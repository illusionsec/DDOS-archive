<?php

Autoloader::map(array(
	'IpnListener' =>  Bundle::path('paypal-ipn').'ipnlistener.php'
));