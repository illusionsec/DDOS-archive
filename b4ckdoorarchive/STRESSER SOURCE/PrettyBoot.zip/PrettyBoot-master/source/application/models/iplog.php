<?php
/**
 * User: Rogier
 * Date: 4-3-13
 * Time: 17:01
 *
 */
class IPLog extends Eloquent
{
    public static $timestamps = true;
    public static $table = 'iplogger';

}
