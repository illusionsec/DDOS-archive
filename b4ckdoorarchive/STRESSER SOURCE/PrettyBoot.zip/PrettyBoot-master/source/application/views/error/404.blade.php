@layout('main')


@section('content')
<div style="width:100%; text-align:center;">
<h2>Uh oh...</h2>
    <p>
        Seems like this page doesn't exist.<br />

        <a href="javascript:history.go(-1)">Click here to go back!</a>
    </p>
</div>
@endsection