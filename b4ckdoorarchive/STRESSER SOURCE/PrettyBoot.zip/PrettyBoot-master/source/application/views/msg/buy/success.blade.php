@layout('main')



@section('content')
<h3>Thank you for purchase!</h3>

    <p>
        Your {{ $type }} blacklist has successfully been saved and is now blacklisted from the booter!
    </p>

@endsection