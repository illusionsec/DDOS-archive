<span style="color:#a50000">
    {{ $error }}
</span>