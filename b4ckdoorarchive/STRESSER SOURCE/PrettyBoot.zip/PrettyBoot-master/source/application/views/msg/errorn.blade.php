
<div class="alert alert-danger" style="margin-top:10px;">
    <a class="close" data-dismiss="alert" href="#">&times;</a>

    <div class="pull-left">
        <img src="/img/error.png" style="width:50px; height:50px;">

    </div>
    <div class="pull-left" style="margin-left:20px;">
        <p >
            {{ $error }}
        </p>
    </div>
    <div class="clearfix"></div>
</div>