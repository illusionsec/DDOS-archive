@layout('user')

@section('content')

<div class="alert alert-success">
    {{ $msg }}
</div>

@endsection