#!/usr/bin/python

#   charge./switch's MutiScript
#   for the kiddos
#   contact: charge.#6660
#   website: theswitcharchive.com
#   IG: @switchnets


#import some hacks
import subprocess, time, sys, os # big up rex for reminding me of os.system :hahayes:
# HEY LOOK NO SUBPROCESS CALL REX ARE U HAPPY NOW??????????
os.system('clear') # clear the screen :hahayes:

menu = raw_input("""

    Welcome to charge./switch's MultiScript

    1) Setup, Configure, and Install Qbot
    2) Start AutoScanner
    3) Install and Configure OpenVPN
    4) Setup Anti-DDoS Firewalls
    5) Quit

    Please select an option: """)

if menu == "1":
    time.sleep(1)
    os.system('clear')
    print("")
    print("Downloading Tesla v1.0...")
    time.sleep(1)
    print("")
    os.system('yum install wget -y')
    os.system('wget https://cdn.discordapp.com/attachments/586514958548860958/587977976054939651/Tesla_AutoQbot_v1.0_FAST_AUTOSETUP.zip')
    print("unzipping...")
    os.system('yum install unzip -y')
    os.system('unzip Tesla_AutoQbot_v1.0_FAST_AUTOSETUP.zip')
    os.system('mv Tesla\ AutoQbot\ v1.0\ \(FAST\ AUTOSETUP\)/* /root')
    os.system('rm -rf Tesla_AutoQbot_v1.0_FAST_AUTOSETUP.zip Tesla\ AutoQbot\ v1.0\ \(FAST\ AUTOSETUP\)')
    print("Running Tesla v1.0")
    time.sleep(2)
    os.system('python Tesla\ AutoQbot\ v1.0.py')

if menu == "2":
    time.sleep(1)
    os.system('clear')
    print("")
    print("Downloading AutoScanner")
    time.sleep(1)
    print("")
    os.system('yum install wget -y')
    os.system('wget https://cdn.discordapp.com/attachments/586514958548860958/587975603899203585/AutoScanner.zip')
    print("unzipping")
    os.system('yum install unzip -y')
    os.system('unzip AutoScanner.zip')
    os.system('mv AutoScanner/* /root')
    os.system('rm -rf AutoScanner AutoScanner.zip')
    print("Running AutoScanner")
    time.sleep(2)
    os.system('python AutoScanner.py')

if menu == "3":
    time.sleep(1)
    os.system('clear')
    print("")
    print("Downloading OpenVPN AutoInstaller")
    time.sleep(1)
    print("")
    os.system('yum install wget -y')
    os.system('wget https://cdn.discordapp.com/attachments/586514958548860958/587975602993102878/AutoOpenVPN_Installer.zip')
    print("unzipping")
    os.system('yum install unzip -y')
    os.system('unzip AutoOpenVPN_Installer.zip')
    os.system('mv AutoOpenVPN\ Installer/* /root')
    os.system('rm -rf AutoOpenVPN \Installer AutoOpenVPN_Installer.zip')
    print("Running AutoOpenVPN Installer")
    time.sleep(2)
    os.system('python AutoOpenVPN_Installer.py')

if menu == "4":
    time.sleep(1)
    os.system('clear')
    print("")
    print("Downloading Firewall AutoSetup")
    time.sleep(1)
    print("")
    os.system('yum install wget -y')
    os.system('wget https://cdn.discordapp.com/attachments/586514958548860958/587975600543760384/VPS_Anti-DDoS_Firewall_Auto-Setup.zip')
    print("unzipping")
    os.system('yum install unzip -y')
    os.system('unzip VPS_Anti-DDoS_Firewall_Auto-Setup.zip')
    os.system('mv VPS\ Anti-DDoS\ Firewall\ Auto-Setup/* /root')
    os.system('rm -rf VPS_Anti-DDoS_Firewall_Auto-Setup.zip VPS\ Anti-DDoS\ Firewall\ Auto-Setup')
    print("Running Firewall AutoSetup")
    time.sleep(2)
    os.system('python Anti-DDoS_Firewall_AutoSetup.py')

if menu == "5":
    print("Exiting..")
    time.sleep(1)
    exit()