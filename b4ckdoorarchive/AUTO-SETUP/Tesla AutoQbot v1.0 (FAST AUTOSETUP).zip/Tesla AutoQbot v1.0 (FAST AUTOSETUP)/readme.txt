made by switch/charge.

for the kiddoz

usage: python Tesla_AutoQbot_v1.0.py


