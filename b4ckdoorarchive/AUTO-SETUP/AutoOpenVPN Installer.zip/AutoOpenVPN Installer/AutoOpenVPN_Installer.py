#!/usr/bin/python

#   charge./switch's AutoOpenVPN Installer
#   for the kiddos
#   contact: charge.#6660
#   website: theswitcharchive.com
#   IG: @switchnets


#import some hacks
import subprocess, time, sys, os # big up rex for reminding me of os.system :hahayes:
# HEY LOOK NO SUBPROCESS CALL REX ARE U HAPPY NOW??????????
os.system('clear') # clear the screen :hahayes:

menu = raw_input("""

	Welcome to charge./switch's AutoOpenVPN Installer

	Press enter to start: """)

os.system('clear')
print("")
print("\x1b[32mStarting...")
time.sleep(1)
print("Installing Wget\x1b[37m")
os.system('yum install wget -y')
os.system('wget https://cdn.discordapp.com/attachments/586514958548860958/587909522803261442/openvpn-install.sh')
os.system('clear')
time.sleep(1)
print("\x1b[32mInstalling OpenVPN\x1b[37m")
print("\x1b[31mPress enter to all questions (unless you know what you're doing)\x1b[37m")
time.sleep(5)
os.system('sh openvpn-install.sh')
print("")
print("")
print("\x1b[32mAll installed, your .ovpn file is in the /root folder.\x1b[37m")
print("")
print("")
exit()