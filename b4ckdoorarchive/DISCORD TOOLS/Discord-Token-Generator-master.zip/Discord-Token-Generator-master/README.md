<div align="center">
<img 
height="100px" 
width="100px"
src="https://camo.githubusercontent.com/4b028e8e841f57ee96b472fa88ea7ed66ddd3720/687474703a2f2f692e696d6775722e636f6d2f65597779386c632e706e67"
></img>
<h1>Token Generator</h1><br>
</div>
Syntax:  

- 2 uppercase letters<br>
- Random letter, uppercase or lowercase<br>
- Number or uppercase/lowercase letter<br>
- Combination of 20 upercase and lowecase letters and numbers<br>
- Dot<br>
- 1 Uppercase letter<br>
- 5 numbers and uppercase/lowercase letters<br>
- Dot<br>
- 27 Random numbers and uppercase/lowercase letters  <br>
**Examples:**  <br>
ODDFOFXUpgf7yEntul5ockCA.OFk6Ph.lmsA54bT0Fux1IpsYvey5XuZk04  
MTdqrd0vGDV1dcF0QPjom6OB.NQxUhj.I4JjFHIympR3mVF3UiUbbD5VVbi  
NTzQvPcLBacBmgajXQc7QAaU.XCgboz.c4t51kFWSEmdmaPnKoyUuu8E78E  
MDGGvAZ0mDvLYaBZgBXgOduB.LH6QMd.VYFAiCSAioXHxWnOGkACJ6cyVtO  
MTkkbSLuyGmw1OPR4fFvJjb1.BbmOlp.Eoysbe9kG1hXzbVRBFtUtB9CRuu  
PNtJFkF7fBH0we42HoZRbQ90.P8a1fh.lZ1EJt9XGhZQRHNfsmwgpeNvDkt  
MTf6LspX6mllDh9gYarxE7O7.ZAUQXX.8a8tN7HbDvI5GUbCbFiYEqbmjIz  
NTYVqPgR1oBTz1LCL2oRxFc8.XT4lzT.WRE6J8x4xTnPfEgqGhiG7JRK5ts  
MDFdikG8VCwPOAEM22D40si9.D76rfn.t4SWt6RFoYWhlFBRvc8en6Z0zCG  
MTOH5CqGFQNkyIXZUSJYvZbj.Mwhnup.JICfg8UPInb3x2Bze31unJPj3x8  
UDrvbuE1I1e3nZlSpb9w089Z.DCeI5i.H8NFmr5elG2E8vv5GkDb6D0X1zp  
## How To use
Once runned the program you just need to insert the amount of loops you want, 1 loop = 5 tokens  
Token Type:  
- First - completely random
- Second - Starts with MT
- Third - Starts with NT
- Fourth - Starts with MD
- Fifth - Starts with NT  
This because MT,NT,MD and NT tokens are the most common, this will have a major chance of getting working tokens.

## Screenshot:  <br>
<img src="https://i.imgur.com/U9e1Oat.png"></img><br>
