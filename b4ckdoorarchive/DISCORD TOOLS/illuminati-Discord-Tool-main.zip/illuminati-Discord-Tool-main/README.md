# illuminati-Discord-Tool 
Features

    Detect Type of gift
    Multi-threading
    Gifts Checker
    Codes Generator
    
    H0w to use? 
    1. git clone https://github.com/ctoANG/illuminati-Discord-Tool.git
    2. cd illuminati
    3. pip install -r requirements.txt 
    4. python3 illuminati.py
    
