<?php 
$name = $_SERVER['SERVER_NAME'];

echo 'Name : ' . $name;




?>