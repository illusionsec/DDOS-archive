function refreshTime(){
        	$('#timeHolder').load('ajax/navbar.php?time=y');
        	setTimeout(refreshTime, 30000);
    	}
    	function refreshOnline(){
        	$('#onlineHolder').load('ajax/navbar.php?online=y');
        	setTimeout(refreshOnline, 30000);
    	}
    	function refreshOffline(){
        	$('#offlineHolder').load('ajax/navbar.php?offline=y');
        	setTimeout(refreshOffline, 30000);
    	}
    	function refreshDead(){
        	$('#deadHolder').load('ajax/navbar.php?dead=y');
        	setTimeout(refreshDead, 60000);
    	}