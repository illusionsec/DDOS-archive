Thank you for purchasing Cayosin.

BP:   CNC:

PAYLOAD:

---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
The Cayosin Bot features unique RHex STD and RHex HTTP attacks. Meaning that the Hex Strings are randomly selected.
Cayosin also contains a custom rTCP method for qBot, comparable to XMAS. As well as a VSE method. 
Then the standard UDP, TCP, and CNC floods. 
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
To Add A User:
*You have the ability to make each account admin/superadmin/common.
"admin" Gives the ability to add/kick users and force unmute all clients. 
"superadmin" Gives all regular admin abilities, as well as IP Ban/Unban.
"common" Only allows the sending of floods, use of Tools and Server Commands.

*You must also select their bot plan.
"noob" gives control over 0 bots
"plan1" gives control over 100 bots
"plan2" gives control over 1000 bots
"plan3" gives control over 5000 bots
"all" gives them control over all bots

And their Plan Expiry Date (Format: 00/00/0000) (day/month/year)

*****Login Entry Format: user pass status level expiry
*****Command Example:"adduser Erradic Erradic555 admin all 02/05/2019"
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
Chat:
By default, you recieve all broadcasts from everyone on the server. All users have the ability to mute all incoming messages (. MUTE ON/OFF)
If admins need to send a notice, they can force unmute all (. UNMUTE)
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
When portscanning, be warned. It may appear to freeze, but it is 
working in the background. It manually checks ports 1-7000.
I recommend using a high RAM server.
If there are a lot of closed ports, it can take a few minutes. 
Just let it run.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
IP Lookup reaches out through an API to grab info. The php file is in html. If for some reason you need to recompile, html will be cleared.
You'll need to reach out to me and I will reload the API to your server.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
Contact @qbotted on Instagram with questions or suggestions.
*Disclaimers* I do not claim to have coded this alone. The Bot is a heavily modded Hakai script. The CNC is a heavily modified Blade script.
The original authors are well aware of what's been done here. Snickers (Blade Author) Coded these CNC features himself.
The credits for the RHex methods go to Studo.*