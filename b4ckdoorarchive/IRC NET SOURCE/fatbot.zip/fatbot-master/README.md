# fatbot
A botnet program developed by demonalex, i.e. Alex Huang, and made up of Perl language for a researching purpose.

1) The primary program is the file, bot_beta6.pl, which will automatically connect to an IRC channel after being executed.
2) The detailed configuration regarding the aforesaid IRC channel can be tweaked by modifying the bot.conf file.
3) The server side of the botnet can carry out three categories of commands shown as follows:
The usage for executing OS commands: CMD command
The usage for triggering a Synflood: SYN target_ip target_port
The usage for downloading a file from the Internet: GET file_url
