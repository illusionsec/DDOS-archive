# Botnet-Perl
Crie uma botnet, com esse script upe ele em uma web shell ou em uma vps e execute ele, assim ira subir o bot (webshell, ou a vps) no servidor irc que você configurar.
