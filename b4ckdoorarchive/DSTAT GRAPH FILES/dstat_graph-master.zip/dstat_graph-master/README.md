# dstat_graph
Graph on top of dstat, because we love UI &lt;3 

dstat graph is a light standalone javascript application that nicely format and display the output of dstat (https://github.com/gianpaj/dstat).

![alt tag](https://raw.githubusercontent.com/Dabz/dstat_graph/master/images/example.png)
