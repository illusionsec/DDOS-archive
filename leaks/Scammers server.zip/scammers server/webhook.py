import requests
import sys

url = "WEBHOOK_URL"

data = {
    "username" : 'Tropical Official API'
}

data["embeds"] = [
    {
        "description" : "API Key: " + sys.argv[1] + "\n Host: " + sys.argv[2] + "\n Port: " + sys.argv[3] + "\n Time: " + sys.argv[4] + "\n Method: " + sys.argv[5],
        "title" : "API Attack Sent!"
    }
]

result = requests.post(url, json = data)

try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print(err)
else:
    print("Webhook Sent!, Code {}".format(result.status_code))