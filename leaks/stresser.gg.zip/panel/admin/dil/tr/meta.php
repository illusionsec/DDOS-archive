<?php

return array (
  'iletisim' => 'CekilisGram instagram çekiliş sitesine ulaşabileceğiniz iletişim bilgilerine bu sayfadan erişebilirsiniz. CekilisGram telefon ve CekilisGram adres bilgileri.',
  'hakkimizda' => 'CekilisGram instagram çekiliş sitesi hakkındaki tüm bilgilere bu sayfadan ulaşabilirsiniz.',
  'kurumsal' => 'CekilisGram ile kurumsal olarak iletişime geçmek için bu sayfayı ziyaret edebilirsiniz.',
  'cerez' => 'CekilisGram tarafından uygulanan çerez politikasını bu sayfadan öğrenebilirsiniz.',
  'iptal' => 'CekilisGram\'dan aldığınız instagram çekiliş paketleri ile ilgili uygulanan iptal ve iade şartlarına bu sayfadan ulaşabilirsiniz.',
  'fiyat' => 'Instagram çekiliş fiyatları ve instagram çekiliş paketleri ile ilgili bilgiye bu sayfadan ulaşabilirsiniz.',
  'anasayfa' => 'Instagram çekilişi yapmak çin kullanabileceğiz ücretsiz ve güvenilir instagram çekiliş sitesi. Tüm dünyanın tercih ettiği instagram çekiliş programı.',
  'gizlilik' => 'CekilisGram tarafından uygulanan gizlilik politikasını bu sayfadan öğrenebilirsiniz.',
);
