<?php

return array (
  'reset' => 'Şifreniz sıfırlandı',
  'sent' => 'Email adresinize şifre sıfırlama linki gönderildi',
  'throttled' => 'Lütfen tekrar denemeden önce biraz bekleyin',
  'token' => 'Geçersiz doğrulama kodu',
  'user' => 'Email adresi bulunamadı',
);
