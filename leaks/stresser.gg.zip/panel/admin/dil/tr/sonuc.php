<?php

return array (
  'hosgeldiniz' => 'Çekilişe Hoşgeldiniz',
  'asagi' => 'Aşağı inerek sonuçları görebilirsiniz.',
  'kaydedildi' => 'Sonuçlar Kaydedildi',
  'paylas' => 'Bu sayfayı paylaşabilirsiniz.',
  'busayfa' => 'Bu sayfadan çekiliş sonuçlarını görebilirsiniz.',
  'guvenli' => 'Sonuçların <span class="p-1 rounded" style="background:#3a00ff;color:white ">Güvenli</span> olduğunu gösterin.',
  'kodu' => 'Çekiliş Kodu',
  'kopyala' => 'Kopyala',
  'kazanan' => 'Kazanan Talihliler',
  'araciligi' => 'cekilisgram.com <span class="text-black-50">aracılığıyla</span>',
  'yedek' => 'Yedek Talihliler',
  'kaydedildi2' => 'Çekilişin <span style="color:#3a00ff ">Sonuçları</span> sizin için kaydedilmiştir.',
);
