<?php

return array (
  'iptal-iade' => '<h1 class="font-weight-bold" style="color:#3a00ff">İptal ve İade Koşulları</h1>

            <span data-contrast="auto">07/11/2003 kabul ve 28/11/2013 yayın tarihli, 6502 sayı numaralı “</span><a href="http://mevzuat.gov.tr/MevzuatMetin/1.5.6502.pdf"><span data-contrast="none">TÜKETİCİNİN KORUNMASI HAKKINDA KANUN</span></a><span data-contrast="auto">” metnindeki ilgili maddeler uyarınca; web ortamında verilen yazılım tabanlı hizmetlerin kullanımın ardından iadesi mümkün değildir.&nbsp;</span><span data-contrast="auto">Ancak müşteri memnuniyeti açısından Premium paketlerin kullanılmayan aylarının iadesi gerçekleştirilmektedir. İade yapılırken kullanılan her bir ay için K.D.V. dahil 43 T.L. + ödeme kuruluşu komisyonları tutarında kesinti yapılır</span><span data-contrast="auto">&nbsp;ve müşte</span><span data-contrast="auto">rinin ödeme yaptığı kanal ile iade gerçekleştirilir.&nbsp;</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <br><br>
            <span data-contrast="auto">İade yapılırken her 0-30 gün arasındaki kullanım için 43 T.L., 31-60&nbsp;</span><span data-contrast="auto">gün arasındaki kullanım için</span><span data-contrast="auto">&nbsp;86 T.L., 61-90&nbsp;</span><span data-contrast="auto">gün arasındaki kullanım için</span><span data-contrast="auto">&nbsp;129 T.L., 91-120&nbsp;</span><span data-contrast="auto">gün arasındaki kullanım için</span><span data-contrast="auto">&nbsp;172 T.L., 121-150&nbsp;</span><span data-contrast="auto">gün arasındaki kullanım için</span><span data-contrast="auto">&nbsp;215 T.L., 15 günden daha fazla süredeki&nbsp;</span><span data-contrast="auto">kullanım için</span><span data-contrast="auto">&nbsp;268 T.L. + banka veya ödeme kuruluşu komisyonu düşüldükten sonra iade işlemi gerçekleştirilir.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <br><br>
            <span data-contrast="auto">İade işlemlerinde; ödeme esnasında kullanılan banka hesabının ya da banka kartlarının hamili ile iade hesabının hamilinin aynı kişi olması zorunludur.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <br><br>
            <span data-contrast="auto">Yukarıdaki şart ve koşullar haricinde iptal, iade işlemi sağlanamamaktadır.&nbsp;Cekilisgram</span><span data-contrast="none">®</span><span data-contrast="none">&nbsp;</span><span data-contrast="auto">bu sayfada yer alan şart ve koşulları önceden belirtmeksizin değiştirme hakkını saklı tutar.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>',
  'hakkimizda' => '<h1 class="font-weight-bold" style="color:#3a00ff">Hakkımızda</h1>
            <span data-contrast="none">Cekilisgram</span><span data-contrast="none">® %100 yerli sermaye ile kurulmuş ve tüm dünyaya hizmet veren nadir</span><span data-contrast="none">&nbsp;Türk</span><span data-contrast="none">&nbsp;internet girişimlerinden biridir.&nbsp;</span><span data-contrast="none">Benzersiz algoritması, %100 güvenli çekiliş sağlayan ve sonuçlarına müdahale edilemeyen sistemi, harika&nbsp;</span><span data-contrast="none">arayüzü</span><span data-contrast="none">&nbsp;ile tartışmasız en başarılı&nbsp;</span><span data-contrast="none">instagram</span><span data-contrast="none">&nbsp;çekiliş sitesidir.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Ar-ge&nbsp;</span><span data-contrast="none">departmanı</span><span data-contrast="none">mız</span><span data-contrast="none">&nbsp;tarafından&nbsp;</span><span data-contrast="none">instagramın</span><span data-contrast="none">&nbsp;sürekli kendini yenileyen algoritmaları için&nbsp;</span><span data-contrast="none">her daim</span><span data-contrast="none">&nbsp;geliştirilmekte olan&nbsp;</span><span data-contrast="none">Cekilisgram</span><span data-contrast="none">;&nbsp;</span><span data-contrast="none">instagram</span><span data-contrast="none">&nbsp;çekilişi düzenleyen birçok fenomenin tercihi haline gelmiştir.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Kurulduğu günden bu yana yüzbinlerce çekilişe ev sahipliği yapan ve neredeyse bir milyon kişinin&nbsp;</span><span data-contrast="none">hediye kazanmasına vesile olan&nbsp;</span><span data-contrast="none">Cekilisgram</span><span data-contrast="none">; on binden fazla üyesi ile her geçen gün büyümeye devam etmektedir.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Instagram</span><span data-contrast="none">&nbsp;çekilişlerinizi gerçekleştirmek için ücretsiz ve ücretli çekiliş paketlerimizi inceleyebilirsiniz.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <b><span data-contrast="none">Sosyal Sorumluluk</span></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Cekilisgram</span><span data-contrast="none">&nbsp;tarafından yürütülen sosyal sorumluluk projeleri aşağıdaki gibidir</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <ol>
                <b><span data-contrast="none">a) Ücretsiz Kullanım Hakkı</span></b>
            </ol>
            <span data-contrast="none">T.C. Cumhurbaşkanlığı, T.C. İçişleri Bakanlığı, T.C. Sağlık Bakanlığı tarafından fonlanan tüm derneklerin ve vakıfların, T.C. Milli Eğitim Bakanlığı’na bağlı ilk ve orta dereceli okulların, YÖK’e bağlı devlet üniversitelerinin, birinci dereceden şehit yakınlarının&nbsp;</span><span data-contrast="none">ve&nbsp; gazilerin</span><span data-contrast="none">&nbsp;şahsi veya kurumsal&nbsp;</span><span data-contrast="none">instagram</span><span data-contrast="none">&nbsp;hesaplarından düzenlenecek çekilişler için herhangi bir ücret talep edilmemektedir.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Yukarıdaki şartların yazılı olarak belgelendirerek&nbsp;</span><a href="https://www.cekilisgram.com/iletisim"><span data-contrast="none">iletişim</span></a><span data-contrast="none">&nbsp;bölümü</span><span data-contrast="none">nden irtibata geçmeniz halinde</span><span data-contrast="none">&nbsp;ücretsiz çekiliş kredileriniz üç iş günü zarfında hesabınıza tanımlanacaktır.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <ol>
                <b><span data-contrast="none">b) İnternet Projelerine Destekler</span></b>
            </ol>
            <span data-contrast="none">Üniversitelerin bilgisayar mühendisliği, yazılım mühendisliği, web tasarımı ve dengi bölümlerinden mezun olan, 28 yaşını aşmamış ve Türkiye Cumhuriyeti uyruklu tüm gerçek kişilerin; sosyal medya alanındaki projelerine yatırım desteği sağlıyoruz.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Yatırım desteği başvurusu yapabilmek için aşağıdaki belgeleri dijital ortamda hazırlayarak&nbsp;</span><a href="mailto:startup@cekilisgram.com"><span data-contrast="none">startup@cekilisgram.com</span></a><span data-contrast="none">&nbsp;adresine göndermeniz yeterlidir:</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <ul>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="1" data-aria-level="1"><span data-contrast="none">Üniversite diplomanız</span><span data-contrast="none">&nbsp;(</span><span data-contrast="none">Jpg</span><span data-contrast="none">&nbsp;formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="2" data-aria-level="1"><span data-contrast="none">Transkript belgeleriniz</span><span data-contrast="none">&nbsp;(</span><span data-contrast="none">Jpg</span><span data-contrast="none">&nbsp;formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="3" data-aria-level="1"><span data-contrast="none">Fotoğraflı özgeçmişiniz (</span><span data-contrast="none">Jpg</span><span data-contrast="none">&nbsp;formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
            </ul>
            <ul>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="1" data-aria-level="1"><span data-contrast="none">Projenizi tüm detayları ile anlatan proje dosyası</span><span data-contrast="none">&nbsp;(PDF formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="2" data-aria-level="1"><span data-contrast="none">Yatırım maliyetlerini gösteren proforma faturalar</span><span data-contrast="none">&nbsp;(PDF formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
                <li data-leveltext="" data-font="Symbol" data-listid="1" aria-setsize="-1" data-aria-posinset="3" data-aria-level="1"><span data-contrast="none">Projenizin tanıtım videosu</span><span data-contrast="none">&nbsp;(AVI formatında olmalı)</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span></li>
            </ul>
            <span data-contrast="none">Yukarıdaki belgelerin eksik olması halinde projeniz değerlendirmeye alınmayacaktır. Projenize yatırım desteği çıkması halinde, 20 iş günü içinde bilgilendirilir ve mülakat için&nbsp;</span><span data-contrast="none">Cekilisgram</span><span data-contrast="none">&nbsp;ofisine davet edilirsiniz.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <b><span data-contrast="none">Staj&nbsp;</span></b><b><span data-contrast="none">İmkanları</span></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>

            <span data-contrast="none">Mesleki ve Teknik Anadolu Liseleri’nin yazılım ile alakalı bölümlerinde son sınıfta okuyan öğrencilerin zorunlu staj eğitimlerine destek veren&nbsp;</span><span data-contrast="none">Cekilisgram’a</span><span data-contrast="none">&nbsp;staj başvurusu yapmak için&nbsp;</span><a href="mailto:stajyer@cekilisgram.com"><span data-contrast="none">stajyer@cekilisgram.com</span></a><span data-contrast="none">&nbsp;adresine aşağıdaki bilgilerle e-posta gönderebilirsiniz:</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            <ol>
            <span data-contrast="none">Hakim</span><span data-contrast="none">&nbsp;olduğunuz programlama dilleri</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            </ol>
            <ol>
               <span data-contrast="none">Öğrenmeyi hedeflediğiniz programlama dilleri</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            </ol>
            <ol>
       <span data-contrast="none">Bir önceki sınıfta mesleki derslerinizin alan bölüm dağılımına göre ortalaması</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            </ol>
            <ol>
               <span data-contrast="none">Bölüm şefi veya sınıf öğretmeni imzalı referans mektubu</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            </ol>
            <ol>
               <span data-contrast="none">Zorunlu staj günleriniz</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}">&nbsp;</span>
            </ol>',
  'cerez' => '<h1 class="font-weight-bold" style="color:#3a00ff">Çerez Politikası</h1>

            <span data-contrast="auto">Cekilisgram</span><span data-contrast="none">®</span><span data-contrast="auto">; kullanıcılarına ve ziyaretçilerine daha hızlı bir kullanım tecrübesi sunmak, internet sarfiyatını azaltmak adına bazı çerezler kullanmaktadır. </span><span data-contrast="auto">Sitemizi ziyaret eden herkes, çerez politikamızı kabul etmektedir. </span><span data-contrast="auto">Cekilisgram</span><span data-contrast="none">®</span><span data-contrast="none"> Çerez Politikası aşağıdaki gibidir:</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <ol>
                <li><span data-contrast="auto">İnternet ortamında “cookies” olarak adlandırılan ve dilimize “web çerez” olarak tercüme edilen çerezler</span><span data-contrast="auto">, </span><span data-contrast="auto">ziyaret ettiğiniz internet sitesi tarafından</span><span data-contrast="auto"> </span><span data-contrast="auto">taşınabilir ya da masaüstü cihazınıza</span><span data-contrast="auto"> </span><span data-contrast="auto">ilgili site tarafından indirilen</span><span data-contrast="auto"> küçük </span><span data-contrast="auto">boyutlu metin dosyaları olarak tanımlanabilir</span><span data-contrast="auto">. </span><span data-contrast="auto">Çerez dosyalarında erişim sağladığınız IP adresi, web </span><span data-contrast="auto">oturum</span><span data-contrast="auto">u bilgileri</span><span data-contrast="auto">, </span><span data-contrast="auto">ilgili sitede gezindiğiniz web sayfaları</span><span data-contrast="auto"> </span><span data-contrast="auto">gibi veriler saklanmaktadır</span><span data-contrast="auto">. </span><span data-contrast="auto">Çerez kullanan web siteleri; üyelik gerektiren sitelerde oturumunuzu açık tutar, site ziyareti esnasındaki gezinti tercihlerinizi saklar, ilgi alanınıza göre içerik gösterir. Çerez dosyalarını birçok şekilde kategorize etmek mümkün olsa da, genelde birinci taraf (sitenin bizzat kullandığı çerezler) ve üçüncü taraf (diğer web sitelerine ait çerezler) olarak ikiye ayrılırlar. </span><span data-contrast="auto">Ayrıca çerezleri geçici ve kalıcı olmasına</span><span data-contrast="auto"> </span><span data-contrast="auto">göre de sınıflandırmak mümkündür.</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span></li>
           
                <li><span data-contrast="auto">Çerezlerin asıl kullanım amacı, web sitesinin hızını arttırmak ve internet sarfiyatını düşürmektir. Bunun dışında oturum bilgileri de depolanarak, kullanıcı deneyiminin pozitif yönde arttırılması hedeflenmektedir. İçerik bazlı çerezleri kullanma amacı ise, ilgi alanına yönelik içeriği ziyaretçi ile buluşturmaktır.</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span></li>
          
                <li><span data-contrast="auto">Cekilisgram; hem birinci taraf çerezlerini hem de üçüncü taraf çerezlerini kullanmaktadır. Üçüncü taraf çerezlerinin tamamı Google, Yandex, Windows, Alexa gibi dünyaca tanınmış web firmalarına aittir. Üçüncü taraf çerezlerimize yenilerini eklediğimiz zaman, bu politika sayfası aracılığı ile ilan etmekteyiz.</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span></li>
            
                <li ><span data-contrast="auto">Kullanmak istemediğiniz çerezleri, erişim sağladığınız web tarayıcısından engellemeniz mümkündür. Ancak bazı çerez dosyalarını engellemeniz halinde, sistemdeki bazı özellikler kullanılamayabilir. Bu bağlamda </span><span data-contrast="auto">Cekilisgram</span><span data-contrast="none">®</span><span data-contrast="none">’ın kullanırken ihtiyaç duyduğu çerezleri engellememenizi tavsiye ederiz. Zira çerezlerin ziyaret esnasında kullandığınız cihaza ve yazılımlarına bilinen bir zararı bulunmamaktadır. Yine de çerezleri yönetmek için aşağıdaki bağlantıları kullanabilirsiniz:</span><span data-ccp-props="{&quot;134233279&quot;:true,&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span></li>
            </ol>
            <a href="https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&amp;hl=tr"><span data-contrast="none">Google Chorme</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://yandex.com.tr/support/browser/personal-data-protection/cookies.html"><span data-contrast="none">Yandex Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://www.opera.com/tr/privacy/cookies"><span data-contrast="none">Opera Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.apple.com/tr-tr/guide/safari/sfri11471/mac"><span data-contrast="none">Safari Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.mozilla.org/tr/kb/cerezler-web-sitelerinin-bilgisayarinizda-depoladi"><span data-contrast="none">Mozilla Firefox</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://help.vivaldi.com/article/cookies/"><span data-contrast="none">Vivaldi</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.microsoft.com/tr-tr/help/17442/windows-internet-explorer-delete-manage-cookies"><span data-contrast="none">Internet Explorer</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
<br><br>
            <span data-contrast="auto">Yukarıda liste halinde sıralanmış tarayıcılardan farklı bir tarayıcı kullanıyor olmanız </span><span data-contrast="auto">halinde, ilgili tarayıcın yardım sayfasından çerezleri nasıl yönetebileceğinizi öğrenebilirsiniz. </span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>',
  'gizlilik' => '<h1 class="font-weight-bold" style="color:#3a00ff">Gizlilik Politikası</h1><br>



<br><br>
Cekilisgram®; tüm üyelerinin, kullanıcıların ve siteyi herhangi bir sebeple ziyaret eden kişilerin bilgilerini üçüncü taraflarla paylaşmayacağını kabul ve taahhüt eder. Ancak aşağıdaki durumlar bir önceki cümleden istisnadır: 
<br><br>
Türkiye Cumhuriyeti Yargı Kurumları, kolluk kuvvetleri, BTK, TK gibi kurumların yazılı olarak talep ettiği bilgiler; yasalarla belirlenmiş süre içerisinde söz konusu kurumlara iletilmektedir. 
<br><br>
Cekilisgram kullanıcı mahremiyeti ve güvenliği açısından IP adresi kayıtlarını saklamamaktadır. Ayrıca kredi kartı ile yapılan ödemeler ve sitenin her alanına girilen şifre bilgileri 256 bit SSL sertifikası gizlendiğinden dolayı; Cekilisgram tarafından görüntülenemez. 
<br><br>
Cekilisgram sitesinin, instagram çekiliş yazılımının, müşteri kayıtlarının saklandığı web sunucuları; yüksek güvenlikli yazılımlar tarafından korunmaktadır. Ancak internet ortamında alınan önlemlerin tamamının %100 güvenli olduğunu söylemek doğru değildir. Bu sebeple sitemizde kullandığınız şifreleri başka bir hesabınızda kullanmamanızı önemle tavsiye ederiz. 
<br><br>
Cekilisgram; bu sayfada yazılan gizlilik politikasını belirli aralıklarla güncel teknolojiye ve değişen kanunlara ayak uydurabilmek amacı ile değiştirme hakkını saklı tutar. Bu bağlamda bu sayfayı ve yazının sonundaki son güncelleme tarihini, siteyi her ziyaretinizde kontrol etmenizi şiddetle tavsiye etmekteyiz. 
<br><br>
Son Güncelleme Tarihi: 03.01.2021',
  'kurumsal' => '<h1 class="font-weight-bold" style="color:#3a00ff">Kurumsal İletişim</h1>
            <span data-contrast="auto">Bu sayfada yayınladığımız iletişim numaraları ve e-posta adresleri yalnızca kurumsal iletişim ile alakalıdır. Müşteri hizmetlerimiz için lütfen iletişim sayfasındaki yöntemlerle ulaşınız. </span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br>
            <b><h2 data-contrast="auto">Hukuk Departmanı</h2></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <span data-contrast="auto">Sitemiz ve şirketimizle alakalı herhangi bir hukuksal konuda bilgi vermek ya da bilgi almak için </span><a href="mailto:hukuk@cekilisgram.com"><span data-contrast="none">hukuk@cekilisgram.com</span></a><span data-contrast="auto"> adresine elektronik posta gönderebilirsiniz. Departman yetkilileri 7 gün içerisinde tarafınıza bilgilendirme sağlayacaktır.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <b><h2 data-contrast="auto">Satın Alma</h2></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <span data-contrast="auto">Şirketimizin ihtiyacı olduğunu düşündüğünüz herhangi bir ürünle alakalı fiyat teklifi vermek için </span><a href="mailto:buy@cekilisgram.com"><span data-contrast="none">buy@cekilisgram.com</span></a><span data-contrast="auto"> adresine elektronik posta gönderebilirsiniz. Bu e-posta adresi dışında kalan erişim kanallarından yollanılan hiçbir fiyat teklifi dikkate alınmamaktadır. Teklifinizle ilgilenmemiz halinde tarafınıza dönüş sağlanacaktır.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <b><h3 data-contrast="auto">Kurumsal Muhasebe</h3></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <span data-contrast="auto">Cari hesap usulü çalıştığımız bir işletme iseniz, muhasebe mutabakatı ve faturalar başta olmak üzere tüm muhasebe </span><span data-contrast="auto">ile ilgili bilgileri </span><a href="mailto:kurumsalmuhasebe@cekilisgram.com"><span data-contrast="none">kurumsalmuhasebe@cekilisgram.com</span></a><span data-contrast="auto"> adresine yollayabilirsiniz.</span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <b><h3 data-contrast="auto">Reklam</h3></b><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <span data-contrast="auto">Web sitemize reklam vermek için </span><a href="mailto:reklam@cekilisgram.com"><span data-contrast="none">reklam@cekilisgram.com</span></a><span data-contrast="auto"> elektronik posta adresini kullanabilirsiniz. </span><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>',
);
