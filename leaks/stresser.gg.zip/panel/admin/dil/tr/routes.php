<?php

return array (
  'iletisim' => 'iletisim',
  'referanslarimiz' => 'referanslarimiz',
  'girisyap' => 'giris-yap',
  'cekilis' => 'instagram-cekilis',
  'gizlilik' => 'gizlilik-politikasi',
  'cerez' => 'cerez-politikasi',
  'iade' => 'iptal-iade',
  'hakkimizda' => 'hakkimizda',
  'kurumsal' => 'kurumsal-iletisim',
  'fiyat' => 'fiyat-listesi',
  'ozellik' => 'ozelliklerimiz',
  'kontrol' => 'kontrol-paneli',
  'cekilis1' => 'cekilis',
  'destek' => 'destek',
);
