<?php

return array (
  'failed' => 'Email adresi ya da şifre yanlış',
  'throttle' => 'Lütfen tekrar denemeden  önce :seconds saniye bekleyin.',
);
