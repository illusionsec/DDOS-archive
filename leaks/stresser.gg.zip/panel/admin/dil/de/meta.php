<?php

return array (
  'anasayfa' => 'Eine kostenlose und zuverlässige Instagram-Verlosungs Seite, auf der Sie Instagram-Verlosungen durchführen können. Jeder nutzt dieses lottery programm für die Instagram-Verlosung.',
  'cerez' => 'Auf dieser Seite erfahren Sie mehr über die Cookie-Richtlinien von Cekilisgram.',
  'gizlilik' => 'Auf dieser Seite erfahren Sie die Datenschutzbestimmungen von Cekilis Gram.',
  'hakkimizda' => 'Auf dieser Seite finden Sie alle Informationen zur CekilisGram Instagram-Verlosungs seite.',
  'iletisim' => 'Auf dieser Seite können Sie die Kontaktinformationen der CekilisGram erfahren. CekilisGram Telefonnummer.',
  'iptal' => 'Auf dieser Seite erfahren Sie mehr über die Rückerstattungsrichtlinien von Cekilisgram.',
  'kurumsal' => 'Sie können diese Seite besuchen, um CekilisGram institutionell zu kontaktieren.',
  'fiyat' => 'Auf dieser Seite erfahren Sie Informationen zu Instagram-lotto Preisen und Instagram-lotto paketen.',
);
