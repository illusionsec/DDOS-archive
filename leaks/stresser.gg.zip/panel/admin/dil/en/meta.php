<?php

return array (
  'anasayfa' => 'A free and reliable Instagram raffle site that you can use to make Instagram raffle. Everybody uses this raffle program for Instagram raffle.',
  'cerez' => 'You can learn Cekilisgram\'s cookies policy from this page.',
  'gizlilik' => 'You can learn Cekilisgram\'s privacy policy from this page.',
  'hakkimizda' => 'You can find all information about the CekilisGram Instagram raffle site on this page.',
  'iletisim' => 'You can learn the contact information of CekilisGram Instagram raffle site from this page. CekilisGram phone number.',
  'fiyat' => 'You can learn information about Instagram raffle prices and Instagram raffle packages on this page.',
  'iptal' => 'You can learn Cekilisgram\'s refund policy on this page.',
  'kurumsal' => 'You can visit this page to contact CekilisGram institutionally.',
);
