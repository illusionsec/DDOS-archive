<?php

return array (
  'hosgeldiniz' => 'Welcome to the Raffle',
  'asagi' => 'You can see the raffle results on this page.',
  'kaydedildi' => 'Results Saved',
  'paylas' => 'You can share this page.',
  'kaydedildi2' => 'This page has been published publicly.',
  'busayfa' => 'Anyone can see the raffle results on this page.',
  'guvenli' => 'Prove to your followers that you are  <span class="p-1 rounded" style="background:#3a00ff;color:white ">trustworthy</span>',
  'kodu' => 'Raffle Code',
  'kopyala' => 'Copy',
  'kazanan' => 'Winners',
  'araciligi' => '<span class="text-black-50">With </span> Cekilisgram.com',
  'yedek' => 'Reserve Winners',
);
