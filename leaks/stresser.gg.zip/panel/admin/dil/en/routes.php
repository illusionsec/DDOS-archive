<?php

return array (
  'iletisim' => 'contact',
  'cekilis' => 'instagram-raffle',
  'cerez' => 'cookies',
  'iade' => 'return-policy',
  'girisyap' => 'login',
  'gizlilik' => 'privacy-policy',
  'hakkimizda' => 'about-us',
  'referanslarimiz' => 'references',
  'kurumsal' => 'corporate-communications',
  'fiyat' => 'prices',
  'ozellik' => 'specifications',
  'kontrol' => 'control-board',
  'cekilis1' => 'raffle',
  'destek' => 'support',
);
