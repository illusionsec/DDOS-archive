<?php

return array (
  'hosgeldiniz' => 'Benvenuti alla lotteria',
  'asagi' => 'Puoi vedere i risultati della lotteria in questa pagina.',
  'kaydedildi' => 'Risultati salvati',
  'paylas' => 'Puoi condividere questa pagina.',
  'kaydedildi2' => 'Questa pagina è stata pubblicata pubblicamente.',
  'busayfa' => 'Chiunque può vedere i risultati della lotteria in questa pagina.',
  'guvenli' => 'Dimostra ai tuoi follower che sei degno di fiducia.',
  'kodu' => 'Codice della lotteria',
  'kopyala' => 'Copia',
  'kazanan' => 'Vincitrici',
  'araciligi' => '<span class="text-black-50">Con </span> Cekilisgram.com',
  'yedek' => 'Vincente di riserva',
);
