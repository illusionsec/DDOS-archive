<?php

return array (
  'anasayfa' => 'Un site de tombola Instagram gratuit et fiable que vous pouvez utiliser pour faire une tombola Instagram. Tout le monde utilise ce programme de tombola pour la tombola Instagram.',
  'cerez' => 'Vous pouvez découvrir la politique de cookies de Cekilisgram à partir de cette page.',
  'gizlilik' => 'Vous pouvez découvrir la politique de confidentialité de Cekilisgram à partir de cette page.',
  'hakkimizda' => 'Vous pouvez trouver toutes les informations sur le CekilisGram.',
  'iletisim' => 'Vous pouvez connaître les coordonnées de CekilisGram à partir de cette page. Numéro de téléphone de CekilisGram.',
  'iptal' => 'Vous pouvez découvrir la politique de remboursement de Cekilisgram sur cette page.',
  'kurumsal' => 'Vous pouvez visiter cette page pour contacter institutionnellement CekilisGram.',
  'fiyat' => 'Vous pouvez obtenir des informations sur les prix de tombola Instagram et les packages de tombola Instagram sur cette page.',
);
