<?php

return array (
  'optdesc' => "Vous pouvez parler au service client de CekilisGram 24 heures sur 24 via l'assistance en direct.",
  'optdesc2' => 'Le plus grand site de tirage au sort Instagram au monde.',
  'baslik' => 'Nous contacter',
  'isim' => 'Prénom / nom de famille',
  'email' => 'Email',
  'mesaj' => 'Votre message',
  'gonder' => 'Soumettre',
  'email2' => 'Nous ne partageons jamais votre adresse e-mail avec qui que ce soit.',
  'sifre' => 'Mot de passe',
  'sifrenizimi' => 'Mot de passe oublié?',
  'hala' => 'Vous n\'êtes pas membre?',
  'kayitol' => 'Inscrivons-nous',
  'sifretekrar' => 'Retaper le mot de passe',
  'telefon' => 'Numéro de téléphone',
  'hala2' => 'Êtes vous membre?',
);
