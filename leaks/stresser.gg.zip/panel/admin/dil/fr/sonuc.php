<?php

return array (
  'hosgeldiniz' => 'Bienvenue à la tombola',
  'asagi' => 'Vous pouvez voir les résultats du tirage sur cette page.',
  'kaydedildi' => 'Résultats enregistrés',
  'paylas' => 'Vous pouvez partager cette page.',
  'kaydedildi2' => 'Cette page a été publiée publiquement.',
  'busayfa' => 'Tout le monde peut voir les résultats du tirage sur cette page.',
  'guvenli' => 'Prouver à vos abonnés que vous êtes digne de confiance.',
  'kodu' => 'Code de loterie',
  'kopyala' => 'Copie',
  'kazanan' => 'Gagnantes',
  'araciligi' => '<span class="text-black-50">Avec </span>Cekilisgram.com',
  'yedek' => 'Gagnant de la réserve',
);
