<?php

return array (
  'iletisim' => 'contact',
  'cekilis' => 'instagram-tombola',
  'cerez' => 'cookies',
  'iade' => 'politique-de-retour',
  'girisyap' => 'sidentifier',
  'gizlilik' => 'politique-de-confidentialite',
  'hakkimizda' => 'propos-de-nous',
  'referanslarimiz' => 'references',
  'kurumsal' => 'communications-entreprise',
  'fiyat' => 'des-prix',
  'ozellik' => 'caracteristiques',
  'kontrol' => 'tableau-controle',
  'cekilis1' => 'tombola',
  'destek' => 'support',
);
