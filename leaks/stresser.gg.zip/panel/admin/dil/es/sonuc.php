<?php

return array (
  'hosgeldiniz' => 'Bienvenido a la rifa',
  'asagi' => 'Puedes ver los resultados del sorteo en esta página.',
  'kaydedildi' => 'Resultados guardados',
  'paylas' => 'Puedes compartir esta página.',
  'kaydedildi2' => 'Esta página ha sido publicada públicamente.',
  'busayfa' => 'Cualquiera puede ver los resultados del sorteo en esta página.',
  'guvenli' => 'Demuestra a tus seguidores que eres confiable.',
  'kodu' => 'Código de lotería',
  'kopyala' => 'Copiar',
  'kazanan' => 'Ganadoras',
  'araciligi' => '<span class="text-black-50">Con </span> Cekilisgram.com',
  'yedek' => 'Ganador de reserva',
);
