<?php

return array (
  'iletisim' => 'contacto',
  'cekilis' => 'instagram-sorteo',
  'cerez' => 'cookies',
  'iade' => 'politica-de-devolucion',
  'girisyap' => 'iniciar-sesion',
  'gizlilik' => 'politica-de-privacidad',
  'hakkimizda' => 'sobre-nosotros',
  'referanslarimiz' => 'referencias',
  'kurumsal' => 'comunicaciones-corporativas',
  'fiyat' => 'precios',
  'ozellik' => 'especificaciones',
  'kontrol' => 'tabla-control',
  'cekilis1' => 'sorteo',
  'destek' => 'soporte',
);
