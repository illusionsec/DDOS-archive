gword = [
  b'SjiW8JO7mH65awR3B4kTZeU90N1szIMrF2PCtLGYxghDoQXcKdqVyfvnubAlEp',
  b'04A1EF7rCH3fYl9UngKRcObJD6ve8W5jdTtaBuGIXiLqmoQNM2wSsZPhVpzkyx',
  b'brU5XqY02ZcA3ygE6lf74BIG9LF8PzOHmTaCJSNupxQdDjseWtoiKRk1hwvnVM',
  b'2I1vF5NMYd0L68aQrp7gTwc4RP9kniJyfuCHsezlXO3BjqxEKmhoVAtZbDWGUS',
  b'136HjBIPWzXCY9VMQa7JRiT4kKv2FGS5s8LtoOdEyr0xuUZgDAbfeqmhwplNnc',
  b'Hwrhs0Y1Ic3Eq25a6t8Z7TQXVMgdePuxCNzJWkLKoRGyUm4OBFnD9bvlpSfiAj',
  b'WAmkt3RCZM829P4g1hanBluw6eVGSf7E05oXFcDbOvsyjdxqKiJQLrzpYTUHIN',
  b'dMxreKZ35tRQg8E02UNTaoI76wGSvVh9Wmc1YpuO4FfyzPLkisnBCljXDqHJAb',
  b'i20mzKraY74A6qR9QM8H3ecUkBlpJC1nyFSZEvfPIsguTwo5VjWGDbLNXxhOtd',
  b'XCAUP6H37toQWSgsNanf0j21VKu9T4EqyGd5JB8vImxhLkRwpOlYceFzZDirbM',
  b'dFZPb9B6z1TavMUmXQHk7x402oEhKJD58pyGewn3NArORWfYSqtIVsljcuCLgi',
  b'rg8V3snTAX6xjuoCYf519BzWRtcMl2OiZNeIvy7F0bKJSqQGH4UPELdpDhmakw',
  b'dZe620lr8JW4iFhNj3K1x59Una7PXsLGvSmBEOfpMwkTYQIDCRcybtuqVAzHog',
  b'5yaQlGSArNzek6MXZ1BPOE3xV470h9KvgYmbufHToWi2pqUjLcIRCnD8twsFdJ',
  b'f12CVxeQ56YWd7OTXDtlnPqugjJikELayvMsFR3GwHzp09ANo8K4rISbZhcBUm',
  b'9Qoa5XkM6iIrR7u8tNZgSpbdDUWvwH21KyzhfsVBG0OAxFl43PLCJcnjTqeYEm',
  b'AqGWke65Y2ufVgljEhMHJL01D8Zptvcw7CxX9zyiRSoK3BTnIsba4PrdFmQNOU',
  b't960P2inR8qEVmAUsDZIpH5wzSXJ43ob1kGWavCrFLdujg7BOyxfMTYNclKQeh',
  b'4l6SAi2KhveRHVN5JGcmx9jOC3afB7wF0ITqXorQk1MDELyzY8dPnWpustgUZb',
  b'tEOp6Xo87QzPbn24J3i9FjWKS1lIBVaMZeHURDg05rmCswvNdqhYuAkLfGcyTx',
  b'zx27DH915lhs04aMJOgf6Z3pyERrGndiLwIev8WUASuktPbTFqcCmVKBjoYNXQ',
  b'8XxOBzZ02hUWDQfvL471q9RC6sAaJVFuTMdG53NykYjcgKtbioSmeHplEnwPIr',
  b'jON0i4C6Z3K97DkbqSypH8lRmx5o2eIwXas1WgzTtGrBhPdUJEFAVuncfvMLYQ',
  b'OIGT0ubwH1x6hCvEgBn274A5Q8K9e3YyzWlmtUcJRFZVfsXrqadoiLPSMpjDNk',
  b'zgejY41CLwRNabovBUP2Aql7FVM8uEDXZQ0cyf6mxi3dSKr95stGOWnpHJkTIh',
  b'Z2MpQE91gdRLYJ8bGIWyOfc4v03Hjzs6VlU5Shrea7NnCiFtkAXmDBwPuToKxq',
  b't6PuvrBXeoHk5FJW08DYQSI49GCwZ27cA1UKjaEMfslTxhngRzpbd3iqVNmLyO',
  b'FiBA53IMW97kYNz82GhHf1yUCdL0nlvRD46sTZxKmPpSrQXVaboeEjtJucqwgO',
  b'2Vz3b06h54jmc7a8AIYtNHM1iQU9wBXWyJkRLvCfdGDFSpgZKlxreqsoOnEuTP',
  b'wyI42azocV3UOX6fk579hMH8eEGJsgFuBmqbtxSDrCPl1TYQjvnLdAWNKZ0Rip',
  b'TxmnK4ljJ9iroY8vVtg3Rae2L516fBWUuXASZC7PzQNGHcdbqkMD0sIwFhEOyp',
  b'z6Y1bPrJEln0uWeLKkjo9IZ2y7ROcFHqBm548GNtvw3hXDfsTApMaUQdiSxCVg',
  b'x064LFB39TsXeryqvt2pZN8QIERuWAVUmwjJibY1nzD5gP7aOKCGSokdHflMhc',
  b'76qg85yB31uH90YbZofsjKrRGiTVndAEtFMxNcp4IQlUaSDvWXwCePz2OmJkLh',
  b'WjwTEbCA752kq89shcaLB1xO64rgMYnoFiJQtSZRUzpv0K3NXDyeIVGufHPdlm',
  b'u6307O4J2DeZs8UYyjlzfX91KGmavEdwTRSgNt5bCFxHBIoMniWphLVAcqQPrk',
  b'4zFsHa5uEbe872WwBPXTJCliN0jvxSo1ApRcqdtK6L3y9knDUfhOVYQMgZIrGm',
  b'tLAi5Bp3WMwzm46nj9NvlUO7h21RgkV0GDEaIHq8FsubCXQdcPTSYxryKoZeJf',
  b'Kj3bWg8qVvLA5Nrn46xt7HIU1MckDozQeR2iG9XEs0fuZymaTJdPYOwphFBSCl',
  b'9bA53vgchwM4Lj2PI8nxt7QSDUfdCz1FNrZEuypRV06JOYesKlHXoBaqTmkWGi',
  b'3vkU7FeNaczPjiHnbpo069qAMIRxrwgGmQ24Es5Xf8TVlKDLY1uStJByWOCdhZ',
  b'xKcI51fpQ49rlW3A0VFMSmgjU7CyYtG8sDodXh2ORunqEZew6zaLHbNBPivTJk',
  b'V67pN53oJqmYF2u4l8hZi9zsGMvROUXHBjTDeL0gQIdSc1KkywaPnxbtAECWrf',
  b'7dvu514sLCPJltyeE890n3gKUY2ZwMF6qpWDhbNTfIiaxQVHcoOjXmrSzARGBk',
  b'67BPwxcXkudqE035yWL8e1YCspRGbUKrVhO9oZaH2Fv4lTMQtnADmJSjfzigIN',
  b'JgDlOb5B09fSUoiRuesZ6VX3cqF8zn2HhkxCvyMK4IEYpTPj1aWrdw7QtGLANm',
  b'1LQpqYuOV4i9gU8Nn2RflAey6E7PaJ3FD5Txb0wGomzrvdjCZWshHXtIMSkBKc',
  b'ldg8W9D75q60Ua4C3hGjnF1KVIvBtJ2MZrcEmORsNoTeiLxQuykbSpXzYAwfPH',
  b'4RqhfsVn5jpW9wxtQJPemN8Y6b2T03DayA1CIczrZlguEGUMBFH7kvKSOidLXo',
  b'CYl1I3Mm87w9gk2ZKHAq0cW4EBuL65USOGsoDFbtvyeaQrhXRnjxzTJdPiVpfN',
  b'8SsH5ZB46Kt21JwoVfLvODxcRPA9q0eG3gFrXyIQThWk7maiYnjMEuNpUdzlbC',
  b'E30HgCD7uOoF5NtLzB8ShbqaUefMl9nv2cdpY6kmAiJ1VXKw4PTZyjWrGsQRIx',
  b'vRFBr5L706yOjWw2I1oDaxJe8ZMQTHK9USNAtp3qPdfYinuz4EhsGlCbkcVmXg',
  b'bt64qN0MW7Jw51Y8ZTXSEhRKkOoDVn3jiLyvC9UalBFzdx2HIgmpfQsGAePcur',
  b'1ZAH2XwTGJL5Ihv7pND03e4jMkVyR6d8CKsaxiqlrbPzYfmgo9cuQFWUOEBtSn',
  b'T3QajnmGq8MUu0p1hRJF25V7SBfZkbzKLDEdCWtYy96AlveIs4roxNXHciwOPg',
  b'e7ToMXx1jySmLFZ2hrPBwK8NUb9tilGYa36DQ4JERVAWOHsvfd0pCczgun5Iqk',
  b'D8m6QaFg1UkX52VeWhY930TBtGzcSZI4fnxJMAoE7CRLwbqylvNPKupdsrHOij',
  b'b53UXT7LIurcwmSfiWzRxDBQs9G8eAhMjPCK6y4g0NJV21vdYnOHqltoZFEpka',
  b'5NBAZV84Ft16O0DRCxPg7a9jc3MUukJhveYKo2TnlfSGsiIQWLXEwdyqbHrzmp',
  b'FJOC6Syu7K81hBblAUgkjHVdfZ0xXMi4vQGWp3w9RD5eztEILoPcaNY2mqsTrn',
  b'Ts5dJr78NaBUF3fcEQ1lvpPOVk2SMit6yhC9zGqHgemZx0Dn4oAKuLRbXjIWYw',
  b'LfGi72D0nF359d6PwSqV8UTIZtWHEK4ysYXNuojM1rzAQpCObehaJBkRlgvcmx'
]

def pwatnm(code):
  if 0x2f < code < 0x3a:
    return code - 0x30

  if 0x60 < code < 0x7b:
    return code - 0x57

  if 0x40 < code < 0x5b:
    return code - 0x1d

  return 0

def pwcrypt(data, key):
  knum = pwatnm(key)

  kdx = 0
  ret = []

  for idx, code in enumerate(data):
    dnum = pwatnm(code)

    ret.append(gword[knum][dnum])

  return bytes(ret)

def derive(pwd):
  for x in range(16):
    password = pwcrypt(password, password[x])

  return passwd
