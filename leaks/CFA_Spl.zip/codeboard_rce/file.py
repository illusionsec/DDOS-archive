import sys
import subprocess

def run(cmd):
    subprocess.call(cmd, shell=True)

run("mkdir t")
run("touch t/sora.x86")