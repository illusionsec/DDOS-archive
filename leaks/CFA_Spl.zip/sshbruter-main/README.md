# sshbruter
sshbruter 0day
for bruting your ssh servers x86_64 for your net.
