echo -e "STARTING AUTOSCANNER"

zmap -p22 -w 1.lst -o mfu.txt -B1000M
./update 1500
python TragicSSH.py vuln.txt
rm -rf 1.lst
zmap -p22 -w 2.lst -o mfu.txt -B1000M
./update 1500
python TragicSSH.py vuln.txt
rm -rf 2.lst