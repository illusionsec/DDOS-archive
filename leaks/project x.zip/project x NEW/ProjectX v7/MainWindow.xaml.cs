﻿using Fusion;
using ProjectX_v7.Includes;
using ProjectX_v7.Includes.FujiPopup;
using ProjectX_v7.User_Controls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ProjectX_v7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TabDisplay.Children.Add(new ucAttackHub());
            Clipboard.SetText(User.Expiry);
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private async void btnChat_Click(object sender, RoutedEventArgs e)
        {
            TabDisplay.Children.Clear();
            TabDisplay.Children.Add(new ucChat());
            try { await FusionApp.RefreshApp(); } catch { }
            lblRunningAttacks.Content = Fusion.App.ActiveApis;
        }

        private async void Window_Initialized(object sender, EventArgs e)
        {
            await Functions.GetAppInfo();
            lblPlan.Content = Functions.userRank;
            lblUsername.Content = User.Username;
            lblUsers.Content = Fusion.App.UserCount;
            lblYourAttacks.Content = await FusionApp.GetUserVar("attacks");
            tbNews.Text = await FusionApp.GetAppVar("news");
        }

        private async void btnAttack_Click(object sender, RoutedEventArgs e)
        {
            TabDisplay.Children.Clear();
            TabDisplay.Children.Add(new ucAttackHub());
            try { await FusionApp.RefreshApp(); } catch { }
            try { lblYourAttacks.Content = await FusionApp.GetUserVar("attacks"); } catch { }
            lblRunningAttacks.Content = Fusion.App.ActiveApis;
        }

        private void Border_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private async void btnTools_Click(object sender, RoutedEventArgs e)
        {
            TabDisplay.Children.Clear();
            TabDisplay.Children.Add(new ucTools());
            try { await FusionApp.RefreshApp(); } catch { }
            try { lblYourAttacks.Content = await FusionApp.GetUserVar("attacks"); } catch { }
            lblRunningAttacks.Content = Fusion.App.ActiveApis;
        }

        private async void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            TabDisplay.Children.Clear();
            TabDisplay.Children.Add(new ucSettings());
            try { await FusionApp.RefreshApp(); } catch { }
            try { lblYourAttacks.Content = await FusionApp.GetUserVar("attacks"); } catch { }
            lblRunningAttacks.Content = Fusion.App.ActiveApis;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnDiscord_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://discord.gg/wmpHrrYTKW");
        }

        private void btnInstagram_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.instagram.com/projectx.panel/");
        }
    }
}
