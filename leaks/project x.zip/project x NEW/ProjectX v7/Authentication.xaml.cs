﻿using Fusion;
using ProjectX_v7.Includes;
using ProjectX_v7.Includes.FujiPopup;
using ProjectX_v7.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ProjectX_v7
{
    /// <summary>
    /// Interaction logic for Authentication.xaml
    /// </summary>
    public partial class Authentication : Window
    {
        public Authentication()
        {
            InitializeComponent();

            bool checkDirResp = FileHelper.CheckDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ProjectX"), true);
            if (!checkDirResp) msgHost.dangerBox("Could not locate file!", "The directory for this application doesn't exist or couldn't be created, please relaunch!");

            string themeFile = $"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ProjectX")}\\ThemeInformation.json";
            bool checkFileResp = FileHelper.CheckFile(themeFile);
            if (checkFileResp) ThemeChanger.UpdateTheme(File.ReadAllText(themeFile));

            tbUsername.Focus();
            new msgHost().Show();

            if (Settings.Default.AutoLogin == true) 
            {
                btnAuthenticate.IsEnabled = false;
                msgHost.infoBox("Logging in...", $"Logging you in now {Settings.Default.Username}", 6);
                tbUsername.Text = Settings.Default.Username;
                tbPassword.Password = Settings.Default.Password;
                login(Settings.Default.Username, Settings.Default.Password);
            }

            if (Settings.Default.RememberUser == true) 
            {
                tbUsername.Text = Settings.Default.Username;
                tbPassword.Password = Settings.Default.Password;
                tgRemember.IsChecked = true;
            }
        }

        private static FusionApp App = new FusionApp("978143");

        private void menu_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void btnSignUp_Click(object sender, RoutedEventArgs e)
        {
            pgLogin.Visibility = Visibility.Hidden;
            pgRegister.Visibility = Visibility.Visible;
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            pgLogin.Visibility = Visibility.Visible;
            pgRegister.Visibility = Visibility.Hidden;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private async void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbRUsername.Text)) 
            {
                msgHost.dangerBox("Registration Failed!", "Username is empty!");
                return;
            }          
            if (string.IsNullOrWhiteSpace(tbRPassword.Password)) 
            {
                msgHost.dangerBox("Registration Failed!", "Password is empty!");
                return;
            }          
            if (string.IsNullOrWhiteSpace(tbRToken.Password)) 
            {
                msgHost.dangerBox("Registration Failed!", "Token is empty!");
                return;
            }

            var registerResponse = await App.Register(tbRUsername.Text, tbRPassword.Password, tbRToken.Password);
            if (registerResponse.Error == false)
            {
                Hide();
                msgHost.successBox("Registration Successful!", $"Thank you for choosing Project X, please login {tbRUsername.Text}.", 10);
                pgLogin.Visibility = Visibility.Visible;
                pgRegister.Visibility = Visibility.Hidden;
            }
            else
            {
                msgHost.dangerBox("Registration Failed!", registerResponse.Message);
            }
        }

        private void btnAuthenticate_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbUsername.Text))
            {
                msgHost.dangerBox("Login Failed!", "Username is empty!");
                return;
            }
            if (string.IsNullOrWhiteSpace(tbPassword.Password))
            {
                msgHost.dangerBox("Login Failed!", "Password is empty!");
                return;
            }

            login(tbUsername.Text, tbPassword.Password);
        }

        private void btnDiscord_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://discord.gg/c73hAm6rP2");
        }

        private void tbUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) 
            {
                if (string.IsNullOrWhiteSpace(tbUsername.Text))
                {
                    msgHost.dangerBox("Empty Field!", "Username is empty!");
                    return;
                }

                tbPassword.Focus();
            }
        }

        private void tbPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (string.IsNullOrWhiteSpace(tbPassword.Password))
                {
                    msgHost.dangerBox("Empty Field!", "Password is empty!");
                    return;
                }

                login(tbUsername.Text, tbPassword.Password);
            }
        }

        private async void login(string username, string password)
        {
            var loginResponse = await App.Login(username, password, "", false, false);
            if (loginResponse.Error == false)
            {
                if (tgRemember.IsChecked == true)
                {
                    Settings.Default.RememberUser = true;
                }
                else
                {
                    Settings.Default.RememberUser = false;
                }

                if (await FusionApp.GetUserVar("attacks") == "Invalid Var")
                    await FusionApp.SetUserVar("attacks", "0");

                Settings.Default.Username = tbUsername.Text;
                Settings.Default.Password = tbPassword.Password;
                Settings.Default.Save();

                Hide();
                msgHost.successBox("Login Successful!", $"Welcome {tbUsername.Text} to Project X v7!", 10);
                new MainWindow().Show();
            }
            else
            {
                msgHost.dangerBox("Login Failed!", loginResponse.Message);
            }
        }
    }
}
