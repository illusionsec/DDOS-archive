﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectX_v7.Includes
{
    public class ThemeObject
    {
        public Colors Colors { get; set; }
    }

    public class Colors
    {
        public string TitleColor { get; set; }
        public string LabelHeaderColor { get; set; }
        public string LabelLowerColor { get; set; }
        public string PrimaryDataColor { get; set; }
        public string HeaderDarkerColor { get; set; }
        public string TextColor { get; set; }
        public string IconForegroundColor { get; set; }
        public string IconBackgroundColor { get; set; }
        public string ButtonForegroundColor { get; set; }
        public string ButtonBackgroundColor { get; set; }
        public string GridBackgroundColor { get; set; }
        public string MainBackgroundColor { get; set; }
        public string SecondaryBackgroundColor { get; set; }
        public string HeaderColor { get; set; }
        public string SidebarColor { get; set; }

        public string LightSuccessColor { get; set; }
        public string SuccessColor { get; set; }
        public string DarkSuccessColor { get; set; }

        public string LightDangerColor { get; set; }
        public string DangerColor { get; set; }
        public string DarkDangerColor { get; set; }

        public string LightInfoColor { get; set; }
        public string InfoColor { get; set; }
        public string DarkInfoColor { get; set; }

        public string LightWarningColor { get; set; }
        public string WarningColor { get; set; }
        public string DarkWarningColor { get; set; }
    }
}
