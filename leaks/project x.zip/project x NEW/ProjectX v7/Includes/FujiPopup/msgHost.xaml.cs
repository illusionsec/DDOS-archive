﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectX_v7.Includes.FujiPopup
{
    /// <summary>
    /// Interaction logic for msgHost.xaml
    /// </summary>
    public partial class msgHost : Window
    {
        public static msgHost Instance { get; private set; }

        public msgHost()
        {
            InitializeComponent();
            Instance = this;
        }

        public static void infoBox(string Title, string Message, int Timeout = 5)
        {
            Instance.spNotifications.Children.Add(new msgInformation(Title, Message, Timeout));
        }

        public static void successBox(string Title, string Message, int Timeout = 5)
        {
            Instance.spNotifications.Children.Add(new msgSuccess(Title, Message, Timeout));
        }

        public static void warningBox(string Title, string Message, int Timeout = 5)
        {
            Instance.spNotifications.Children.Add(new msgWarning(Title, Message, Timeout));
        }

        public static void dangerBox(string Title, string Message, int Timeout = 5)
        {
            Instance.spNotifications.Children.Add(new msgDanger(Title, Message, Timeout));
        }

        private void wdFuji_Loaded(object sender, RoutedEventArgs e)
        {
            var desktopWorkingArea = System.Windows.SystemParameters.WorkArea;
            this.Left = desktopWorkingArea.Right - this.Width;
            this.Top = desktopWorkingArea.Bottom - this.Height;
        }

        private void wdFuji_Deactivated(object sender, EventArgs e)
        {
            Window window = (Window)sender;
            window.Topmost = true;
        }
    }
}
