﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectX_v7.Includes.FujiPopup
{
    /// <summary>
    /// Title = Whatever the fuck you want the title to be bbg
    /// Message = Same as the title but the content of the message
    /// Timeout = How long in ms the message will stay on the screen
    /// </summary>
    public partial class msgDanger : UserControl
    {
        public msgDanger(string Title, string Message, int Timeout)
        {
            InitializeComponent();
            lbTitle.Content = Title;
            tbMessage.Text = Message;
            try
            {
                var t = Task.Run(async delegate
                {
                    await Task.Delay(Timeout * 1000);
                    this.Dispatcher.Invoke(() => { try { ((Panel)this.Parent).Children.Remove(this); } catch { } });
                });
            }
            catch 
            { 
            
            }
        }

        private void close(object sender, RoutedEventArgs e)
        {
            ((Panel)this.Parent).Children.Remove(this);
        }
    }
}
