﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ProjectX_v7.Includes.FujiPopup
{
    /// <summary>
    /// Title = Whatever the fuck you want the title to be bbg
    /// Message = Same as the title but the content of the message
    /// Timeout = How long in ms the message will stay on the screen
    /// </summary>
    public partial class msgInformation : UserControl
    {
        public msgInformation(string Title, string Message, int Timeout)
        {
            InitializeComponent();
            lbTitle.Content = Title;
            tbMessage.Text = Message;
            var t = Task.Run(async delegate
            {
                await Task.Delay(Timeout * 1000);
                this.Dispatcher.Invoke(() => { try { ((Panel)this.Parent).Children.Remove(this); } catch { } });
            });
        }

        private void close(object sender, RoutedEventArgs e)
        {
            ((Panel)this.Parent).Children.Remove(this);
        }
    }
}
