﻿using Fusion;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ProjectX_v7.Includes
{
    class Functions
    {
        public static bool ValidateUrl(string value)
        {
            value = value.Trim();

            Regex pattern = new Regex(@"^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$");
            Match match = pattern.Match(value);
            if (value.StartsWith("http"))
                return match.Success;
            else
                return false;
        }

        public static bool ValidateIP(string value)
        {
            value = value.Trim();

            Regex pattern = new Regex(@"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$");
            Match match = pattern.Match(value);
            if (match.Success == false) return false;
            return true;
        }

        public static async Task<string> TrackHost(string value)
        {
            // + https://proxycheck.io/ +
            /// <fields>
            /// &vpn=1 | When the vpn flag is supplied we will perform a VPN check on the IP Address and present the result to you.
            /// &asn=1 | When the asn flag is supplied we will perform an ASN check on the IP Address and present you with the provider name, ASN, Continent, Country, Country ISOCode, Region, Region ISOCode, City (if it's in a city) and Lat/Long for the IP Address.
            /// &node=1 | When the node flag is supplied we will display which node within our cluster answered your API call. This is only really needed for diagnosing problems with our support staff.
            /// &time=1 | When the time flag is supplied we will display how long this query took to be answered by our API excluding network overhead.
            /// &inf=1 | When the inf flag is set to 0 (to disable it) we will not run this query through our real-time inference engine. In the absence of this flag or if it's set to 1 we will run the query through our real-time inference engine.
            /// &risk=1| When the risk flag is set to 1 we will provide you with a risk score for this IP Address ranging from 0 to 100. Scores below 33 can be considered low risk while scores between 34 and 66 can be considered high risk. Addresses with scores above 66 are considered very dangerous. 
            /// &port=1 | When the port flag is supplied we will display to you the port number we saw this IP Address operating a proxy server on.
            /// &seen=1 | When the seen flag is supplied we will display to you the most recent time we saw this IP Address operating as a proxy server.
            /// &days=1 | When the days flag is supplied we will restrict our proxy results to between now and the amount of days you specify. For example if you supplied &days=2 we would only check our database for Proxies that we saw within the past 48 hours. By default without this flag supplied we search within the past 7 days.
            /// &tag=1 | When the tag flag is supplied we will tag your query with the message you supply. You can supply your tag using the POST method and we recommend you do so.
            /// </fields>

            string key = "46d7h7-2n510y-09407m-27514v";
            string fields = "&vpn=1&asn=1&node=1&time=1&inf=0&risk=1&port=1&provider=1";

            var client = new HttpClient();

            var response = await client.GetAsync($"https://proxycheck.io/v2/{value}?key={key}{fields}");
            var content = await response.Content.ReadAsStringAsync();

            return content;
        }

        #region "Application Information"

        public static string userRank;
        public static string maxTime;
        public static string concurrents;
        public static string meme;
        //public static string proxy;

        public static async Task<bool> GetAppInfo()
        {
            string data = await FusionApp.GetAppVar("app");
            string level = Convert.ToString(User.Level);
            var obj = JsonConvert.DeserializeObject<dynamic>(data);

            userRank = obj["membership"][level]["name"];
            maxTime = obj["membership"][level]["maxtime"];
            concurrents = obj["membership"][level]["servers"];
            meme = obj["memeofday"];
            //proxy = obj["statusproxy"];
            return true;
        }

        #endregion

        #region "Hub Functions"

        public static string serverID;
        public static string hostField;
        public static string portField;
        public static string timeField;
        public static string methodField;

        public async static Task LoadServers(ComboBox serverBox, string appVar) 
        {
            string data = await FusionApp.GetAppVar(appVar);
            var obj = JsonConvert.DeserializeObject<dynamic>(data);
            string serverList = obj["serverlist"];
            var strArray = serverList.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < strArray.Length; i++)
            {
                serverBox.Items.Add(strArray[i]);
            }
        }

        public async static Task FetchServerMethods(ComboBox methodBox, string id, string appVar) 
        {
            string data = await FusionApp.GetAppVar(appVar);
            var obj = JsonConvert.DeserializeObject<dynamic>(data);
            string serverMethods = obj["servers"][id]["methods"];
            var strArray = serverMethods.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < strArray.Length; i++)
            {
                methodBox.Items.Add(strArray[i]);
            }
        }

        public async static Task FetchServerInfo(string id, string appVar)
        {
            string data = await FusionApp.GetAppVar(appVar);
            var obj = JsonConvert.DeserializeObject<dynamic>(data);
            serverID = obj["servers"][id]["id"];
            hostField = obj["servers"][id]["hostfield"];
            portField = obj["servers"][id]["portfield"];
            timeField = obj["servers"][id]["timefield"];
            methodField = obj["servers"][id]["methodfield"];
        }

        #endregion

        #region "Log File Manager"

        public class LocalLogs
        {
            // Attack's
            public string AdvHL_Host { get; set; }
            public string AdvHL_Port { get; set; }
            public string AdvHL_Time { get; set; }
            public string AdvHL_Method { get; set; }
            public string AdvHL_Server { get; set; }
            public string AdvHL_ID { get; set; }
        }

        public static bool WriteToFile(LocalLogs UserObject, string FileName, string Location)
        {
            List<LocalLogs> uso = new List<LocalLogs>();
            uso.Add(UserObject);
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDoc‌​uments), Location);
            string file = $"{path}\\{FileName}.json";
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            if (!File.Exists(file))
            {
                File.Create(file).Close();
                File.WriteAllText(file, JsonConvert.SerializeObject(uso));
                return true;
            }
            else
            {
                try
                {
                    uso = null;
                    uso = JsonConvert.DeserializeObject<List<LocalLogs>>(File.ReadAllText(file));
                    uso.Add(UserObject);
                    File.WriteAllText(file, JsonConvert.SerializeObject(uso));
                    return true;
                }
                catch
                {
                    File.Move(file, $"{path}\\Old{FileName}.json");
                    return false;
                }

            }
        }

        public static List<LocalLogs> ReadFile(string FileName, string Location)
        {
            List<LocalLogs> uso = new List<LocalLogs>();
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDoc‌​uments), Location);
            string file = $"{path}\\{FileName}.json";
            if (!Directory.Exists(path))
                return null;
            if (!File.Exists(file))
                return null;
            else
            {
                uso = JsonConvert.DeserializeObject<List<LocalLogs>>(File.ReadAllText(file));
                if (uso != null)
                    return uso;
                else
                    return null;
            }
        }

        #endregion
    }
}
