﻿using System.IO;

namespace ProjectX_v7.Includes
{
    class FileHelper
    {
        /// <summary>
        /// Check if a directory exists, and optionally create the directory if it doesn't.
        /// </summary>
        /// <param name="dir">The path to the directory you want to check.</param>
        /// <param name="create">If true creates directory if it doesn't exist.</param>
        /// <returns>Returns true if exists or creates directory; otherwise false</returns>
        public static bool CheckDirectory(string dir, bool create = false)
        {
            if (!Directory.Exists(dir))
            {
                if (create)
                {
                    try
                    {
                        Directory.CreateDirectory(dir);
                        return true;
                    }
                    catch
                    {
                        return false;
                    }
                }
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check if file exists.
        /// </summary>
        /// <param name="path">The path to the file you want to check.</param>
        /// <returns>Returns true if file exists; otherwise false</returns>
        public static bool CheckFile(string path)
        {
            if (!File.Exists(path)) return false;
            return true;
        }

        /// <summary>
        /// Write to a file, creates the file if it doesn't exist.
        /// </summary>
        /// <param name="path">The path of the file you want to write data to.</param>
        /// <param name="data">The data you want to write to the file.</param>
        /// <returns>Returns true if the file was written to; otherwise false</returns>
        public static bool WriteFile(string path, string data)
        {
            try
            {
                File.WriteAllText(path, data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Copy a file, overwrites file if it already exists.
        /// </summary>
        /// <param name="path">The file you want to copy.</param>
        /// <param name="dest">The destination of the file.</param>
        /// <returns>Returns true if successfully copied; otherwise false</returns>
        public static bool CopyFile(string path, string dest)
        {
            try
            {
                File.Copy(path, dest, true);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
