﻿using Fusion;
using ProjectX_v7.Includes.FujiPopup;
using ProjectX_v7.User_Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectX_v7.Includes.Chat_Handler
{
    /// <summary>
    /// Interaction logic for ucSentChatBubble.xaml
    /// </summary>
    public partial class ucSentChatBubble : UserControl
    {
        public Fusion.ChatResponse message;

        public ucSentChatBubble(Fusion.ChatResponse msg)
        {
            message = msg;
            InitializeComponent();
            lblSender.Content = message.Author[1];
            tbMessage.Text = message.Content;
            rtbEdit.AppendText(message.Content);
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            rtbEdit.Visibility = Visibility.Visible;
            btnEditConfirm.Visibility = Visibility.Visible;
            ucChat.editing = true;
        }

        private async void btnEditConfirm_Click(object sender, RoutedEventArgs e)
        {
            TextRange textRange = new TextRange(rtbEdit.Document.ContentStart, rtbEdit.Document.ContentEnd);
            var editMessage = await FusionApp.EditMessage(message.MessageId, textRange.Text);
            if (editMessage.Error == false)
            {
                msgHost.successBox("Success", $"Message edited!", 5);
            }
            else
            {
                msgHost.dangerBox("Failure...", editMessage.Message, 5);
            }
            rtbEdit.Visibility = Visibility.Hidden;
            btnEditConfirm.Visibility = Visibility.Hidden;
            ucChat.editing = false;
        }

        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var deleteMessage = await FusionApp.DeleteMessage(message.MessageId);
            if (deleteMessage.Error == false)
            {
                msgHost.successBox("Success", $"Message deleted!", 5);
            }
            else
            {
                msgHost.dangerBox("Failure...", deleteMessage.Message, 5);
            }
        }
    }
}
