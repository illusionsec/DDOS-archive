﻿using Newtonsoft.Json;
using ProjectX_v7.Includes.FujiPopup;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ProjectX_v7.Includes
{
    public class ThemeChanger
    {
        public static ThemeObject DefaultTheme()
        {
            return new ThemeObject
            {
                Colors = new Colors()
                {
                    TitleColor = "#DEDEDE",
                    LabelHeaderColor = "#F3F3F3",
                    LabelLowerColor = "#818181",
                    PrimaryDataColor = "#D4191C",
                    HeaderDarkerColor = "#96999E",
                    TextColor = "#FFFFFF",
                    IconForegroundColor = "#D4191C",
                    IconBackgroundColor = "#171717",
                    ButtonForegroundColor = "#FFFFFF",
                    ButtonBackgroundColor = "#D4191C",
                    GridBackgroundColor = "#191C23",
                    MainBackgroundColor = "#101010",
                    SecondaryBackgroundColor = "#171717",
                    HeaderColor = "#FFFFFF",
                    SidebarColor = "#171717",
                    LightSuccessColor = "#51d672",
                    SuccessColor = "#2db84d",
                    DarkSuccessColor = "#2db84d",
                    LightDangerColor = "#B92F3A",
                    DangerColor = "#db3340",
                    DarkDangerColor = "#450c0f",
                    LightInfoColor = "#00bcd4",
                    InfoColor = "#00bcd4",
                    DarkInfoColor = "#003c44",
                    LightWarningColor = "#e9af20",
                    WarningColor = "#e9af20",
                    DarkWarningColor = "#4c3a0f"
                }
            };
        }

        public static void UpdateColors(Color? titleColor = null,
            Color? labelHeaderColor = null,
            Color? labelLowerColor = null,
            Color? primaryDataColor = null,
            Color? headerDarkerColor = null,
            Color? textColor = null,
            Color? iconForgroundColor = null,
            Color? iconBackgroundColor = null,
            Color? buttonForgroundColor = null,
            Color? buttonBackgroundColor = null,
            Color? gridBackgroundColor = null,
            Color? mainBackgroundColor = null,
            Color? secondaryBackgroundColor = null,
            Color? headerColor = null,
            Color? sidebarColor = null,
            Color? lightSuccessColor = null,
            Color? successColor = null,
            Color? darkSuccessColor = null,
            Color? lightDangerColor = null,
            Color? dangerColor = null,
            Color? darkDangerColor = null,
            Color? lightInfoColor = null,
            Color? infoColor = null,
            Color? darkInfoColor = null,
            Color? lightWarningColor = null,
            Color? warningColor = null,
            Color? darkWarningColor = null)
        {
            try
            {
                if (titleColor.HasValue) SetColorResource("TitleColor", (Color)titleColor);
                if (labelHeaderColor.HasValue) SetColorResource("LabelHeaderColor", (Color)labelHeaderColor);
                if (labelLowerColor.HasValue) SetColorResource("LabelLowerColor", (Color)labelLowerColor);
                if (primaryDataColor.HasValue) SetColorResource("PrimaryDataColor", (Color)primaryDataColor);
                if (headerDarkerColor.HasValue) SetColorResource("HeaderDarkerColor", (Color)headerDarkerColor);
                if (textColor.HasValue) SetColorResource("TextColor", (Color)textColor);
                if (iconForgroundColor.HasValue) SetColorResource("IconForegroundColor", (Color)iconForgroundColor);
                if (iconBackgroundColor.HasValue) SetColorResource("IconBackgroundColor", (Color)iconBackgroundColor);
                if (buttonForgroundColor.HasValue) SetColorResource("ButtonForegroundColor", (Color)buttonForgroundColor);
                if (buttonBackgroundColor.HasValue) SetColorResource("ButtonBackgroundColor", (Color)buttonBackgroundColor);
                if (gridBackgroundColor.HasValue) SetColorResource("GridBackgroundColor", (Color)gridBackgroundColor);
                if (mainBackgroundColor.HasValue) SetColorResource("MainBackgroundColor", (Color)mainBackgroundColor);
                if (secondaryBackgroundColor.HasValue) SetColorResource("SecondaryBackgroundColor", (Color)secondaryBackgroundColor);
                if (headerColor.HasValue) SetColorResource("HeaderColor", (Color)headerColor);
                if (sidebarColor.HasValue) SetColorResource("SidebarColor", (Color)sidebarColor);

                if (lightSuccessColor.HasValue) SetColorResource("LightSuccessColor", (Color)lightSuccessColor);
                if (successColor.HasValue) SetColorResource("SuccessColor", (Color)successColor);
                if (darkSuccessColor.HasValue) SetColorResource("DarkSuccessColor", (Color)darkSuccessColor);

                if (lightDangerColor.HasValue) SetColorResource("LightDangerColor", (Color)lightDangerColor);
                if (dangerColor.HasValue) SetColorResource("DangerColor", (Color)dangerColor);
                if (darkDangerColor.HasValue) SetColorResource("DarkDangerColor", (Color)darkDangerColor);

                if (lightInfoColor.HasValue) SetColorResource("LightInfoColor", (Color)lightInfoColor);
                if (infoColor.HasValue) SetColorResource("InfoColor", (Color)infoColor);
                if (darkInfoColor.HasValue) SetColorResource("DarkInfoColor", (Color)darkInfoColor);

                if (lightWarningColor.HasValue) SetColorResource("LightWarningColor", (Color)lightWarningColor);
                if (warningColor.HasValue) SetColorResource("WarningColor", (Color)warningColor);
                if (darkWarningColor.HasValue) SetColorResource("DarkWarningColor", (Color)darkWarningColor);
            }
            catch
            {
                msgHost.dangerBox("Failed to update!", "An error has occurred while try to update the colors!");
            }
        }

        public static void UpdateTheme(string json)
        {
            if (string.IsNullOrEmpty(json)) return;

            ThemeObject themeObject = JsonConvert.DeserializeObject<ThemeObject>(json);
            Colors colors = themeObject.Colors;

            UpdateColors((Color)ColorConverter.ConvertFromString(colors.TitleColor),
            (Color)ColorConverter.ConvertFromString(colors.LabelHeaderColor),
            (Color)ColorConverter.ConvertFromString(colors.LabelLowerColor),
            (Color)ColorConverter.ConvertFromString(colors.PrimaryDataColor),
            (Color)ColorConverter.ConvertFromString(colors.HeaderDarkerColor),
            (Color)ColorConverter.ConvertFromString(colors.TextColor),
            (Color)ColorConverter.ConvertFromString(colors.IconForegroundColor),
            (Color)ColorConverter.ConvertFromString(colors.IconBackgroundColor),
            (Color)ColorConverter.ConvertFromString(colors.ButtonForegroundColor),
            (Color)ColorConverter.ConvertFromString(colors.ButtonBackgroundColor),
            (Color)ColorConverter.ConvertFromString(colors.GridBackgroundColor),
            (Color)ColorConverter.ConvertFromString(colors.MainBackgroundColor),
            (Color)ColorConverter.ConvertFromString(colors.SecondaryBackgroundColor),
            (Color)ColorConverter.ConvertFromString(colors.HeaderColor),
            (Color)ColorConverter.ConvertFromString(colors.SidebarColor),
            (Color)ColorConverter.ConvertFromString(colors.LightSuccessColor),
            (Color)ColorConverter.ConvertFromString(colors.SuccessColor),
            (Color)ColorConverter.ConvertFromString(colors.DarkSuccessColor),
            (Color)ColorConverter.ConvertFromString(colors.LightDangerColor),
            (Color)ColorConverter.ConvertFromString(colors.DangerColor),
            (Color)ColorConverter.ConvertFromString(colors.DarkDangerColor),
            (Color)ColorConverter.ConvertFromString(colors.LightInfoColor),
            (Color)ColorConverter.ConvertFromString(colors.InfoColor),
            (Color)ColorConverter.ConvertFromString(colors.DarkInfoColor),
            (Color)ColorConverter.ConvertFromString(colors.LightWarningColor),
            (Color)ColorConverter.ConvertFromString(colors.WarningColor),
            (Color)ColorConverter.ConvertFromString(colors.DarkWarningColor));
        }


        public static void SetColorResource(string key, Color color)
        {
            Application.Current.Resources[key] = new SolidColorBrush(color);
        }

        public static void SetGradientResource(string key, Color startColor, Color endColor, double angle)
        {
            Application.Current.Resources[key] = new LinearGradientBrush(startColor, endColor, angle);
        }

        public static object GetResource(string key)
        {
            return Application.Current.Resources[key];
        }


        public class CustomBackground : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler PropertyChanged;

            public void SetImageData(byte[] data)
            {
                var source = new BitmapImage();
                source.BeginInit();
                source.StreamSource = new MemoryStream(data);
                source.EndInit();

                ImageSource = source;
            }

            ImageSource imageSource;
            public ImageSource ImageSource
            {
                get { return imageSource; }
                set
                {
                    imageSource = value;
                    OnPropertyChanged("ImageSource");
                }
            }
            protected void OnPropertyChanged(string name)
            {
                var handler = PropertyChanged;
                if (null != handler)
                {
                    handler(this, new PropertyChangedEventArgs(name));
                }
            }
        }

        public class CustomPofilePic : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler PropertyChanged;

            public void SetImageData(byte[] data)
            {
                var source = new BitmapImage();
                source.BeginInit();
                source.StreamSource = new MemoryStream(data);
                source.EndInit();

                ProfileSource = source;
            }

            ImageSource profileSource;
            public ImageSource ProfileSource
            {
                get { return profileSource; }
                set
                {
                    profileSource = value;
                    OnPropertyChanged("ProfileSource");
                }
            }
            protected void OnPropertyChanged(string name)
            {
                var handler = PropertyChanged;
                if (null != handler)
                {
                    handler(this, new PropertyChangedEventArgs(name));
                }
            }
        }
    }
}

