﻿using Newtonsoft.Json;
using ProjectX_v7.Includes;
using ProjectX_v7.Includes.FujiPopup;
using System;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ProjectX_v7.User_Controls
{
    public partial class ucTools : UserControl
    {
        private static int openPorts = 0;
        private static int closedPorts = 0;

        public ucTools()
        {
            InitializeComponent();
        }

        public class Ports
        {
            public string Port { get; set; }
        }

        private async void btnScan_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbTarget.Text) || string.IsNullOrWhiteSpace(tbWaitTime.Text) || string.IsNullOrWhiteSpace(tbStartPort.Text) || string.IsNullOrWhiteSpace(tbEndPort.Text))
            {
                msgHost.dangerBox("Empty Fields!", "Please make sure all fields are filled in.");
                return;
            }
            else if (!int.TryParse(tbStartPort.Text, out _) || !int.TryParse(tbStartPort.Text, out _) || !int.TryParse(tbEndPort.Text, out _))
            {
                msgHost.dangerBox("Invalid fields!", "Please make sure all fields are intergers.");
                return;
            }

            lblClosed.Content = "N/a";
            lblOpen.Content = "N/a";
            lblWaitTime.Content = "N/a";

            lblWaitTime.Content = $"{tbWaitTime.Text}ms";
            for (int port = Convert.ToInt32(tbStartPort.Text); port < Convert.ToInt32(tbEndPort.Text) + 1; port++)
            {
                await Task.Run(() =>
                {
                    using (TcpClient client = new TcpClient())
                    {
                        if (client.ConnectAsync(this.Dispatcher.Invoke(() => tbTarget.Text), port).Wait(80))
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                openPorts += 1;
                                dgOpenPorts.Items.Add(new Ports { Port = port.ToString() });
                                client.Dispose();
                                lblOpen.Content = openPorts;
                            });
                        }
                        else
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                closedPorts += 1;
                                client.Dispose();
                                lblClosed.Content = closedPorts;
                            });
                        }
                    }
                });
            }
        }

        private async void btnTrack_Click(object sender, RoutedEventArgs e)
        {
            var geoObj = JsonConvert.DeserializeObject<dynamic>(await Functions.TrackHost(tbTarget.Text));

            lblCoordinates.Content = $"Lat: {geoObj[tbTarget.Text]["latitude"]} / Lon: {geoObj[tbTarget.Text]["longitude"]}";
            lblCountry.Content = geoObj[tbTarget.Text]["country"];
            lblProvider.Content = geoObj[tbTarget.Text]["provider"];
            lblProxy.Content = geoObj[tbTarget.Text]["proxy"];
            lblRisk.Content = geoObj[tbTarget.Text]["risk"];
        }
    }
}
