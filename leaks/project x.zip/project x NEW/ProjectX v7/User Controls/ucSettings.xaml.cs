﻿using Microsoft.Win32;
using Newtonsoft.Json;
using ProjectX_v7.Includes;
using ProjectX_v7.Includes.FujiPopup;
using ProjectX_v7.Properties;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ProjectX_v7.User_Controls
{
    public partial class ucSettings : UserControl
    {
        private static ThemeObject themeObject;
        private static string StyleKey = null;

        public ucSettings()
        {
            InitializeComponent();

            string themeFile = $"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json";
            bool checkFileResp = FileHelper.CheckFile(themeFile);
            if (!checkFileResp)
            {
                themeObject = ThemeChanger.DefaultTheme();
                string json = JsonConvert.SerializeObject(themeObject, Formatting.Indented);

                bool writeFileResp = FileHelper.WriteFile(themeFile, json);
                if (!writeFileResp) msgHost.dangerBox("Failed to create file!", "The theme file couldn't be created, please relaunch!");
            }
            else
            {
                themeObject = JsonConvert.DeserializeObject<ThemeObject>(File.ReadAllText(themeFile));
            }

            if (Settings.Default.AutoLogin == true)
                tgAutoLogin.IsChecked = true;
            else
                tgAutoLogin.IsChecked = false;

            cbLogManagement.Items.Add("Clear Attacks");

            cbThemeOptions.Items.Add("Import Theme");
            cbThemeOptions.Items.Add("Export Theme");
            cbThemeOptions.Items.Add("Reset Theme");
        }

        private Color SolidColorBrushToColor(SolidColorBrush solidColorBrush)
        {
            return Color.FromArgb(solidColorBrush.Color.A, solidColorBrush.Color.R, solidColorBrush.Color.G, solidColorBrush.Color.B);
        }

        private string ColorToHex(Color c)
        {
            return "#" + c.A.ToString("X2") + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
        }

        private void SaveTheme()
        {
            string json = JsonConvert.SerializeObject(themeObject, Formatting.Indented);
            File.WriteAllText($"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json", json);
        }

        private void EditColor(object sender, RoutedEventArgs e)
        {
            Button sentBy = (Button)sender;
            switch (sentBy.Name) 
            {
                case "btnTitleColor":
                    StyleKey = "TitleColor";
                    lblColorName.Content = "Title";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLabelHeaderColor":
                    StyleKey = "LabelHeaderColor";
                    lblColorName.Content = "Label Header";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLabelLowerColor":
                    StyleKey = "LabelLowerColor";
                    lblColorName.Content = "Label Lower";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnPrimaryDataColor":
                    StyleKey = "PrimaryDataColor";
                    lblColorName.Content = "Primary";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDarkerHeaderColor":
                    StyleKey = "HeaderDarkerColor";
                    lblColorName.Content = "Header Dark";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnTextColor":
                    StyleKey = "TextColor";
                    lblColorName.Content = "Text";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnIconForgroundColor":
                    StyleKey = "IconForegroundColor";
                    lblColorName.Content = "Icon Forground";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnIconBackgroundColor":
                    StyleKey = "IconBackgroundColor";
                    lblColorName.Content = "Icon Background";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnButtonForgroundColor":
                    StyleKey = "ButtonForegroundColor";
                    lblColorName.Content = "Button Forground";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnBackgroundColor":
                    StyleKey = "ButtonBackgroundColor";
                    lblColorName.Content = "Button Background";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnGridBackgroundColor":
                    StyleKey = "GridBackgroundColor";
                    lblColorName.Content = "Grid Background";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnMainBackgroundColor":
                    StyleKey = "MainBackgroundColor";
                    lblColorName.Content = "Main Background";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnMain2BackgroundColor":
                    StyleKey = "SecondaryBackgroundColor";
                    lblColorName.Content = "Main-2 Background";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnHeaderColor":
                    StyleKey = "HeaderColor";
                    lblColorName.Content = "Header";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnSidebarColor":
                    StyleKey = "SidebarColor";
                    lblColorName.Content = "Sidebar";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLightSuccessColor":
                    StyleKey = "LightSuccessColor";
                    lblColorName.Content = "Light Success";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnSuccessColor":
                    StyleKey = "SuccessColor";
                    lblColorName.Content = "Success";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDarkSuccessColor":
                    StyleKey = "DarkSuccessColor";
                    lblColorName.Content = "Dark Success";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLightDangerColor":
                    StyleKey = "LightDangerColor";
                    lblColorName.Content = "Light Danger";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDangerColor":
                    StyleKey = "DangerColor";
                    lblColorName.Content = "Danger";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDarkerDangerColor":
                    StyleKey = "DarkDangerColor";
                    lblColorName.Content = "Dark Danger";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLightInfoColor":
                    StyleKey = "LightInfoColor";
                    lblColorName.Content = "Light Info";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnInfoColor":
                    StyleKey = "InfoColor";
                    lblColorName.Content = "Info";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDarkInfoColor":
                    StyleKey = "DarkInfoColor";
                    lblColorName.Content = "Dark Info";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnLightWarningColor":
                    StyleKey = "LightWarningColor";
                    lblColorName.Content = "Light Warning";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnWarningColor":
                    StyleKey = "WarningColor";
                    lblColorName.Content = "Warning";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
                case "btnDarkWarningColor":
                    StyleKey = "DarkWarningColor";
                    lblColorName.Content = "Dark Warning";

                    lblColorName.SetResourceReference(ForegroundProperty, StyleKey);
                    colorZone.SetResourceReference(BackgroundProperty, StyleKey);

                    colorPicker.Color = SolidColorBrushToColor((SolidColorBrush)Application.Current.Resources[StyleKey]);

                    bColorEditor.Visibility = Visibility.Visible;
                    pnlPopup.Visibility = Visibility.Visible;
                    break;
            }
        }

        private void tbCustomColor_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                Color color = (Color)ColorConverter.ConvertFromString(tbCustomColor.Text);
                Application.Current.Resources[StyleKey] = new SolidColorBrush(color);
                switch (StyleKey)
                {
                    case "TitleColor":
                        themeObject.Colors.TitleColor = ColorToHex(color);
                        break;
                    case "LabelHeaderColor":
                        themeObject.Colors.LabelHeaderColor = ColorToHex(color);
                        break;
                    case "LabelLowerColor":
                        themeObject.Colors.LabelLowerColor = ColorToHex(color);
                        break;
                    case "PrimaryDataColor":
                        themeObject.Colors.PrimaryDataColor = ColorToHex(color);
                        break;
                    case "HeaderDarkerColor":
                        themeObject.Colors.HeaderDarkerColor = ColorToHex(color);
                        break;
                    case "TextColor":
                        themeObject.Colors.TextColor = ColorToHex(color);
                        break;
                    case "IconForegroundColor":
                        themeObject.Colors.IconForegroundColor = ColorToHex(color);
                        break;
                    case "IconBackgroundColor":
                        themeObject.Colors.IconBackgroundColor = ColorToHex(color);
                        break;
                    case "ButtonForegroundColor":
                        themeObject.Colors.ButtonForegroundColor = ColorToHex(color);
                        break;
                    case "ButtonBackgroundColor":
                        themeObject.Colors.ButtonBackgroundColor = ColorToHex(color);
                        break;
                    case "GridBackgroundColor":
                        themeObject.Colors.GridBackgroundColor = ColorToHex(color);
                        break;
                    case "MainBackgroundColor":
                        themeObject.Colors.MainBackgroundColor = ColorToHex(color);
                        break;
                    case "SecondaryBackgroundColor":
                        themeObject.Colors.SecondaryBackgroundColor = ColorToHex(color);
                        break;
                    case "HeaderColor":
                        themeObject.Colors.HeaderColor = ColorToHex(color);
                        break;
                    case "SidebarColor":
                        themeObject.Colors.SidebarColor = ColorToHex(color);
                        break;

                    case "LightSuccessColor":
                        themeObject.Colors.LightSuccessColor = ColorToHex(color);
                        break;
                    case "SuccessColor":
                        themeObject.Colors.SuccessColor = ColorToHex(color);
                        break;
                    case "DarkSuccessColor":
                        themeObject.Colors.DarkSuccessColor = ColorToHex(color);
                        break;

                    case "LightDangerColor":
                        themeObject.Colors.LightDangerColor = ColorToHex(color);
                        break;
                    case "DangerColor":
                        themeObject.Colors.DangerColor = ColorToHex(color);
                        break;
                    case "DarkDangerColor":
                        themeObject.Colors.DarkDangerColor = ColorToHex(color);
                        break;

                    case "LightInfoColor":
                        themeObject.Colors.LightInfoColor = ColorToHex(color);
                        break;
                    case "InfoColor":
                        themeObject.Colors.InfoColor = ColorToHex(color);
                        break;
                    case "DarkInfoColor":
                        themeObject.Colors.DarkInfoColor = ColorToHex(color);
                        break;

                    case "LightWarningColor":
                        themeObject.Colors.LightWarningColor = ColorToHex(color);
                        break;
                    case "WarningColor":
                        themeObject.Colors.WarningColor = ColorToHex(color);
                        break;
                    case "DarkWarningColor":
                        themeObject.Colors.DarkWarningColor = ColorToHex(color);
                        break;
                }
            }
            catch 
            {
                msgHost.dangerBox("Unknown Error", "Failed to complete task.");
            }
        }

        private void ClosePopup(object sender, RoutedEventArgs e)
        {
            pnlPopup.Visibility = Visibility.Hidden;
        }

        private void ChangeColor(object sender, MouseButtonEventArgs e)
        {
            Color color = colorPicker.Color;
            Application.Current.Resources[StyleKey] = new SolidColorBrush(color);
            switch (StyleKey)
            {
                case "TitleColor":
                    themeObject.Colors.TitleColor = ColorToHex(color);
                    break;
                case "LabelHeaderColor":
                    themeObject.Colors.LabelHeaderColor = ColorToHex(color);
                    break;
                case "LabelLowerColor":
                    themeObject.Colors.LabelLowerColor = ColorToHex(color);
                    break;
                case "PrimaryDataColor":
                    themeObject.Colors.PrimaryDataColor = ColorToHex(color);
                    break;
                case "HeaderDarkerColor":
                    themeObject.Colors.HeaderDarkerColor = ColorToHex(color);
                    break;
                case "TextColor":
                    themeObject.Colors.TextColor = ColorToHex(color);
                    break;
                case "IconForegroundColor":
                    themeObject.Colors.IconForegroundColor = ColorToHex(color);
                    break;
                case "IconBackgroundColor":
                    themeObject.Colors.IconBackgroundColor = ColorToHex(color);
                    break;
                case "ButtonForegroundColor":
                    themeObject.Colors.ButtonForegroundColor = ColorToHex(color);
                    break;
                case "ButtonBackgroundColor":
                    themeObject.Colors.ButtonBackgroundColor = ColorToHex(color);
                    break;
                case "GridBackgroundColor":
                    themeObject.Colors.GridBackgroundColor = ColorToHex(color);
                    break;
                case "MainBackgroundColor":
                    themeObject.Colors.MainBackgroundColor = ColorToHex(color);
                    break;
                case "SecondaryBackgroundColor":
                    themeObject.Colors.SecondaryBackgroundColor = ColorToHex(color);
                    break;
                case "HeaderColor":
                    themeObject.Colors.HeaderColor = ColorToHex(color);
                    break;
                case "SidebarColor":
                    themeObject.Colors.SidebarColor = ColorToHex(color);
                    break;
                case "LightSuccessColor":
                    themeObject.Colors.LightSuccessColor = ColorToHex(color);
                    break;
                case "SuccessColor":
                    themeObject.Colors.SuccessColor = ColorToHex(color);
                    break;
                case "DarkSuccessColor":
                    themeObject.Colors.DarkSuccessColor = ColorToHex(color);
                    break;
                case "LightDangerColor":
                    themeObject.Colors.LightDangerColor = ColorToHex(color);
                    break;
                case "DangerColor":
                    themeObject.Colors.DangerColor = ColorToHex(color);
                    break;
                case "DarkDangerColor":
                    themeObject.Colors.DarkDangerColor = ColorToHex(color);
                    break;
                case "LightInfoColor":
                    themeObject.Colors.LightInfoColor = ColorToHex(color);
                    break;
                case "InfoColor":
                    themeObject.Colors.InfoColor = ColorToHex(color);
                    break;
                case "DarkInfoColor":
                    themeObject.Colors.DarkInfoColor = ColorToHex(color);
                    break;
                case "LightWarningColor":
                    themeObject.Colors.LightWarningColor = ColorToHex(color);
                    break;
                case "WarningColor":
                    themeObject.Colors.WarningColor = ColorToHex(color);
                    break;
                case "DarkWarningColor":
                    themeObject.Colors.DarkWarningColor = ColorToHex(color);
                    break;
            }
            Task.Run(() => SaveTheme());
        }

        private void cbThemeOptions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = $"{Fusion.App.AppName} - Import Theme...",
                InitialDirectory = Environment.SpecialFolder.MyDocuments.ToString(),
                Filter = "JSON File (*.json)|*.json|All Files (*.*)|*"
            };

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Title = $"{Fusion.App.AppName} - Export Theme...",
                InitialDirectory = Environment.SpecialFolder.MyDocuments.ToString(),
                Filter = "JSON File (*.json)|*.json|All Files (*.*)|*"
            };

            switch (cbThemeOptions.SelectedIndex)
            {
                case 0:
                    try
                    {
                        if (openFileDialog.ShowDialog() == true)
                        {
                            string themeData = File.ReadAllText(openFileDialog.FileName);

                            bool writeFileResp = FileHelper.WriteFile($"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json", themeData);
                            if (!writeFileResp)
                            {
                                msgHost.dangerBox("Import Error!", "The theme couldn't be saved, try and re-import!");
                                return;
                            }

                            ThemeChanger.UpdateTheme(themeData);
                        }
                    }
                    catch
                    {
                        msgHost.dangerBox("Import Error!", "The theme couldn't be saved, try and re-import!");
                        return;
                    }

                    msgHost.infoBox("Theme Imported", "Successfully imported your theme!");
                    break;
                case 1:
                    try
                    {
                        if (saveFileDialog.ShowDialog() == true)
                        {
                            string themeData = File.ReadAllText($"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json");

                            bool writeFileResp = FileHelper.WriteFile(saveFileDialog.FileName, themeData);
                            if (!writeFileResp)
                            {
                                msgHost.dangerBox("Export Error", "Failed to write the file, try and re-export!");
                                return;
                            }
                        }
                    }
                    catch
                    {
                        msgHost.dangerBox("Export Error", "Failed to write the file, try and re-export!");
                        return;
                    }

                    msgHost.infoBox("Theme Exported", "Successfully exported your theme!");
                    break;
                case 2:
                    string themeFile = $"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json";
                    bool checkFileResp = FileHelper.CheckFile(themeFile);
                    if (checkFileResp)
                    {
                        themeObject = ThemeChanger.DefaultTheme();
                        string json = JsonConvert.SerializeObject(themeObject, Formatting.Indented);

                        bool writeFileResp = FileHelper.WriteFile(themeFile, json);
                        if (!writeFileResp) msgHost.dangerBox("Reset Error", "The theme file couldn't be created, please relaunch!");
                    }
                    else
                    {
                        themeObject = JsonConvert.DeserializeObject<ThemeObject>(File.ReadAllText(themeFile));
                    }

                    ThemeChanger.UpdateTheme(File.ReadAllText($"{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Fusion.App.AppName)}\\ThemeInformation.json"));
                    break;
                default:

                    break;
            }
            cbThemeOptions.SelectedIndex = -1;
        }

        private void tgAutoLogin_Checked(object sender, RoutedEventArgs e)
        {
            if (tgAutoLogin.IsChecked == true)
            {
                Settings.Default.AutoLogin = true;
            }
            else
            {
                Settings.Default.AutoLogin = false;
            }
            Settings.Default.Save();
        }

        private void cbLogManagement_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cbLogManagement.SelectedIndex) 
            {
                case 0:
                    string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDoc‌​uments), Fusion.App.AppName);
                    string file = $"{path}\\AttackLogs.json";
                    try { if (File.Exists(file)) { File.Delete(file); msgHost.infoBox("Logs Cleared!", "Your attack logs have been cleared!"); } } catch { msgHost.dangerBox("Logs Not Cleared!", "Attack logs not cleared! Unknown error."); }
                    break;
            }
            cbLogManagement.SelectedIndex = -1;
        }
    }
}
