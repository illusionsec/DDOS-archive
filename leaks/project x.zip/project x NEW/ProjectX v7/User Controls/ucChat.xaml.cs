﻿using ProjectX_v7.Includes.Chat_Handler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProjectX_v7;
using Fusion;
using ProjectX_v7.Includes.FujiPopup;
using System.Timers;

namespace ProjectX_v7.User_Controls
{
    /// <summary>
    /// Interaction logic for ucChat.xaml
    /// </summary>
    public partial class ucChat : UserControl
    {
        public System.Timers.Timer timer = new System.Timers.Timer();
        public static bool editing = false;

        public ucChat()
        {
            InitializeComponent();
            UpdateChat();
            timer.Interval = 3500;
            timer.Elapsed += timer_Elapsed;
            timer.Start();
        }

        public void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                UpdateChat();
            });
        }

        private async void UpdateChat()
        {
            if (editing) return;
            try
            {
                var chat = await FusionApp.GetChat();
                if (chat.Error == false)
                {
                    spMessages.Children.Clear();
                    foreach (var message in chat.Chat)
                    {
                        if (message.Author[0] == User.UserId)
                        {
                            spMessages.Children.Add(new ucSentChatBubble(message));
                        }
                        else
                        {
                            spMessages.Children.Add(new ucRecievedChatBubble(message));
                        }
                    }
                }
                else
                {
                    msgHost.dangerBox("FusionAPI.dev", chat.Message);
                }
            } catch (Exception e)
            { msgHost.dangerBox("FusionAPI.dev", e.Message); }
        }

        private async void tbMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var sendMessage = await FusionApp.SendMessage(tbMessage.Text);
                if (sendMessage.Error == false)
                {
                    spMessages.Children.Insert(0, new ucSentChatBubble(new ChatResponse { Author = new List<string>() { User.UserId, User.Username }, Content = tbMessage.Text, Edited = false, MessageId = "N/A", Timestamp = 0 }));
                }
                else
                {
                    msgHost.dangerBox("FusionAPI.dev", sendMessage.Message);
                }
                tbMessage.Text = "";
            }
        }

        private void control_Unloaded(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }
    }
}
