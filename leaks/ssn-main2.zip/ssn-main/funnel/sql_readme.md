# SSN SQL Manager Tutorial

Thank you for your trust in SSN, you will not regret it.

Customer Information:
User: ``
license: ``
Compiled: ``
Version: ``

# Suggested specs and details

Operating System: `Ubuntu 20.04`
Ram: `1 Gb`
CPU: `1 core` @ `1 Ghz`
Absolute minimum Storage: `3 Gb`

# How To Setup SSN SQL Manager

*  Navigate into the directory that the "assets" folder is in by using: `cd "your directory"`.

0. `chmod 777 *`

# How to run SSN SQL Manager

1. `./SQL`