import time, os
while True:
    screen = os.system("cd /root/SSN;screen -dmS SSN ./SSN")
    time.sleep(10)
