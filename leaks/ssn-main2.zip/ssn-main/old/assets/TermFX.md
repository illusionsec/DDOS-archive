SSN CNC TermFX

FiveM Resolver:

<<$cfx.ip>>
<<$cfx.port>>
<<$cfx.code>>
<<$cfx.country>>
<<$cfx.hosting>>
<<$cfx.org>>
<<$cfx.players.current>>
<<$cfx.players.max>>

IP Lookup:

<<$ip.ip>>
<<$ip.region>>
<<$ip.country>>
<<$ip.continent>>
<<$ip.city>>
<<$ip.zip>>
<<$ip.isp>>
<<$ip.asn>>
<<$ip.org>>
<<$ip.timezone>>

Broadcast Banner:

<<$broadcast.message>>
<<$broadcast.sender>>

Attack Sent Banner:

<<$target.host>>
<<$target.port>>
<<$target.duration>>
<<$target.method>>

Base TermFX:

<<$clear>>
<<$skipline>>
<<$general.online>>
<<$general.ongoing>>
<<$general.attackcount>>
<<$user.username>>
<<$user.ongoing>>
<<$user.concurrents>>
<<$user.maxtime>>
<<$user.rank>>
<<$user.expiry.days>>
<<$user.expiry.formatted>>
<<$user.attackcount>>

Colours:

reset: [0m
bright: [1m
dim: [2m
underscore: [4m
blink: [5m
reverse: [7m
hidden: [8m
black: [30m
brightblack: [90m
backgroundblack: [40m
red: [31m
brightred: [91m
backgroundred: [41m
green: [32m
brightgreen: [92m
backgroundgreen: [42m
yellow: [33m
brightyellow: [93m
backgroundyellow: [43m
blue: [34m
brightblue: [94m
backgroundblue: [44m
magenta: [35m
brightmagenta: [95m
backgroundmagenta: [45m
cyan: [36m
brightcyan: [96m
backgroundcyan: [46m
white: [37m
brightwhite: [97m
backgroundwhite: [47m