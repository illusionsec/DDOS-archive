<!-- frontend for cloud-register -->
<?php
require 'Repository/configuration.php';
require 'Repository/init.php';
session_start();
unset($_SESSION['captcha']);
$_SESSION['captcha'] = rand(1, 100);
$x1 = rand(2,10);
$x2 = rand(1,10);
$x = SHA1(($x1 + $x2).$_SESSION['captcha']); 
?>
<!DOCTYPE html>
<html lang="en"> 
	<!--begin::Head-->
	<head>
		<title>Cloud-Manager</title>
		<meta charset="utf-8" />
		<link rel="shortcut icon" href="assets/Logo.png" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<!--end::Global Stylesheets Bundle-->
		<link href="assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
	</head>
	<!--end::Head-->
<!--begin::Theme mode setup on page load-->
<script>
	if ( document.documentElement ) {
	 const defaultThemeMode = "system";
   
	 const name = document.body.getAttribute("data-kt-name");
	 let themeMode = localStorage.getItem("kt_" + ( name !== null ? name + "_" : "" ) + "theme_mode_value");
   
	 if ( themeMode === null ) {
	  if ( defaultThemeMode === "system" ) {
	   themeMode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
	  } else {
	   themeMode = defaultThemeMode;
	  }
	 }
   
	 document.documentElement.setAttribute("data-theme", themeMode);
	}
   </script>
   <!--end::Theme mode setup on page load-->
	<!--begin::Body-->
	<body data-theme="dark" id="kt_body" class="app-blank app-blank">
		<!--begin::Theme mode setup on page load-->
		<!--end::Theme mode setup on page load-->
		<!--Begin::Google Tag Manager (noscript) -->
		<!--End::Google Tag Manager (noscript) -->
		<!--begin::Root-->
		<div class="d-flex flex-column flex-root" id="kt_app_root">
			<!--begin::Authentication - Sign-in -->
			<div class="d-flex flex-column flex-lg-row flex-column-fluid">
				<!--begin::Body-->
				<div class="d-flex flex-column flex-lg-row-fluid w-lg-50 p-10 order-2 order-lg-1">
					<!--begin::Form-->
					<div class="d-flex flex-center flex-column flex-lg-row-fluid">
						<!--begin::Wrapper-->
						<div class="w-lg-500px p-10">
							<!--begin::Form-->
								<!--begin::Heading-->
								<div class="text-center mb-11">
									<!--begin::Title-->
									<h1 class="text-dark fw-bolder mb-3">Register</h1>
									<!--end::Title-->
									<!--begin::Subtitle-->
									<div class="text-gray-500 fw-semibold fs-6">Welcome to <?php echo htmlspecialchars($sitename); ?></div>
									<!--end::Subtitle=-->
								</div>
								<!--begin::Heading-->
								<!--begin::Login options-->
								<div class="row g-3 mb-9">
								</div>
                                <div id="registerdiv" style="display:none"></div>
								<!--end::Separator-->
								<!--begin::Input group=-->
								<div class="fv-row mb-3">
									<!--begin::Email-->
									<input type="text" id="username" placeholder="Username" name="Username" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Email-->
								</div>
								<!--end::Input group=-->
								<div class="fv-row mb-3">
									<!--begin::Password-->
									<input type="password" id="password" placeholder="Password" name="password" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Password-->
								</div>
                                <div class="fv-row mb-3">
									<!--begin::Password-->
									<input type="password" id="rpassword" placeholder="Confirm Password" name="password" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Password-->
								</div>
                                <div class="fv-row mb-3">
									<!--begin::Email-->
									<input type="email" id="email" placeholder="Email" name="Email" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Email-->
								</div>
                                <div class="fv-row mb-3">
									<!--begin::Email-->
									<input type="text" id="scode" placeholder="1234" name="text" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Email-->
								</div>
                                <div class="fv-row mb-3">
									<!--begin::Email-->
									<input type="text" id="question" placeholder="<?php echo ''.$x1.'+'.$x2.'?'; ?>" name="text" autocomplete="off" class="form-control bg-transparent" />
									<!--end::Email-->
								</div>
								<!--end::Input group=-->
								<!--begin::Submit button-->
								<div class="d-grid mb-10">
									<button onclick="register()" type="submit" class="btn btn-danger">
										<!--begin::Indicator label-->
										<span class="indicator-label">Sign In</span>
										<!--end::Indicator label-->
										<!--begin::Indicator progress-->
										<span class="indicator-progress">Please wait... 
										<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
										<!--end::Indicator progress-->
									</button>
								</div>
								<!--end::Submit button-->
								<!--begin::Sign up-->
								<div class="text-gray-500 text-center fw-semibold fs-6">Already have an account
								<a href="cloud-login.php" class="link-danger">Sign In</a></div>
								<!--end::Sign up-->
							<!--end::Form-->
						</div>
						<!--end::Wrapper-->
					</div>
					<!--end::Form-->
				</div>
				<!--end::Body-->
				<!--begin::Aside-->
				<div class="d-flex flex-lg-row-fluid w-lg-50 bgi-size-cover bgi-position-center order-1 order-lg-2" style="background-image: url(assets/media/auth/bg5-dark.jpg)">
					<!--begin::Content-->
					<div class="d-flex flex-column flex-center py-15 px-5 px-md-15 w-100">
						<!--begin::Title-->
						<h1 class="text-white fs-2qx fw-bolder text-center mb-7">RocketAPI</h1>
						<!--end::Title-->
					<!--end::Content-->
				</div>
				<!--end::Aside-->
			</div>
			<!--end::Authentication - Sign-in-->
		</div>
		<!--end::Root-->
		<!--end::Main-->
		<!--begin::Javascript-->
		<script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="assets/plugins/global/plugins.bundle.js"></script>
		<script src="assets/js/scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Custom Javascript(used by this page)-->
		<script src="assets/js/custom/authentication/sign-in/general.js"></script>
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->

        <script>
		function register()
		{
		var username=$('#username').val();
		var password=$('#password').val();
		var rpassword=$('#rpassword').val();
		var email=$('#email').val();
		var scode=$('#scode').val();
        var question=$('#question').val();
		var answer="<?php echo $x; ?>";
		document.getElementById("registerdiv").style.display="none";
		var xmlhttp;
		if (window.XMLHttpRequest)
		  {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		  }
		else
		  {// code for IE6, IE5
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		xmlhttp.onreadystatechange=function()
		  {
		  if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("registerdiv").innerHTML=xmlhttp.responseText;
			document.getElementById("registerdiv").style.display="inline";
			if (xmlhttp.responseText.search("Redirecting") != -1)
			{
			setInterval(function(){window.location="cloud-login.php"},3000);
			}
			}
		  }
		xmlhttp.open("POST","Endpoints/login.php?type=register",true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("username=" + username + "&password=" + password + "&rpassword=" + rpassword + "&scode=" + scode + "&email=" + email + "&question=" + question + "&answer=" + answer);
		}
		</script> 
	</body>
	<!--end::Body-->
</html>