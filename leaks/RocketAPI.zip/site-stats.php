<?php
include("Repository/header.php");
require_once 'Repository/init.php';



$onedayago = time() - 86400;
   
$twodaysago = time() - 172800;
$twodaysago_after = $twodaysago + 86400;

$threedaysago = time() - 259200;
$threedaysago_after = $threedaysago + 86400;

$fourdaysago = time() - 345600;
$fourdaysago_after = $fourdaysago + 86400;

$fivedaysago = time() - 432000;
$fivedaysago_after = $fivedaysago + 86400;

$sixdaysago = time() - 518400;
$sixdaysago_after = $sixdaysago + 86400;

$sevendaysago = time() - 604800;
$sevendaysago_after = $sevendaysago + 86400;

$monthdaysago = time() - 2628000;
$monthdaysago_after = $monthdaysago + 86400;

$today = time();

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date AND `stopped` = '0'");
$SQL -> execute(array(":date" => $onedayago));
$started_count_one = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
$started_count_two = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
$started_count_three = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
$started_count_four = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
$started_count_five = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
$started_count_six = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '0'");
$SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
$started_count_seven = $SQL->fetchColumn(0);


$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date AND `stopped` = '1'");
$SQL -> execute(array(":date" => $onedayago));
$stopped_count_one = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
$stopped_count_two = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
$stopped_count_three = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
$stopped_count_four = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
$stopped_count_five = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
$stopped_count_six = $SQL->fetchColumn(0);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after AND `stopped` = '1'");
$SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
$stopped_count_seven = $SQL->fetchColumn(0);


$date_one = date('d/m/Y', time());
$date_two = date('d/m/Y', $onedayago);
$date_three = date('d/m/Y', $twodaysago);
$date_four = date('d/m/Y', $threedaysago);
$date_five = date('d/m/Y', $fourdaysago);
$date_six = date('d/m/Y', $fivedaysago);
$date_seven = date('d/m/Y', $sixdaysago);

$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
$SQL -> execute(array(":before" => $monthdaysago, ":after" => time()));
$count_month = $SQL->fetchColumn(0);
$onedayago = time() - 86400;
?>
<body oncontextmenu="return false">
<div class="nk-content ">
<div class="container-fluid">
                    <!--begin::Main-->
					<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
						<!--begin::Content wrapper-->
						<div class="d-flex flex-column flex-column-fluid">
							<!--begin::Toolbar-->
							<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
								<!--begin::Toolbar container-->
								<div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
								</div>
								<!--end::Toolbar container-->
							</div>
							<!--end::Toolbar-->
									<div class="row g-5 g-xl-10">
										<!--begin::Col-->
										<div class="col-xl-4 mb-xl-10">
											<!--begin::Lists Widget 19-->
											<div class="card card-flush h-xl-100">
												<!--begin::Heading-->
												<div class="card-header rounded bgi-no-repeat bgi-size-cover bgi-position-y-top bgi-position-x-center align-items-start h-250px" style="background-image:url('assets/media/svg/shapes/wave-bg-red.svg" data-theme="light">
													<!--begin::Title-->
													<h3 class="card-title align-items-start flex-column text-white pt-15">
														<span class="fw-bold fs-2x mb-3">Hello, <?php echo $_SESSION[username]; ?></span>
														<div class="fs-4 text-white">
															<span class="opacity-75">Welcome to </span>
															<span class="opacity-75"><?php echo htmlspecialchars($sitename)?>s</span>
                                                            <p class="opacity-75">Statistics Page</p>
														</div>
													</h3>
													<!--end::Title-->
												</div>
												<!--end::Heading-->
<!--begin::Body-->
<div class="card-body mt-n20">
													<!--begin::Stats-->
													<div class="mt-n20 position-relative">
														<!--begin::Row-->
														<div class="row g-3 g-lg-6">
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
																<!--begin::FontAwesome Icons-->
                                                                <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-users"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $stats -> totalUsers($odb); ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Total Users</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
			                                                            <!--begin::FontAwesome Icons-->
                                                                        <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-user-check"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $stats -> activeUsers($odb); ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Paid Users</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
	                                                            <!--begin::FontAwesome Icons-->
                                                                <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-clock"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $stats -> runningBoots($odb); ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Running Attacks</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
			                                                          <!--begin::FontAwesome Icons-->
                                                                      <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-percent"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
                                                                    <?php
						                                            $attacks = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `handler` LIKE '%$name%' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
						                                            $load    = round($attacks / $maxattacks * 100, 2);
                                                                    ?>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $load . '%'; ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Network Load</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
														</div>
														<!--end::Row-->
													</div>
													<!--end::Stats-->
												</div>
												<!--end::Body-->
											</div>
											<!--end::Lists Widget 19-->
											</div>
                            <!--begin::Col-->
								<div class="col-xxl-8 mb-5 mb-xl-10">
									<!--begin::Chart widget 28-->
									<div class="card card-flush h-xl-100">
										<!--begin::Header-->
										<div class="card-header py-7">
											<!--begin::Statistics-->
											<div class="m-0">
												<!--begin::Heading-->
												<div class="d-flex align-items-center mb-2">
													<!--begin::Title-->
													<span class="fs-2hx fw-bolder text-danger me-2 lh-1 ls-n2"><?php echo $stats -> totalBoots($odb); ?></span>
													<!--end::Title-->
												</div>
												<!--end::Heading-->
												<!--begin::Description-->
												<span class="fs-6 fw-bold text-gray-400">Total Request</span>
												<!--end::Description-->
											</div>
											<!--end::Statistics-->
										</div>
										<!--end::Header-->
										<!--begin::Body-->
										<div class="card-body d-flex align-items-end ps-4 pe-0 pb-4">
											<!--begin::Chart-->
											<div id="kt_charts_widget_28" class="h-300px w-100 min-h-auto"></div>
											<!--end::Chart-->
										</div>
										<!--end::Body-->
									</div>
									<!--end::Chart widget 28-->
								</div>
								<!--end::Col-->
                                <div class="col-md-4">
									<!--begin::Row-->
									<div class="row">
                                    <div class="card shadow-sm">
    <div class="card-header">
        <h3 class="card-title">Method Statistics</h3>
        <div class="card-toolbar">
		<a href="#" class="btn btn-block btn-bg-light btn-color-danger" data-bs-toggle="modal" data-bs-target="#kt_modal_new_card"><span class="fw-bold">Full List</span></a>
        </div>
    </div>
          <div class="card">
              <div class="card-body">
                  <div class="table-responsive">
                  <table id="kt_datatable_column_rendering" class="table table-striped table-row-bordered gy-5 gs-7">
                          <thead>
                              <tr>
                              <th scope="col">METHOD</th>
                              <th scope="col">ATTACKS</th>
                              </tr>
                          </thead>
                          <tbody>
                            
                        <?php
                      
                        $SQLGetMethods = $odb -> query("SELECT * FROM `logs`");
                        $metodos_limit = 0;
                        while($getInfo = $SQLGetMethods -> fetch(PDO::FETCH_ASSOC)){
                          if (!(isset($Metodos[$getInfo['method']]))) {
                          $Metodos[$getInfo['method']] = 0;
                          }
                          $Metodos[$getInfo['method']] = $Metodos[$getInfo['method']] + 1;
                        }
                        asort($Metodos);
                        $Metodos = array_reverse($Metodos);
                        $Metodos = array_slice($Metodos, 0, 8, true);

                        $Total = 0;


                        foreach ($Metodos as $key => $value) {
                          $Total = $Total + $value;
                        }

                        function get_percentage($total, $number)
                        {
                          if ( $total > 0 ) {
                            return round($number / ($total / 100),2);
                          } else {
                            return 0;
                          }
                        }



                        foreach ($Metodos as $key => $value) {
                          $Porcentaje = get_percentage($Total, $value);
                      
                        if ($Porcentaje >= 0 and $Porcentaje <= 10 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width:'. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 11 and $Porcentaje <= 25 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-info" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 25 and $Porcentaje <= 30 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 40 and $Porcentaje <= 100 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-danger" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }
                      ?>
                            <tr>
                              <th scope="row"><?=htmlspecialchars($key)?></th>
                              <td>
                                  <?=$value?>
                              </td>
                            </tr>
                            <?php } ?>
                          </tbody>
                      </table>
                  </div>
              </div>
              </div>
											</div>
											<!--end::List widget 21-->
										</div>
                                        </div>
                        	<!--end::Col-->
                          <div class="col-xl-8 mb-5 mb-xl-10">
                            									<!--begin::Row-->
									<div class="row">
                                    <div class="card shadow-sm">
    <div class="card-header">
        <h3 class="card-title">Server Statistics</h3>
    </div>
          <div class="card">
              <div class="card-body">
                  <div class="table-responsive">
                  <table id="kt_datatable_column_rendering" class="table table-striped table-row-bordered gy-5 gs-7">
<thead>
<tr>
<th class="">Server</th>
<th class="">Slots</th>
<th class="">Methods</th>
</tr>
</thead>
<tbody> 
          <?php
            $newssql = $odb -> query("SELECT * FROM `api` LIMIT 0,30");
            while($row = $newssql ->fetch()){
              $name = $row['name'];
              $slots = $row['slots'];
              $layer = $row['layer'];
              $methods = $row['methods'];             
              $attacks = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `handler` LIKE '%$name%' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
              $load    = round($attacks / $slots * 100, 2);


                    
              echo'
           <tr>
<td class="">'.htmlspecialchars($name).'</td>
<td class="">'.htmlspecialchars($slots).'</td>
<td class="">'.htmlspecialchars($methods).'</td> ';
          
            }
            ?>
                </ul> 
                          </tbody>
                      </table>
                  </div>
              </div>
              </div>
                    </div>
											<!--end::List widget 21-->

            
              <div class="modal fade" id="kt_modal_new_card" tabindex="-1" aria-hidden="true">
			<!--begin::Modal dialog-->
			<div class="modal-dialog modal-dialog-centered mw-650px">
				<!--begin::Modal content-->
				<div class="modal-content">
					<!--begin::Modal header-->
					<div class="modal-header">
						<!--begin::Modal title-->
						<h2>Full Method List</h2>
						<!--end::Modal title-->
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-1">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Modal header-->
					<!--begin::Modal body-->
					<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
						<!--begin::Form-->
							<!--begin::Input group-->
							<div class="d-flex flex-column mb-7 fv-row">
								<!--begin::Label-->
								<div class="col-lg-12  layout-spacing">
                                <div class="card card-bordered">
<div class="card-body">

<table id="kt_datatable_zero_configuration" class="table table-row-bordered gy-5">

<thead>

  <tr>

    <th>ID</th>
    <th>NAME</th>
    <th>Real Name</th>
    <th>Type</th>
    
  </tr>
  </thead>

  <tbody>

    <?php
            $SQLGetMethods2 = $odb->query("SELECT * FROM `methods`");
            while ($getInfo = $SQLGetMethods2->fetch(PDO::FETCH_ASSOC)) 
                {
                    $id     = $getInfo['id'];
                    $name     = $getInfo['name'];
                    $fullname = $getInfo['fullname'];
                    $type = $getInfo['type'];
                     echo'
  <tr>

  <td>'.htmlspecialchars($id).'</td>
  <td>'.htmlspecialchars($name).'</td>
  <td>'.htmlspecialchars($fullname).'</td>
  <td>'.htmlspecialchars($type).'</td>

  </tr>
</div>
</div>
</div>
';
}
?>
</tbody>
</table>
							</div>
							<!--end::Input group-->
						<!--end::Form-->
					</div>
					<!--end::Modal body-->
				</div>
				<!--end::Modal content-->
			</div>
			<!--end::Modal dialog-->
		</div>
        <div class="modal fade" id="kt_modal_new_card2" tabindex="-1" aria-hidden="true">
			<!--begin::Modal dialog-->
			<div class="modal-dialog modal-dialog-centered mw-650px">
				<!--begin::Modal content-->
				<div class="modal-content">
					<!--begin::Modal header-->
					<div class="modal-header">
						<!--begin::Modal title-->
						<h2>Full Method List</h2>
						<!--end::Modal title-->
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-1">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Modal header-->
					<!--begin::Modal body-->
					<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
						<!--begin::Form-->
							<!--begin::Input group-->
							<div class="d-flex flex-column mb-7 fv-row">
								<!--begin::Label-->
								<div class="col-lg-12  layout-spacing">
							</div>
							<!--end::Input group-->
						<!--end::Form-->
					</div>
					<!--end::Modal body-->
				</div>
				<!--end::Modal content-->
			</div>
			<!--end::Modal dialog-->
		</div>

<script>

var one = "<?php echo $date_one; ?>";
var two = "<?php echo $date_two; ?>";
var three = "<?php echo $date_three; ?>";
var four = "<?php echo $date_four; ?>";
var five = "<?php echo $date_five; ?>";
var six = "<?php echo $date_six; ?>";
var seven = "<?php echo $date_seven; ?>";
// Webpack support
if (typeof module !== 'undefined') {
    module.exports = KTChartsWidget27;
}

// On document ready
KTUtil.onDOMContentLoaded(function() {
    KTChartsWidget27.init();
});


 
"use strict";

// Class definition
var KTChartsWidget28 = function () {
    var chart = {
        self: null,
        rendered: false
    };
    
    // Private methods
    var initChart = function(chart) {
        var element = document.getElementById("kt_charts_widget_28");

        if (!element) {
            return;
        }
        
        var height = parseInt(KTUtil.css(element, 'height'));
        var labelColor = KTUtil.getCssVariableValue('--kt-gray-500');
        var borderColor = KTUtil.getCssVariableValue('--kt-border-dashed-color');
        var baseColor = KTUtil.getCssVariableValue('--kt-danger');         

        var options = {
            series: [{
                name: 'Attacks',
                data: [<?php echo $started_count_one; ?>, <?php echo $started_count_two; ?>, <?php echo $started_count_three; ?>, <?php echo $started_count_four; ?>, <?php echo $started_count_five; ?>, <?php echo $started_count_six; ?>, <?php echo $started_count_seven; ?>]
			}, {
        name: 'Stopped',
		data: [<?php echo $started_count_one; ?>, <?php echo $started_count_two; ?>, <?php echo $started_count_three; ?>, <?php echo $started_count_four; ?>, <?php echo $started_count_five; ?>, <?php echo $started_count_six; ?>, <?php echo $started_count_seven; ?>]
    }],     
            chart: {
                fontFamily: 'inherit',
                type: 'area',
                height: height,
                toolbar: {
                    show: false
                }
            },            
            legend: {
                show: false
            },
            dataLabels: {
                enabled: false
            },
            fill: {
                type: "gradient",
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.4,
                    opacityTo: 0,
                    stops: [0, 80, 100]
                }
            },
            stroke: {
                curve: 'smooth',
                show: true,
                width: 3,
                colors: [baseColor]
            },
            xaxis: {
                categories: ['May 04', 'May 05', 'May 06', 'May 09', 'May 10', 'May 12', 'May 14', 'May 17', 'May 18', 'May 20', 'May 22', 'May 24', 'May 26', 'May 28', 'May 30'],
                axisBorder: {
                    show: false,
                },
                offsetX: 20,
                axisTicks: {
                    show: false
                },
                tickAmount: 3,
                labels: {
                    rotate: 0,
                    rotateAlways: false,
                    style: {
                        colors: labelColor,
                        fontSize: '12px'                        
                    }
                },
                crosshairs: {
                    position: 'front',
                    stroke: {
                        color: baseColor,
                        width: 1,
                        dashArray: 3
                    }
                },
                tooltip: {
                    enabled: true,
                    formatter: undefined,
                    offsetY: 0,
                    style: {
                        fontSize: '12px'
                    }
                }
            },
            yaxis: {
                tickAmount: 4,
                max: 250,
                min: 100,
                labels: {
                    style: {
                        colors: labelColor,
                        fontSize: '12px'
                    },
                    formatter: function (val) {
                        return val 
                    }
                }
            },
            states: {
                normal: {
                    filter: {
                        type: 'none',
                        value: 0
                    }
                },
                hover: {
                    filter: {
                        type: 'none',
                        value: 0
                    }
                },
                active: {
                    allowMultipleDataPointsSelection: false,
                    filter: {
                        type: 'none',
                        value: 0
                    }
                }
            },
            tooltip: {
                style: {
                    fontSize: '12px'
                },
                y: {
                    formatter: function (val) {
                        return val 
                    }
                }
            },
            colors: [baseColor],
            grid: {
                borderColor: borderColor,
                strokeDashArray: 4,
                yaxis: {
                    lines: {
                        show: true
                    }
                }
            },
            markers: {
                strokeColor: baseColor,
                strokeWidth: 3
            }
        };

        chart.self = new ApexCharts(element, options);

        // Set timeout to properly get the parent elements width
        setTimeout(function() {
            chart.self.render();
            chart.rendered = true;
        }, 200);  
    }

    // Public methods
    return {
        init: function () {
            initChart(chart);

            // Update chart on theme mode change
            KTThemeMode.on("kt.thememode.change", function() {                
                if (chart.rendered) {
                    chart.self.destroy();
                }

                initChart(chart);
            });
        }   
    }
}();
</script>