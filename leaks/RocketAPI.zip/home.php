
<?php
include("Repository/header.php");
function refreshPage(){
    window.location.reload();
} 


?>
                <script>
			function redeemCode() {
				var code = $('#code').val();
				document.getElementById("redeemdiv").style.display="inline"; 
				var xmlhttp;
				if (window.XMLHttpRequest) {
					xmlhttp=new XMLHttpRequest();
				}
				else {
					xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) {

                        document.getElementById("redeemdiv").innerHTML=xmlhttp.responseText;
			            document.getElementById("redeemdiv").style.display="inline";
						if (xmlhttp.responseText.search("SUCCESS") != -1) {
							inbox();
						}
					}
				}
				xmlhttp.open("GET","Endpoints/token-system.php?user=<?php echo htmlspecialchars($_SESSION['ID']); ?>" + "&code=" + code,true);
				xmlhttp.send();
			}
			</script>
            <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!--begin::Main-->
<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
						<!--begin::Content wrapper-->
						<div class="d-flex flex-column flex-column-fluid">
							<!--begin::Toolbar-->
							<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
								<!--begin::Toolbar container-->
								<div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
								</div>
								<!--end::Toolbar container-->
							</div>
							<!--end::Toolbar-->
							<!--begin::Content-->
                            <!--begin::Engage widget 4-->
                            <div id="kt_app_content" class="app-content flex-column-fluid">
								<!--begin::Content container-->
								<div id="kt_app_content_container" class="app-container container-xxl">
											<div class="card border-transparent" data-theme="dark">
												<!--begin::Body-->
												<div class="card-body d-flex ps-xl-15">
													<!--begin::Wrapper-->
													<div class="m-0">
														<!--begin::Title-->
														<div class="position-relative fs-2x z-index-2 fw-bold text-white mb-7">
														<span class="me-2">Want to Buy?
														<span class="position-relative d-inline-block text-danger">
															<a href="store.php" class="text-danger opacity-75-hover">Click Here</a>
															<!--begin::Separator-->
															<span class="position-absolute opacity-50 bottom-0 start-0 border-4 border-danger border-bottom w-100"></span>
															<!--end::Separator-->
														</span></span>
														<br />Cheap and Fast Process</div>
                                                        <span></span>
														<!--end::Title-->
														<!--begin::Action-->
                                                        <a href="#" class="btn btn-block btn-danger er fs-6 px-8 py-4" data-bs-toggle="modal" data-bs-target="#kt_modal_new_card"><span class="fw-bold">Insert Token Here</span></a>
														<!--begin::Action-->
													</div>
													<!--begin::Wrapper-->
													<!--begin::Illustration-->
													<img src="assets/Profile2.png" class="position-absolute me-3 bottom-0 end-0 h-200px" alt="" />
													<!--end::Illustration-->
												</div>
												<!--end::Body-->
											</div>
											<!--end::Engage widget 4-->
										</div>
										<!--end::Col-->
									</div>
									<!--end::Row-->
							<div id="kt_app_content" class="app-content flex-column-fluid">
								<!--begin::Content container-->
								<div id="kt_app_content_container" class="app-container container-xxl">
									<!--begin::Row-->
									<div class="row g-5 g-xl-10">
										<!--begin::Col-->
										<div class="col-xl-4 mb-xl-10">
											<!--begin::Lists Widget 19-->
											<div class="card card-flush h-xl-100">
												<!--begin::Heading-->
												<div class="card-header rounded bgi-no-repeat bgi-size-cover bgi-position-y-top bgi-position-x-center align-items-start h-250px" style="background-image:url('assets/media/svg/shapes/wave-bg-red.svg" data-theme="light">
													<!--begin::Title-->
													<h3 class="card-title align-items-start flex-column text-white pt-15">
														<span class="fw-bold fs-2x mb-3">Hello, <?php echo $_SESSION[username]; ?></span>
														<div class="fs-4 text-white">
															<span class="opacity-75">You have</span>
															<span class="position-relative d-inline-block">
																<a href="" style="color:#B2506D" class="opacity-75-hover fw-bold d-block mb-1"><?php echo $total_my_attacks; ?></a>
																<!--begin::Separator-->
																<span class="position-absolute opacity-50 bottom-0 start-0 border-2 border-body border-bottom w-100"></span>
																<!--end::Separator-->
															</span>
															<span class="opacity-75">Attacks today.</span>
                                                            <p class="opacity-75">Down Below is Users Stats</p>
														</div>
													</h3>
													<!--end::Title-->
												</div>
												<!--end::Heading-->
												<!--begin::Body-->
												<div class="card-body mt-n20">
													<!--begin::Stats-->
													<div class="mt-n20 position-relative">
														<!--begin::Row-->
														<div class="row g-3 g-lg-6">
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
																<!--begin::FontAwesome Icons-->
                                                                <span class="icon-item">
														<i style="color:#B2506D" class="fa-brands fa-artstation"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $total_my_attacks; ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Total Attacks</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
			                                                            <!--begin::FontAwesome Icons-->
                                                                        <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-rocket"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $my_running_attacks; ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Running Attacks</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
	                                                            <!--begin::FontAwesome Icons-->
                                                                <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-clock"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $rowxd[mbt]; ?> <span class="text-gray-500 fw-semibold fs-6">Sec</span></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Users Max time</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
															<!--begin::Col-->
															<div class="col-6">
																<!--begin::Items-->
																<div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
																	<!--begin::Symbol-->
																	<div class="symbol symbol-30px me-5 mb-8">
																		<span class="symbol-label">
			                                                          <!--begin::FontAwesome Icons-->
                                                                      <span class="icon-item">
														<i style="color:#B2506D" class="fas fa-splotch"></i>
														</span>
														<!--end::FontAwesome Icons-->
																		</span>
																	</div>
																	<!--end::Symbol-->
																	<!--begin::Stats-->
																	<div class="m-0">
																		<!--begin::Number-->
																		<span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo $total_user_tokens; ?></span>
																		<!--end::Number-->
																		<!--begin::Desc-->
																		<span class="text-gray-500 fw-semibold fs-6">Spent Tokens</span>
																		<!--end::Desc-->
																	</div>
																	<!--end::Stats-->
																</div>
																<!--end::Items-->
															</div>
															<!--end::Col-->
														</div>
														<!--end::Row-->
													</div>
													<!--end::Stats-->
												</div>
												<!--end::Body-->
											</div>
											<!--end::Lists Widget 19-->
										</div>
										<!--end::Col-->
                                        <div class="col-xl-8 mb-5 mb-xl-10">
                                    <!--begin::Body-->
                                        <?php
													$newssql = $odb -> query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 5");
													while($row = $newssql ->fetch())
													{
													$id = $row['ID'];
													$title = $row['title'];
													$content = $row['content'];
													$date = date("m/d/Y", $row['date']);


                                                    echo ' <div class="card-body pt-0">
													<!--begin::Item-->
													<div class="d-flex align-items-center rounded p-5 mb-7">
			                                                          <!--begin::FontAwesome Icons-->
                                                                      <span class="icon-item  m-3">
														<i style="color:#BC395C" class="fas fa-laptop fs-2x"></i>
														</span>
														<!--end::FontAwesome Icons-->
														<!--begin::Title-->
														<div class="flex-grow-1 me-2">
															<a class="fw-bold text-white fs-6">'.htmlspecialchars($title).'</a>
															<span class="fw-bold text-danger d-block">'.htmlspecialchars($content).'</span>
														</div>
														<!--end::Title-->
														<!--begin::Lable-->
														<span class="fw-bold text-white py-1">'.$date.'</span>
														<!--end::Lable-->
													</div>
													';
												}
												?>
													<!--end::Item-->
												</div>
												<!--end::Body-->
											</div>
											<!--end::List Widget 6-->
										</div>
									</div>
									<!--end::Row-->
                                        </div>
		<div class="modal fade" id="kt_modal_new_card" tabindex="-1" aria-hidden="true">
			<!--begin::Modal dialog-->
			<div class="modal-dialog modal-dialog-centered mw-650px">
				<!--begin::Modal content-->
				<div class="modal-content">
					<!--begin::Modal header-->
					<div class="modal-header">
						<!--begin::Modal title-->
						<h2>Redeem Token!</h2>
						<!--end::Modal title-->
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-1">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Modal header-->
					<!--begin::Modal body-->
					<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
						<!--begin::Form-->
							<!--begin::Input group-->
							<div class="d-flex flex-column mb-7 fv-row">
								<!--begin::Label-->
                                <div id="redeemdiv" style="display:none"></div>
								<label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
									<span class="required">Token Here</span>
									<i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Rocket tokens are the currency for buying products."></i>
								</label>
								<!--end::Label-->
								<input type="text" class="form-control form-control-solid" id="code" placeholder="XXXXXXXXXXXXX" name="token" value="" />
							</div>
							<!--end::Input group-->
							<!--begin::Actions-->
							<div class="text-center pt-10">
								<button onclick="redeemCode()" type="submit" class="btn btn-danger">
									<span class="indicator-label">Spend Token</span>
									<span class="indicator-progress">Please wait... 
									<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
								</button>
							</div>
							<!--end::Actions-->
						<!--end::Form-->
					</div>
					<!--end::Modal body-->
				</div>
				<!--end::Modal content-->
			</div>
			<!--end::Modal dialog-->
		</div>
		<!--end::Modal - New Card-->
                                </div>
                                