
<?php
include("header.php");  
if (!($user -> isAdmin($odb)))
{
    header('location: ../home.php');
    die();
}
?>
<div class="nk-content ">
<div class="container-fluid">

        <!-- start page title -->
<div class="row">
<div class="col-lg-12">
		<div class="card">

			<div class="card-body">
					
<table id="datatable" class="table dt-responsive  nowrap w-100">
						<thead>
								<tr>
									<th style="font-size: 20px;">Client ID</th>
									<th style="font-size: 20px;">Host</th>
                                    <th style="font-size: 20px;">Port</th>
                                    <th style="font-size: 20px;">Method</th>
									<th style="font-size: 20px;">Time</th>
									<th style="font-size: 20px;">Date</th>
									<th style="font-size: 20px;">Handler</th>
								</tr>
							</thead>
							<div class='panel-Body scroll' id='messageBody'></div>
							
							<tbody style="font-size: 12px;">
							<?php
							$SQLGetLogs = $odb -> query("SELECT * FROM `logs` ORDER BY `date` DESC LIMIT 100000");
							while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC)){
								$user = $getInfo['user'];
								$host = $getInfo['ip'];
								if (filter_var($host, FILTER_VALIDATE_URL)) {$port='';} else {$port=''.$getInfo['port'];}
								$time = $getInfo['time'];
								$method = $getInfo['method'];
								$handler = $getInfo['handler'];
								$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
								
								echo '<tr>
										<td><span class="badge">'.htmlspecialchars($user).'</span></td>
										<td><span class="badge">'.htmlspecialchars($host).'</span></td>
                    <td><span class="badge">'.htmlspecialchars($port).'</span></td>
                    <td><span class="badge">'.htmlspecialchars($method).'</span></td>
										<td><span class="badge">'.htmlspecialchars($time).'</span></td>
										<td>'.htmlspecialchars($date).'</td>
										<td><span class="badge ">'.htmlspecialchars($handler).'</span></td>
									  </tr>';
							}
								
							?>	
							</tbody>                                    
					</table>
			</div>
            </div>

</body>
</html>