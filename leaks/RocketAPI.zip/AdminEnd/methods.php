<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}
?>
<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />	
<div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">					
			  								<div class="col-md-12 grid-margin stretch-card">	
                                   <div class="card">
                                   <div class="card-header">
      <h4 class="card-title">Available Methods</h4>
    </div>
								     <table class="table">
 										<form method="post">
                                        <tr>
                                            <th>Name</th>
											<th>Tag</th>
											<th>Type</th>
											<th>Delete</th>
                                        </tr>
                                        <tr>
										<form method="post">


<?php

$SQLGetMethods = $odb -> query("SELECT * FROM `methods`");
while($getInfo = $SQLGetMethods -> fetch(PDO::FETCH_ASSOC))
{
 $id = $getInfo['id'];
 $name = $getInfo['name'];
 $fullname = $getInfo['fullname'];
 $type = $getInfo['type'];
 echo '<tr><td>'.htmlspecialchars($name).'</td><td>'.htmlspecialchars($fullname).'</td><td>'.$type.'</td><td><button type="submit" title="Delete API" name="deletem" value="'.htmlspecialchars($id).'" class="btn btn-danger btn-icon"><i data-feather=""></i></button></td></tr>';
}
if (isset($_POST['deletem']))
{
$delete = $_POST['deletem'];
$SQL = $odb -> prepare("DELETE FROM `methods` WHERE `id` = :id");
$SQL -> execute(array(':id' => $delete));
echo success('Methods has been removed <meta http-equiv="refresh" content="3;url=methods.php">');
}
?>
</form>
                                        </tr>                                       
                                    </table>
									</div>
									  </div>
                                      <br>
                                      <div class="row">
                        <div class="col-md-12">
                            <div class="card">
							<div class="card-header">
      <h4 class="card-title">Method Manager</h4>
    </div>
                                <div class="card-body">
                                <div class="block-content controls">
								<form method="post">
								<?php

if (isset($_POST['add']))
{
if (empty($_POST['name']) || empty($_POST['fullname']) || empty($_POST['type']))
{
$error = 'Please verify all fields';
}

if (empty($error))
{
$name = $_POST['name'];
$fullname = $_POST['fullname'];
$type = $_POST['type'];
if ($system=='servers') {$command = $_POST['command'];} else {$command = '';}
$SQLinsert = $odb -> prepare("INSERT INTO `methods` VALUES(NULL, :name, :fullname, :type, :command)");
$SQLinsert -> execute(array(':name' => $name, ':fullname' => $fullname, ':type' => $type, ':command' => $command));
echo success2('Method has been added <meta http-equiv="refresh" content="3;url=methods.php">');
}
else
{
echo error2($error);
}
}
?>
                                    <div class="row-form">
                                        <div class="col-md-4"><strong>Real Name:</strong></div>
                                        <div class="col-md-12"><input type="text" class="form-control tip" title="This will be used when executing the attack" name="name"/></div>
                                    </div>
                                    <div class="row-form">
                                        <div class="col-md-4"><strong>Tag Name:</strong></div>
                                        <div class="col-md-12"><input type="text" class="form-control tip" title="This will be used on the Hub page" name="fullname"/></div>
                                    </div>
                                    <div class="row-form">
                                        <div class="col-md-4"><strong>Type:</strong></div>
                                        <div class="col-md-12">
                                            <select name="type" class="form-control">
									<option value="amp">Amplification Methods - L4</option>
                                    <option value="raw">RAW Methods - L4</option>
									<option value="game">Game Methods - L4</option>
                                    <option value="bypass">Bypass Methods - L4</option>
                                    <option value="vip">VIP Methods - VIP L4</option>
                                    <option value="l7">Layer 7 Methods - L7</option>
									<option value="l7vip">Layer 7 Methods - VIP L7 </option>
                                            </select>
                                        </div>
                                    </div>	
																		 <div class="card-body">
									<div  class="col-xs-4 text-center" >
                                     <button name="add" class="btn btn-primary">Update</button>
                                </div> 
							  </div>					