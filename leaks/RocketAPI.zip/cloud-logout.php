<!-- frontend for cloud-logout --><?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['ID']);
session_destroy();
header('location: cloud-login.php');
?>
<body oncontextmenu="return false">