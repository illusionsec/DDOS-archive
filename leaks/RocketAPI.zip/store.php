<?php
include("Repository/header.php");
?>
<!--begin::Main-->
<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
						<!--begin::Content wrapper-->
						<div class="d-flex flex-column flex-column-fluid">
							<!--begin::Toolbar-->
							<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
								<!--begin::Toolbar container-->
								<div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
								</div>
								<!--end::Toolbar container-->
							</div>
							<!--end::Toolbar-->
                            <div class="card-body">
                            <table id="kt_datatable_zero_configuration" class="table table-row-bordered gy-5">
                    <thead>
                    <tr>
                    <th class="text-center">Name</th>
                      <th class="text-center">Price</th>
                      <th class="text-center">Attack Time</th>
                      <th class="text-center">Concurrent</th>
                    <th class="text-center">Length</th>
                    <th class="text-center">Duration</th>
                    <th class="text-center">API Access</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    </thead>

 <tbody class="text-center">
<?php 
    $SQLGetPlans = $odb -> query("SELECT * FROM `plans` WHERE `private` = 0 ORDER BY `ID` ASC");
    while ($getInfo = $SQLGetPlans -> fetch(PDO::FETCH_ASSOC))
    {
        $id = $getInfo['ID'];
        $name = $getInfo['name'];
        $price = $getInfo['price'];
        $length = $getInfo['length'];
        $unit = $getInfo['unit'];
        $concurrents = $getInfo['concurrents'];
        $mbt = $getInfo['mbt'];
        $apiaccess = $getInfo['apiaccess'];
        if($apiaccess == 0)
{
$apiaccess = "No";
}
else 
{
$apiaccess = "Yes";
}
        echo'
        <tr>
            <td>'.htmlspecialchars($name).'</td>
            <td id="totalDue">$'.htmlentities($price).'<small></td>
            <td>'.$mbt.' Seconds</td>
            <td>'.htmlentities($concurrents).'</td>
            <td>'.htmlentities($length).'</td>
            <td>'.htmlspecialchars($unit).'</td>
            <td>'.htmlentities($apiaccess).'</td>
            <td>
            <form method="POST"><a href="error.html" class="btn btn-success btn-block "><i class="dripicons-store" style="color: #30C730" aria-hidden="true"></i> Buy</button></form>
            </td>
        </tr>
        <div class="modal fade" id="defaultsizemodal'.$id.'">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post"></form>
                    <div class="modal-header">
                        <h5 class="modal-title">Plan Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i class="fas fa-times" aria-hidden="true"></i> Close</button>
                    </div>
                </div>
            </div>
        </div>
        ';
    }
?>
</tbody>
</table>
</div>
</div>
</div>