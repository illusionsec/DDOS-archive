<?php
include("Repository/header.php");
if(!isset($_POST['keyBtn']))

{

    $SQLGetKey = $odb -> prepare("SELECT `apikey` FROM `users` WHERE `ID` = :id");

    $SQLGetKey -> execute(array(':id' => $_SESSION['ID']));

    $userKey = $SQLGetKey -> fetchColumn(0);

    if(isset($_POST['disable_key'])){
        if(isset($_SESSION['username'])){
            disableKey($_SESSION['username'], $odb);
            header('Location: api-manager.php');
        }
    }
}



else

{

    function generateRandomKey($length = 15) 

    {

        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';

        $randomString = '';

        for ($i = 0; $i < $length; $i++) {

            $randomString .= $characters[rand(0, strlen($characters) - 1)];

        }

        return $randomString;

    }

    

    $userKey = generateRandomKey();

    
    $SQLNewKey = $odb -> prepare("UPDATE `users` SET `apikey` = :newkey WHERE `ID` = :id");

    $SQLNewKey -> execute(array(':newkey' => $userKey, ':id' => $_SESSION['ID']));

}
//function to disable API key
    function disableKey($username, $odb){
    $stmt2 = $odb->query("UPDATE users SET apikey='No Key Assigned' WHERE username='$username'");
} 
?> 

<body oncontextmenu="return false">
<div class="nk-content ">
<div class="container-fluid">
<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
						<!--begin::Content wrapper-->
						<div class="d-flex flex-column flex-column-fluid">
							<!--begin::Toolbar-->
							<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
								<!--begin::Toolbar container-->
								<div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
								</div>
								<!--end::Toolbar container-->
							</div>
							<!--end::Toolbar-->
<div id="kt_app_content" class="app-content flex-column-fluid">
								<!--begin::Content container-->
								<div id="kt_app_content_container" class="app-container container-xxl">
									<!--begin::Row-->
									<div class="row g-5 g-xl-10">
										<!--begin::Col-->
										<div class="col-xl-4 mb-xl-10">
											<!--begin::Lists Widget 19-->
											<div class="card card-flush h-xl-100">
												<!--begin::Heading-->
												<div class="card-header rounded bgi-no-repeat bgi-size-cover bgi-position-y-top bgi-position-x-center align-items-start h-250px" style="background-image:url('assets/media/svg/shapes/wave-bg-red.svg" data-theme="light">
													<!--begin::Title-->
													<h3 class="card-title align-items-start flex-column text-white pt-15">
														<span class="fw-bold fs-2x mb-3">Hello api user</span>
														<div class="fs-4 text-white">
															<span class="fw-bold opacity-75">This is your API KEY</span>
															<span class="position-relative d-inline-block">
																<!--begin::Separator-->
																<span class="position-absolute opacity-50 bottom-0 start-0 border-2 border-body border-bottom w-100"></span>
																<!--end::Separator-->
															</span>
                                                            <form action="" method="POST">
                                                            <p class="text-danger opacity-75"><?php echo htmlspecialchars ($userKey);?></p>
														</div>
                                                        <button type="submit" class="btn btn-block btn-danger" name="keyBtn">Assign Key</button>
													</h3>
													<!--end::Title-->
												</div>
												<!--end::Heading-->
												<!--begin::Body-->
											</div>
											<!--end::Lists Widget 19-->
										</div>
										<!--end::Col-->
                                        <div class="card card-bordered">
    <div class="card-body">
        <h3 class="card-title m-5 fw-bold">API Link</h3>
        <!--begin::Input group-->
        <div class="input-group">
            <!--begin::Input-->
            <input id="kt_clipboard_1" type="text" class="form-control" readonly="" value="http://localhost/Endpoints/apistart.php?key=<?php echo htmlspecialchars ($userKey);?>&host=[host]&port=[port]&time=[time]&method=[method]&username=[username]" placeholder="http://localhost/Endpoints/apistart.php?key=<?php echo htmlspecialchars ($userKey);?>&host=[host]&port=[port]&time=[time]&method=[method]&username=[username]" />
            <!--end::Input-->

            <!--begin::Button-->
            <button class="btn btn-light-danger" data-clipboard-target="#kt_clipboard_1">
                Copy
            </button>
            <!--end::Button-->
        </div>
        <!--begin::Input group-->
    </div>
</div>
<div class="card card-bordered">
<div class="card-body">
<h3 class="card-title m-5 fw-bold">API Method List</h3>

<table id="kt_datatable_zero_configuration" class="table table-row-bordered gy-5">

<thead>

  <tr>

    <th>ID</th>
    <th>NAME</th>
    <th>Real Name</th>
    <th>Type</th>
    
  </tr>
  </thead>

  <tbody>

    <?php
            $SQLGetMethods2 = $odb->query("SELECT * FROM `methods`");
            while ($getInfo = $SQLGetMethods2->fetch(PDO::FETCH_ASSOC)) 
                {
                    $id     = $getInfo['id'];
                    $name     = $getInfo['name'];
                    $fullname = $getInfo['fullname'];
                    $type = $getInfo['type'];
                     echo'
  <tr>

  <td>'.htmlspecialchars($id).'</td>
  <td>'.htmlspecialchars($name).'</td>
  <td>'.htmlspecialchars($fullname).'</td>
  <td>'.htmlspecialchars($type).'</td>

  </tr>
</div>
</div>
</div>
';
}
?>
</tbody>
</table>
</div>
</div>
</div>

    </div>
</div>

                                        <script>
                                            // Select elements
// Select elements
const target = document.getElementById('kt_clipboard_1');
const button = target.nextElementSibling;

// Init clipboard -- for more info, please read the offical documentation: https://clipboardjs.com/
var clipboard = new ClipboardJS(button, {
    target: target,
    text: function() {
        return target.value;
    }
});

// Success action handler
clipboard.on('success', function(e) {
    const currentLabel = button.innerHTML;

    // Exit label update when already in progress
    if(button.innerHTML === 'Copied!'){
        return;
    }

    // Update button label
    button.innerHTML = 'Copied!';

    // Revert button label after 3 seconds
    setTimeout(function(){
        button.innerHTML = currentLabel;
    }, 3000)
});
</script>