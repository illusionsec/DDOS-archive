<?php
header("Location: http://localhost/store.php");
exit();
?>