Most of the projects FB has created in Golang, leaked because of his own dumbness.

Kaboom - A custom made scripting markup language created to interact more easily and efficiently with any application, currently used in CNC's and WEB (Inspired by TFX2) 

Nosviak3 - His biggest and most complex SSH CNC to be made, it has new features such as: TAB completion which includes a drop down menu, hover effects, arrow keys/WASD navigation support & autofill in a low opacity. It also includes a new optimized reader and his newest way of initiating config files.

GoGuard - A new licensing system manager which uses a WEB3 dashboard to control everything from a nice user interface. It includes, FamilyTREE for parent and child recognition, secure token redirects, a custom HyperText Writer and a Database adapter for beginners to use and a huge API to send requests to. This API can also be interacted with through JS to display certain values on the pages.

Martian - A custom source which is built for use of buttons and click events. A addition to this is GoEYE very interactive, (unfinished) but still has the core features.

Also a few other things such as Nosviak 1 and 2 whatever i could find i dropped it in here, go find out for yourself what they are.

Leaked by Bermuda aka Bermuda.SH
Instagram: onebermuda
