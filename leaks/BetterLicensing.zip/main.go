package main

import (
	"bufio"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"math/rand"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

var (
	DB       *sql.DB
	Licenses []License
)

type License struct {
	username   string
	key        string
	expiration string
	ip         string
	locked     int
}

type Config struct {
	WebPort       string `json:"WebPort"`
	Port          string `json:"Port"`
	ServerPort    string `json:"ServerPort"`
	DiscordHook   string `json:"DiscordHook"`
	TelegramToken string `json:"TelegramToken"`
	TelegramChat  string `json:"TelegramChat"`
	Locked        bool   `json:"Locked"`
	Version       string `json:"Version"`
}

var Cfg Config

func GenerateKey() string {
	rand.Seed(time.Now().UnixNano())
	chars := []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
	token := make([]rune, 13)
	for i := 0; i < 4; i++ {
		token[i] = chars[rand.Intn(len(chars))]
	}
	token[4] = '-'
	for i := 5; i < 10; i++ {
		token[i] = chars[rand.Intn(len(chars))]
	}
	token[10] = '-'
	for i := 11; i < 13; i++ {
		token[i] = chars[rand.Intn(len(chars))]
	}
	return string(token)
}

func CreateLicense(username string, expiration time.Time, ip string) (string, error) {
	sqlStmt := `INSERT INTO licenses (username, key, expiration, ip, locked) VALUES (?, ?, ?, ?, ?);`
	key := GenerateKey()
	_, err := DB.Exec(sqlStmt, username, key, expiration.Format("02-01-2006"), ip, 0)
	if err != nil {
		return "", err
	}
	Licenses = append(Licenses, License{username, key, expiration.Format("02-01-2006"), ip, 0})
	return key, nil
}

func LoadLicenses() {
	rows, err := DB.Query("SELECT * FROM `licenses`")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	for rows.Next() {
		var license License
		err = rows.Scan(&license.username, &license.key, &license.expiration, &license.ip, &license.locked)
		if err != nil {
			fmt.Println(err)
			os.Exit(1)
		}
		Licenses = append(Licenses, license)
	}
}

func Connect() {
	var err error
	DB, err = sql.Open("sqlite", "./licenses.db")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	err = DB.Ping()
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	sqlStmt := `CREATE TABLE IF NOT EXISTS licenses (username TEXT NOT NULL, key TEXT PRIMARY KEY NOT NULL, expiration TEXT NOT NULL, ip TEXT NOT NULL, locked INT NOT NULL);`
	_, err = DB.Exec(sqlStmt)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func ValidateLicense(key string, ip string, first string) bool {
	for _, license := range Licenses {
		if license.locked == 1 || Cfg.Locked == true {
			return false
		}
		if license.key == key && license.ip == ip {
			expiration, err := time.Parse("02-01-2006", license.expiration)
			if err != nil {
				fmt.Println(err)
				return false
			}
			if expiration.After(time.Now()) {
				if first == "" {
				}
				return true
			}
		}
	}
	return false
}

func ConnectionHandler(port string) {
	server, err := net.ListenPacket("udp", "0.0.0.0:"+port)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	for {
		buffer := make([]byte, 1024)
		n, addr, err := server.ReadFrom(buffer)
		if err != nil {
			fmt.Println(err)
		}
		buff := strings.Split(string(buffer[:n]), ";")
		if len(buff) < 2 {
			server.WriteTo([]byte("invalid"), addr)
			break
		}
		key := buff[0]
		ip := buff[1]
		var first string
		if len(buff) >= 3 {
			first = buff[2]
		}
		if ValidateLicense(key, ip, first) {
			server.WriteTo([]byte("valid"), addr)
		} else {
			server.WriteTo([]byte("invalid"), addr)
		}
	}
}

func LoadConfig() {
	file, err := ioutil.ReadFile("./config.json")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	err = json.Unmarshal(file, &Cfg)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func getAllFiles(dirPath string) ([]string, error) {
	var files []string

	err := filepath.Walk(dirPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			files = append(files, path)
		}
		return nil
	})

	return files, err
}

func sendFile(conn net.Conn, filePath string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	fileInfo, _ := file.Stat()
	fileName := fileInfo.Name()
	fileSize := fileInfo.Size()
	conn.Write([]byte(fmt.Sprintf("%s,%d\n", fileName, fileSize)))

	_, err = io.Copy(conn, file)
	if err != nil {
		return err
	}

	return nil
}

func StartUpdateServer() {
	listenAddr := ":" + Cfg.ServerPort
	listener, err := net.Listen("tcp", listenAddr)
	if err != nil {
		return
	}
	defer listener.Close()
	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		uploadPath := "./upload"

		files, err := getAllFiles(uploadPath)
		if err != nil {
			return
		}

		for _, file := range files {
			err = sendFile(conn, file)
			if err != nil {
				return
			}
		}
		conn.Close()
	}
}

func StartWebServer() {
	http.HandleFunc("/version", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(Cfg.Version))
	})
	err := http.ListenAndServe(":"+Cfg.WebPort, nil)
	if err != nil {
		fmt.Println(err)
	}
}

func GetServerIP() string {
	resp, err := http.Get("https://api.ipify.org/")
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	return string(body)
}

func CreateLicenseFile(license License) {
	file, err := os.Create("./licenses/" + license.username + ".key")
	if err != nil {
		fmt.Println(err)
	}
	defer file.Close()
	str := license.username + "\r\n" + license.key + "\r\n" + license.expiration + "\r\n" + license.ip + "\r\n" + Cfg.Port + "\r\n" + Cfg.WebPort + "\r\n" + GetServerIP() + "\r\n" + Cfg.Version + "\r\n" + Cfg.ServerPort
	encoded := base64.StdEncoding.EncodeToString([]byte(str + "UwUGirl101"))
	_, err = file.WriteString(encoded)
	if err != nil {
		fmt.Println(err)
	}
}

func SaveConfig() {
	file, err := json.MarshalIndent(Cfg, "", " ")
	if err != nil {
		fmt.Println(err)
	}
	err = ioutil.WriteFile("./config.json", file, 0644)
	if err != nil {
		fmt.Println(err)
	}
}

func main() {
	Connect()
	LoadLicenses()
	LoadConfig()
	go ConnectionHandler(Cfg.Port)
	go StartWebServer()
	go StartUpdateServer()
	fmt.Println("License Server Started")
	for {
		var err error
		fmt.Print("Enter command: ")
		reader := bufio.NewReader(os.Stdin)
		input, _ := reader.ReadString('\n')
		input = input[:len(input)-1]
		command := strings.Fields(input)
		if len(command) < 1 {
			continue
		}
		arg := command[1:]
		switch command[0] {
		case "lock":
			if len(arg) < 1 {
				fmt.Println("Usage: lock USERNAME")
				continue
			}
			username := arg[0]
			_, err = DB.Exec("UPDATE licenses SET locked = 1 WHERE username = ?", username)
			if err != nil {
				fmt.Println(err)
				fmt.Println("Error locking license.")
				continue
			}
			for i, license := range Licenses {
				if license.username == username {
					Licenses[i].locked = 1
				}
			}
			fmt.Println("License locked successfully.")
		case "set-version", "setver", "setversion":
			if len(arg) < 1 {
				fmt.Println("Usage: set-version VERSION")
				continue
			}
			version := arg[0]
			Cfg.Version = version
			SaveConfig()
			fmt.Println("Version set successfully.")
		case "unlock":
			if len(arg) < 1 {
				fmt.Println("Usage: unlock USERNAME")
				continue
			}
			username := arg[0]
			_, err = DB.Exec("UPDATE licenses SET locked = 0 WHERE username = ?", username)
			if err != nil {
				fmt.Println(err)
				fmt.Println("Error unlocking license.")
				continue
			}
			for i, license := range Licenses {
				if license.username == username {
					Licenses[i].locked = 0
				}
			}
			fmt.Println("License unlocked successfully.")
		case "lock-all", "panic":
			_, err = DB.Exec("UPDATE licenses SET locked = 1")
			if err != nil {
				fmt.Println(err)
				fmt.Println("Error locking licenses.")
				continue
			}
			for i, _ := range Licenses {
				Licenses[i].locked = 1
			}
			Cfg.Locked = true
			SaveConfig()
			fmt.Println("All licenses locked successfully.")
		case "unlock-all", "unpanic":
			_, err = DB.Exec("UPDATE licenses SET locked = 0")
			if err != nil {
				fmt.Println(err)
				fmt.Println("Error unlocking licenses.")
				continue
			}
			for i, _ := range Licenses {
				Licenses[i].locked = 0
			}
			Cfg.Locked = false
			SaveConfig()
			fmt.Println("All licenses unlocked successfully.")
		case "add":
			if len(arg) < 3 {
				fmt.Println("Usage: add USERNAME EXPIRATION IP")
				continue
			}
			username := arg[0]
			expr, _ := strconv.Atoi(arg[1])
			expiration, err := time.Parse("02-01-2006", strconv.Itoa(expr))
			ip := arg[2]
			if err != nil {
				expiration = time.Now().AddDate(0, 0, expr)
			}
			key, err := CreateLicense(username, expiration, ip)
			if err != nil {
				fmt.Println(err)
				fmt.Println("Error creating license.")
				continue
			}
			CreateLicenseFile(License{username, key, expiration.Format("02-01-2006"), ip, 0})
			fmt.Printf("License created successfully.\r\nKey: %s\r\nExpiration: %s\r\nIP: %s\r\n", key, expiration.Format("02-01-2006"), ip)
		case "delete", "remove", "rm":
			if len(arg) != 1 {
				fmt.Println("Usage: delete USERNAME")
				continue
			}
			username := arg[0]
			sqlStmt := `DELETE FROM licenses WHERE username = ?;`
			_, err = DB.Exec(sqlStmt, username)
			if err != nil {
				fmt.Println(err)
				continue
			}
			for i, license := range Licenses {
				if license.username == username {
					Licenses = append(Licenses[:i], Licenses[i+1:]...)
				}
			}
			fmt.Println("License deleted successfully.")
		case "change-ip":
			if len(arg) != 2 {
				fmt.Println("Usage: change-ip USERNAME IP")
				continue
			}
			username := arg[0]
			ip := arg[1]
			sqlStmt := `UPDATE licenses SET ip = ? WHERE username = ?;`
			_, err = DB.Exec(sqlStmt, ip, username)
			if err != nil {
				fmt.Println(err)
				continue
			}
			for i, license := range Licenses {
				if license.username == username {
					Licenses[i].ip = ip
				}
			}
			fmt.Println("IP changed successfully.")
		case "show", "list":
			for _, license := range Licenses {
				if len(arg) >= 1 {
					if arg[0] == license.username || arg[0] == license.key {
						_exp, _ := time.Parse("02-01-2006", license.expiration)
						fmt.Printf("Key %s\r\nExpiry: %s\r\nIP: %s\r\n", license.key, _exp.Format("02-01-2006"), license.ip)
					}
				} else {
					fmt.Printf("Key: %s | %s\r\n", license.key, license.username)
				}
			}
		case "extend", "exp", "edit":
			if len(arg) != 2 {
				fmt.Println("Usage: extend USERNAME EXPIRATION")
				continue
			}
			username := arg[0]
			expiration, err := time.Parse("02-01-2006", arg[1])
			if err != nil {
				fmt.Println("Invalid date format. Use DD-MM-YYYY")
				continue
			}
			sqlStmt := `UPDATE licenses SET expiration = ? WHERE username = ?;`
			_, err = DB.Exec(sqlStmt, expiration.Format("02-01-2006"), username)
			if err != nil {
				fmt.Println(err)
				continue
			}
			for i, license := range Licenses {
				if license.username == username {
					Licenses[i].expiration = expiration.Format("02-01-2006")
				}
			}
			fmt.Println("License extended successfully.")
		default:
			fmt.Println("Invalid command.")
			continue
		}
	}
}
