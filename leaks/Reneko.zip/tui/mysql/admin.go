package mysql

import (
	"errors"
	"fmt"
	"time"
)

func Update(User, Column, Value string) error {
	switch Column {
	case "password", "timelimit", "cooldown", "admin", "email", "concurrents":

	default:
		return errors.New("unavailable column \"" + Column + "\"")
	}
	_, err := db.Exec(fmt.Sprintf("update users set %s = ? where username = ?", Column), Value, User)
	if err != nil {
		return fmt.Errorf("could not set %s to %s", Column, Value)
	}
	return nil

}

func Ban(User string, Reason string) error {
	_, err := db.Exec("insert into bans (username,reason,bantime) values (?,?,?)", User, Reason, time.Now())
	return err
}

func Unban(User string) error {
	_, err := db.Exec("delete from bans where username = ?", User)
	return err
}
