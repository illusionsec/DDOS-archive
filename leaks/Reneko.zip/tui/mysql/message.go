package mysql

import (
	"neko/structs"
)

/*
bleach [Admin]: fuck you
tester: black people
*/
func SendPublic(user structs.User, message string) []structs.Message {
	db.Exec("insert into messages (`sender`,`recipient`, `content`, `isadmin`, `isowner`, `private`) values (?,'.',?,?,?,false)", user.Username, message, user.Admin, user.Owner)
	return nil
}

func Send(user structs.User, recipient string, message string) []structs.Message {
	db.Exec("insert into messages (`sender`,`recipient`, `content`, `isadmin`, `isowner`, `private`) values (?,?,?,?,?,true)", user.Username, recipient, message, user.Admin, user.Owner)
	return nil
}

func Public() []structs.Message {
	r, err := db.Query("select sender, content, isadmin, isowner from messages where private = false")
	if err != nil {
		myerr(err.Error())
		return nil
	}
	var out []structs.Message
	for r.Next() {
		var m structs.Message
		r.Scan(&m.Username, &m.Content, &m.Admin, &m.Owner)
		out = append(out, m)
	}
	return out
}

func Private(you string, them string) []structs.Message {
	r, err := db.Query("select sender, content, isadmin, isowner from messages where ((sender = ? and recipient = ?) or (sender = ? and recipient = ?)) and  (private = true)", you, them, them, you)
	if err != nil {
		myerr(err.Error())
		return nil
	}
	var out []structs.Message
	for r.Next() {
		var m structs.Message
		r.Scan(&m.Username, &m.Content, &m.Admin, &m.Owner)
		out = append(out, m)
	}
	return out
}
