package mysql

import (
	"errors"
	"neko/structs"
)

func Login(user string, password string) (bool, *structs.User) {
	r, err := db.Query("select username, admin, timelimit, cooldown, concurrents, expiry, email, owner from users where username = ? AND password = ?", user, password)
	if err != nil {
		myerr(err.Error())
		return false, nil
	}

	defer r.Close()

	var u structs.User
	if !r.Next() {
		return false, nil
	} else {
		r.Scan(&u.Username, &u.Admin, &u.Timelimit, &u.Cooldown, &u.Concurrent, &u.Expiry, &u.Email, &u.Owner)
		return true, &u
	}
}

func Register(username string, password string, email string) error {
	if UserRegistered(username) {
		return errors.New("this username is already in use")
	}
	if EmailRegistered(email) {
		return errors.New("this email is already in use")
	}
	db.Exec("insert into users (`username`,`password`,`email`) values (?,?,?)", username, password, email)
	return nil
}

func UserRegistered(username string) bool {
	r, err := db.Query("Select * from users where username = ?", username)
	if err != nil {
		return false
	}

	defer r.Close()
	return r.Next()
}

func EmailRegistered(email string) bool {
	r, err := db.Query("Select * from users where email = ?", email)
	if err != nil {
		myerr(err.Error())
		return false
	}

	defer r.Close()
	return r.Next()
}

func User(u *structs.User) {
	r, err := db.Query("select username, admin, timelimit, cooldown, concurrents, expiry, email, owner from users where username = ? ", u.Username)
	if err != nil {
		myerr(err.Error())
		return
	}

	defer r.Close()

	if !r.Next() {
		return
	} else {
		r.Scan(&u.Username, &u.Admin, &u.Timelimit, &u.Cooldown, &u.Concurrent, &u.Expiry, &u.Email, &u.Owner)
		return
	}
}

func GetUser(u *structs.User) {
	r, err := db.Query("select username, admin, timelimit, cooldown, concurrents, expiry, email, owner from users where username = ? ", u.Username)
	if err != nil {
		myerr(err.Error())
		return
	}
	r.Next()
	defer r.Close()

	if !r.Next() {
		return
	} else {
		r.Scan(&u.Username, &u.Admin, &u.Timelimit, &u.Cooldown, &u.Concurrent, &u.Expiry, &u.Email, &u.Owner)
		return
	}
}

func ListUsers() []string {
	r, err := db.Query("select username from users")
	if err != nil {
		myerr(err.Error())
		return []string{}
	}
	defer r.Close()
	var out []string
	for r.Next() {
		var s string
		r.Scan(&s)
		out = append(out, s)
	}
	return out
}

func Banned(u string) bool {
	r, err := db.Query("select * from users where username = ?", u)
	if err != nil {
		myerr(err.Error())
		return false
	}
	return r.Next()
}
