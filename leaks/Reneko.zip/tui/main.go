package main

//m8/d3/y22

/*
Life really does keep you busy
*/
import (
	"log"
	"neko/dbug"
	"neko/files"
	"neko/json"
	"neko/mysql"
	"neko/server"
)

func main() {
	json.Init()
	mysql.Init()
	log.Print("Init() Starting RE: Neko...")
	dbug.Debug() // basically useless
	files.Init()
	server.Init()
}
