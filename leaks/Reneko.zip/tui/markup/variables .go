package markup

import (
	"fmt"
	"strings"
)

// I think im only going to need varibles for this
func (in Index) Varibles(input string) string {

	var is bool
	var name string
	var skip int
	var out strings.Builder
	for i, n := range input {
		if n == '<' && ReadA(i+1, input, "<$") {
			skip = 3
			if is {
				out.WriteString("Error Varible aready escaped")
			}
			is = true

		}
		if n == '>' && ReadA(i+1, input, ">") && is {
			is = false
			value, ok := in[name]
			if ok {
				v := fmt.Sprintf("%v", value)
				out.WriteString(v)

			} else {

				out.WriteString(fmt.Sprintf("Undefined varible \"%s\"", name))
			}
			name = ""
			skip += 2
		}
		switch {
		case skip > 0:
			skip--
			continue
		case is:
			name += string(n)
		default:
			out.WriteRune(n)
		}
	}
	return out.String()
}
