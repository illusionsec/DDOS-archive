package markup

import (
	"neko/structs"
	"neko/util"
	"time"
)

func Make(u structs.User) *map[string]interface{} {
	m := make(map[string]interface{})
	Update(&m, u)
	return &m
}

func Update(m *map[string]interface{}, u structs.User) {
	go func() {
		for {
			*m = map[string]interface{}{
				"user":       u.Username,
				"concurrent": u.Concurrent,
				"timelimit":  u.Timelimit,
				"admin":      util.ColorBool(u.Admin),
				"expiry":     u.Expiry,
				//tbd
				/**/

			}
			time.Sleep(time.Second * 5)
		}
	}()

}
