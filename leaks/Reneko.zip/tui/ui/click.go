package ui

import "neko/structs"

func Click(click structs.Cord, pos structs.Coordinates) bool {
	if (click.X >= pos.P1.X && click.X <= pos.P2.X) && (click.Y >= pos.P1.Y && click.Y <= pos.P2.Y) {
		return true
	}
	return false
}
