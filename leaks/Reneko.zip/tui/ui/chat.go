package ui

import (
	"fmt"
	"neko/colors"
	"neko/structs"
	"neko/util"
	"strings"
)

//Meant to work with my mysql package

const (
	grey  = "[38;5;244m"
	white = "[38;5;255m"

	admin = " [" + colors.YellowFg + "Admin" + colors.Reset + "]"
	owner = " [" + colors.CyanFg + "Owner" + colors.Reset + "]"
)

type Chat struct {
	Cord     structs.Cord
	Mode     bool
	Height   int
	Width    int
	Messages []structs.Message
}

func (ch *Chat) Print(text *string) {
	*text = util.Replace(ch.Cord, *text, ch.lines())

}

func (ch *Chat) PrintScroll() {

}

func (ch *Chat) ToggleMode() {
	if ch.Mode {
		ch.Mode = false
	} else {
		ch.Mode = true
	}
}

func (ch *Chat) PrintMode(text *string, c structs.Cord) {
	if ch.Mode {
		*text = util.Replace(c, *text, "private")
	} else {
		*text = util.Replace(c, *text, "public")
	}
}

func (ch *Chat) lines() string {
	var str strings.Builder // Testing a little (ended up less useful
	mess := ch.Messages
	if len(mess) == 0 {
		return fmt.Sprintf("[%sSystem%s] No messages to display!", colors.GreenFg, colors.Reset)
	}
	if len(mess) > ch.Height {
		mess = ch.Messages[len(ch.Messages)-ch.Height:]
	}
	for i, m := range mess {
		var line string
		var color string
		if i%2 == 0 {
			color = grey
		} else {
			color = white
		}
		line += color + m.Username + colors.Reset
		switch {
		case m.Owner:
			line += owner
		case m.Admin:
			line += admin
		}
		line += fmt.Sprintf(":%s%s", color, m.Content)
		str.WriteString(util.Limit(line, ch.Width) + colors.Reset + "\r\n")
	}
	return util.Mutlistr(util.Mutlistr(" ", ch.Width)+"\r\n", ch.Height-len(ch.Messages)) + str.String()
}

/*
	for i, m := range ch.Messages[len(ch.Messages)-ch.Height:] {
		var color string
		if i%2 == 0 {
			color = grey
		} else {
			color = white
		}
		switch {
		case m.Owner:
			str.WriteString(owner)
		case m.Admin:
			str.WriteString(admin)
		}
		str.WriteString(fmt.Sprintf())
	}
*/
