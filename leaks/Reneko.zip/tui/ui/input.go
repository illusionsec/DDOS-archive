package ui

import (
	"neko/structs"
	"neko/util"
)

type Input struct {
	Text   string // stored input
	Length int    // Max length
	Cords  structs.Cord
	Masked bool
	Active bool // if clicked on
}

func (i *Input) Input(interaction structs.Actions) { // Add charactor to text

	if !i.Active {
		return
	}

	input, ok := interaction.Data.(string) // Convert to string

	if !ok || len(i.Text) >= i.Length {
		return
	}

	i.Text += input // Append to text

}

func (i *Input) Reset() { // Go back one charactor

	i.Text = ""

}

func (i *Input) Backspace() { // Go back one charactor

	if !i.Active {
		return
	}

	if len(i.Text) > 0 { // Don't go into negitive
		i.Text = i.Text[:len(i.Text)-1]
	}

}

func (i *Input) Print(text *string) {
	if i.Masked {
		*text = util.Replace(i.Cords, *text, util.Mutlistr("*", len(i.Text)))

	} else {
		*text = util.Replace(i.Cords, *text, i.Text)
	}
}

func (i *Input) InputPrintMasked(text string) string {
	return util.Replace(i.Cords, text, util.Mutlistr("*", len(i.Text)))
}

func (i *Input) Click(click []int) bool {
	t := i.Cords
	t.X += i.Length
	pos := structs.Coordinates{P1: i.Cords, P2: t}

	i.Active = Click(structs.Cord{
		X: click[0],
		Y: click[1],
	}, pos)
	return i.Active
}
