package ui

type LoginPage struct {
	Title string `json:"title"`

	Subtext  Subway `json:"subway text"`
	Username Input  `json:"username"`
	Password Input  `json:"password"`
	Submit   Button `json:"submit"`
	Register Button `json:"register"`
	Toggle   Toggle `json:"toggle"`
}
type RegisterPage struct {
	Title string `json:"title"`

	Email    Input  `json:"email"`
	Username Input  `json:"username"`
	Password Input  `json:"password"`
	Toggle   Toggle `json:"toggle"`
	Submit   Button `json:"submit"`
}

type VerifyPage struct {
	Title string `json:"title"`

	Code   Input  `json:"code"`
	Submit Button `json:"submit"`
}

type AttackPage struct {
	Title string `json:"title"`

	Subtext   Subway `json:"subway text"`
	Scroll    Scroll `json:"methods"`
	Host      Input  `json:"host"`
	Port      Input  `json:"port"`
	Duration  Input  `json:"duration"`
	Community Button `json:"community"`
	Send      Button `json:"send button"`

	// Swap pages
	UserPage      Button `json:"user page"`
	AttackPage    Button `json:"attack page"`
	CommunityPage Button `json:"community page"`
	AdminPage     Button `json:"admin page"`
}

type CommunityPage struct {
	Title string `json:"title"`

	Chats   Chat   `json:"chat"`
	Message Input  `json:"text"`
	Mode    Button `json:"mode"`
	Users   Scroll `json:"users"`
	Online  Box    `json:"online"`

	// Swap pages
	UserPage      Button `json:"user page"`
	AttackPage    Button `json:"attack page"`
	CommunityPage Button `json:"community page"`
	AdminPage     Button `json:"admin page"`
}

type UserPage struct {
	Title string `json:"title"`

	Password1      Input `json:"password"`
	Password2      Input `json:"confirm password"`
	ChangePassword Button
	Toggle         Toggle `json:"toggle"`
	Info           Box    `json:"info"`
	Attacks        Box    `json:"attacks"`

	// Swap pages
	UserPage      Button `json:"user page"`
	AttackPage    Button `json:"attack page"`
	CommunityPage Button `json:"community page"`
	AdminPage     Button `json:"admin page"`
}

type AdminPage struct {
	Title string `json:"title"`

	User    Scroll `json:"users"`
	Column  Input  `json:"column"`
	Value   Input  `json:"value"`
	Enter   Button `json:"update user"`
	Ban     Button `json:"ban user"`
	Unban   Button `json:"unban user"`
	Kick    Button `json:"kick user"`
	Info    Box    `json:"info"`
	Attacks Box    `json:"attacks"`

	// Swap pages
	UserPage      Button `json:"user page"`
	AttackPage    Button `json:"attack page"`
	CommunityPage Button `json:"community page"`
	AdminPage     Button `json:"admin page"`
}

type ChallengePos struct {
	Title string `title`
}
