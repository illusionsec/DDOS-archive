package ui

import (
	"fmt"
	"neko/structs"
	"neko/util"
	"strings"
)

type Scroll struct {
	Text   string
	Width  int
	Height int
	POS    int // + pos if scroll doesn't fit move downwards by pos offset
	Cords  structs.Cord
	//Cords    structs.Coordinates
	Selected *string
	Active   bool // if clicked on
	Options  []string
}

func (s *Scroll) Print(text *string) { // Scroll down selection
	*text = util.Replace(s.Cords, *text, s.Scroll_line())

}

func (s *Scroll) Scroll_up() {
	if s.POS > 0 {

		s.POS--

	}
}

func (s *Scroll) Scroll_down() {
	if len(s.Options)-1 > s.Height+s.POS {
		s.POS++
	}

}

func (s *Scroll) Click(i []int, b bool) bool {

	cord := structs.Cord{
		X: i[0],
		Y: i[1],
	}

	if s.Active {

		t := s.Cords

		t2 := s.Cords

		t.Y += 1
		t2.Y += s.Height + 1
		t2.X += s.Width

		if Click(cord, structs.Coordinates{P1: t, P2: t2}) {
			opt := cord.Y - t.Y + s.POS

			if opt < len(s.Options) {
				if b {
					s.Selected = &s.Options[opt]
				}
				return true
			}

		} else {

			s.Active = false

		}

	} else if Click(cord, structs.Coordinates{P1: s.Cords, P2: structs.Cord{X: s.Cords.X + s.Width, Y: s.Cords.Y}}) {

		s.Active = true

		return true

	} else {

		s.Active = false

	}

	return false
}

func (s *Scroll) Scroll_line() string {

	var out string
	out += "\x1b[4m"
	if s.Selected != nil {

		out += *s.Selected + util.Mutlistr(" ", s.Width-len(*s.Selected))

	} else {

		out += s.Text + util.Mutlistr(" ", s.Width-len(s.Text))

	}
	out += "\x1b[0m"
	out += "\r\n"
	// Method
	if s.Active {

		for i, str := range s.Options[s.POS:] {

			if i > s.Height {

				break

			}
			out += fmt.Sprintf("\x1b[1;30;47m%s%s\x1b[0m\r\n", str, util.Mutlistr(" ", s.Width-len(str)))

		}
	}

	return strings.TrimSuffix(out, "\r\n")
}
