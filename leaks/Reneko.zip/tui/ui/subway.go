package ui

import (
	"neko/structs"
	"neko/util"
)

type Subway struct {
	Text   string
	Length int
	Cord   structs.Cord
	Pos    int // Offset for subway position
}

func (s *Subway) Print(text *string) {

	var txt string

	if len(s.Text) > s.Pos {

		txt = s.Text[len(s.Text)-s.Pos:]

	} else if s.Pos > s.Length {

		txt = util.Mutlistr(" ", s.Pos-len(s.Text)) + s.Text[:(s.Length-(s.Pos-len(s.Text)))]

	} else {

		txt = util.Mutlistr(" ", s.Pos-len(s.Text)) + s.Text

	}

	out := txt + util.Mutlistr(" ", s.Length-s.Pos)
	*text = util.Replace(s.Cord, *text, out)
}

func (s *Subway) Move() {
	if s.Pos >= s.Length+len(s.Text) {
		s.Pos = 0
	}
	s.Pos++
}
