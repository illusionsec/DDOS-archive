package util

func Mutlistr(str string, i int) (out string) {

	for n := 0; i > n; n++ {
		out += str
	}

	return out
}
