package util

import (
	"regexp"
	"strings"
)

const Ansiregex = "<\\w*>|<\\/>|([\u001B\u009B\x1b][[\\]()#;?]*(?:(?:(?:[a-zA-Z\\d]*(?:;[a-zA-Z\\d]*)*)?\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PRZcf-ntqry=><~])))"

//const Ansiregex = "[\u001B\u009B][[\\]()#;?]*(?:(?:(?:[a-zA-Z\\d]*(?:;[a-zA-Z\\d]*)*)?\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PRZcf-ntqry=><~]))"

var Ansi = regexp.MustCompile(Ansiregex)

func Escape(in string) string { // This is a very messy but easy way for me to escape ANSI sequences
	noprint := Ansi.FindAllString(in, -1)
	for _, z := range noprint {
		in = strings.Replace(strings.Replace(in, "\b"+z+"\b", z, -1), z, "\b"+z+"\b", -1)
	}
	return in
}

func EscapeSplit(s string) []string {
	var out []string
	var tmp strings.Builder
	var escaped bool
	for _, r := range s {
		if escaped && r == '\b' {
			out = append(out, tmp.String())
			tmp.Reset()
			escaped = false
			continue
		} else if r == '\b' {
			escaped = true
			continue
		}
		if escaped {
			tmp.WriteRune(r)
			continue
		}
		out = append(out, string(r))
	}
	if tmp.Len() > 0 {
		out = append(out, tmp.String())
		tmp.Reset()
	}
	return out
}
