package util

import (
	"strings"
)

func Limit(str string, i int) string {
	e := EscapeSplit(Escape(str))
	var pos int
	var out strings.Builder
	for _, s := range e {
		if pos >= i {
			break
		}
		out.WriteString(s)

		if Ansi.MatchString(s) { // ignore ansi

		} else {
			pos++
		}

	}
	return out.String()
}
