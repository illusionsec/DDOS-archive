package json

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"neko/structs"
	"neko/ui"
	"strings"
	"time"
)

var (
	Config       structs.Config
	ChallengePos map[string]structs.Coordinates
	Gradients    structs.Gradients
	SMTP         structs.SMTP
	Methods      []structs.Method
	Blacklist    []structs.Blacklist
	AttackPos    ui.AttackPage
	LoginPos     ui.LoginPage
	RegisterPos  ui.RegisterPage
	VerifyPos    ui.VerifyPage
	CommunityPos ui.CommunityPage
	UserPos      ui.UserPage
	AdminPos     ui.AdminPage
)

// Set location and pointer
var Configuration = map[string]interface{}{
	"./_config/config.json": &Config,
	"./_config/smtp.json":   &SMTP,
	//"./_config/gradients.json": &Gradients,
	"./_config/methods.json":   &Methods,
	"./_config/blacklist.json": &Blacklist,

	"./_assets/attack page/pos.json":    &AttackPos,
	"./_assets/login page/pos.json":     &LoginPos,
	"./_assets/challenge page/pos.json": &ChallengePos,
	"./_assets/register page/pos.json":  &RegisterPos,
	"./_assets/verify page/pos.json":    &VerifyPos,
	"./_assets/community page/pos.json": &CommunityPos,
	"./_assets/user page/pos.json":      &UserPos,
	"./_assets/admin page/pos.json":     &AdminPos,
}

func update() {
	for path, pointer := range Configuration { // For loop of Paths and Pointers
		b, err := ioutil.ReadFile(path)
		if err != nil {
			log.Printf("could not open %s error: \"%s\"", path, err)
		}
		err = json.Unmarshal(b, pointer) // Set Pointer & Global value
		if err != nil {
			log.Printf("could not unmarshal %s error: \"%s\"", path, err)
		}

	}
}

func Init() {
	update() // Out side goroutine to ensure all configs have been set\
	go func() {
		for {

			update()                    // update all file locations to type
			time.Sleep(time.Second * 5) // update delay

		}
	}()
}

func generate(i interface{}) string {
	b, _ := json.MarshalIndent(i, "", "    ")
	return strings.ToLower(string(b))
}
