package server

import (
	"bytes"
	"fmt"
	"log"
	"neko/handle"
	"neko/json"
	"neko/server/actions"
	"net"
	"time"
)

func Init() {
	l, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", json.Config.Port)) // Start Listener
	if err != nil {
		log.Fatal(err) // If error exit
	}

	for {
		c, err := l.Accept() //  Accept all Requests
		if err != nil {
			continue // Errors are ignored
		}
		go Handle(c)

	}
}

func Handle(c net.Conn) {
	c.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))
	fmt.Fprint(c, "\033[?1000h\033[?1006h\033[?25l") // Decide what to do later :p
	verify(c)
	ch := actions.Init(c)
	handle.Take(c, ch)
	c.Close()

}

func verify(c net.Conn) {

	var auth = []byte{255, 251, 31, 255, 251, 32, 255, 251, 24, 255, 251, 39, 255, 253, 1, 255, 251, 3, 255, 253, 3}
	buf := make([]byte, len(auth))
	c.SetReadDeadline(time.Now().Add(
		time.Second, // Allowed time for authentication of connection
	))
	c.Read(buf)
	if !bytes.Equal(buf, auth) {
		c.Write([]byte("\x1bcUnsupported client"))
		c.Close()
	}
}
