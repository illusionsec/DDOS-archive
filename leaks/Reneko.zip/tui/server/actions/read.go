package actions

import (
	"neko/globals"
	"neko/structs"
	"net"
	"strconv"
	"time"
	"unicode"
)

/*
My first attempt at a decently high level terminal action reader

This will be used for all interactions

- Bleach 5/25/22

*/

type Reader struct {
	Actions chan structs.Actions
	Conn    net.Conn
}

func Init(c net.Conn) chan structs.Actions { // Init Function for oganization
	ch := make(chan structs.Actions)

	c.SetReadDeadline(time.Now().Add(time.Second * 2))

	go Reader{ // goRoutine will allow us to do more while waiting for actions
		Actions: ch,
		Conn:    c,
	}.read()

	go GetPos(c)

	return ch
}

func GetPos(c net.Conn) {
	for {
		_, err := c.Write([]byte("\033[6n"))
		if err != nil {
			return
		}
		time.Sleep(3 * time.Second)
	}
}

func (r Reader) read() { // function for reading all client side actions
reader:

	for {

		var a structs.Actions

		b := make([]byte, 1)
		n, err := r.Conn.Read(b)
		if err != nil || n < 1 {
			r.Conn.Write([]byte("\x1bcYour client did not repond to the heart beat..."))
			close(r.Actions)
			//r.Conn.Close()
			return
		}

		switch b[0] {

		case '\r': // Ignored
			continue

		case '\b', 127: // Backspace!
			a.Type = globals.BackSpace
		case '\n': // Newline is the enter key
			a.Type = globals.EnterKey

		case 27: // Special Action Reading
			tmp := make([]byte, 1) // Should be more to this message
			r.Conn.Read(tmp)
			if err != nil || n < 1 {
				continue reader
			}

			if tmp[0] != '[' { // Most of our actions should include this!
				a.Type = globals.Unknown
				a.Data = b[0]
				continue reader
			}

			r.Conn.Read(tmp)
			if err != nil || n < 1 {
				a.Type = globals.Unknown
				a.Data = b[0]
				continue reader
			}

			switch tmp[0] { // Decide type of action

			case 'A': //  Up arrow key
				a.Type = globals.UpKey

			case 'B': //  Down arrow key
				a.Type = globals.DownKey

			case 'C': //  Right arrow key
				a.Type = globals.RightKey

			case 'D': //  Left Allow Key
				a.Type = globals.LeftKey

			case '<': // Possible Mouse Action!
				// This will be where mouse action type is decided
				mState, err := ReadUntil(r.Conn, ';')
				if err != nil {
					//a.Type = globals.Unknown
					//r.Actions <- a
					continue reader
				}
				xPosB, err := ReadUntil(r.Conn, ';')
				if err != nil {
					//a.Type = globals.Unknown
					//r.Actions <- a
					continue reader
				}

				var yPosB []byte
				for { // Ignore The repeat using the Uppercase M terminator
					b := make([]byte, 1)
					n, err := r.Conn.Read(b)
					if err != nil || n < 1 {
						//a.Type = globals.Unknown
						//r.Actions <- a
						continue reader
					}
					if b[0] == 'm' {
						//a.Type = globals.Unknown
						//r.Actions <- a
						continue reader
					}
					if b[0] == 'M' {
						break
					}
					yPosB = append(yPosB, b[0])
				}

				a.Type = globals.MouseLeftClick

				state := btoi(mState)
				switch state {
				case 0:
					a.Type = globals.MouseLeftClick
				case 2:
					a.Type = globals.MouseRightClick
				case 64:
					a.Type = globals.MouseSrcollUp
				case 65:
					a.Type = globals.MouseSrcollDown
				default:
					continue
				}
				a.Data = []int{btoi(xPosB), btoi(yPosB)}

			default:
				for {
					b := make([]byte, 1)
					n, err := r.Conn.Read(b)
					if err != nil || n < 1 {
						continue reader
					}
					if unicode.IsLetter(rune(b[0])) {
						r.Conn.SetReadDeadline(time.Now().Add(time.Second * 60))
						continue reader
					}
				}

				//I was going to make this unknown but i don't want it in the way

				//a.Type = globals.Unknown // Throw away trash interactions (unneeded)

			}

		default:
			if b[0] > 126 || b[0] <= 31 {
				a.Type = globals.Unknown // Non standard treated like unknown
			} else {
				a.Type = globals.KeyPress // Readible Keys Sent like this
				a.Data = string(b[0])
			}
		}

		//fmt.Printf("We got %s | Parse %v | Raw %d\r\n", a.Type, a.Data, b[0])

		r.Actions <- a

	}
}

func btoi(b []byte) int {
	i, err := strconv.Atoi(string(b))
	if err != nil {
		return 0
	}
	return i
}

func ReadUntil(c net.Conn, u byte) ([]byte, error) { // Read until byte "u" has been found
	var out []byte
	for {
		b := make([]byte, 1)
		n, err := c.Read(b)
		if err != nil || n < 1 {
			return out, err
		}
		if b[0] == u {
			break
		}
		out = append(out, b[0])
	}
	return out, nil

}
