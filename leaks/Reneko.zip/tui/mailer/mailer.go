package mailer

import (
	"crypto/tls"
	"fmt"
	"neko/json"
	"net/smtp"
)

/*
Create connection to SMTP server and send a message "msg" to "to"
*/

func Send(to string, msg string) bool { // Return bool users do not need to know error information

	client, err := smtp.Dial(fmt.Sprintf("%s:%d", json.SMTP.Hostname, json.SMTP.Port))
	if err != nil { // redundant
		return false
	}

	err = client.StartTLS(&tls.Config{ // Enable encryption
		ServerName:         json.SMTP.Hostname,
		InsecureSkipVerify: false,
	})
	if err != nil { // redundant
		return false
	}

	err = client.Auth(smtp.PlainAuth("", json.SMTP.Username, json.SMTP.Password, json.SMTP.Hostname))
	if err != nil { // redundant
		return false
	}

	err = client.Mail(json.SMTP.Username)
	if err != nil { // redundant
		return false
	}

	err = client.Rcpt(to)
	if err != nil { // redundant
		return false
	}

	w, err := client.Data()
	if err != nil { // redundant
		return false
	}

	_, err = w.Write([]byte(msg))
	if err != nil { // redundant
		return false
	}

	err = client.Mail("Neko CNC Verifcation")
	return err == nil

}
