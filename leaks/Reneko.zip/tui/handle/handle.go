package handle

import (
	"neko/handle/pages"
	"neko/structs"
	"net"
)

func Take(c net.Conn, a chan structs.Actions) { // Connect all functions for user interface

	//Challenge
	if err := pages.Challenge(c, a); err != nil {
		return
	}
	sess := pages.Login(c, a)
	if sess == nil {
		return
	}
	pages.Community(sess)
	sess.Close()
	//pages.Attack(sess)

}
