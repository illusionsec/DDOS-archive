package pages

import (
	"fmt"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/mysql"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"time"
)

//const tries = 3

func Community(session *sessions.Session) {
	ch2 := make(chan interface{})
	ch1 := make(chan interface{})

	var private bool
	erro := &ui.Box{
		Cord:   structs.Cord{X: 20, Y: 7},
		Height: 8,
		Width:  40,
	}
	chat := json.CommunityPos.Chats
	mode := json.CommunityPos.Mode
	users := json.CommunityPos.Users
	txt := json.CommunityPos.Message
	online := json.CommunityPos.Online

	ex := null
	defer func() {
		ch1 <- 1
		ch2 <- 1
		ex(session)
	}()
	go func() { // Gather messages
		for {
			select {
			case <-ch1:
				close(ch1)
				return
			default:
				if chat.Mode && users.Selected != nil {
					chat.Messages = mysql.Private(session.User.Username, *users.Selected)
				} else {
					chat.Messages = mysql.Public()
				}
				online.Text = sessions.PrettyOnline()
				users.Options = mysql.ListUsers()
				time.Sleep(time.Second)

			}
		}
	}()
	online.Appear()
	go func() { // Render asset
		for {

			select {

			case <-ch2:

				close(ch2)

				return // DIE

			default:
				var text string = files.Community
				if private {
					json.CommunityPos.Users.Print(&text)
				}
				chat.Print(&text)
				if chat.Mode {
					users.Print(&text)
				}
				online.Print(&text)
				chat.PrintMode(&text, mode.Cords.P1)

				txt.Print(&text)
				erro.PrintErr(&text)
				util.Title(session.Conn, json.CommunityPos.Title)
				fmt.Fprintf(session.Conn, "\x1b[0;0H%s", text)
				time.Sleep(time.Millisecond * conf.Delay) // Render frames relay
			}

		}

	}()
	lastmessage := time.Now()
	for {

		action, ok := <-session.Actions // Get current action!
		if !ok {
			return
		}
		switch action.Type {

		case globals.MouseLeftClick: // check if object pressed
			p := util.GetPos(action.Data)
			switch {
			case mode.Click(p): //Function handles all that needs to be done.
				chat.ToggleMode()
			case users.Click(p, chat.Mode):

			case txt.Click(p):

			case json.CommunityPos.AdminPage.Click(p):
				if !session.User.Admin {
					erro.Text = []string{
						"",
						"you are not an admin",
					}
					erro.Appear()
					<-session.Actions
					erro.Disappear()
					continue
				}
				ex = Admin
				return
			case json.CommunityPos.CommunityPage.Click(p):
				ex = Community
				return
			case json.CommunityPos.AttackPage.Click(p):
				ex = Attack
				return
			case json.CommunityPos.UserPage.Click(p):
				ex = User
				return

			}
		case globals.KeyPress: // Process if reading only
			txt.Input(action)
		case globals.BackSpace:
			txt.Backspace()
		case globals.EnterKey:
			if txt.Active && len(txt.Text) > 0 && (time.Now().Unix()-lastmessage.Unix()) > 3 {
				if chat.Mode && users.Selected != nil {
					mysql.Send(session.User, *users.Selected, txt.Text)
					txt.Text = ""
				} else {
					mysql.SendPublic(session.User, txt.Text)
					txt.Text = ""
				}
				lastmessage = time.Now()

			}
		case globals.MouseSrcollUp:
			if users.Click(util.GetPos(action.Data), false) {
				users.Scroll_up()
			}
		case globals.MouseSrcollDown:
			if users.Click(util.GetPos(action.Data), false) {
				users.Scroll_down()
			}

		}

	}

	<-session.Actions
	return

}
