package pages

import (
	"fmt"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/mysql"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"time"
)

func User(session *sessions.Session) {
	ch1 := make(chan interface{})
	ch2 := make(chan interface{})
	password1 := json.UserPos.Password1
	password2 := json.UserPos.Password2
	enter := json.UserPos.ChangePassword
	toggle := json.UserPos.Toggle
	info := json.UserPos.Info
	erro := &ui.Box{
		Cord:   structs.Cord{X: 20, Y: 7},
		Height: 8,
		Width:  40,
	}
	atks := json.UserPos.Attacks
	info.Appear()
	atks.Appear()
	ex := null
	defer func() {
		ch1 <- 1
		ch2 <- 1
		ex(session)
	}()
	go func() {
		for {
			select {
			case <-ch2:
				return
			default:
				atks.Text = mysql.Attackstrings(mysql.UserAttacks(session.User.Username))
				time.Sleep(time.Second)
			}
		}
	}()
	go func() { // Render text
		for {
			select {
			case <-ch1:
				return
			default:
				text := files.User
				//session.User.
				info.Text = []string{
					fmt.Sprintf("Email: %s", session.User.Email),
					fmt.Sprintf("Cooldown: %d", session.User.Cooldown),
					fmt.Sprintf("Timelimit: %d", session.User.Timelimit),
					fmt.Sprintf("Concurrent: %d", session.User.Concurrent),
					fmt.Sprintf("Admin: %s", util.ColorBool(session.User.Admin)),
					fmt.Sprintf("Owner: %s", util.ColorBool(session.User.Admin)),
					fmt.Sprintf("Expiry: %s", time.Unix(session.User.Expiry, 0).Format("01/02/2006")),
					fmt.Sprintf("Session Started: %.2fmin", time.Since(session.Login).Minutes()),
				}
				info.Print(&text)
				atks.Print(&text)
				erro.PrintErr(&text)
				password1.Print(&text)
				password2.Print(&text)
				toggle.Print(&text)
				util.Title(session.Conn, json.UserPos.Title)
				fmt.Fprint(session.Conn, "\x1b[0;0H"+text)
				time.Sleep(conf.Delay * time.Millisecond)
			}
		}
	}()
	password1.Masked = toggle.On
	password2.Masked = toggle.On
	for {
		action, ok := <-session.Actions
		if !ok {
			return
		}
		switch action.Type {

		case globals.MouseLeftClick:
			p := util.GetPos(action.Data)

			password1.Click(p)
			password2.Click(p)
			switch {
			case toggle.Click(p):
				password1.Masked = toggle.On
				password2.Masked = toggle.On
			case enter.Click(p):
				if password1.Text != password2.Text {
					erro.Appear()
					erro.Text = []string{
						"",
						"passwords do not match",
					}
					<-session.Actions
					erro.Disappear()

					continue
				}
				if len(password1.Text) < 2 {
					erro.Appear()
					erro.Text = []string{
						"",
						"password too short",
					}
					<-session.Actions
					erro.Disappear()

					continue
				}

				if err := mysql.Update(session.User.Username, "password", password1.Text); err != nil {
					erro.Appear()
					erro.Text = []string{
						"",
						"database error",
					}
					<-session.Actions
					erro.Disappear()

					continue
				}
			case json.CommunityPos.AdminPage.Click(p):
				if !session.User.Admin {
					erro.Text = []string{
						"",
						"you are not an admin",
					}
					erro.Appear()
					<-session.Actions
					erro.Disappear()
					continue
				}
				ex = Admin
				return
			case json.CommunityPos.CommunityPage.Click(p):
				ex = Community
				return
			case json.CommunityPos.AttackPage.Click(p):
				ex = Attack
				return
			case json.CommunityPos.UserPage.Click(p):
				ex = User
				return
			}

		case globals.KeyPress:
			password1.Input(action)
			password2.Input(action)

		case globals.BackSpace:
			password1.Backspace()
			password2.Backspace()

		}
	}
}
