package pages

import "neko/sessions"

//Null function
func null(session *sessions.Session) { return }
