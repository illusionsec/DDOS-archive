package pages

import (
	"fmt"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/mysql"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"net"
	"time"
)

//const tries = 3

func Register(c net.Conn, a chan structs.Actions) *sessions.Session {
	const tries = 3
register:
	for i := 0; tries > i; i++ {
		ch := make(chan interface{})

		toggle := json.RegisterPos.Toggle
		email := json.RegisterPos.Email
		username := json.RegisterPos.Username
		password := json.RegisterPos.Password
		password.Masked = toggle.On
		box := &ui.Box{
			Cord:   structs.Cord{X: 20, Y: 7},
			Height: 8,
			Width:  40,
		}
		//subtext := json.RegisterPos.Subtext
		submit := json.RegisterPos.Submit
		go func() { // Render asset
			for {

				select {

				case <-ch:

					close(ch)

					return // DIE

				default:
					var text string = files.Register
					email.Print(&text)
					username.Print(&text) // I will clean these up later hopfully
					password.Print(&text)
					toggle.Print(&text)
					box.PrintErr(&text)
					util.Title(c, json.RegisterPos.Title)
					fmt.Fprintf(c, "\x1b[0;0H%s", text)
					time.Sleep(time.Millisecond * conf.Delay) // Render frames relay
					//subtext.Move()
				}

			}

		}()
		for {

			action, ok := <-a // Get current action!
			if !ok {
				return nil
			}
			switch action.Type {

			case globals.MouseLeftClick: // check if object pressed
				switch {

				case toggle.Click(util.GetPos(action.Data)): //Function handles all that needs to be done.

					password.Masked = toggle.On

				case email.Click(util.GetPos(action.Data)):

				case username.Click(util.GetPos(action.Data)):

				case password.Click(util.GetPos(action.Data)):

				case submit.Click(util.GetPos(action.Data)): // Custom handle for this action
					if len(username.Text) > 3 && len(password.Text) > 3 {
						ch <- 1337
						if !Verify(c, a, email.Text) {
							return nil
						} else {
							if err := mysql.Register(username.Text, password.Text, email.Text); err != nil {
								box.Appear()
								box.Text = []string{
									"",
									err.Error(),
								}
								<-a
								box.Disappear()
							}

							sess, err := sessions.Login(username.Text, password.Text, c, a)
							if err != nil {

								return nil
							}
							return sess
						}
					}
					ch <- 3
					continue register
				}

			case globals.KeyPress: // Process if reading only
				switch {

				case username.Active:
					username.Input(action)
				case password.Active:
					password.Input(action)
				case email.Active:
					email.Input(action)
				}
			case globals.BackSpace:
				switch {
				case username.Active:
					username.Backspace()
				case password.Active:
					password.Backspace()
				case email.Active:
					email.Backspace()
				}

			}
		}
		ch <- 0 // close render function

	}
	c.SetReadDeadline(time.Now().Add(10 * time.Second))
	fmt.Println()
	<-a
	c.Close() // Close after failure
	return nil

}
