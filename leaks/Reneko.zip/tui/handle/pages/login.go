package pages

import (
	"fmt"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"net"
	"time"
)

func Login(c net.Conn, a chan structs.Actions) *sessions.Session {
	const tries = 3
login:
	for i := 0; tries > i; i++ {
		ch := make(chan interface{})
		toggle := json.LoginPos.Toggle
		username := json.LoginPos.Username
		password := json.LoginPos.Password
		box := &ui.Box{
			Cord:   structs.Cord{X: 20, Y: 7},
			Height: 8,
			Width:  40,
		}
		subtext := json.LoginPos.Subtext
		new := json.LoginPos.Register
		login := json.LoginPos.Submit

		password.Masked = toggle.On
		go func() { // Render asset
			for {

				select {

				case <-ch:

					close(ch)

					return // DIE

				default:
					var text string = files.Login

					username.Print(&text)
					password.Print(&text)
					toggle.Print(&text)
					box.PrintErr(&text)

					fmt.Fprintf(c, "\x1b[0;0H%s", text)
					util.Title(c, json.LoginPos.Title)
					time.Sleep(time.Millisecond * conf.Delay) // Render frames relay
					subtext.Move()
				}

			}

		}()
		for {

			action, ok := <-a // Get current action!
			if !ok {
				return nil
			}
			switch action.Type {

			case globals.MouseLeftClick: // check if object pressed
				switch {

				case toggle.Click(util.GetPos(action.Data)):
					password.Masked = toggle.On
				case username.Click(util.GetPos(action.Data)):

				case password.Click(util.GetPos(action.Data)):

				case login.Click(util.GetPos(action.Data)):

					sess, err := sessions.Login(username.Text, password.Text, c, a) // Attempt to Create session!

					if err != nil {
						box.Appear()
						box.Text = []string{
							"",
							err.Error(),
						}
						<-a
						box.Disappear()
						ch <- 2
						continue login
					}
					ch <- 2
					return sess

				case new.Click(util.GetPos(action.Data)):
					ch <- 1337
					return Register(c, a)
				}

			case globals.KeyPress: // Process if reading only
				switch {
				case username.Active:
					username.Input(action)
				case password.Active:
					password.Input(action)
				}
			case globals.BackSpace:
				switch {
				case username.Active:
					username.Backspace()
				case password.Active:
					password.Backspace()
				}

			}
		}
		ch <- 0 // close render function

	}
	c.SetReadDeadline(time.Now().Add(10 * time.Second))
	fmt.Println()
	<-a
	c.Close() // Close after failure
	return nil

}
