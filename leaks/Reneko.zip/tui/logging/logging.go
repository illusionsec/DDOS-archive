package logging

import "log"

func Print() { // Will work on later!
	log.Println()
}
