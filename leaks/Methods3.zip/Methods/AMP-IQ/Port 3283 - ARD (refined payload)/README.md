# ARD (Apple Remote Desktop)

## Port: 3283

## Proto: UDP

## Amplification factor: 33x

---
