# MSSQL (Microsoft SQL Server)

## Port: 1434

## Proto: UDP

## Amplification factor: 10-30x

---
