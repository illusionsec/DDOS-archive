# IPSec Internet Key Exchange (IPSec-IKE)

## Port: 500

## Proto: UDP

## Amplification factor: 4-5x

---

1100000000000000000000000000000001
Length dependant response.
