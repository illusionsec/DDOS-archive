# Sentinel (RMS License Manager)

## Port: 5093

## Proto: UDP

## Amplification factor: 20x

---
