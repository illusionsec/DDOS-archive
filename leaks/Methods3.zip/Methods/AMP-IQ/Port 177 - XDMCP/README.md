# XDMCP (X Display Manager Control Protocol)

## Port: 177

## Proto: UDP

## Amplification factor: 7x

---
