# QOTD (Quote of the day)

## Port: 17

## Proto: UDP

## Amplification factor: 30-100x

---
