package util

func GetPos(i interface{}) []int {
	n, ok := i.([]int)
	if !ok {
		return []int{}
	}
	return n
}
