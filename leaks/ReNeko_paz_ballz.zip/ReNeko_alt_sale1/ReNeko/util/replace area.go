package util

import (
	"neko/structs"
	"strings"
)

/*
this took a lot of debugging to actually make functional
*/

//This will be used to add all updates to an asset

func Replace(pos structs.Cord, text string, replace string) string {

	text = Escape(text)
	replace = Escape(replace)

	replace_lines := strings.Split(replace, "\r\n")

	lines := strings.SplitAfterN(text, "\n", -1)
	if len(lines) < pos.Y { // if not enough space
		return strings.ReplaceAll(text, "\b", "")
	}
	pos.Y--
	for y, this := range replace_lines {

		lines[pos.Y+y] = Put(this, lines[pos.Y+y], pos.X)

	}
	return strings.ReplaceAll(strings.Join(lines, ""), "\b", "")
}

// replace pos while ignoring ansi escaped charactors
func Put(strnew, strsrc string, i int) string {
	var b, pos, start int
	var is bool
	src := EscapeSplit(strsrc)
	new := EscapeSplit(strnew)
	for n, str := range src {
		if Ansi.MatchString(str) { // if ansi ignore
			if is {
				start++
			}
			continue
		}
		if b >= i {
			is = false
			if pos >= Runesize(new) {
				return strings.Join(src[:start], "") + strnew + strings.Join(src[n:], "") // slide in between for flawless replace
			}
			pos++
			continue
		}
		is = true
		start = n + 1
		b++

	}
	return strsrc
}

//Get rune size with ansi removed
func Runesize(str []string) int { // It may be a []string but they are actually single runes besides ansi escape codes
	var size int
	for _, s := range str {
		if Ansi.MatchString(s) { // ignore ansi
			continue
		}
		size++ // normal rune
	}
	return size
}
