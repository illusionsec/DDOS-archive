package util

func ColorBool(v bool) string {
	if v {
		return "\x1b[32mTrue\x1b[0m" //13
	} else {
		return "\x1b[31mFalse\x1b[0m" //14
	}
}
