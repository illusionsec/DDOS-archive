package util

import (
	"net"
)

func Title(c net.Conn, s string) {
	c.Write([]byte("\033]0;" + s + "\007"))
}
