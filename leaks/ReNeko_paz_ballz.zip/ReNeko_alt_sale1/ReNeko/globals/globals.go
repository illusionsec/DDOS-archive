package globals

//Actions
const (
	KeyPress  = "KeyPress"
	EnterKey  = "EnterKey"
	BackSpace = "BackSpace"
	TabKey    = "Tabkey"

	UpKey    = "UpKey"
	DownKey  = "DownKey"
	LeftKey  = "LeftKey"
	RightKey = "RightKey"

	MouseLeftClick  = "MouseLeftClick"
	MouseRightClick = "MouseRightClick"
	MouseSrcollUp   = "MouseSrcollUp"
	MouseSrcollDown = "MouseSrcollDown"

	End = "End"

	Unknown = "Unknown"
)
