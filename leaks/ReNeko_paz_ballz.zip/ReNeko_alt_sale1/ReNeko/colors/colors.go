package colors

import "fmt"

const (
	esc = "\x1b"
	//Foreground
	BlackFg   = esc + "[30m"
	RedFg     = esc + "[31m"
	GreenFg   = esc + "[32m"
	YellowFg  = esc + "[33m"
	BlueFg    = esc + "[34m"
	MagentaFg = esc + "[35m"
	CyanFg    = esc + "[36m"
	WhiteFg   = esc + "[37m"
	DefaultFg = esc + "[39m"
	//Background
	BlackBg   = esc + "[40m"
	RedBg     = esc + "[41m"
	GreenBg   = esc + "[42m"
	YellowBg  = esc + "[43m"
	BlueBg    = esc + "[44m"
	MagentaBg = esc + "[45m"
	CyanBg    = esc + "[46m"
	WhiteBg   = esc + "[47m"
	DefaultBg = esc + "[49m"

	Reset = esc + "[0m"
)

func Tag(color string, text string) string {
	return fmt.Sprintf("[%s%s%s]", color, text, Reset)
}
