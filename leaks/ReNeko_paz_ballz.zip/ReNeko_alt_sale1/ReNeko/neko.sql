USE reneko;
CREATE TABLE attacks (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(10) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `host` text NOT NULL,
  `sent` int(10) unsigned NOT NULL,
  `duration` int(10) unsigned NOT NULL,
  `method` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
)

CREATE TABLE users (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(100) NOT NULL,
  `concurrents` varchar(32) NOT NULL,
  `timelimit` int unsigned DEFAULT NULL,
  `cooldown` int unsigned NOT NULL,
  `expiry` bigint DEFAULT '0',
  `admin` bool NOT NULL,
  `verified` bool NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
)

CREATE TABLE verify (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `code` int(20) NOT NULL, 
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
)