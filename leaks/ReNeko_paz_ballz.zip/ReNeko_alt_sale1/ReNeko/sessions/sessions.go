package sessions

import (
	"errors"
	"fmt"
	"log"
	"neko/colors"
	"neko/mysql"
	"neko/structs"
	"net"
	"sync"
	"time"
)

var Sessions = make(map[string]Session)

var mut sync.Mutex

type Session struct {
	User    structs.User
	Text    string
	Login   time.Time
	Conn    net.Conn
	Actions chan structs.Actions
	close   chan interface{}
}

//Handle User auth and create a session for user
func Login(user string, password string, c net.Conn, a chan structs.Actions) (*Session, error) {

	mut.Lock()
	defer mut.Unlock()

	_, ok := Sessions[user]
	if ok {
		return nil, errors.New("this user is already logged in")
	}
	ok, u := mysql.Login(user, password)

	if !ok {
		return nil, errors.New("login failed")
	}

	ch := make(chan interface{}) // chan to kill user data lopp function

	var s = &Session{
		User:    *u,
		Login:   time.Now(),
		Conn:    c,
		Actions: a,
		close:   ch,
	}
	Sessions[user] = *s
	s.loop()

	log.Printf("[sessions] Session created for %s", user)

	return s, nil

}

func (s *Session) Close() {

	mut.Lock() // Use mut to stop multiple functions from accessing sessions map at once
	defer mut.Unlock()
	if _, ok := Sessions[s.User.Username]; !ok {
		return
	}
	delete(Sessions, s.User.Username) // remove from online users
	s.close <- 0                      // User update chan to kill goroutine
	s.Conn.Close()                    // Close connection
	log.Printf("[sessions] Removed session for %s", s.User.Username)

}

func (s *Session) loop() {
	go func() {
		for {
			select {
			case <-s.close:
				return
			default:
				mysql.User(&s.User)
				time.Sleep(5 * time.Second)
			}

		}
	}()

}

func PrettyOnline() []string {
	var s []string
	mut.Lock()
	for _, u := range mysql.ListUsers() {
		i, ok := Sessions[u]
		if !ok {
			continue
		}
		switch {
		case i.User.Owner:
			//✨👑♛
			s = append(s, fmt.Sprint(colors.CyanFg+"✧"+colors.Reset+i.User.Username))
		case i.User.Admin:
			s = append(s, fmt.Sprint(colors.YellowFg+"★"+colors.Reset+i.User.Username))

		default:
			s = append(s, fmt.Sprint("•"+i.User.Username))
		}
	}
	mut.Unlock()
	return s
}

func Kick(u string) error {
	mut.Lock() // Use mut to stop multiple functions from accessing sessions map at once
	defer mut.Unlock()
	s, ok := Sessions[u]
	if !ok {
		return errors.New("this user it not online")
	}
	s.Close()
	return nil
}
