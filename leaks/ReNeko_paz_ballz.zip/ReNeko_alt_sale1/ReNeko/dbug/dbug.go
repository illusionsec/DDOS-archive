package dbug

import "fmt"

var debug bool

func Print(s string, i ...interface{}) {
	if debug {
		fmt.Printf(s, i...)
		fmt.Println()
	}
}

func Debug() {
	debug = true
}
