package markup

func ReadA(pos int, input string, find string) bool {
	if len(input) >= pos+len(find) {
		if input[pos:pos+len(find)] == find {
			return true
		}
	}
	return false
}
