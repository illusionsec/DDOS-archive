package markup

import "neko/structs"

type Index map[string]interface{}

func (i Index) Process(s string, u structs.User) string {

	return s
}
