package conf

const Delay = 200
