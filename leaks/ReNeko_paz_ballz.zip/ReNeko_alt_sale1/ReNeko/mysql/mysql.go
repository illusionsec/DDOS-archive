package mysql

import (
	"database/sql"
	"fmt"
	"log"
	"neko/json"
	"os"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB

func Init() {
	d, err := sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s)/%s", json.Config.MySQL.Username, json.Config.MySQL.Password, json.Config.MySQL.Host, json.Config.MySQL.Table))
	if err != nil {
		log.Fatalf("Could not connect to database Error: \"%s\"", err)
		os.Exit(1)
	}
	log.Printf("Init() Connected to database")
	d.SetMaxOpenConns(0)
	d.SetConnMaxLifetime(time.Second * 10)
	db = d
}
