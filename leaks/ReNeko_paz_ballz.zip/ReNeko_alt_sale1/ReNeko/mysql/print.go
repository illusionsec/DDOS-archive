package mysql

import (
	"neko/colors"
	"neko/dbug"
)

func myerr(s string) {
	dbug.Print("%s Error: \"%s\"", colors.Tag(colors.RedFg, "MySQL"), s)
}

func mylog(s string) {
	dbug.Print("%s %s", colors.Tag(colors.GreenFg, "MySQL"), s)
}
