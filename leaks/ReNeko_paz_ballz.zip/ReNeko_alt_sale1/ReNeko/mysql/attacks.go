package mysql

import (
	"fmt"
	"neko/structs"
	"time"
)

func UserAttacks(user string) []structs.Attack {
	var attacks []structs.Attack
	r, err := db.Query("select * from attacks where username = ? and (sent + duration) > UNIX_TIMESTAMP()", user)
	if err != nil {
		return attacks
	}
	for r.Next() {
		var a structs.Attack
		r.Scan(&a.ID, &a.Username, &a.Host, &a.Sent, &a.Duration, &a.Method)
		attacks = append(attacks, a)
	}
	return attacks
}

func Attacks() []structs.Attack {
	var attacks []structs.Attack
	r, err := db.Query("select * from attacks where (sent + duration) > UNIX_TIMESTAMP()")
	if err != nil {
		return attacks
	}
	for r.Next() {
		var a structs.Attack

		r.Scan(&a.ID, &a.Username, &a.Host, &a.Sent, &a.Duration, &a.Method)
		attacks = append(attacks, a)
	}
	return attacks
}

func Attackstrings(a []structs.Attack) []string {
	var s []string
	for _, i := range a {

		s = append(s, fmt.Sprintf("%-15s %-12s %.fs", i.Host, i.Method, time.Until(time.Unix(i.Sent+i.Duration, 0)).Seconds()))

	}
	return s
}

func Attack(user, host, duration, method string) error {
	_, err := db.Exec("insert into attacks (username,host,sent,duration,method) values (?,?,?,?,?)", user, host, time.Now().Unix(), duration, method)
	return err

}
