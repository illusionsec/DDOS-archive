package structs

type Actions struct {
	Type string
	Data interface{}
}

type Config struct {
	Port int `json:"port"`

	MySQL struct {
		Host     string `json:"host"`
		Username string `json:"username"`
		Password string `json:"password"`
		Table    string `json:"table"`
	} `json:"mysql"`

	Assets map[string]string `json:"assets"`
}

type Cord struct {
	X int
	Y int
}

type Coordinates struct {
	P1 Cord
	P2 Cord
}

type User struct {
	Username string // Useful for getting map value etc
	Email    string

	Admin    bool
	Verified bool
	Owner    bool

	Timelimit  int
	Cooldown   int
	Concurrent int
	Joined     int64
	Expiry     int64
}

type Gradients []Gradient

type Gradient struct {
	Name    string   `json:"name"`
	Type    string   `json:"type"`
	Colors  []Colors `json:"colors"`
	Colors2 []Colors `json:"more colors"`
}

type Colors struct {
	R int `json:"r"`
	G int `json:"g"`
	B int `json:"b"`
}

type SMTP struct {
	Hostname string `json:"hostname"`
	Port     int    `json:"port"`
	Username string `json:"username"`
	Password string `json:"password"`
}

type Method struct {
	Name string   `json:"name"`
	Time *int     `json:"time"`
	Apis []string `json:"apis"`
}

type Blacklist struct {
	Prefix *string `json:"prefix"`
	Octal  *int    `json:"octal"`
	Reason *string `json:"reason"`
}

type Message struct {
	Username string
	Admin    bool
	Owner    bool
	Content  string
	Sent     int64
}

type Attack struct {
	ID       int
	Username string
	Host     string
	Sent     int64
	Duration int64
	Method   string
}
