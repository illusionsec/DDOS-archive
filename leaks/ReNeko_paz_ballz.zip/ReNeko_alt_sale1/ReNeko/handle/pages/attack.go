package pages

import (
	"fmt"
	"neko/attack"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"time"
)

func Attack(session *sessions.Session) {

	subtext := json.AttackPos.Subtext
	scroll := json.AttackPos.Scroll
	duration := json.AttackPos.Duration
	port := json.AttackPos.Port
	host := json.AttackPos.Host
	erro := &ui.Box{
		Cord:   structs.Cord{X: 20, Y: 7},
		Height: 8,
		Width:  40,
	}
	alr := &ui.Box{
		Cord:   structs.Cord{X: 20, Y: 7},
		Height: 8,
		Width:  40,
	}
	ch := make(chan interface{}) // Channel to "Kill" rendor GoRoutine
	ex := null
	defer func() {
		ch <- 1
		ex(session)
	}()
	go func() { // Render asset
		for {

			select {

			case <-ch:

				close(ch)

				return // DIE

			default:
				scroll.Options = attack.List()
				var text string = files.Attack

				host.Print(&text) // I will clean these up later hopfully
				port.Print(&text)
				duration.Print(&text)
				subtext.Print(&text)
				scroll.Print(&text)

				alr.PrintAlert(&text)
				erro.PrintErr(&text)
				util.Title(session.Conn, json.AttackPos.Title)
				fmt.Fprintf(session.Conn, "\x1b[0;0H%s", text)
				time.Sleep(time.Millisecond * conf.Delay) // Render frames relay
				subtext.Move()
			}

		}

	}()

	for {

		action, ok := <-session.Actions // Get current action!
		if !ok {
			return
		}

		switch action.Type {

		case globals.MouseLeftClick: // check if object pressed
			p := util.GetPos(action.Data)
			switch {
			case host.Click(p):
			case port.Click(p):
			case duration.Click(p):

			case scroll.Click(p, true):

			case json.AttackPos.Send.Click(p):
				if scroll.Selected != nil {
					if err := attack.Attack(*session, host.Text, port.Text, duration.Text, *scroll.Selected); err != nil {
						erro.Text = []string{
							"",
							err.Error(),
							"",
							"contact admin for resolution",
						}
						erro.Appear()
						<-session.Actions
						erro.Disappear()
					} else {
						alr.Text = []string{
							"*This attack has successfully be sent*",
							fmt.Sprintf("Host:\"%s\"", host.Text),
							fmt.Sprintf("Port:\"%s\"", port.Text),
							fmt.Sprintf("Duration:\"%s\"", duration.Text),
							fmt.Sprintf("Method:\"%s\"", *scroll.Selected),
						}
						alr.Appear()
						<-session.Actions
						alr.Disappear()
					}
					host.Text = ""

				}

			case json.CommunityPos.AdminPage.Click(p):
				if !session.User.Admin {
					erro.Text = []string{
						"",
						"you are not an admin",
					}
					erro.Appear()
					<-session.Actions
					erro.Disappear()
				}
				ex = Admin
				return
			case json.CommunityPos.CommunityPage.Click(p):
				ex = Community
				return
			case json.CommunityPos.AttackPage.Click(p):
				ex = Attack
				return
			case json.CommunityPos.UserPage.Click(p):
				ex = User
				return
			}

		case globals.KeyPress: // Process if reading only
			switch {
			case host.Active:
				host.Input(action)
			case port.Active:
				port.Input(action)
			case duration.Active:
				duration.Input(action)
			}
		case globals.BackSpace:
			switch {
			case host.Active:
				host.Backspace()
			case port.Active:
				port.Backspace()
			case duration.Active:
				duration.Backspace()
			}
		case globals.MouseSrcollUp:
			if scroll.Click(util.GetPos(action.Data), false) {
				scroll.Scroll_up()
			}
		case globals.MouseSrcollDown:
			if scroll.Click(util.GetPos(action.Data), false) {
				scroll.Scroll_down()
			}

		}
	}
}

/*
x20,y4
when switching pages:
defer NewPage(c,a)
close(ch)
return
*/
