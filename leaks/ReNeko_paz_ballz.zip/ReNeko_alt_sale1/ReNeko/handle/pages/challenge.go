package pages

import (
	"errors"
	"fmt"
	"math/rand"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/structs"
	"neko/util"
	"net"
	"strconv"
	"time"
)

//Might Remove this after it is in production stages
/*
const HardCoded_Asset = "\x1b[2J\x1b[3J\x1b[H╓──────────────────────────────────────────────────────────────────────────────╖\r\n" +
	"║                             ╦═╗╔═╗  ╔╗╔╔═╗╦╔═╔═╗                             ║\r\n" +
	"║                             ╠╦╝║╣ o ║║║║╣ ╠╩╗║ ║                             ║\r\n" +
	"║                             ╩╚═╚═╝o ╝╚╝╚═╝╩ ╩╚═╝                             ║\r\n" +
	"║                     Welcome to RE: Neko to login please                      ║\r\n" +
	"║                      solve the following math problem:                       ║\r\n" +
	"║                                                                              ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m   1   \x1b[0m \x1b[1;37;42m   2   \x1b[0m \x1b[1;37;42m   3   \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║                                                                              ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m   4   \x1b[0m \x1b[1;37;42m   5   \x1b[0m \x1b[1;37;42m   6   \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║                                                                              ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m   7   \x1b[0m \x1b[1;37;42m   8   \x1b[0m \x1b[1;37;42m   9   \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║                                                                              ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;31;42m   <   \x1b[0m \x1b[1;37;42m   0   \x1b[0m \x1b[1;33;42m   ➤   \x1b[0m                                            ║\r\n" +
	"║           \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m \x1b[1;37;42m       \x1b[0m                                            ║\r\n" +
	"║                                                                              ║\r\n" +
	"╙──────────────────────────────────────────────────────────────────────────────╜"
*/
func Challenge(c net.Conn, a chan structs.Actions) error {
	//Do not render asset
	util.Title(c, "-")
	fmt.Fprint(c, "\x1b[0;0H"+files.Challege) // Print Asset
	rand.Seed(time.Now().Unix())
	s1 := rand.Intn(9) + 1
	s2 := rand.Intn(9) + 1
	ans := s1 + s2
	fmt.Fprintf(c, "\x1b[10;52H%d + %d", s1, s2)
	fmt.Fprintf(c, "\x1b[1;30;47m\x1b[12;48H%-15s\x1b[0m", "...")
	var input string
chloop:
	for {
		interaction, ok := <-a
		if !ok {
			return errors.New("disconnect")
		}
		switch interaction.Type {
		/*
			case globals.KeyPress:
				b, ok := interaction.Data.(string)
				if !ok {
					continue chloop
				}
				if !unicode.IsDigit(rune(b[0])) {
					continue chloop
				}
				if len(input) < 15 {
					input += string(interaction.Data.(string))
				}

			case globals.BackSpace:
				if len(input) == 1 {
					input = ""
				}
				if len(input) > 0 {
					input = input[:len(input)-2]
				}
			case globals.EnterKey:
				break chloop*/
		case globals.MouseLeftClick:
			ma := IsKeyClick(interaction)
			if ma == nil {
				continue chloop
			}
			switch *ma {
			case "":
				continue chloop
			case "e":
				break chloop
			case "b":
				if len(input) > 0 {
					input = input[:len(input)-1]
				}
			default:
				if len(input) < 15 {
					input += *ma
				}
			}
		}
		fmt.Fprintf(c, "\x1b[1;30;47m\x1b[12;48H%-15s\x1b[0m", input)

	}

	g, err := strconv.Atoi(input)

	if err != nil || g != ans {
		fmt.Fprintf(c, "\x1b[1;37;41m\x1b[12;48H%-15s\x1b[0m", "Failed!")
		<-a
		return errors.New("Failed")
	}
	fmt.Fprintf(c, "\x1b[1;30;42m\x1b[12;48H%-15s\x1b[0m", "Success!")

	<-a

	return nil
}

func IsKeyClick(a structs.Actions) *string {
	i, ok := a.Data.([]int)
	if !ok {
		return nil
	}

	x := i[0]
	y := i[1]
	for name, cords := range json.ChallengePos {

		if (x >= cords.P1.X && x <= cords.P2.X) && (y >= cords.P1.Y && y <= cords.P2.Y) {
			return &name
		}

	}

	return nil
}
