package pages

import (
	"fmt"
	"math/rand"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/mailer"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"net"
	"strings"
	"time"
)

//const tries = 3

func Verify(c net.Conn, a chan structs.Actions, email string) bool {
	const tries = 5
	for i := 0; tries > i; i++ {
		ch := make(chan interface{})
		code := json.VerifyPos.Code
		answer := fmt.Sprintf("%04d", rand.Intn(999999))

		box := &ui.Box{
			Cord:   structs.Cord{X: 20, Y: 7},
			Height: 8,
			Width:  40,
		}
		submit := json.VerifyPos.Submit
		go func() { // Render asset
			for {

				select {

				case <-ch:

					close(ch)

					return // DIE

				default:
					var text string = files.Verify
					code.Print(&text) // I will clean these up later hopfully
					box.PrintErr(&text)
					fmt.Fprintf(c, "\x1b[0;0H%s", text)
					time.Sleep(time.Millisecond * conf.Delay) // Render frames relay
				}

			}

		}()
		if !mailer.Send(email, fmt.Sprintf("Your Neko CNC Verifcation Code: %s", answer)) {
			box.Appear()
			box.Text = []string{
				"",
				"There was an issue sending an email",
				"to that address!",
			}
			time.Sleep(time.Second * 5)
			box.Disappear()
			ch <- 2
			return false
		}
	ver:
		for {

			action, ok := <-a // Get current action!
			if !ok {
				return false
			}
			switch action.Type {

			case globals.MouseLeftClick: // check if object pressed
				switch {

				case code.Click(util.GetPos(action.Data)): //Function handles all that needs to be done.

				case submit.Click(util.GetPos(action.Data)): // Custom handle for this action
					if answer == strings.TrimSpace(code.Text) {
						ch <- 2
						return true
					}
					box.Appear()
					box.Text = []string{
						"",
						"Your submitted the wrong code!",
						"The answer was " + answer,
						"and you submitted " + code.Text,
					}
					box.Disappear()

					break ver
				}

			case globals.KeyPress: // Process if reading only
				code.Input(action)
			case globals.BackSpace:
				code.Backspace()
			}
		}
		ch <- 0 // close render function

	}
	c.SetReadDeadline(time.Now().Add(10 * time.Second))
	fmt.Println()
	<-a
	c.Close() // Close after failure
	return false

}
