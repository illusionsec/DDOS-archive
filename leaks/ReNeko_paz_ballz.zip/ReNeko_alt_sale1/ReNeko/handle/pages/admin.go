package pages

import (
	"fmt"
	"neko/conf"
	"neko/files"
	"neko/globals"
	"neko/json"
	"neko/mysql"
	"neko/sessions"
	"neko/structs"
	"neko/ui"
	"neko/util"
	"time"
)

func Admin(session *sessions.Session) {

	if !session.User.Admin {
		return
	}

	ch1 := make(chan interface{})
	ch2 := make(chan interface{})

	erro := &ui.Box{
		Cord:   structs.Cord{X: 20, Y: 7},
		Height: 8,
		Width:  40,
	}
	adm := json.AdminPos
	col := ui.Scroll{
		Text:    "Select",
		Width:   adm.Column.Length,
		Height:  5,
		Cords:   adm.Column.Cords,
		Options: []string{"password", "timelimit", "cooldown", "admin", "email", "concurrents"},
	}

	ex := null
	defer func() {
		ch1 <- 1
		ch2 <- 1
		ex(session)
	}()
	go func() {
		for {
			select {
			case <-ch1:
				close(ch1)
				return
			default:
				var u structs.User
				adm.User.Options = mysql.ListUsers()

				if adm.User.Selected == nil {
					adm.Attacks.Text = mysql.Attackstrings(mysql.Attacks())
				} else {
					u.Username = *adm.User.Selected
					adm.Attacks.Text = mysql.Attackstrings(mysql.UserAttacks(session.User.Username))
				}
				mysql.User(&u)
				if u.Username == "" {
					adm.Info.Text = []string{}
				} else {
					_, ok := sessions.Sessions[u.Username]
					adm.Info.Text = []string{
						fmt.Sprintf("Email: %s", u.Email),
						fmt.Sprintf("Cooldown: %d", u.Cooldown),
						fmt.Sprintf("Concurrent: %d", u.Concurrent),
						fmt.Sprintf("Admin: %s", util.ColorBool(u.Admin)),
						fmt.Sprintf("Owner: %s", util.ColorBool(u.Admin)),
						fmt.Sprintf("Expiry: %s", time.Unix(u.Expiry, 0).Format("Jan/02/2006")),
						fmt.Sprintf("Online: %s", util.ColorBool(ok)),
					}
				}
				time.Sleep(time.Second)
			}
		}
	}()
	adm.Info.Appear()
	adm.Attacks.Appear()
	go func() {
		for {
			select {
			case <-ch2:
				close(ch2)
				return
			default:
				var text = files.Admin

				adm.Attacks.Print(&text)
				col.Print(&text)
				adm.Info.Print(&text)
				adm.User.Print(&text)
				adm.Value.Print(&text)
				erro.PrintErr(&text)
				util.Title(session.Conn, adm.Title)
				fmt.Fprint(session.Conn, text)
				time.Sleep(time.Millisecond * conf.Delay)
			}
		}
	}()
	for {
		action, ok := <-session.Actions
		if !ok {
			return
		}
		switch action.Type {
		case globals.MouseLeftClick:
			p := util.GetPos(action.Data)
			switch {
			case adm.User.Click(p, true):
				fallthrough
			case adm.Value.Click(p):
				fallthrough
			case col.Click(p, true):
				fallthrough

			case adm.Enter.Click(p):
				if adm.User.Selected != nil && col.Selected != nil {
					err := mysql.Update(*adm.User.Selected, *col.Selected, adm.Value.Text)
					if err != nil {
						erro.Appear()
						erro.Text = []string{
							"",
							err.Error(),
						}
						<-session.Actions
						erro.Disappear()
						continue
					}
				}
			case adm.Ban.Click(p):
				if adm.User.Selected != nil {
					err := mysql.Ban(*adm.User.Selected, adm.Value.Text)
					if err != nil {
						erro.Appear()
						erro.Text = []string{
							"",
							err.Error(),
						}
						<-session.Actions
						erro.Disappear()
					}
				}
			case adm.Unban.Click(p):
				if adm.User.Selected != nil {
					err := mysql.Unban(*adm.User.Selected)
					if err != nil {
						erro.Appear()
						erro.Text = []string{
							"",
							err.Error(),
						}
						<-session.Actions
						erro.Disappear()
					}
				}
			case adm.Kick.Click(p):
				if adm.User.Selected != nil {

					if err := sessions.Kick(*adm.User.Selected); err != nil {
						erro.Appear()
						erro.Text = []string{
							"",
							err.Error(),
						}
						<-session.Actions
						erro.Disappear()
					}
				}
			case json.CommunityPos.AdminPage.Click(p):
				ex = Admin
				return
			case json.CommunityPos.CommunityPage.Click(p):
				ex = Community
				return
			case json.CommunityPos.AttackPage.Click(p):
				ex = Attack
				return
			case json.CommunityPos.UserPage.Click(p):
				ex = User
				return
			}
		case globals.KeyPress:
			adm.Value.Input(action)
			adm.Column.Input(action)
		case globals.BackSpace:
			adm.Value.Backspace()
			adm.Column.Backspace()
		case globals.MouseSrcollUp:
			if adm.User.Click(util.GetPos(action.Data), false) {
				adm.User.Scroll_up()
			}
		case globals.MouseSrcollDown:
			if adm.User.Click(util.GetPos(action.Data), false) {
				adm.User.Scroll_down()
			}

		}
	}
}
