package pages

import "neko/sessions"

//Null function
var null func(session *sessions.Session)
