package files

import (
	"io/ioutil"
	"log"
	"time"
)

var (
	Challege,
	Login,
	Attack,
	Register,
	Verify,
	Community,
	User,
	Admin string
)

var files = map[string]*string{
	"./_assets/challenge page/challenge.txt": &Challege,
	"./_assets/login page/login.txt":         &Login,
	"./_assets/register page/register.txt":   &Register,
	"./_assets/attack page/attack.txt":       &Attack,
	"./_assets/verify page/verify.txt":       &Verify,
	"./_assets/community page/community.txt": &Community,
	"./_assets/user page/user.txt":           &User,
	"./_assets/admin page/admin.txt":         &Admin,
}

func render() {
	for file, pointer := range files {

		b, err := ioutil.ReadFile(file)
		if err != nil {
			log.Printf("[files/get.go] Error \"%s\"", err)
		}
		*pointer = string(b)
	}
}

func Init() { //  Start loop for opening asset files
	render()
	go func() {
		for {
			render()
			time.Sleep(time.Second * 5)
		}
	}()
}
