package ui

import (
	"fmt"
	"neko/colors"
	"neko/structs"
	"neko/util"
	"strings"
)

type Box struct {
	Text   []string
	Cord   structs.Cord
	Show   bool
	Height int
	Width  int
}

func (b *Box) Appear() {
	b.Show = true
}

func (b *Box) Disappear() {
	b.Show = false
}

func (b *Box) PrintAlert(text *string) {
	if !b.Show {
		return
	}
	title := "[!] Alert"
	*text = util.Replace(b.Cord, *text, b._print(colors.YellowBg+colors.BlackFg+"%s"+colors.Reset, &title))
}

func (b *Box) PrintErr(text *string) {
	if !b.Show {
		return
	}
	title := "[X] Error"
	*text = util.Replace(b.Cord, *text, b._print(colors.RedBg+colors.BlackFg+"%s"+colors.Reset, &title))

}

func (b *Box) Print(text *string) {
	if !b.Show {
		return
	}
	*text = util.Replace(b.Cord, *text, b._print("%s", nil))
}

func (b *Box) _print(line string, title *string) string {
	var out string
	var p int
	if title != nil {
		t := *title
		if len(*title) > b.Width {
			out += t[:b.Width]
		} else {
			out += fmt.Sprintf(line, t+util.Mutlistr(" ", (b.Width-len(t))))
		}
		out += "\r\n"
		p++
	}
	for _, s := range b.Text {
		if len(s) > b.Width {

			out += fmt.Sprintf(line, util.Limit(s, b.Width))
		} else {
			out += fmt.Sprintf(line, util.Limit(s+util.Mutlistr(" ", (b.Width-len(s))), b.Width))
		}
		out += "\r\n"
		p++

	}
	return strings.TrimSuffix(out, "\r\n")
}
