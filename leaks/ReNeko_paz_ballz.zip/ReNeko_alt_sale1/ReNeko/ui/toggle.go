package ui

import (
	"neko/colors"
	"neko/structs"
	"neko/util"
)

const (
	on  = colors.GreenFg + "O" + colors.Reset
	off = colors.RedFg + "X" + colors.Reset
)

type Toggle struct {
	On   bool
	Cord structs.Cord
}

func (t *Toggle) Toggle() {
	t.On = !t.On
}

func (t *Toggle) Print(text *string) {
	var str string
	if t.On {
		str = on
	} else {
		str = off
	}
	*text = util.Replace(structs.Cord{
		X: t.Cord.X - 1,
		Y: t.Cord.Y,
	}, *text, str)
}

func (t *Toggle) Click(click []int) bool {
	c := (click[0] == t.Cord.X && click[1] == t.Cord.Y)

	if c {
		t.Toggle()
	}

	return c

}
