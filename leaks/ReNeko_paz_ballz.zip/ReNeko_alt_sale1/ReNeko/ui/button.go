package ui

import "neko/structs"

type Button struct {
	Cords structs.Coordinates
}

func (i *Button) Click(click []int) bool {
	return Click(structs.Cord{
		X: click[0],
		Y: click[1],
	}, i.Cords)
}
