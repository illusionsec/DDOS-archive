import argparse
import sys
import requests
from concurrent.futures import ThreadPoolExecutor
import time
from colorama import init, Fore, Style
from bs4 import BeautifulSoup

init(autoreset=True)

def chezburga(ip, port, protocol, outburga, debug, title_to_search):
    url = f"{protocol}://{ip}:{port}"
    try:
        if protocol == "https":
            response = requests.get(url, timeout=7, verify=False)
        else:
            response = requests.get(url, timeout=7)

        if response.status_code == 200:
            valid = True
            if title_to_search:
                soup = BeautifulSoup(response.content, "html.parser")
                page_title = soup.title.string.strip() if soup.title else ""
                valid = title_to_search == page_title

            if valid:
                if debug:
                    print(f"{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} KITSUNE SCAN {Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} | {url} z{Fore.LIGHTMAGENTA_EX}VALID{Style.RESET_ALL}\n")
                with open(outburga, "a") as f:
                    f.write(url + "\n")
            else:
                if debug:
                    print(f"{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} KITSUNE SCAN {Fore.LIGHTMAGENTA_EX}≧{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} | {url} z{Fore.RED}INVALID TITLE{Style.RESET_ALL}\n")
        else:
            if debug:
                print(f"{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} KITSUNE SCAN {Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} | {url} z{Fore.RED}INVALID{Style.RESET_ALL}\n")
    except requests.RequestException:
        if debug:
            print(f"{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} KITSUNE SCAN {Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL}{Fore.YELLOW}w{Style.RESET_ALL}{Fore.LIGHTMAGENTA_EX}z{Style.RESET_ALL} | {url} z{Fore.RED}INVALID{Style.RESET_ALL}\n")

def process_stdin(port_list, protocol, outburga, speed, debug, title_to_search):
    with ThreadPoolExecutor(max_workers=speed) as executor:
        for line in sys.stdin:
            ip = line.strip()
            for port in port_list:
                executor.submit(chezburga, ip, port, protocol, outburga, debug, title_to_search)
                time.sleep(1 / speed)

def process_list(file, port_list, protocol, outburga, speed, debug, title_to_search):
    with open(file, "r") as f:
        ips = [line.strip() for line in f]

    with ThreadPoolExecutor(max_workers=speed) as executor:
        for ip in ips:
            for port in port_list:
                executor.submit(chezburga, ip, port, protocol, outburga, debug, title_to_search)
                time.sleep(1 / speed)

def load_ports(port_file):
    try:
        with open(port_file, "r") as f:
            return [int(line.strip()) for line in f if line.strip().isdigit()]
    except Exception as e:
        print(f"Error loading ports from {port_file}: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Check HTTP/HTTPS")
    parser.add_argument("--mode", choices=["stdin", "list"], required=True, help="Input mode: stdin or list.")
    parser.add_argument("--port", type=int, help="Port to test.")
    parser.add_argument("--portlist", type=str, help="File containing a list of ports to test.")
    parser.add_argument("--type", choices=["http", "https"], required=True, help="Protocol type: http or https.")
    parser.add_argument("--output", type=str, required=True, help="Output file to save valid URLs.")
    parser.add_argument("--file", type=str, help="Path to input file (for list mode).")
    parser.add_argument("--speed", type=int, default=5, help="Number of IPs to check per second.")
    parser.add_argument("--debug", action="store_true", help="Enable debug output.")
    parser.add_argument("--title", action="store_true", help="Enable title search.")

    args = parser.parse_args()

    if not args.port and not args.portlist:
        parser.error("Either --port or --portlist must be specified.")

    port_list = [args.port] if args.port else load_ports(args.portlist)

    title_to_search = None
    if args.title:
        title_to_search = input("Title to search for: ").strip()

    if args.mode == "list" and not args.file:
        parser.error("--file is required when mode is 'list'.")

    if args.mode == "stdin":
        process_stdin(port_list, args.type, args.output, args.speed, args.debug, title_to_search)
    elif args.mode == "list":
        process_list(args.file, port_list, args.type, args.output, args.speed, args.debug, title_to_search)

if __name__ == "__main__":
    main()