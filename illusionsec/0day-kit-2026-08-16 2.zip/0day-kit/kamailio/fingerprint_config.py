#!/usr/bin/env python3
# kamailio BEHAVIORAL fingerprint: is set_body_multipart() in the route config?
# Send INVITE (multipart/related body) addressed to a URI WE control; kamailio
# forwards after rebuild (record_route). If the received body is rewritten to
# multipart/mixed with boundary="unique-boundary-1" -> config vulnerable.
# Usage: python3 fingerprint_config.py <kamailio_ip> [local_ip] [listen_port]
import socket, sys, threading

def recv_body(sock, timeout=5):
    sock.settimeout(timeout)
    data = b""
    try:
        while True:
            d, _ = sock.recvfrom(65535)
            data += d
    except socket.timeout:
        pass
    return data

def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    local  = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
    lport  = int(sys.argv[3]) if len(sys.argv) > 3 else 5099

    lis = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    lis.bind(("0.0.0.0", lport))

    body = b"--X\r\npart1\r\n--X"
    msg = (
        f"INVITE sip:bob@{local}:{lport} SIP/2.0\r\n"
        f"Via: SIP/2.0/UDP {local}:5061;branch=z9hG4bK-1;rport\r\n"
        "Max-Forwards: 70\r\n"
        f"From: <sip:alice@{local}>;tag=1\r\n"
        f"To: <sip:bob@{local}>\r\n"
        f"Call-ID: fp@{local}\r\nCSeq: 1 INVITE\r\n"
        f"Contact: <sip:alice@{local}:5061>\r\n"
        "Content-Type: multipart/related;boundary=X\r\n"
        f"Content-Length: {len(body)}\r\n\r\n"
    ).encode() + body

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.sendto(msg, (target, 5060))

    data = recv_body(lis)
    if not data:
        print("[*] no forwarded message (not a forwarder / dropped) -> can't confirm")
        return
    text = data.decode(errors="replace")
    if 'multipart/mixed' in text and 'unique-boundary-1' in text:
        print("[+] VULNERABLE CONFIG: body rewritten to multipart/mixed (unique-boundary-1)")
        print("[+] set_body_multipart() is in the route config -> check_boundaries() reachable")
    else:
        print("[-] body NOT rewritten (arrived as multipart/related) -> config not vulnerable via set_body_multipart")

if __name__ == "__main__":
    main()
