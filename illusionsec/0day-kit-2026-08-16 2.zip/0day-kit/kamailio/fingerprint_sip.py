#!/usr/bin/env python3
# kamailio active fingerprint: SIP OPTIONS -> Server header (exact version)
# Usage: python3 fingerprint_sip.py <ip> [port] [udp|tcp]
#        python3 fingerprint_sip.py targets.txt   # one "ip:port proto" per line
import socket, sys

def sip_probe(ip, port=5060, proto="udp", timeout=3):
    msg = (f"OPTIONS sip:probe@{ip} SIP/2.0\r\n"
           f"Via: SIP/2.0/{proto.upper()} 1.2.3.4;branch=z9hG4bK-p\r\n"
           f"From: <sip:p@1.2.3.4>;tag=1\r\n"
           f"To: <sip:probe@{ip}>\r\n"
           f"Call-ID: x@{ip}\r\n"
           f"CSeq: 1 OPTIONS\r\nMax-Forwards: 1\r\nContent-Length: 0\r\n\r\n").encode()
    try:
        if proto == "tcp":
            s = socket.create_connection((ip, port), timeout)
        else:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(timeout)
        s.sendto(msg, (ip, port))
        data = s.recv(4096)
        s.close()
    except Exception:
        return None
    for line in data.decode(errors="replace").split("\r\n"):
        if line.lower().startswith("server:"):
            return line.strip()
    return None

if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args) == 1 and not args[0].replace(".", "").isdigit():
        for line in open(args[0]):
            parts = line.split()
            ip, port, proto = (parts + ["5060", "udp"])[:3]
            r = sip_probe(ip, int(port), proto)
            print(f"{ip}:{port}/{proto}  {r or 'no-response'}")
    else:
        ip = args[0]; port = int(args[1]) if len(args) > 1 else 5060
        proto = args[2] if len(args) > 2 else "udp"
        r = sip_probe(ip, port, proto)
        print(f"{ip}:{port}/{proto}  {r or 'no-response'}")
        print("=> VULNERABLE (all releases <= 6.1.3; fix d7a7f22 unreleased)" if r else "")
