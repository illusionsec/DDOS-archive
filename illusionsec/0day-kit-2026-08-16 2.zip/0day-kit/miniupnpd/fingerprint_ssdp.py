#!/usr/bin/env python3
# miniupnpd active fingerprint: SSDP M-SEARCH -> SERVER header (exact version)
# Usage: python3 fingerprint_ssdp.py <ip>           # single host
#        python3 fingerprint_ssdp.py targets.txt    # one IP per line
import socket, re, sys

def ssdp_probe(dst, timeout=3):
    m = (b"M-SEARCH * HTTP/1.1\r\nHOST:239.255.255.250:1900\r\n"
         b'MAN:"ssdp:discover"\r\nMX:1\r\nST:upnp:rootdevice\r\n\r\n')
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    s.sendto(m, (dst, 1900))
    hits = set()
    try:
        while True:
            data, _ = s.recvfrom(65535)
            if b"MiniUPnPd" in data:
                ver = re.search(rb"MiniUPnPd/([\d.]+)", data)
                hits.add(ver.group(1).decode() if ver else "?")
    except socket.timeout:
        pass
    return sorted(hits)

if __name__ == "__main__":
    args = sys.argv[1:]
    targets = open(args[0]).read().split() if len(args) == 1 and not args[0].replace(".", "").isdigit() else args[:1]
    for ip in targets:
        vers = ssdp_probe(ip)
        if vers:
            for v in vers:
                vuln = "VULNERABLE (<=2.3.10)" if v != "2.3.11" else "PATCHED"
                print(f"{ip}:1900  MiniUPnPd/{v}  => {vuln}")
        else:
            print(f"{ip}:1900  no-miniupnpd-response")
