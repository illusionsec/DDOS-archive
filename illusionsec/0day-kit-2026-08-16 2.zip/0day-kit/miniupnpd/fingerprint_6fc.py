#!/usr/bin/env python3
# miniupnpd 6FC (WANIPv6FirewallControl) presence check — side-effect free.
# Step 1: GET /rootDesc.xml -> check serviceType WANIPv6FirewallControl:1
# Step 2: SOAP AddPinhole with InternalClient=<unresolvable hostname>:
#   402 Invalid Args  -> PinholeVerification ran  -> 6FC compiled, TARGET VALID
#   401 Invalid Action-> 6FC not compiled         -> skip
# Usage: python3 fingerprint_6fc.py <ip> [port]
import http.client, sys, re

def fetch(ip, port, path):
    try:
        c = http.client.HTTPConnection(ip, port, timeout=5)
        c.request("GET", path)
        r = c.getresponse()
        b = r.read()
        c.close()
        return b
    except Exception:
        return None

def soap_probe(ip, port):
    body = ('<?xml version="1.0"?>'
            '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">'
            '<s:Body><u:AddPinhole xmlns:u="urn:schemas-upnp-org:service:WANIPv6FirewallControl:1">'
            '<RemoteHost>1.2.3.4</RemoteHost><RemotePort>53</RemotePort><InternalPort>53</InternalPort>'
            '<Protocol>17</Protocol><LeaseTime>3600</LeaseTime>'
            '<InternalClient>no-such-host-6fc-probe.invalid</InternalClient>'
            '</u:AddPinhole></s:Body></s:Envelope>').encode()
    req = (f"POST /ctl/IP6FCtl HTTP/1.1\r\nHost: {ip}:{port}\r\n"
           'Content-Type: text/xml; charset="utf-8"\r\n'
           'SOAPAction: "urn:schemas-upnp-org:service:WANIPv6FirewallControl:1#AddPinhole"\r\n'
           f"Content-Length: {len(body)}\r\n\r\n").encode() + body
    try:
        c = http.client.HTTPConnection(ip, port, timeout=5)
        c.request("POST", "/ctl/IP6FCtl", body=body, headers={
            'Content-Type': 'text/xml; charset="utf-8"',
            'SOAPAction': '"urn:schemas-upnp-org:service:WANIPv6FirewallControl:1#AddPinhole"'})
        r = c.getresponse()
        b = r.read().decode(errors="replace")
        c.close()
        return b
    except Exception as e:
        return None

def main():
    ip = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else None
    ports = [port] if port else [5555, 5000]
    for p in ports:
        root = fetch(ip, p, "/rootDesc.xml")
        if not root:
            continue
        sixfc = b"WANIPv6FirewallControl" in root
        print(f"{ip}:{p} rootDesc OK, WANIPv6FirewallControl: {'PRESENT' if sixfc else 'absent'}")
        if not sixfc:
            print("  => 6FC not compiled, skip")
            return
        resp = soap_probe(ip, p)
        if resp and "402" in resp and "Invalid Args" in resp:
            print(f"{ip}:{p} SOAP probe: 402 Invalid Args => 6FC ACTIVE, VULNERABLE TARGET")
        elif resp and "401" in resp:
            print(f"{ip}:{p} SOAP probe: 401 Invalid Action => action not registered, skip")
        else:
            print(f"{ip}:{p} SOAP probe: unexpected: {(resp or b'')[:80]!r}")
        return
    print(f"{ip}: no UPnP HTTP on 5555/5000")

if __name__ == "__main__":
    main()
