# 0day-kit — kamailio & miniupnpd 漏洞研究交付包

生成日期: 2026-08-16
适用范围: 仅限授权测试 / 红队 / 防御研究。两条漏洞均无 CVE 编号。

---

## 1. kamailio check_boundaries() 堆溢出 — 修复未发布 (真 0day)

- **漏洞版本**: 全部 release ≤ 6.1.3 (5.8.x / 6.0.x / 6.1.x 及更老)
- **修复状态**: 修复提交 d7a7f22 (PR #4791, 2026-06-24) 只在 master,**无任何 release 包含, 无 CVE**
- **位置**: `src/core/msg_translator.c:check_boundaries()` — multipart body 重写时分配 `buf.len + 2`:
  - 路径 A: 一行内含两个边界匹配 (`--X--X\r\n`) → `t = next - (this + line_len) < 0` → `memcpy(pb, src, (size_t)-5)` → 堆打穿, worker SIGSEGV, 整个进程组终止 (远程 DoS, 已验证)
  - 路径 B: body 以 `--X` 结尾 → 末边界重写为长形式 `fb` → 2 字节堆越界, 溢出字节为攻击者控制 boundary 串尾部
- **触发前置**: 目标配置含 `set_body_multipart()` (SBC/消息网关常见), 请求 `Content-Type: multipart/related` (非 mixed, 绕过 check_multipart 跳过逻辑)
- **验证**: ASAN 构建 6.1.3 崩溃 (worker signal 11 + core), 修复版对照组同报文优雅拒绝 ("body rebuild would overflow buffer")

### 文件

| 文件 | 用途 |
|---|---|
| `exp_crash.py` | 远程无认证触发 (324B UDP 报文, 已验证) |
| `fingerprint_sip.py` | 主动指纹: OPTIONS → Server 头 (精确版本) |
| `fingerprint_config.py` | 行为指纹: 确认目标配置里 set_body_multipart() 在位 |
| `repro-kamailio.cfg` | 本地复现配置 |
| `fix-d7a7f22.patch` | 官方修复补丁 (对照/研究) |
| `evidence/` | 漏洞版 SIGSEGV 日志 + 修复版不崩日志 |

## 2. miniupnpd PinholeVerification() 堆溢出 — 修复发布仅 4 天

- **漏洞版本**: ≤ 2.3.10 (2.3.11 于 2026-08-12 修复, 无 CVE 引用) → 现网部署 (OpenWrt/pfSense/OEM 路由) 全中
- **位置**: `miniupnpd/upnpsoap.c:PinholeVerification()` — `inet_ntop(AF_INET6, &result_ip, int_ip, sizeof(struct in6_addr))`, `int_ip` 指向 SOAP 请求体解析缓冲 (攻击者内容), 写入最多 16 字节
- **触发技巧 (已实锤)**:
  1. `</>` 短闭合标签 — miniupnpd `parseelt()` 不校验 end tag 名字匹配, `<InternalClient>x</>` 即可, 值距缓冲末尾仅 3 字节
  2. InternalClient 解析为短 IPv6 (如 `fd00::1`) — ≤15 字符才能通过 inet_ntop 的 16 字节自检 (长地址 ENOSPC 拒绝写入)
- **效果**: 8 字节写越界 5 字节出堆块 → ASAN heap-buffer-overflow → 守护进程崩溃 (远程 DoS, 无认证, 单 SOAP 请求)
- **前置**: IGD2 构建 (WANIPv6FirewallControl 服务, ENABLE_6FC_SERVICE); 溢出发生在授权检查 (606) 之前, 无碍
- **验证**: ASAN 构建 2.3.10, `WRITE of size 8` in `__interceptor_inet_ntop`, 进程崩溃

### 文件

| 文件 | 用途 |
|---|---|
| `exp_crash.py` | 远程无认证触发 (SOAP AddPinhole, 已验证) |
| `fingerprint_ssdp.py` | SSDP 主动指纹: SERVER 头精确版本 |
| `fingerprint_6fc.py` | 6FC 服务确认: rootDesc + SOAP 402/401 无副作用探测 |
| `repro-miniupnpd.conf` | 本地复现配置 |
| `fix-b24d595.patch` | 官方修复补丁 |
| `evidence/` | ASAN 越界报告 + 守护进程日志 |

## 3. 指纹速查 (详见 dorks.txt)

- **kamailio**: `Server: kamailio (6.1.3 (x86_64/linux))` 版本明文直出; FOFA `server="kamailio"`
- **miniupnpd**: SSDP `SERVER: <OS> UPnP/1.1 MiniUPnPd/2.3.10` 版本明文直出; FOFA `server="MiniUPnPd"`
- **判定**: kamailio 见即中; miniupnpd 需 ≤2.3.10 + 6FC 在位 (fingerprint_6fc.py 确认)

## 4. Exploitation 状态与下一步

| 目标 | 当前能力 | RCE 路线 |
|---|---|---|
| kamailio | 远程 DoS (进程组全崩) + 堆破坏原语 | 把 t 调成可控正值做有界越界写 → pkg 私有池相邻 chunk 布局 → 函数指针/结构体覆盖 |
| miniupnpd | 远程 DoS + 16 字节有界溢出原语 (内容为解析出的 IPv6 串, 半可控) | 覆盖请求缓冲内后续已解析参数原始文本 (rem_host/LeaseTime 等被后续使用) 或相邻堆块 |

两条均无 CVE: 需要编号可走 MITRE CVE Request 流程 (kamailio 修复未发布, 申请窗口最佳)。
