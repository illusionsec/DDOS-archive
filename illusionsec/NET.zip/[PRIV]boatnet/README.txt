thank for buying condi net!!!
dont leak source pls