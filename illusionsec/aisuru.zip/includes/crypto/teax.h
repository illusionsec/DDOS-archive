#ifndef TEA_H
#define TEA_H

#include <netinet/in.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define TEAX_DELTA 0x61C88647
#define TEAX_ACCUM 0xE0A4CBD6
#define TEAX_FEEDBACK 0xD800A4
#define TEAX_MIXING_ROUNDS 5

#define TEAX_KEY_SIZE 16

typedef struct {
  uint8_t sbox[256];
  uint32_t key[4];
} teax_ctx_t, *pteax_ctx_t;

static void teax_init(pteax_ctx_t ctx, const uint8_t *key, size_t key_len) {
  uint8_t expanded_key[16];
  memset(expanded_key, 0, 16);

  for (size_t i = 0; i < 16; i++) {
    expanded_key[i] = (i < key_len) ? key[i] : expanded_key[i % key_len];
  }

  for (int i = 0; i < 4; i++) {
    uint32_t k = ((uint32_t)expanded_key[i * 4] << 24) | ((uint32_t)expanded_key[i * 4 + 1] << 16) |
                 ((uint32_t)expanded_key[i * 4 + 2] << 8) | ((uint32_t)expanded_key[i * 4 + 3]);
    ctx->key[i] = k;
  }

  for (int i = 0; i < 256; i++) {
    ctx->sbox[i] = (i * 167 + 13) & 0xFF;
  }

  int j = 0;
  for (int i = 0; i < 256; i++) {
    uint32_t k_idx = i % 4;
    j = (j + ctx->sbox[i] + ((ctx->key[k_idx] >> (i % 32)) & 0xFF)) % 256;

    uint8_t temp = ctx->sbox[i];
    ctx->sbox[i] = ctx->sbox[j];
    ctx->sbox[j] = temp;
  }

  uint32_t accumulator = TEAX_ACCUM;
  for (int r = 0; r < TEAX_MIXING_ROUNDS; r++) {
    for (int i = 0; i < 256; i++) {
      uint32_t s_idx = (i + r) % 4;
      accumulator = (accumulator * 1103515245 + 12345) & 0xFFFFFFFF;
      j = (j + ((ctx->sbox[i] * accumulator) >> 24)) % 256;

      uint32_t mix = (ctx->key[s_idx] ^ accumulator) & 0xFFFFFFFF;
      ctx->sbox[i] ^= (mix & 0xFF);

      j = (j + ctx->sbox[i]) % 256;
      uint8_t temp = ctx->sbox[i];
      ctx->sbox[i] = ctx->sbox[j];
      ctx->sbox[j] = temp;
    }
  }
}

static inline void teax_process(pteax_ctx_t ctx, const uint8_t *input, uint8_t *output,
                                size_t length) {
  int i = 0, j = 0, k = 0;
  uint8_t sbox[256];
  uint32_t feedback = 0x1;

  memcpy(sbox, ctx->sbox, 256);

  for (size_t n = 0; n < length; n++) {
    i = (i + 1) % 256;
    j = (j + sbox[i]) % 256;
    k = (k + sbox[(i + j) % 256]) % 256;

    uint8_t temp = sbox[i];
    sbox[i] = sbox[j];
    sbox[j] = temp;

    uint8_t a = sbox[(i + j) % 256];
    uint8_t b = sbox[(j + k) % 256];
    uint8_t c = sbox[(a + b) % 256];

    feedback = ((feedback << 1) | (feedback >> 31)) & 0xFFFFFFFF;
    if (feedback & 0x1) {
      feedback ^= 0xD800A4;
    }

    uint8_t keystream = c ^ (feedback & 0xFF);
    keystream = ((keystream << 3) | (keystream >> 5)) ^ (keystream >> 4);
    output[n] = input[n] ^ keystream;
  }
}

#endif
