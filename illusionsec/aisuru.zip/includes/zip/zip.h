#ifndef ZIP_H
#define ZIP_H

#include <stddef.h>
#include <stdint.h>

#define ZIP_DIR_MAGIC_NUMBER 0x02014b50
#define ZIP_FILE_MAGIC_NUMBER 0x04034b50

typedef struct {
  uint32_t local_header_offset;
  uint32_t crc32;
  uint32_t uncompressed_size;
  char *filename;
  uint16_t filename_len;
} zip_entry_t, *pzip_entry_t;

typedef struct {
  unsigned char *buf;
  size_t capacity;
  size_t length;

  pzip_entry_t files;
  size_t file_count;
  size_t file_capacity;
} zip_buffer_t, *pzip_buffer_t;

int zip_add_entry(zip_buffer_t *zip, const char *filename, const unsigned char *data, size_t size);
void zip_free(zip_buffer_t *zip);
int zip_finalize(pzip_buffer_t zip);

#endif
