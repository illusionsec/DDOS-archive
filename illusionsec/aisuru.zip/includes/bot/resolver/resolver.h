#ifndef RESOLVER_H
#define RESOLVER_H

#include "bot/definitions.h"
#include <stddef.h>

typedef struct __attribute__((packed)) {
  uint16_t id;
  uint16_t opts;

  uint16_t qdcount; // Question count
  uint16_t ancount; // Answer count
  uint16_t nscount; // Authority record cocunt
  uint16_t arcount; // Additional record count
} dns_header_t;

typedef struct __attribute__((packed)) {
  uint16_t type;  /* Query type (A, MX, CNAME, etc.) */
  uint16_t class; /* Query class (usually IN for Internet) */
} dns_question_t, *pdns_question_t;

typedef struct __attribute__((packed)) {
  uint16_t type;   /* Record type */
  uint16_t class;  /* Record class*/
  uint32_t ttl;    /* Time to live */
  uint16_t length; /* Length of data */
} resource_record_t, *presource_record_t;

typedef enum {
  DNS_TYPE_A = 1,     /* IPv4 host address */
  DNS_TYPE_NS = 2,    /* Name server */
  DNS_TYPE_CNAME = 5, /* Canonical name for an alias */
  DNS_TYPE_SOA = 6,   /* Start of a zone of authority */
  DNS_TYPE_MX = 15,   /* Mail exchange */
  DNS_TYPE_TXT = 16,  /* Text strings */
  DNS_TYPE_AAAA = 28, /* IPv6 host address */
  DNS_TYPE_SRV = 33   /* Server selection */
} dns_record_type_t;

typedef union {
  u32 a;
  char *txt;
} resolver_record_t, *presolver_record_t;

typedef struct {
  presolver_record_t records;
  size_t len;
} resolver_response_t, *presolver_response_t;

int resolver_query(const char *, presolver_response_t, u16);
void resolver_free(presolver_response_t);

#endif
