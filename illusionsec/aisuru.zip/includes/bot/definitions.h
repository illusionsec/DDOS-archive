#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include "bot/utils/network.h"

#include <netinet/in.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/param.h>
#include <unistd.h>

#define UNUSED_PARM(x) (void)x;
#define INLINE_GNU __attribute__((gnu_inline)) inline
#define NON_BLOCK(fd) fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0))
#define BLOCKING(fd) fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) & ~O_NONBLOCK)
#define FREE_NULL(p)                                                                               \
  if (p) {                                                                                         \
    free(p);                                                                                       \
    p = NULL;                                                                                      \
  }

/* macros that only have an effect in debug mode */
#ifdef DEBUG
#include "bot/utils/logger.h"
#define PRINTF(...) LOG_INFO(__VA_ARGS__)
#define PRINTF_C(name, ...) LOG_INFO(__VA_ARGS__)
#define ASSERT(expression) assert(expression)
#define LOG_TRACE(...) log_log(0, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_DEBUG(...) log_log(1, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_INFO(...) log_log(2, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_WARN(...) log_log(3, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_ERROR(...) log_log(4, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_FATAL(...) log_log(5, __FILE__, __LINE__, __VA_ARGS__)
#else
#define PRINTF(...)
#define PRINTF_C(...)
#define ASSERT(...)
#define LOG_TRACE(...)
#define LOG_DEBUG(...)
#define LOG_INFO(...)
#define LOG_WARN(...)
#define LOG_ERROR(...)
#define LOG_FATAL(...)
#endif

typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8, *pu8, *puint8_t;

extern int c2s_pipe[2];
extern mac_parse_t MAC_ADDR;

static inline bool is_socket_connected(int fd) {
  int error = 0;
  socklen_t len = sizeof(error);
  int ret = getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len);
  if (ret < 0) return false;
  return error == 0;
}

/**
 * The pipe header will be the main way of communicating via pipes.
 */
typedef struct {
  uint8_t command; /* Target command */
  uint16_t length; /* Target length */
} pipe_header_t, *ppipe_header_t;

typedef struct {
  uint8_t minor;
  uint8_t major;
  uint8_t patch;
  uint32_t local_addr;
} local_esi_packet_t, *plocal_esi_packet_t;

#endif
