#ifndef LATENCY_TEST_H
#define LATENCY_TEST_H

#include "bot/speedtest/server_list.h"

int speedtest_lowest_latency(pserver_list_t list, int *index, int *latency);

#endif
