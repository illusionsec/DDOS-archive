#ifndef SERVERLIST_H
#define SERVERLIST_H

#include "bot/utils/urlparser.h"
#include <stddef.h>

typedef struct {
  purl_t urls;
  size_t count;
} server_list_t, *pserver_list_t;

int speedtest_retrieve_list(pserver_list_t list);
void speedtest_free_list(pserver_list_t list);

int speedtest_parse_server(char *entry, purl_t url);

#endif
