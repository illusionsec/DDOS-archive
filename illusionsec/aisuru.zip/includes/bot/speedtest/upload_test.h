#ifndef UPLOAD_TEST_H
#define UPLOAD_TEST_H

#include "bot/utils/urlparser.h"

uint64_t speedtest_upload_test(purl_t server, int duration);

#endif
