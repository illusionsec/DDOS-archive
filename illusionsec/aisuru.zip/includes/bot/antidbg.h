#ifndef ANTIDBG_H
#define ANTIDBG_H

void antidebug_init();

#endif
