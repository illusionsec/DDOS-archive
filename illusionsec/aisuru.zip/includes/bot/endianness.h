#ifndef ENDIANNESS_H
#define ENDIANNESS_H

#include <stdint.h>
#include <endian.h>   // on Linux

// Detect endianness at compile time
#if defined(BYTE_ORDER) && (BYTE_ORDER == BIG_ENDIAN)
  #define IS_BIG_ENDIAN 1
#else
  #define IS_BIG_ENDIAN 0
#endif

#define SWAP16(x) ( \
  (((uint16_t)(x) & 0x00FFU) << 8) | \
  (((uint16_t)(x) & 0xFF00U) >> 8) )

#define SWAP32(x) ( \
    (((uint32_t)(x) & 0x000000FFU) << 24) | \
    (((uint32_t)(x) & 0x0000FF00U) << 8)  | \
    (((uint32_t)(x) & 0x00FF0000U) >> 8)  | \
    (((uint32_t)(x) & 0xFF000000U) >> 24) )

// Build IP address in network byte order from 4 octets
#define INET_ADDR(o1, o2, o3, o4)                                                                  \
  (htonl(((uint32_t)(o1) << 24) | ((uint32_t)(o2) << 16) | ((uint32_t)(o3) << 8) |             \
             ((uint32_t)(o4))))

#endif // ENDIANNESS_H
