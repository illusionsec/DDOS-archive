#ifndef BANNER_SCANNER_H
#define BANNER_SCANNER_H

#include <stdbool.h>
#include <netinet/in.h>
#include <stdint.h>

#define BSC_RDBUF_SIZE 4096
#define BSC_HACK_DRAIN 1024
#define BSC_MAX_FDS 1

enum {
  BSC_TYPE_HIKVISION,
  BSC_TYPE_UCHTTPD,
  BSC_TYPE_TPLINK,
  BSC_MAX_TYPE,
};

typedef struct {
  uint8_t type;
  size_t banner_len;
  char *banner;
} bsc_banner_t, *pbsc_banner_t;

typedef struct {
  int fd;
  struct sockaddr_in addr;

  enum {
    BSC_CONNECTION_PENDING,
    BSC_WAITING_RESPONSE,
  } state;

  int type;

  int rdbuf_pos;
  char rdbuf[BSC_RDBUF_SIZE];

  time_t last_recv;
} bsc_connection_t, *pbsc_connection_t;

void bsc_init();

#endif
