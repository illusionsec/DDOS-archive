#ifndef DYNAMIC_H
#define DYNAMIC_H

void dynamic_init(char **argv);
void dynamic_fallback(char **argv);

#endif
