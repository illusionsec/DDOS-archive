#ifndef LOCKER_H
#define LOCKER_H

#include <fcntl.h>
#include <linux/limits.h>
#include <stdbool.h>

void locker_init();
void locker_kill();

#endif
