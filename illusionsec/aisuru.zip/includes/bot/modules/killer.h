#ifndef KILLER_H
#define KILLER_H

#include <fcntl.h>
#include <linux/limits.h>
#include <stdbool.h>
#include <stddef.h>

#define FLAG_STATIC (1 << 0)   // 0001
#define FLAG_DELETED (1 << 1)  // 0010
#define FLAG_TEMP_DIR (1 << 2) // 0100

#define KILLER_VL_THRESHOLD 3

typedef struct {
  int ppid;
  int vl;
  int flags;

  char exe_path[PATH_MAX];
  char directory[PATH_MAX];

  int cmdline_len;
  char cmdline[PATH_MAX];
} process_info_t, *pprocess_info_t;

bool killer_retrieve_ppid(char *pid, pprocess_info_t info);
void killer_retrieve_cmdline(char *pid, pprocess_info_t info);

void killer_kill_by_inode(char *inode);
void killer_clean_mnt();

void killer_init();
void killer_kill();

#endif
