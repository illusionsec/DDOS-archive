#ifdef DEBUG

#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

static const char *level_strings[] = {"TRAC", "DEBU", "INFO", "WARN", "ERRO", "FATA"};
static const char *level_colors[] = {"\x1b[94m", "\x1b[36m", "\x1b[32m",
                                     "\x1b[33m", "\x1b[31m", "\x1b[35m"};
static int log_level = 0; // Default log level (TRACE)

static inline void log_log(int level, const char *file, int line, const char *fmt, ...) {
  if (level < log_level) {
    return;
  }

  time_t t = time(NULL);
  struct tm *time = localtime(&t);

  // start var args list
  va_list ap;
  va_start(ap, fmt);

  // write time
  char time_str[16];
  strftime(time_str, sizeof(time_str), "%H:%M:%S", time);

  const char *last_slash = strrchr(file, '/');
  last_slash++;

  // write stuff
  fprintf(stderr, "%s %s%-4s\x1b[0m \x1b[90m%s:%d\x1b[0m ", time_str, level_colors[level],
          level_strings[level], last_slash, line);
  vfprintf(stderr, fmt, ap);
  fprintf(stderr, "\n");

  // end var args
  va_end(ap);
}
#endif
