#ifndef STRING_H
#define STRING_H

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// buf, buf len, mem, mem len
#define memsearch(a, b, c, d) str_search(a, c, b, d)

// case insensitive strstr
int stristr(char *haystack, int haystack_len, char *str);

ssize_t str_search(void *buf, void *mem, size_t buf_len, size_t mem_len);
int str_template(char *buffer, size_t size, const char *format, ...);

char *str_fdgets(char *buffer, int buffer_size, int fd, int *total);
int str_strip(void *str, int len);

static inline char *strdupn(const char *s, size_t n) {
  size_t len = 0;

  // Manually find the length up to n or null terminator
  while (len < n && s[len] != '\0') {
    len++;
  }

  // Allocate memory (+1 for null terminator)
  char *dup = malloc(len + 1);
  if (!dup) return NULL;

  // Copy the characters
  for (size_t i = 0; i < len; i++) {
    dup[i] = s[i];
  }

  dup[len] = '\0'; // null-terminate
  return dup;
}

#endif
