#ifndef URL_H
#define URL_H

#include <errno.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>

#define HTTP_HEADER_END 0x0d0a0d0a

typedef struct {
  char *scheme;
  char *host;
  char *port;
  char *path;
  char *query;
  char *fragment;
} url_t, *purl_t;

int url_parse(const char *url_str, purl_t url);
void url_free(purl_t url);

// blehh
static inline int http_skip_hdr(int fd, unsigned int *hdr) {
  if (hdr == NULL) return -1;

  while (*hdr != HTTP_HEADER_END) {
    char ch;

    ssize_t n = read(fd, &ch, 1);
    if (n != 1) {
      if (n == 0) errno = EPROTO;
      return -1;
    }

    *hdr = (*hdr << 8) | (unsigned char)ch;
  }

  return 0;
}

#endif
