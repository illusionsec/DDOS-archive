#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <stdio.h>
#include <unistd.h>

typedef struct {
  char **tokens;
  ssize_t size;
} tokenizer_t, *ptokenizer_t;

/**
 * Splits the input data into tokens based on the provided delimiter.
 *
 * @param data The string (data) that is to be tokenized.
 * @param delim The delimiter that is used to split the data into multiple tokens.
 * @return A new tokenizer object, which contains the tokenized data. If there is an error
 * allocating memory or processing the inputted data, this function will return NULL.
 */
ptokenizer_t tokenizer_new(const char *data, char *delim);

/**
 * Frees the memory allocated for a tokenizer object.
 * It is important to call this function when you are done using the tokenizer to prevent memory
 leaks.
 * @param tokenizer A pointer to the tokenizer object that should be freed.
 */
void tokenizer_free(ptokenizer_t tokenizer);

#endif // TOKENIZER_H
