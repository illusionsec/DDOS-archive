#ifndef TIME_H
#define TIME_H

#include <stdint.h>
#include <sys/time.h>
#include <time.h>

#define NANOSECONDS_IN_SEC 1000000000L

static uint64_t get_time_micro() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec * 1000000LL + tv.tv_usec;
}

#endif
