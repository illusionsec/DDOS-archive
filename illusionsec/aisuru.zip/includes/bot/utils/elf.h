#ifndef ELF_U_H
#define ELF_U_H

#include <elf.h>
#include <fcntl.h>
#include <stdbool.h>
#include <unistd.h>

static inline bool elf_is_static(const char *path) {
  union ElfHeader {
    Elf32_Ehdr elf32;
    Elf64_Ehdr elf64;
  } header;

  int fd = open(path, O_RDONLY);
  if (fd < 0) return false;

  ssize_t n = read(fd, &header, sizeof(header));
  if (n <= 0) {
    close(fd);
    return false;
  }

  const unsigned char *ident = header.elf32.e_ident;
  if (ident[EI_MAG0] != ELFMAG0 || ident[EI_MAG1] != ELFMAG1 || ident[EI_MAG2] != ELFMAG2 ||
      ident[EI_MAG3] != ELFMAG3) {
    close(fd);
    return false;
  }

  if (header.elf32.e_type != ET_EXEC) {
    close(fd);
    return false;
  }

  bool is_64bit = (ident[EI_CLASS] == ELFCLASS64);
  size_t phdr_size = is_64bit ? sizeof(Elf64_Phdr) : sizeof(Elf32_Phdr);
  size_t phdr_count = is_64bit ? header.elf64.e_phnum : header.elf32.e_phnum;
  off_t phdr_offset = is_64bit ? header.elf64.e_phoff : header.elf32.e_phoff;

  if (phdr_count > 128) {
    close(fd);
    return true;
  }

  char buffer[128 * sizeof(Elf64_Phdr)];
  if (lseek(fd, phdr_offset, SEEK_SET) < 0 || read(fd, buffer, phdr_size * phdr_count) <= 0) {
    close(fd);
    return false;
  }

  bool has_interp = false;
  for (size_t i = 0; i < phdr_count && !has_interp; ++i) {
    if (is_64bit) {
      Elf64_Phdr *ph64 = (Elf64_Phdr *)buffer;
      has_interp = (ph64[i].p_type == PT_INTERP);
    } else {
      Elf32_Phdr *ph32 = (Elf32_Phdr *)buffer;
      has_interp = (ph32[i].p_type == PT_INTERP);
    }
  }

  close(fd);
  return !has_interp;
}

#endif
