#ifndef STUN_H
#define STUN_H

#include <arpa/inet.h>
#include <stdbool.h>

#define STUN_BINDING_REQUEST 0x0001
#define STUN_MAGIC_COOKIE 0x2112A442
#define STUN_XOR_MAPPED_ADDRESS 0x0020

typedef struct {
  uint16_t type;
  uint16_t length;
  uint32_t magic_cookie;
  uint8_t transaction_id[12];
} stun_header_t;

typedef struct {
  uint16_t type;
  uint16_t length;
} stun_attr_t;

bool stun_get_public_ip(struct sockaddr_in *mapped_addr);
struct sockaddr_in stun_random_server();

#endif
