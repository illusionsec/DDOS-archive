#ifndef XOSHIRO_H
#define XOSHIRO_H

#include <fcntl.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>

static uint64_t xoshiro_states[4];
static uint64_t splitmix64_seed;

void random_init(void);
uint64_t xoshiro_next(void);
uint64_t xoshiro_range(uint64_t min, uint64_t max);
void xoshiro_bytes(void *buffer, size_t len);

#endif
