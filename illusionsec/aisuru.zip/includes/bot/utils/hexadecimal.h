#ifndef HEXADECIMAL_H
#define HEXADECIMAL_H

#include <stddef.h>
#include <stdint.h>

void hex_from_byte(uint8_t byte, char *out);
int8_t hex_to_value(char c);
uint8_t hex_to_byte(char o1, char o2);
uint16_t hex_convert_u16(char o1, char o2, char o3, char o4);
uint32_t hex_convert_u32_str(const char *hex);
char **hex_split(const uint8_t *bin_data, size_t bin_len, int chunk_size, int *num_chunks);

#endif
