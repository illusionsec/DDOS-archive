#ifndef MATH_H
#define MATH_H

char *math_itoa(int value, char *output, int base);

#endif
