#include <netinet/in.h>
#include <stdlib.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/resolver/resolver.h"
#include "bot/speedtest/latency_test.h"
#include "bot/speedtest/server_list.h"
#include "bot/utils/string.h"
#include "bot/utils/urlparser.h"
#include "bot/utils/xoshiro.h"

typedef struct {
  int id;
  int fd;
  int last_recv;
  struct timeval start;
  short events;
  short revents;
} connection_t;

static int calc_past_time(struct timeval *start, struct timeval *end) {
  return (end->tv_sec - start->tv_sec) * 1000 + (end->tv_usec - start->tv_usec) / 1000;
}

int speedtest_lowest_latency(pserver_list_t list, int *lat_index, int *lat) {
  if (!list || list->count == 0) return -1;

  LOG_INFO("(Speed Test) Testing %d servers for the lowest latency...", list->count);

  resolver_response_t resp = {0};
  connection_t *conns = calloc(list->count, sizeof(connection_t));
  if (!conns) return -1;

  size_t active_conns = 0;
  for (size_t i = 0; i < list->count; i++) {
    purl_t url = &list->urls[i];
    conns[i].id = i;
    conns[i].fd = -1;

    if (resolver_query(url->host, &resp, DNS_TYPE_A) != 0) {
      resolver_free(&resp);
      LOG_WARN("Resolving ['%s'] failed", url->host);
      continue;
    }

    if (resp.len == 0) {
      resolver_free(&resp);
      continue;
    }

    struct sockaddr_in addr = {.sin_family = AF_INET,
                               .sin_addr.s_addr = resp.records[xoshiro_next() % resp.len].a,
                               .sin_port = htons(url->port ? atoi(url->port) : 8080)};
    resolver_free(&resp);

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd == -1) {
      LOG_WARN("Socket creation for ['%s'] failed", url->host);
      continue;
    }

    NON_BLOCK(fd);
    int ret = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
    if (ret == -1 && errno != EINPROGRESS) {
      close(fd);
      continue;
    }

    conns[i].fd = fd;
    conns[i].events = POLLOUT;
    conns[i].last_recv = time(NULL);

    active_conns++;
  }

  if (active_conns == 0) {
    free(conns);
    return -1;
  }

  // now init all latencys, now that everything is setup
  for (size_t i = 0; i < list->count; i++) {
    if (conns[i].fd != -1) {
      gettimeofday(&conns[i].start, NULL);
    }
  }

  // convert conns to pollfds
  struct pollfd *pollfds = calloc(list->count, sizeof(struct pollfd));
  if (!pollfds) {
    for (size_t i = 0; i < list->count; i++)
      if (conns[i].fd != -1) close(conns[i].fd);
    free(conns);
    return -1;
  }

  // setup lowest latency shit and time shit
  int lowest_latency = INT_MAX;
  int found_server = -1;
  time_t start_time = time(NULL);

  // wait for events
  while (active_conns > 0) {
    if (time(NULL) - start_time > 15) break;

    for (size_t i = 0; i < list->count; i++) {
      pollfds[i].fd = conns[i].fd;
      pollfds[i].events = conns[i].events;
    }

    int ret = poll(pollfds, list->count, 1000);

    for (size_t i = 0; i < list->count; i++) {
      if (conns[i].fd == -1) continue;

      // Timeout handling
      if (time(NULL) - conns[i].last_recv > 5) {
        LOG_INFO("Server %zu timed out", i);
        close(conns[i].fd);
        conns[i].fd = -1;
        active_conns--;
        continue;
      }

      if (pollfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
        close(conns[i].fd);
        conns[i].fd = -1;
        active_conns--;
        continue;
      }

      if (pollfds[i].revents & POLLOUT) {
        if (!is_socket_connected(conns[i].fd)) {
          LOG_INFO("Server %zu failed to connect", i);
          close(conns[i].fd);
          conns[i].fd = -1;
          active_conns--;
          continue;
        }

        char request[4096] = {0};
        if (str_template(request, sizeof(request), table_retrieve(SPEEDTEST_LATENCY_REQUEST, NULL),
                         list->urls[conns[i].id].host) == -1) {
          break;
        }

        send(conns[i].fd, request, strlen(request), MSG_NOSIGNAL);

        conns[i].events = POLLIN;
        conns[i].last_recv = time(NULL);
      }

      if (pollfds[i].revents & POLLIN) {
        char c;

        // recv data
        ssize_t n = recv(pollfds[i].fd, &c, 1, MSG_NOSIGNAL);
        if (n <= 0) {
          close(conns[i].fd);
          conns[i].fd = -1;
          active_conns--;
          continue;
        }

        struct timeval e_time;
        gettimeofday(&e_time, NULL);
        int latency = calc_past_time(&conns[i].start, &e_time);

        // get lowest latency
        if (latency < lowest_latency) {
          lowest_latency = latency;
          found_server = i;
        }

        close(conns[i].fd);
        conns[i].fd = -1;
        active_conns--;
      }
    }

    if (ret <= 0) continue;
  }

  // cleanup remaining connections
  for (size_t i = 0; i < list->count; i++) {
    if (conns[i].fd != -1) close(conns[i].fd);
  }

  free(pollfds);
  free(conns);

  // found server, update stuff
  if (found_server != -1) {
    if (lat) *lat = lowest_latency;
    if (lat_index) *lat_index = found_server;

    LOG_INFO("(Speed Test) Server ['%s'] has a latency of ['%dms']!", list->urls[found_server].host,
             lowest_latency);

    return 0;
  }

  return -1;
}
