#include <poll.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/resolver/resolver.h"
#include "bot/speedtest/upload_test.h"
#include "bot/utils/string.h"
#include "bot/utils/time.h"
#include "bot/utils/xoshiro.h"

// conn states
enum {
  STATE_CONNECT,
  STATE_DATA,
  STATE_DONE,
};

// chunk states
enum {
  CHUNK_HEADER,
  CHUNK_DATA,
  CHUNK_TRAILER,
  CHUNK_END,
};

typedef struct {
  const char *ptr;
  int len;
} chunk_data_t;

uint64_t speedtest_upload_test(purl_t server, int duration_sec) {
  uint64_t start_time_us = get_time_micro();
  uint64_t test_start_us = 0;
  uint64_t total_bytes = 0;

  char chunk[65536];
  for (int i = 0; i < 65536; i += 4) {
    uint32_t rand_val = xoshiro_next();
    memcpy(chunk + i, &rand_val, (i + 4 <= 65536) ? 4 : 65536 - i);
  }

  chunk_data_t parts[] = {
      {"10000\r\n", 7}, // Chunk header (size)
      {chunk, 65536},   // Chunk data
      {"\r\n", 2},      // Chunk trailer
      {"0\r\n\r\n", 5}, // Final chunk
  };

  int part_index = 0;
  int sent_len = 0;

  resolver_response_t resp = {0};
  if (resolver_query(server->host, &resp, DNS_TYPE_A) != 0 || resp.len == 0) {
    resolver_free(&resp);
    return -1;
  }

  struct sockaddr_in addr = {
      .sin_family = AF_INET,
      .sin_addr.s_addr = resp.records[xoshiro_next() % resp.len].a,
      .sin_port = htons(server->port ? atoi(server->port) : 8080),
  };

  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd == -1) {
    resolver_free(&resp);
    return -1;
  }

  NON_BLOCK(fd);

  int ret = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
  if (ret == -1 && errno != EINPROGRESS) {
    close(fd);
    resolver_free(&resp);
    return -1;
  }

  // Disable Nagle to improve latency of small sends
  int flag = 1;
  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(int));

  struct pollfd pfd = {.fd = fd, .events = POLLOUT};
  int state = STATE_CONNECT;

  while (state != STATE_DONE) {
    int ret = poll(&pfd, 1, 100);
    if (ret < 0) break;

    if (ret == 0) {
      uint64_t now_us = get_time_micro();

      if (state == STATE_CONNECT && now_us - start_time_us > 10 * 1000000ULL) {
        // 10s connect timeout
        break;
      }

      if (state == STATE_DATA && now_us - test_start_us > 30 * 1000000ULL) {
        // 30s data timeout
        break;
      }

      continue;
    }

    if (!(pfd.revents & POLLOUT)) {
      // not ready bruda
      continue;
    }

    uint64_t now_us = get_time_micro();

    switch (state) {
      case STATE_CONNECT: {
        if (!is_socket_connected(fd)) {
          state = STATE_DONE;
          break;
        }

        test_start_us = now_us;

        // prepare http chunked upload request
        char request[4096] = {0};
        if (str_template(request, sizeof(request), table_retrieve(SPEEDTEST_UPLOAD_REQUEST, NULL),
                         server->path ? server->path : "/", server->host) < 0) {
          state = STATE_DONE;
          break;
        }

        // send initial request
        ssize_t n = send(fd, request, strlen(request), MSG_NOSIGNAL);
        if (n <= 0) {
          state = STATE_DONE;
          break;
        }

        LOG_INFO("(Speed Test) Connected! Starting upload speed test...");
        state = STATE_DATA;
        break;
      }

      case STATE_DATA: {
        if (test_start_us == 0) {
          test_start_us = now_us;
        }

        if (part_index == CHUNK_END) {
          state = STATE_DONE;
          break;
        }

        const char *buffer = parts[part_index].ptr + sent_len;
        int remaining = parts[part_index].len - sent_len;

        ssize_t n = send(fd, buffer, remaining, MSG_NOSIGNAL);
        if (n <= 0) {
          if (errno == EAGAIN || errno == EWOULDBLOCK) {
            continue;
          } else {
            state = STATE_DONE;
            break;
          }
        }

        sent_len += n;

        if (sent_len == parts[part_index].len) {
          sent_len = 0;
          part_index++;

          // AAAAA if its OVER THE TRAILE R we WEEEEEEEEEEEEEEEEEEEEEE
          if (part_index > CHUNK_TRAILER) {
            total_bytes += 65536;
            part_index = CHUNK_HEADER;

            // check if duration timeout has elapsed
            if (now_us - test_start_us >= (uint64_t)duration_sec * 1000000ULL) {
              part_index = CHUNK_END;
            }
          }
        }

        break;
      }

      default:
        state = STATE_DONE;
        break;
    }
  }

  close(fd);
  resolver_free(&resp);

  if (total_bytes == 0) {
    return -1;
  }

  uint64_t elapsed_us = get_time_micro() - test_start_us;
  if (elapsed_us == 0) elapsed_us = 1;

  uint64_t bps = (total_bytes * 8 * 1000000ULL) / elapsed_us;
  uint64_t kbps = bps / 1000;

  LOG_INFO("(Speed Test) Average upload speed: %llu Kbps", kbps);
  return kbps;
}
