#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/resolver/resolver.h"
#include "bot/speedtest/server_list.h"
#include "bot/utils/urlparser.h"
#include "bot/utils/xoshiro.h"

int speedtest_retrieve_list(pserver_list_t list) {
  list->urls = NULL;

  char rdbuf[8192] = {0};
  resolver_response_t resp = {0};
  size_t buffer_pos = 0;

  struct sockaddr_in addr = {.sin_port = htons(80), .sin_family = AF_INET};

  // wtf is the chance that this fails bruh
  if (resolver_query(table_retrieve(SPEEDTEST_SERVERLIST_DOMAIN, NULL), &resp, DNS_TYPE_A) != 0) {
    resolver_free(&resp);
    speedtest_free_list(list);
    return -1;
  }

  // receive random record and free the resolver
  addr.sin_addr.s_addr = resp.records[xoshiro_next() % resp.len].a;
  resolver_free(&resp);

  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd == -1) {
    speedtest_free_list(list);
    return -1;
  }

  NON_BLOCK(fd);
  connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

  struct pollfd pfd = {
      .fd = fd,
      .events = POLLOUT,
  };

  unsigned int header_parser = 0;

  while (true) {
    int ret = poll(&pfd, 1, 5000);
    if (ret <= 0) {
      LOG_ERROR("(Speed Test) Error while polling (timeout?)");

      close(fd);
      speedtest_free_list(list);

      return -1;
    }

    if (pfd.revents & POLLOUT) {
      if (!is_socket_connected(fd)) {
        LOG_ERROR("(Speed Test) Connection to 'c.speedtest.net' failed");

        close(fd);
        speedtest_free_list(list);

        return -1;
      }

      const char *request = table_retrieve(SPEEDTEST_SERVERLIST_REQUEST, NULL);
      send(fd, request, strlen(request), MSG_NOSIGNAL);
      LOG_INFO("(Speed Test) Connected! Retrieving server list...");

      // wait for data now
      pfd.events = POLLIN;
    }

    if (pfd.revents & POLLIN) {
      // skips until no hdrs are left
      http_skip_hdr(fd, &header_parser);

      // receives the data
      ssize_t n = recv(fd, rdbuf + buffer_pos, sizeof(rdbuf) - buffer_pos - 1, 0);
      if (n <= 0) break;

      // incr current buffer pos
      buffer_pos += n;
      rdbuf[buffer_pos] = '\0';

      // gets start
      char *start = rdbuf;
      char *line;

      while ((line = strchr(start, '\n')) != NULL) {
        // make string end at new line char
        *line = '\0';

        // parses current line
        url_t url = {0};
        if (speedtest_parse_server(start, &url) != 0) {
          start = line + 1;
          continue;
        }

        // reallocates list to make space for one more element
        purl_t tmp = realloc(list->urls, (list->count + 1) * sizeof(url_t));
        if (!tmp) {
          close(fd);
          speedtest_free_list(list);
          return -1;
        }

        // add element to list
        list->urls = tmp;
        list->urls[list->count++] = url;

        // move to next line
        start = line + 1;
      }

      // move leftover data to front of buffer
      size_t remaining = buffer_pos - (start - rdbuf);
      memmove(rdbuf, start, remaining);
      buffer_pos = remaining;

      // handle BOF by accident
      if (buffer_pos >= sizeof(rdbuf) - 1) {
        close(fd);
        speedtest_free_list(list);
        LOG_ERROR("Buffer Overflow occured! Bailing.");
        return -1;
      }

      // ...
    }
  }

  LOG_INFO("(Speed Test) Received %d servers!", list->count);
  return 0;
}

void speedtest_free_list(pserver_list_t list) {
  if (!list) return;

  if (list->urls) {
    for (size_t i = 0; i < list->count; i++) {
      url_free(&list->urls[i]);
    }

    free(list->urls);
    list->urls = NULL;
  }
}

int speedtest_parse_server(char *entry, purl_t url) {
  char dest[4096] = {0};

  // retrieve start of url
  char *start = strstr(entry, table_retrieve(SPEEDTEST_URL, NULL));
  if (!start) return -1;

  // get the first quote, which should ALWAYS be the url then move past it
  start = strchr(start, '"');
  if (!start) return -1;
  start++;

  // get the end of the quote
  char *end = strchr(start, '"');
  if (!end) return -1;

  // sanitize dest array, so we will never go out of bounds
  size_t cpylen = end - start;
  if (cpylen > sizeof(dest)) cpylen = sizeof(dest) - 1;

  strncpy(dest, start, cpylen);
  dest[cpylen] = '\0';

  // now actually parse the url lol
  return url_parse(dest, url);
}
