#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <sys/socket.h>

#include "bot/definitions.h"
#include "bot/endianness.h"
#include "bot/utils/math.h"
#include "bot/utils/string.h"
#include "bot/utils/network.h"

uint32_t network_local_addr() {
  int fd;
  struct sockaddr_in addr;
  socklen_t addr_len = sizeof(addr);

  if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) return 0;

  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INET_ADDR(8, 8, 8, 8);
  addr.sin_port = htons(53);

  int ret = connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
  UNUSED_PARM(ret);

  getsockname(fd, (struct sockaddr *)&addr, &addr_len);

  close(fd);
  return addr.sin_addr.s_addr;
}

pnetwork_info_t network_retrieve_pidinfo(pid_t pid, size_t *count) {
  if (count) *count = 0;

  size_t num_inodes = 0;
  size_t num_result = 0;

  // the lists
  pnetwork_info_t result = NULL;
  char **nodes = NULL;

  // convert pid
  char pid_str[32];
  math_itoa(pid, pid_str, 10);

  char fd_dir_path[PATH_MAX];
  strcpy(fd_dir_path, "/proc/");
  strcat(fd_dir_path, pid_str);
  strcat(fd_dir_path, "/fd");

  DIR *dir = opendir(fd_dir_path);
  if (!dir) goto cleanup;

  struct dirent *entry;
  while ((entry = readdir(dir)) != NULL) {
    if (!isdigit(*entry->d_name)) continue;

    char fd_path[PATH_MAX];
    char rdbuf[PATH_MAX];

    strcpy(fd_path, fd_dir_path);
    strcat(fd_path, "/");
    strcat(fd_path, entry->d_name);

    // read the link
    ssize_t n = readlink(fd_path, rdbuf, sizeof(rdbuf) - 1);
    if (n == -1) continue;
    rdbuf[n] = '\0';

    if (strncmp(rdbuf, "socket:[", 8) == 0) {
      char *inode_start = rdbuf + 8;
      char *inode_end = strchr(inode_start, ']');
      if (!inode_end) continue;
      *inode_end = '\0';

      // we have too many inodes, bail
      if (num_inodes >= 16) {
        break;
      }

      // increase list
      char **tmp = realloc(nodes, sizeof(char *) * (num_inodes + 1));
      if (!tmp) goto cleanup;
      nodes = tmp;

      // copy inode into list
      nodes[num_inodes] = malloc(strlen(inode_start) + 1);
      if (!nodes[num_inodes]) goto cleanup;
      strcpy(nodes[num_inodes], inode_start);

      num_inodes++;
    }
  }

  closedir(dir);
  dir = NULL;

  // no sockets found, bail
  if (num_inodes == 0) {
    goto cleanup;
  }

  int fd = open("/proc/net/tcp", O_RDONLY);
  if (fd == -1) goto cleanup;

  char line[512];
  bool first_line = true;

  while (str_fdgets(line, sizeof(line), fd, NULL)) {
    if (first_line) {
      first_line = false;
      continue;
    }

    char *saveptr;
    char *token;

    // skip sequence
    token = strtok_r(line, " \t", &saveptr);
    if (!token) continue;

    // skip local addr
    token = strtok_r(NULL, " \t", &saveptr);
    if (!token) continue;

    // retrieve remote addr
    char *remote_addr = strtok_r(NULL, " \t", &saveptr);
    if (!remote_addr) continue;

    // we only want connection states, for now
    token = strtok_r(NULL, " \t", &saveptr);
    if (!token || strcmp(token, "01") != 0) continue;

    // skip until inode
    for (int i = 0; i < 5; i++) {
      token = strtok_r(NULL, " \t", &saveptr);
      if (!token) break;
    }

    // retrieve the inode
    char *line_inode = strtok_r(NULL, " \t", &saveptr);
    if (!line_inode) continue;

    // get all inodes, compare them
    for (size_t i = 0; i < num_inodes; i++) {
      if (strcmp(line_inode, nodes[i]) != 0) continue;

      char *addr_hex = strtok_r(remote_addr, ":", &saveptr);
      char *port_hex = strtok_r(NULL, ":", &saveptr);

      if (addr_hex && port_hex) {
        uint32_t addr = (uint32_t)strtoul(addr_hex, NULL, 16);
        uint16_t port = (uint16_t)strtoul(port_hex, NULL, 16);

        LOG_INFO("Found connection: inode=%s, addr=0x%08x, port=%d", line_inode, addr, port);

        // realloc the list
        pnetwork_info_t tmp = realloc(result, sizeof(network_info_t) * (num_result + 1));
        if (!tmp) goto cleanup;
        result = tmp;

        // add it to the list
        result[num_result].address = htonl(addr);
        result[num_result].port = port;

        // incr
        num_result++;
      }
    }
  }

  close(fd);
  fd = -1;

cleanup:
  // free the nodes
  if (nodes) {
    for (size_t i = 0; i < num_inodes; i++) {
      if (nodes[i]) free(nodes[i]);
    }
    free(nodes);
  }

  // close the dirs and shit, + set the count
  if (dir) closedir(dir);
  if (fd != -1) close(fd);
  if (count) *count = num_result;

  return result;
}
