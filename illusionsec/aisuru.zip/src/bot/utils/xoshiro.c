#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "bot/definitions.h"
#include "bot/utils/xoshiro.h"

/**
 * Read more at: https://en.wikipedia.org/wiki/Xorshift#xoshiro256+
 */

static uint64_t splitmix64_next(void) {
  uint64_t result = (splitmix64_seed += 0x9E3779B97f4A7C15);
  result = (result ^ (result >> 30)) * 0xBF58476D1CE4E5B9;
  result = (result ^ (result >> 27)) * 0x94D049BB133111EB;
  return result ^ (result >> 31);
}

static uint64_t rotl(const uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }

void random_init(void) {
  int fd = open("/dev/urandom", O_RDONLY);
  if (fd < 0) {
    LOG_ERROR("Failed to open /dev/urandom to seed generator. Falling back to pid, time & clock!");

    splitmix64_seed = (uint64_t)getpid();
    splitmix64_seed ^= ((uint64_t)time(NULL) << 32);
    splitmix64_seed ^= (uint64_t)clock();
  }

  for (int i = 0; i < 4; i++) {
    if (fd == -1 || read(fd, &splitmix64_seed, sizeof(splitmix64_seed)) <= 0) {
      LOG_ERROR("Seeding with urandom failed, seeding using splitnext");
      splitmix64_seed = splitmix64_next();
    }

    xoshiro_states[i] = splitmix64_seed;
  }

  LOG_INFO("Initialized xoshiro256+ prng");
  close(fd);
}

uint64_t xoshiro_next(void) {
  uint64_t const result = xoshiro_states[0] + xoshiro_states[3];
  uint64_t const t = xoshiro_states[1] << 17;

  xoshiro_states[2] ^= xoshiro_states[0];
  xoshiro_states[3] ^= xoshiro_states[1];
  xoshiro_states[1] ^= xoshiro_states[2];
  xoshiro_states[0] ^= xoshiro_states[3];

  xoshiro_states[2] ^= t;
  xoshiro_states[3] = rotl(xoshiro_states[3], 45);

  return result;
}

void xoshiro_bytes(void *buffer, size_t len) {
  uint8_t *buf = (uint8_t *)buffer;
  size_t i = 0;

  // fill buf in 8 byte chunks
  for (; i + 8 <= len; i += 8) {
    uint64_t r = xoshiro_next();
    memcpy(buf + i, &r, 8);
  }

  // handle remaining bytes
  if (i < len) {
    uint64_t r = xoshiro_next();
    memcpy(buf + i, &r, len - i);
  }
}

uint64_t xoshiro_range(uint64_t min, uint64_t max) {
  if (min >= max) return min;

  uint64_t range = max - min + 1;
  return (xoshiro_next() % range) + min;
}
