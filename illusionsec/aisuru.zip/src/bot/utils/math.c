#include "bot/utils/math.h"
#include <string.h>
#include <time.h>

char *math_itoa(int value, char *output, int base) {
  if (output == NULL) return NULL;

  if (value == 0) {
    output[0] = '0';
    output[1] = '\0';
    return output;
  }

  char scratch[34] = {0};
  int offset = 32;

  int neg = 0;
  unsigned int accum;

  if (base == 10 && value < 0) {
    neg = 1;
    accum = -value;
  } else {
    accum = (unsigned int)value;
  }

  while (accum) {
    int c = accum % base;
    if (c < 10)
      c += '0';
    else
      c += 'A' - 10;

    scratch[offset] = c;
    accum /= base;
    offset--;
  }

  if (neg)
    scratch[offset] = '-';
  else
    offset++;

  strcpy(output, &scratch[offset]);
  return output;
}
