#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdbool.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/endianness.h"
#include "bot/resolver/resolver.h"
#include "bot/utils/stun.h"
#include "bot/utils/xoshiro.h"

#define MAPPED_ADDR_LEN 8
#define BINDING_RESPONSE 0x0101

bool stun_parse_xor_mapped_address(const uint8_t *attr_value, const int length,
                                   struct sockaddr_in *mapped_addr) {
  if (length != MAPPED_ADDR_LEN) {
    LOG_ERROR("Received unexpected xor-mapped-addr length: %d", length);
    return false;
  }

  uint16_t port;
  uint32_t ip;

  memcpy(&port, attr_value + 2, 2);
  memcpy(&ip, attr_value + 4, 4);

  port = ntohs(port) ^ STUN_MAGIC_COOKIE >> 16;
  ip = ntohl(ip) ^ STUN_MAGIC_COOKIE;

  mapped_addr->sin_family = AF_INET;
  mapped_addr->sin_port = htons(port);
  mapped_addr->sin_addr.s_addr = htonl(ip);

  return true;
}

bool stun_parse_response(uint8_t *buffer, int len, struct sockaddr_in *mapped_addr) {
  const stun_header_t *header = (stun_header_t *)buffer;

  if (ntohs(header->type) != BINDING_RESPONSE) {
    PRINTF("Received stun header is not a binding response");
    return false;
  }

  int pos = sizeof(stun_header_t);

  while (pos < len) {
    const stun_attr_t *attr = (stun_attr_t *)(buffer + pos);
    const int attr_type = ntohs(attr->type);
    const int attr_length = ntohs(attr->length);
    const uint8_t *attr_value = buffer + pos + sizeof(stun_attr_t);

    if (attr_type == STUN_XOR_MAPPED_ADDRESS)
      return stun_parse_xor_mapped_address(attr_value, attr_length, mapped_addr);

    pos += sizeof(stun_attr_t) + attr_length;
  }

  return false;
}

struct sockaddr_in stun_random_server() {
  struct sockaddr_in addr = {
      .sin_family = AF_INET,
      .sin_addr.s_addr = INET_ADDR(74, 125, 250, 129),
      .sin_port = htons(19302),
  };

  resolver_response_t res = {0};

  int ret = resolver_query(table_retrieve(TABLE_STUN_DOMAIN, NULL), &res, ns_t_a);
  table_lock(TABLE_STUN_DOMAIN);

  if (ret <= 0 || res.len <= 0) {
    resolver_free(&res);
    return addr;
  }

  addr.sin_addr.s_addr = res.records[xoshiro_next() % res.len].a;
  addr.sin_port = htons(19302);
  resolver_free(&res);

  return addr;
}

bool stun_get_public_ip(struct sockaddr_in *mapped_addr) {
  const uint8_t transaction_id[12] = {0x33, 0x55, 0x99, 0xAA, 0xBB, 0xCC,
                                      0xDD, 0xEE, 0xFF, 0x11, 0x22, 0x44};
  uint8_t buffer[1024];

  const int fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (fd < 0) {
    PRINTF("socket() failed");
    return false;
  }

  struct sockaddr_in stun_addr = stun_random_server();

  // create stun hdr
  stun_header_t *header = (stun_header_t *)buffer;

  header->type = htons(STUN_BINDING_REQUEST);
  header->length = 0;
  header->magic_cookie = htonl(STUN_MAGIC_COOKIE);

  memcpy(header->transaction_id, transaction_id, sizeof(header->transaction_id));
  sendto(fd, buffer, sizeof(stun_header_t), 0, (struct sockaddr *)&stun_addr, sizeof(stun_addr));

  // setup poll
  struct pollfd poll_fd = {
      .fd = fd,
      .events = POLLIN,
  };

  // 15 seconds
  const int ret = poll(&poll_fd, 1, 15 * 1000);
  if (ret <= 0) {
    PRINTF("poll() failed (timeout?)");
    return false;
  }

  // if it can receive smth, we parse
  if (poll_fd.revents & POLLIN) {
    socklen_t addr_len = sizeof(stun_addr);

    const int n = recvfrom(fd, buffer, 1024, 0, (struct sockaddr *)&stun_addr, &addr_len);
    if (n < 0) {
      PRINTF("failed to receive!");
      close(fd);
      return false;
    }

    close(fd);
    return stun_parse_response(buffer, n, mapped_addr);
  }

  close(fd);
  return false;
}
