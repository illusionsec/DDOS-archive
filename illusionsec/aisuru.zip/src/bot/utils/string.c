#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bot/utils/string.h"
#include "bot/definitions.h"

/* searches for something in binary data */
ssize_t str_search(void *buf, void *mem, size_t buf_len, size_t mem_len) {
  if (mem_len > buf_len) return -1;

  char *s_buf = (char *)buf;
  char *m_buf = (char *)mem;

  for (size_t i = 0; i <= buf_len - mem_len; i++) {
    size_t matched = 0;

    for (size_t j = 0; j < mem_len; j++) {
      if (m_buf[j] != '?' && s_buf[i + j] != m_buf[j]) {
        break;
      }

      matched++;
    }

    if (matched == mem_len) {
      return i + mem_len;
    }
  }

  return -1;
}

/* replaces '?' with a specific string, the buffer must be big enough! */
int str_template(char *buffer, size_t size, const char *format, ...) {
  va_list args;
  va_start(args, format);

  size_t pos = 0;

  while (*format) {
    if (*format == '?') {
      const char *replacement = va_arg(args, const char *);
      size_t replacement_len = strlen(replacement);

      if (pos + replacement_len >= size) {
        va_end(args);
        return -1;
      }

      while (*replacement) {
        buffer[pos++] = *replacement++;
      }
    } else {
      if (pos + 1 >= size) {
        va_end(args);
        return -1;
      }

      buffer[pos++] = *format;
    }

    format++;
  }

  buffer[pos < size ? pos : size - 1] = '\0';
  va_end(args);

  return pos < size ? pos : -1;
}

/* strips new lines and shit */
int str_strip(void *str, int len) {
  uint8_t *bytes = str;
  int removed = 0;

  for (int i = 0; i < len; ++i) {
    if (bytes[i] == '\n' || bytes[i] == '\r') {
      bytes[i] = 0;
      removed++;
    }
  }

  return removed;
}

/* reads until a new line */
char *str_fdgets(char *buffer, int buffer_size, int fd, int *total) {
  int count = 0;
  memset(buffer, 0, buffer_size);

  while (count < buffer_size) {
    int got = read(fd, &buffer[count], 1);
    if (got <= 0) break;

    count++;
    if (buffer[count - 1] == '\n') break;
  }

  count -= str_strip(buffer, count);

  if (total) {
    *total = count;
  }

  return (count > 0) ? buffer : NULL;
}

int stristr(char *haystack, int haystack_len, char *str) {
  char *ptr = haystack;
  int str_len = strlen(str);
  int match_count = 0;

  while (haystack_len-- > 0) {
    char a = *ptr++;
    char b = str[match_count];

    a = a >= 'A' && a <= 'Z' ? a | 0x60 : a;
    b = b >= 'A' && b <= 'Z' ? b | 0x60 : b;

    if (a == b) {
      if (++match_count == str_len) return (ptr - haystack);
    } else
      match_count = 0;
  }

  return -1;
}
