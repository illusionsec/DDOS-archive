#include <stdlib.h>
#include <string.h>

#include "bot/definitions.h"
#include "bot/utils/tokenizer.h"

/**
 * Splits the input data into tokens based on the provided delimiter.
 *
 * @param data The string (data) that is to be tokenized.
 * @param delim The delimiter that is used to split the data into multiple tokens.
 * @return A new tokenizer object, which contains the tokenized data. If there is an error
 * allocating memory or processing the inputted data, this function will return NULL.
 */
ptokenizer_t tokenizer_new(const char *data, char *delim) {
  ptokenizer_t tokenizer = malloc(sizeof(tokenizer_t));
  if (!tokenizer) return NULL;

  tokenizer->tokens = NULL;
  tokenizer->size = 0;

  char *str = strdup(data);
  if (!str) goto cleanup;

  char *token = strtok(str, delim);
  while (token) {
    char **tmp = realloc(tokenizer->tokens, (tokenizer->size + 1) * sizeof(char *));
    if (!tmp) goto cleanup;

    // dupe token into list
    tokenizer->tokens = tmp;
    tokenizer->tokens[tokenizer->size] = strdup(token);
    if (!tokenizer->tokens[tokenizer->size]) goto cleanup;

    // go to the next token
    ++tokenizer->size;
    token = strtok(NULL, delim);
  }

  FREE_NULL(str);
  return tokenizer;

  /* cleans up the tokens n stuff */
cleanup:
  FREE_NULL(str);
  tokenizer_free(tokenizer);
  return NULL;
}

/**
 * Frees the memory allocated for a tokenizer object.
 * It is important to call this function when you are done using the tokenizer to prevent memory
 leaks.
 * @param tokenizer A pointer to the tokenizer object that should be freed.
 */
void tokenizer_free(ptokenizer_t tokenizer) {
  if (!tokenizer) return;

  /* free the tokens */
  for (int i = 0; i < tokenizer->size; i++) {
    FREE_NULL(tokenizer->tokens[i]);
  }

  FREE_NULL(tokenizer->tokens);

  /* reset size and free tokenizer */
  tokenizer->size = 0;
  FREE_NULL(tokenizer);
}
