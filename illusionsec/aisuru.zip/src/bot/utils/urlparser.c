#include "bot/utils/urlparser.h"
#include "bot/utils/string.h"
#include <stdlib.h>
#include <string.h>

int url_parse(const char *url_str, purl_t url) {
  if (!url_str || !url) return -1;

  const char *p = url_str;
  memset(url, 0, sizeof(url_t));

  const char *scheme_end = strstr(p, "://");
  if (!scheme_end) return -1;

  url->scheme = strdupn(p, scheme_end - p);
  p = scheme_end + 3;

  const char *slash = strchr(p, '/');
  const char *colon = strchr(p, ':');
  const char *question = strchr(p, '?');
  const char *hash = strchr(p, '#');

  const char *host_start = p;
  const char *host_end;

  if (colon && (!slash || colon < slash)) {
    host_end = colon;
    url->host = strdupn(host_start, host_end - host_start);

    const char *port_start = colon + 1;
    const char *port_end =
        slash ? slash : (question ? question : (hash ? hash : port_start + strlen(port_start)));
    url->port = strdupn(port_start, port_end - port_start);
  } else {
    host_end = slash ? slash : (question ? question : (hash ? hash : p + strlen(p)));
    url->host = strdupn(host_start, host_end - host_start);
  }

  if (slash) {
    const char *path_start = slash;
    const char *path_end = question ? question : (hash ? hash : slash + strlen(slash));
    url->path = strdupn(path_start, path_end - path_start);
  }

  if (question) {
    const char *query_start = question + 1;
    const char *query_end = hash ? hash : question + strlen(question);
    url->query = strdupn(query_start, query_end - query_start);
  }

  if (hash) {
    url->fragment = strdup(hash + 1);
  }

  return 0;
}

void url_free(purl_t url) {
  if (!url) return;

  free(url->scheme);
  url->scheme = NULL;

  free(url->host);
  url->host = NULL;

  free(url->port);
  url->port = NULL;

  free(url->path);
  url->path = NULL;

  free(url->query);
  url->query = NULL;

  free(url->fragment);
  url->fragment = NULL;
}
