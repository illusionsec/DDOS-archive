#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void hex_from_byte(uint8_t byte, char *out) {
  const char hex[] = "0123456789ABCDEF";
  out[0] = hex[(byte >> 4) & 0xF];
  out[1] = hex[byte & 0xF];
}

int8_t hex_to_value(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

uint8_t hex_to_byte(char o1, char o2) {
  uint8_t high = hex_to_value(o1);
  return (16 * high) | hex_to_value(o2);
}

uint16_t hex_convert_u16(char o1, char o2, char o3, char o4) {
  int8_t v1 = hex_to_value(o1);
  int8_t v2 = hex_to_value(o2);
  int8_t v3 = hex_to_value(o3);
  int8_t v4 = hex_to_value(o4);

  if (v1 < 0 || v2 < 0 || v3 < 0 || v4 < 0) return 0;

  return (uint16_t)((v1 << 12) |
                    (v2 << 8)  |
                    (v3 << 4)  |
                     v4);
}

uint32_t hex_convert_u32_str(const char *hex) {
  if (!hex || strlen(hex) != 8)
    return 0;

  uint32_t result = 0;

  for (int i = 0; i < 8; ++i) {
    int8_t value = hex_to_value(hex[i]);
    if (value < 0) return 0;
    result = (result << 4) | value;
  }

  return result;
}

char **hex_split(const uint8_t *bin_data, size_t bin_len, int chunk_size,
                               int *num_chunks) {
  *num_chunks = (bin_len + chunk_size - 1) / chunk_size;

  char **chunks = malloc(*num_chunks * sizeof(char *));
  if (!chunks) goto error;

  int i = 0;
  for (i = 0; i < *num_chunks; i++) {
    size_t start = i * chunk_size;
    size_t len = (bin_len - start > chunk_size) ? chunk_size : bin_len - start;

    chunks[i] = malloc(len * 4 + 1);
    if (!chunks[i]) goto cleanup;

    char *p = chunks[i];
    for (size_t j = 0; j < len; j++) {
      *p++ = '\\';
      *p++ = 'x';
      hex_from_byte(bin_data[start + j], p);
      p += 2;
    }
    *p = '\0';
  }
  return chunks;

cleanup:
  while (--i >= 0)
    free(chunks[i]);
  free(chunks);

error:
  *num_chunks = 0;
  return NULL;
}
