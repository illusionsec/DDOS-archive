#include "bot/client/client.h"
#include "bot/client/commands.h"

void client_cmd_ping(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(buffer);
  return client_write(client, CMD_PING, NULL);
}
