#include "bot/client/client.h"
#include "bot/client/commands.h"
#include "bot/modules/locker.h"

void client_cmd_exit(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(client);
  UNUSED_PARM(buffer);

  locker_kill();
  exit(0);
}
