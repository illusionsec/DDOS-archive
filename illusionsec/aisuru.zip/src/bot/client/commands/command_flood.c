#include "bot/client/client.h"
#include "bot/definitions.h"
#include "bot/modules/flood.h"
#include "bot/client/commands.h"

void client_cmd_flood(pclient_t client, pbytebuf_t buffer) {
  UNUSED_PARM(client);
  return flood_parse(buffer);
}
