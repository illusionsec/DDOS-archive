#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bot/definitions.h"
#include "bot/resolver/resolver.h"
#include "bot/endianness.h"
#include "bot/utils/xoshiro.h"

size_t u_strnlen(const char *s, size_t n) {
  const char *p = memchr(s, 0, n);
  return p ? p - s : n;
}

/* https://github.com/bminor/musl/blob/master/src/network/dn_skipname.c#L3 */
int dn_skipname(const unsigned char *s, const unsigned char *end) {
  const unsigned char *p = s;
  while (p < end)
    if (!*p)
      return p - s + 1;
    else if (*p >= 192)
      if (p + 1 < end)
        return p - s + 2;
      else
        break;
    else if (end - p < *p + 1)
      break;
    else
      p += *p + 1;
  return -1;
}

/* label start offsets of a compressed domain name s */
/* https://github.com/bminor/musl/blob/master/src/network/dn_comp.c#L7 */
static int getoffs(short *offs, const unsigned char *base, const unsigned char *s) {
  int i = 0;
  for (;;) {
    while (*s & 0xc0) {
      if ((*s & 0xc0) != 0xc0) return 0;
      s = base + ((s[0] & 0x3f) << 8 | s[1]);
    }
    if (!*s) return i;
    if (s - base >= 0x4000) return 0;
    offs[i++] = s - base;
    s += *s + 1;
  }
}

/* label lengths of an ascii domain name s */
/* https://github.com/bminor/musl/blob/master/src/network/dn_comp.c#L23 */
static int getlens(unsigned char *lens, const char *s, int l) {
  int i = 0, j = 0, k = 0;
  for (;;) {
    for (; j < l && s[j] != '.'; j++)
      ;
    if (j - k - 1u > 62) return 0;
    lens[i++] = j - k;
    if (j == l) return i;
    k = ++j;
  }
}

/* longest suffix match of an ascii domain with a compressed domain name dn */
/* https://github.com/bminor/musl/blob/master/src/network/dn_comp.c#L36 */
static int match(int *offset, const unsigned char *base, const unsigned char *dn, const char *end,
                 const unsigned char *lens, int nlen) {
  int l, o, m = 0;
  short offs[128];
  int noff = getoffs(offs, base, dn);
  if (!noff) return 0;
  for (;;) {
    l = lens[--nlen];
    o = offs[--noff];
    end -= l;
    if (l != base[o] || memcmp(base + o + 1, end, l)) return m;
    *offset = o;
    m += l;
    if (nlen) m++;
    if (!nlen || !noff) return m;
    end--;
  }
}

// https://github.com/bminor/musl/blob/master/src/network/dn_comp.c#L57
int dn_comp(const char *src, unsigned char *dst, int space, unsigned char **dnptrs,
            unsigned char **lastdnptr) {
  int i, j, n, m = 0, offset, bestlen = 0, bestoff;
  unsigned char lens[127];
  unsigned char **p;
  const char *end;
  size_t l = u_strnlen(src, 255);
  if (l && src[l - 1] == '.') l--;
  if (l > 253 || space <= 0) return -1;
  if (!l) {
    *dst = 0;
    return 1;
  }
  end = src + l;
  n = getlens(lens, src, l);
  if (!n) return -1;

  p = dnptrs;
  if (p && *p)
    for (p++; *p; p++) {
      m = match(&offset, *dnptrs, *p, end, lens, n);
      if (m > bestlen) {
        bestlen = m;
        bestoff = offset;
        if (m == l) break;
      }
    }

  /* encode unmatched part */
  if (space < l - bestlen + 2 + (bestlen - 1 < l - 1)) return -1;
  memcpy(dst + 1, src, l - bestlen);
  for (i = j = 0; i < l - bestlen; i += lens[j++] + 1)
    dst[i] = lens[j];

  /* add tail */
  if (bestlen) {
    dst[i++] = 0xc0 | bestoff >> 8;
    dst[i++] = bestoff;
  } else
    dst[i++] = 0;

  /* save dst pointer */
  if (i > 2 && lastdnptr && dnptrs && *dnptrs) {
    while (*p)
      p++;
    if (p + 1 < lastdnptr) {
      *p++ = dst;
      *p = 0;
    }
  }
  return i;
}

int generate_query(const char *domain, unsigned char *buffer, size_t buf_len, int type) {
  if (!domain || !buffer || buf_len < sizeof(dns_header_t)) {
    LOG_ERROR("Invalid parameters or buffer too small for DNS header");
    return -1;
  }

  /* clear buffer */
  memset(buffer, 0, buf_len);

  /* create dns header */
  dns_header_t dnsh = {0};
  dnsh.id = htons(xoshiro_next() & 0xFFFF);
  dnsh.opts = htons(0x0100);
  dnsh.qdcount = htons(1);
  dnsh.nscount = htons(0);
  dnsh.arcount = htons(0);

  /* copy header into buffer */
  memcpy(buffer, &dnsh, sizeof(dns_header_t));

  /* calculate remaining len and current offset */
  size_t remaining = buf_len - sizeof(dns_header_t);
  size_t offset = sizeof(dns_header_t);

  /* encode domain name */
  int len = dn_comp(domain, buffer + offset, remaining, NULL, NULL);
  if (len < 0) {
    LOG_ERROR("Compressing domain failed: %s", domain);
    return -1;
  }

  /* update offset and check len again */
  offset += len;
  if (buf_len < offset + sizeof(dns_question_t)) {
    LOG_ERROR("Buffer too small for DNS question");
    return -1;
  }

  /* add question */
  dns_question_t qinfo = {
      .type = htons(type),
      .class = htons(1) // Internet class
  };

  /* copy question into buffer */
  memcpy(buffer + offset, &qinfo, sizeof(dns_question_t));

  return offset + sizeof(dns_question_t);
}

int resolver_query(const char *domain, presolver_response_t response, u16 type) {
  if (!domain || !response) {
    LOG_ERROR("Invalid parameters");
    return -1;
  }

  // Initialize response structure
  memset(response, 0, sizeof(*response));
  unsigned char query_buffer[1024];
  unsigned char response_buffer[1024];

  /* generate the query */
  uint16_t query_len = generate_query(domain, query_buffer, sizeof(query_buffer), type);
  if (query_len <= 0) {
    LOG_ERROR("Generating DNS query failed");
    return -1;
  }

  /* create the socket */
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) {
    LOG_ERROR("Creating socket failed: %s", strerror(errno));
    return -1;
  }

  /* setup dns server - Google DNS */
  struct sockaddr_in addr = {
      .sin_family = AF_INET,
      .sin_addr = INET_ADDR(8, 8, 8, 8),
      .sin_port = htons(53),
  };

  /* connect to server via. tcp */
  connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
  NON_BLOCK(fd);

  struct pollfd pfd = {
      .fd = fd,
      .events = POLLOUT,
  };

  while (true) {
    int ret = poll(&pfd, 1, 5000); // 5 second timeout
    if (ret <= 0) {
      LOG_ERROR("DNS request %s: %s", ret < 0 ? "failed" : "timed out",
                ret < 0 ? strerror(errno) : "timeout");
      close(fd);
      return -1;
    }

    if (pfd.revents & POLLOUT) {
      if (!is_socket_connected(fd)) {
        LOG_ERROR("not connected");
        return -1;
      }

      uint16_t data_len = htons(query_len);
      if (send(fd, &data_len, sizeof(uint16_t), MSG_NOSIGNAL) < 0) {
        LOG_ERROR("Failed to send DNS query: %s", strerror(errno));
        close(fd);
        return -1;
      }

      if (send(fd, query_buffer, query_len, MSG_NOSIGNAL) < 0) {
        LOG_ERROR("Failed to send DNS query: %s", strerror(errno));
        close(fd);
        return -1;
      }

      pfd.events = POLLIN;
    }

    // TODO: READ THE THING
    if (pfd.revents & POLLIN) {
      // read len, prefixed
      unsigned long n = recv(fd, &query_len, sizeof(uint16_t), MSG_NOSIGNAL);
      if (n < sizeof(uint16_t)) {
        LOG_ERROR("not read");
        return -1;
      }

      query_len = ntohs(query_len);

      // read the rest
      n = recv(fd, response_buffer, query_len, MSG_NOSIGNAL);
      close(fd);

      if (n < 0) {
        LOG_ERROR("Reading response failed: %s", strerror(errno));
        return -1;
      }

      // LOG_INFO("Received %zd bytes from DNS server", n);

      /* validate dns header */
      if (n < sizeof(dns_header_t)) {
        LOG_ERROR("Response too small for header (%zd bytes)", n);
        return -1;
      }

      dns_header_t header;
      memcpy(&header, response_buffer, sizeof(header));

      /* convert fields back from network byte order */
      header.id = ntohs(header.id);
      header.qdcount = ntohs(header.qdcount);
      header.ancount = ntohs(header.ancount);
      header.nscount = ntohs(header.nscount);
      header.arcount = ntohs(header.arcount);

      if (header.ancount <= 0) {
        LOG_INFO("No answers in DNS response");
        return 0; // Not an error, just no answers
      }

      // skip over the question section
      size_t offset = sizeof(dns_header_t);
      for (int i = 0; i < header.qdcount; i++) {
        int len = dn_skipname(response_buffer + offset, response_buffer + n);
        if (len <= 0) {
          LOG_ERROR("Failed to skip question name");
          resolver_free(response);
          return -1;
        }

        offset += len;

        /* check for overflow */
        if (offset + sizeof(dns_question_t) > n) {
          LOG_ERROR("Invalid DNS response (question section)");
          resolver_free(response);
          return -1;
        }

        /* skip the question section */
        offset += sizeof(dns_question_t);
      }

      // Process answer records
      for (int i = 0; i < header.ancount; i++) {
        int len = dn_skipname(response_buffer + offset, response_buffer + n);
        if (len <= 0) {
          LOG_ERROR("Failed to skip answer name");
          resolver_free(response);
          return -1;
        }

        offset += len;

        /* check for overflow */
        if (offset + sizeof(resource_record_t) > n) {
          LOG_ERROR("Invalid DNS response (record section)");
          resolver_free(response);
          return -1;
        }

        resource_record_t rr;
        memcpy(&rr, response_buffer + offset, sizeof(resource_record_t));

        rr.type = ntohs(rr.type);
        rr.class = ntohs(rr.class);
        rr.ttl = ntohl(rr.ttl);
        rr.length = ntohs(rr.length);

        offset += sizeof(resource_record_t);

        if (offset + rr.length > n) {
          LOG_ERROR("Invalid DNS response (record data exceeds message)");
          resolver_free(response);
          return -1;
        }

        // Handle A record
        if (rr.type == DNS_TYPE_A && rr.length == 4) {
          // LOG_INFO("A record: %d.%d.%d.%d", response_buffer[offset], response_buffer[offset + 1],
          //          response_buffer[offset + 2], response_buffer[offset + 3]);

          // Allocate or resize the records array
          void *new_records =
              realloc(response->records, (response->len + 1) * sizeof(resolver_record_t));
          if (!new_records) {
            LOG_ERROR("Memory allocation failed for A record");
            resolver_free(response);
            return -1;
          }

          response->records = new_records;
          memcpy(&response->records[response->len].a, &response_buffer[offset], sizeof(uint32_t));

          response->len++;
        }
        // Handle TXT record
        else if (rr.type == DNS_TYPE_TXT) {
          char *txt_buf = malloc(rr.length + 1);
          if (!txt_buf) {
            LOG_ERROR("Memory allocation failed for TXT record");
            resolver_free(response);
            return -1;
          }

          size_t pos = 0;
          size_t remaining = rr.length;
          size_t data_offset = offset;

          while (remaining > 0) {
            uint8_t txt_len = response_buffer[data_offset];

            /* check for buffer overflow */
            if (txt_len + 1 > remaining || pos + txt_len > rr.length) {
              LOG_ERROR("Invalid TXT record format");
              free(txt_buf);
              resolver_free(response);
              return -1;
            }

            /* copy text segment */
            memcpy(txt_buf + pos, response_buffer + data_offset + 1, txt_len);
            pos += txt_len;

            /* move to next text segment */
            data_offset += txt_len + 1;
            remaining -= txt_len + 1;
          }

          txt_buf[pos] = '\0';
          LOG_INFO("TXT record content: %s", txt_buf);

          void *new_records =
              realloc(response->records, (response->len + 1) * sizeof(resolver_record_t));
          if (!new_records) {
            LOG_ERROR("Memory allocation failed for TXT record storage");
            free(txt_buf);
            resolver_free(response);
            return -1;
          }

          response->records = new_records;
          response->records[response->len].txt = strdup(txt_buf);

          if (!response->records[response->len].txt) {
            LOG_ERROR("Failed to duplicate TXT record");
            free(txt_buf);
            resolver_free(response);
            return -1;
          }

          response->len++;
          free(txt_buf);
        }

        offset += rr.length;
      }

      break;
    }
  }

  return response->len > 0 ? 0 : -1;
}

void resolver_free(presolver_response_t response) {
  if (response->records) free(response->records);
  response->len = 0;
  response->records = NULL;
}
