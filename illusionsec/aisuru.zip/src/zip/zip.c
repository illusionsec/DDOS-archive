#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "zip/zip.h"

void write_le16_buf(unsigned char **p, uint16_t val) {
  *(*p)++ = val & 0xff;
  *(*p)++ = (val >> 8) & 0xff;
}

void write_le32_buf(unsigned char **p, uint32_t val) {
  *(*p)++ = val & 0xff;
  *(*p)++ = (val >> 8) & 0xff;
  *(*p)++ = (val >> 16) & 0xff;
  *(*p)++ = (val >> 24) & 0xff;
}

uint16_t get_dos_time() {
  time_t t = time(NULL);
  struct tm *lt = localtime(&t);
  return ((lt->tm_hour) << 11) | ((lt->tm_min) << 5) | ((lt->tm_sec) / 2);
}

uint16_t get_dos_date() {
  time_t t = time(NULL);
  struct tm *lt = localtime(&t);
  return (((lt->tm_year - 80) & 0x7f) << 9) | ((lt->tm_mon + 1) << 5) | (lt->tm_mday);
}

int ensure_capacity(pzip_buffer_t zip, size_t add) {
  if (zip->length + add > zip->capacity) {
    size_t newcap = zip->length + add;

    unsigned char *newbuf = realloc(zip->buf, newcap);
    if (!newbuf) return -1;

    zip->buf = newbuf;
    zip->capacity = newcap;
  }

  return 0;
}

int append_data(zip_buffer_t *zip, const void *data, size_t len) {
  if (ensure_capacity(zip, len) != 0) return -1;

  memcpy(zip->buf + zip->length, data, len);
  zip->length += len;

  return 0;
}

// --- Append zeroed bytes ---
int append_zero(zip_buffer_t *zip, size_t len) {
  if (ensure_capacity(zip, len) != 0) return -1;

  memset(zip->buf + zip->length, 0, len);
  zip->length += len;

  return 0;
}

uint32_t crc32_dummy(const unsigned char *data, size_t len) {
  (void)data;
  (void)len;
  return 0;
}

int zip_add_entry(pzip_buffer_t zip, const char *filename, const unsigned char *data, size_t size) {
  uint16_t filename_len = strlen(filename);
  uint32_t local_header_offset = zip->length;
  uint32_t crc32_val = crc32_dummy(data, size);

  // increase zip size
  if (zip->file_count == zip->file_capacity) {
    size_t newcap = zip->file_capacity + 1;
    zip_entry_t *newfiles = realloc(zip->files, newcap * sizeof(zip_entry_t));
    if (!newfiles) return -1;
    zip->files = newfiles;
    zip->file_capacity = newcap;
  }

  // set size and shit
  zip->files[zip->file_count].local_header_offset = local_header_offset;
  zip->files[zip->file_count].crc32 = crc32_val;
  zip->files[zip->file_count].uncompressed_size = size;
  zip->files[zip->file_count].filename_len = filename_len;
  zip->files[zip->file_count].filename = strdup(filename);

  if (!zip->files[zip->file_count].filename) {
    return -1;
  }

  zip->file_count++;

  unsigned char header[30];
  unsigned char *p = header;

  write_le32_buf(&p, ZIP_FILE_MAGIC_NUMBER); // Local file header signature
  write_le16_buf(&p, 20);                    // version needed to extract
  write_le16_buf(&p, 0);                     // general purpose bit flag
  write_le16_buf(&p, 0);                     // compression method = 0 (store)
  write_le16_buf(&p, get_dos_time());
  write_le16_buf(&p, get_dos_date());
  write_le32_buf(&p, crc32_val);
  write_le32_buf(&p, (uint32_t)size); // compressed size (same as uncompressed)
  write_le32_buf(&p, (uint32_t)size); // uncompressed size
  write_le16_buf(&p, filename_len);
  write_le16_buf(&p, 0); // extra field length

  if (append_data(zip, header, sizeof(header)) != 0) return -1;
  if (append_data(zip, filename, filename_len) != 0) return -1;
  if (append_data(zip, data, size) != 0) return -1;

  return 0;
}

int zip_finalize(pzip_buffer_t zip) {
  uint32_t central_dir_offset = (uint32_t)zip->length;
  uint32_t central_dir_size = 0;

  for (size_t i = 0; i < zip->file_count; i++) {
    zip_entry_t *fe = &zip->files[i];

    uint16_t filename_len = fe->filename_len;
    unsigned char header[46];
    unsigned char *p = header;

    write_le32_buf(&p, ZIP_DIR_MAGIC_NUMBER); // Central directory file header signature
    write_le16_buf(&p, 20);                   // version made by
    write_le16_buf(&p, 20);                   // version needed to extract
    write_le16_buf(&p, 0);                    // general purpose bit flag
    write_le16_buf(&p, 0);                    // compression method
    write_le16_buf(&p, get_dos_time());
    write_le16_buf(&p, get_dos_date());
    write_le32_buf(&p, fe->crc32);
    write_le32_buf(&p, fe->uncompressed_size);
    write_le32_buf(&p, fe->uncompressed_size);
    write_le16_buf(&p, filename_len);
    write_le16_buf(&p, 0); // extra field length
    write_le16_buf(&p, 0); // file comment length
    write_le16_buf(&p, 0); // disk number start
    write_le16_buf(&p, 0); // internal file attrs
    write_le32_buf(&p, 0); // external file attrs
    write_le32_buf(&p, fe->local_header_offset);

    if (append_data(zip, header, sizeof(header)) != 0) {
      zip_free(zip);
      return -1;
    }

    if (append_data(zip, fe->filename, filename_len) != 0) {
      zip_free(zip);
      return -1;
    }

    central_dir_size += sizeof(header) + filename_len;
  }

  unsigned char eocd[22];
  unsigned char *p = eocd;

  write_le32_buf(&p, 0x06054b50); // End of central dir signature
  write_le16_buf(&p, 0);          // number of this disk
  write_le16_buf(&p, 0);          // number of the disk with the start of the central directory
  write_le16_buf(&p, (uint16_t)zip->file_count); // total entries on this disk
  write_le16_buf(&p, (uint16_t)zip->file_count); // total entries overall
  write_le32_buf(&p, central_dir_size);          // size of central directory
  write_le32_buf(&p, central_dir_offset);        // offset of start of central directory
  write_le16_buf(&p, 0);                         // ZIP file comment length

  if (append_data(zip, eocd, sizeof(eocd)) != 0) {
    zip_free(zip);
    return -1;
  }

  return 0;
}

void zip_free(zip_buffer_t *zip) {
  for (size_t i = 0; i < zip->file_count; i++) {
    free(zip->files[i].filename);
  }

  free(zip->files);
  free(zip->buf);
  zip->files = NULL;
  zip->buf = NULL;
  zip->file_count = 0;
  zip->file_capacity = 0;
  zip->capacity = 0;
  zip->length = 0;
}
