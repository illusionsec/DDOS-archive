#!/bin/bash

declare -A file_mapping

cross_compiler_directory="$HOME/.cc/"
toolchain_directory="$(pwd)/toolchains"
output_directory="debug"
build_type="Debug"
out_name="bot"

arch_list=(
    i686
    armv7l
)

function strip_bot {
    if command -v "$1-strip" &>/dev/null; then
        "$1-strip" build-"$arch"/"$out_name" \
            -S \
            --strip-unneeded \
            --remove-section=.note.gnu.gold-version \
            --remove-section=.comment \
            --remove-section=.note \
            --remove-section=.note.gnu.build-id
    else
        "$1-linux-strip" build-"$arch"/"$out_name" \
            -S \
            --strip-unneeded \
            --remove-section=.note.gnu.gold-version \
            --remove-section=.comment \
            --remove-section=.note \
            --remove-section=.note.gnu.build-id
    fi
}

if [ -e $output_directory ]; then
    rm -rf $output_directory
fi

mkdir $output_directory

for arch in "${arch_list[@]}"; do
    echo -e "\e[92m[$arch] Starting compilation\x1b[0m"
    export PATH="$PATH:$cross_compiler_directory/$arch/bin"

    cmake -DCMAKE_TOOLCHAIN_FILE="$toolchain_directory"/"$arch".cmake \
        -B build-"$arch" \
        -DCUSTOM_SUFFIX=."$arch" \
        -DMODULES="$2" \
        -DCMAKE_BUILD_TYPE=$build_type \
        -S .. \
        --no-warn-unused-cli \
        >/dev/null

    cmake --build build-"$arch" -j$(nproc)
    strip_bot "$arch"

    if [[ -v file_mapping[$arch] ]]; then
        mv build-"$arch"/"$out_name" \
            $output_directory/"$1""${file_mapping[$arch]}"
    else
        mv build-"$arch"/"$out_name" \
            $output_directory/"$1""$arch"
    fi

    echo -e "\e[92m[$arch] Finished compilation\x1b[0m"
    rm -rf build-"$arch"
done
