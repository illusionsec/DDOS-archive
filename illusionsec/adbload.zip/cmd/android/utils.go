package main

import (
	adb2 "android/internal/adb"
	"android/pkg/circslice"
	"math/rand"
	"net"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"golang.org/x/net/proxy"
)

var (
	rsaSigner *adb2.Signer

	urlCache    sync.Map // map[string]*url.URL
	dialerCache sync.Map // map[string]proxy.Dialer

	proxies *circslice.CircularSlice
)

func loadProxyFile() {
	r, err := os.ReadFile(proxyInputFile)
	if err != nil {
		panic(err)
	}

	proxies = circslice.NewCircularSlice(strings.Split(strings.ReplaceAll(string(r), "\r", ""), "\n"))
}

// Helper to load signer
func loadSigner(path string) error {
	var err error
	rsaSigner, err = adb2.LoadSigner(path)
	return err
}

func getDialer(proxyStr string, auth *proxy.Auth) (proxy.Dialer, error) {
	// if cached, ok := dialerCache.Load(proxyStr); ok {
	// 	return cached.(proxy.Dialer), nil
	// }

	dialer, err := proxy.SOCKS5("tcp", proxyStr, auth, &net.Dialer{
		Timeout: 10 * time.Second,
	})
	if err != nil {
		return nil, err
	}

	// dialerCache.Store(proxyStr, dialer)
	return dialer, nil
}

func parseProxyURL(prx string) (*url.URL, error) {
	proxyURL := "socks5h://" + prx
	if cached, ok := urlCache.Load(proxyURL); ok {
		return cached.(*url.URL), nil
	}

	parsed, err := url.Parse(proxyURL)
	if err != nil {
		return nil, err
	}

	urlCache.Store(proxyURL, parsed)
	return parsed, nil
}

func parseProxy(proxer string) (string, *proxy.Auth) {
	var host = proxer
	var auth *proxy.Auth

	if strings.Contains(proxer, "@") {
		parts := strings.Split(proxer, "@")

		if len(parts) == 2 {
			userPass := parts[0]
			host = parts[1]

			if strings.Contains(userPass, ":") {
				credParts := strings.Split(userPass, ":")
				if len(credParts) == 2 {

					auth = &proxy.Auth{
						User:     credParts[0],
						Password: credParts[1],
					}
				}
			}
		}
	}

	return host, auth
}

const charset = "abcdefghijklmnopqrstuvwxyz" +
	"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

var seededRand *rand.Rand = rand.New(
	rand.NewSource(time.Now().UnixNano()))

func StringWithCharset(length int, charset string) string {
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[rand.Intn(len(charset))]
	}
	return string(b)
}

func String(length int) string {
	return StringWithCharset(length, charset)
}
