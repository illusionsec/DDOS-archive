package main

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "android-tool",
	Short: "Android ADB Exploitation Tool",
}

var (
	globalPorts    = []int{5555, 5858, 22337, 63002}
	globalThreads  = 1000
	proxyInputFile = "prx.txt"
)

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().IntSliceVarP(&globalPorts, "port", "p", globalPorts, "List of ports to scan")
	rootCmd.PersistentFlags().IntVarP(&globalThreads, "threads", "t", globalThreads, "Threads to use")
}

func main() {
	Execute()
}
