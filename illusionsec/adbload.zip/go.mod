module android

go 1.25

require (
	github.com/spf13/pflag v1.0.10
	golang.ngrok.com/muxado v1.0.0
	golang.org/x/net v0.47.0
)

require (
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/cobra v1.10.2 // indirect
)
