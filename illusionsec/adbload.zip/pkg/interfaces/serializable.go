package interfaces

type Serializable interface {
	Serialize() []byte
}
