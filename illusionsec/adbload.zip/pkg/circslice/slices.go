package circslice

import (
	"sync/atomic"
)

type CircularSlice struct {
	data  []string
	index uint64
	size  uint64
}

func NewCircularSlice(data []string) *CircularSlice {
	return &CircularSlice{
		data: data,
		size: uint64(len(data)),
	}
}

func (cs *CircularSlice) Next() string {
	idx := atomic.AddUint64(&cs.index, 1) - 1
	return cs.data[idx%cs.size]
}
