package adb

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"os"
)

type Signer struct {
	privateKey *rsa.PrivateKey
}

// LoadSigner loads an RSA private key from a PKCS#8 PEM file
func LoadSigner(keyPath string) (*Signer, error) {
	data, err := os.ReadFile(keyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read key file: %w", err)
	}

	block, _ := pem.Decode(data)
	if block == nil {
		return nil, fmt.Errorf("failed to decode PEM block")
	}

	key, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		rsaKey, err := x509.ParsePKCS1PrivateKey(block.Bytes)
		if err != nil {
			return nil, fmt.Errorf("failed to parse private key: %w", err)
		}

		return &Signer{privateKey: rsaKey}, nil
	}

	rsaKey, ok := key.(*rsa.PrivateKey)
	if !ok {
		return nil, fmt.Errorf("key is not an RSA private key")
	}

	return &Signer{privateKey: rsaKey}, nil
}

func (s *Signer) PrivateKey() *rsa.PrivateKey {
	return s.privateKey
}
func (s *Signer) PublicKey() *rsa.PublicKey {
	return &s.privateKey.PublicKey
}
