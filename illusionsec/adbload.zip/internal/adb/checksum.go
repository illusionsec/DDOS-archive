package adb

func checksum(data []byte) uint32 {
	var sum uint32 = 0
	for _, b := range data {
		sum += uint32(b)
	}
	return sum
}
