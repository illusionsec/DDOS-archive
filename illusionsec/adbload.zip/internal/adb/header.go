package adb

import (
	"bytes"
	"encoding/binary"
)

// struct message {
//     unsigned command;       /* command identifier constant      */
//     unsigned arg0;          /* first argument                   */
//     unsigned arg1;          /* second argument                  */
//     unsigned data_length;   /* length of payload (0 is allowed) */
//     unsigned data_crc32;    /* crc32 of data payload            */
//     unsigned magic;         /* command ^ 0xffffffff             */
// };

const (
	Sync = 0x434e5953
	Cnxn = 0x4e584e43
	Auth = 0x48545541
	Open = 0x4e45504f
	Okay = 0x59414b4f
	Clse = 0x45534c43
	Wrte = 0x45545257
)

const (
	AuthToken     = 1
	AuthSignature = 2
	AuthRSAPublic = 3
)

type Message struct {
	Command uint32
	Arg0    uint32
	Arg1    uint32
	Payload []byte
}

func (h *Message) Serialize() ([]byte, error) {
	buf := new(bytes.Buffer)

	_ = binary.Write(buf, binary.LittleEndian, h.Command)
	_ = binary.Write(buf, binary.LittleEndian, h.Arg0)
	_ = binary.Write(buf, binary.LittleEndian, h.Arg1)
	_ = binary.Write(buf, binary.LittleEndian, uint32(len(h.Payload)))
	_ = binary.Write(buf, binary.LittleEndian, checksum(h.Payload))
	_ = binary.Write(buf, binary.LittleEndian, h.Command^0xffffffff)

	if _, err := buf.Write(h.Payload); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}
