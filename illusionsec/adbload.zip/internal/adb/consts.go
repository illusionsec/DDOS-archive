package adb

import "errors"

const (
	AdbVersion        = 0x01000000
	MaxPayload        = 4096
	AdbClientIdentity = "host::localhost"
)

var (
	ErrAuthorizationRequired = errors.New("required auth but no signer")
	ErrRejectedAuth          = errors.New("rejected auth")
	ErrInvalidCommand        = errors.New("invalid command")
)
