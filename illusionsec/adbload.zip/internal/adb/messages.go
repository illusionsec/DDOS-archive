package adb

func NewConnectMessage(identity string, version, maxPayloadSize uint32) *Message {
	payload := append([]byte(identity), 0)

	return &Message{
		Command: Cnxn,
		Arg0:    version,
		Arg1:    maxPayloadSize,
		Payload: payload,
	}
}

func NewAuthSignatureMessage(signature []byte) *Message {
	return &Message{
		Command: Auth,
		Arg0:    AuthSignature,
		Arg1:    0,
		Payload: signature,
	}
}

func NewAuthPublicKeyMessage(publicKey []byte) *Message {
	payload := append(publicKey, 0)

	return &Message{
		Command: Auth,
		Arg0:    AuthRSAPublic,
		Arg1:    0,
		Payload: payload,
	}
}
