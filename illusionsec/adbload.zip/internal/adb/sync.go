package adb

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"time"
)

const (
	IdSend = 0x444E4553 // SEND
	IdData = 0x41544144 // DATA
	IdDone = 0x454E4F44 // DONE
	IdOkay = 0x59414B4F // OKAY
	IdFail = 0x4C494146 // FAIL
	IdQuit = 0x54495551 // QUIT
)

// WriteServiceData sends data to a remote service stream, chunking it if necessary,
// and waiting for OKAY acknowledgments for each chunk.
func (c *Client) WriteServiceData(remoteID, localID uint32, data []byte) error {
	offset := 0
	for offset < len(data) {
		chunkSize := int(c.maxPayload)
		if len(data)-offset < chunkSize {
			chunkSize = len(data) - offset
		}

		chunk := data[offset : offset+chunkSize]
		msg := &Message{
			Command: Wrte,
			Arg0:    localID,
			Arg1:    remoteID,
			Payload: chunk,
		}

		if err := c.WriteMessage(msg); err != nil {
			return fmt.Errorf("failed to write service data: %w", err)
		}

		// Wait for OKAY
		resp, err := c.ReadMessage(10 * time.Second)
		if err != nil {
			return fmt.Errorf("failed to read ACK for service data: %w", err)
		}

		if resp.Command != Okay {
			return fmt.Errorf("expected OKAY for WRTE, got %s", cmdString(resp.Command))
		}
		
		if resp.Arg1 != localID {
			// This might happen if we receive an OKAY for a previous packet or another stream?
			// But strictly sequential, it should be fine.
			// Warn?
		}

		offset += chunkSize
	}
	return nil
}

// Push pushes a local file to the remote device using the ADB SYNC protocol.
func (c *Client) Push(localPath, remotePath string, perms os.FileMode) error {
	f, err := os.Open(localPath)
	if err != nil {
		return err
	}
	defer f.Close()

	info, err := f.Stat()
	if err != nil {
		return err
	}

	localID, remoteID, err := c.OpenStream("sync:")
	if err != nil {
		return fmt.Errorf("failed to open sync stream: %w", err)
	}

	// Helper to send sync packets
	sendSyncPacket := func(id uint32, length uint32, payload []byte) error {
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, id)
		binary.Write(buf, binary.LittleEndian, length)
		if len(payload) > 0 {
			buf.Write(payload)
		}
		return c.WriteServiceData(remoteID, localID, buf.Bytes())
	}

	// 3. Send SEND request
	// format: <remote_path>,<mode>
	reqStr := fmt.Sprintf("%s,%d", remotePath, perms)
	if err := sendSyncPacket(IdSend, uint32(len(reqStr)), []byte(reqStr)); err != nil {
		return fmt.Errorf("failed to send SEND packet: %w", err)
	}

	// 4. Send DATA packets
	buf := make([]byte, 32*1024) // 32KB chunks for SYNC data
	for {
		n, err := f.Read(buf)
		if err != nil {
			if err == io.EOF {
				break
			}
			return fmt.Errorf("failed to read local file: %w", err)
		}

		if err := sendSyncPacket(IdData, uint32(n), buf[:n]); err != nil {
			return fmt.Errorf("failed to send DATA packet: %w", err)
		}
	}

	// 5. Send DONE packet
	timestamp := uint32(info.ModTime().Unix())
	if err := sendSyncPacket(IdDone, timestamp, nil); err != nil {
		return fmt.Errorf("failed to send DONE packet: %w", err)
	}

	// 6. Read response from Sync Service (OKAY or FAIL)
	// The response comes in a WRTE message.
	// We might receive multiple WRTE messages if we are lucky/unlucky, but usually just one for status.
	
	// We need to loop reading WRTE until we get a full sync response (ID + Length + maybe payload)
	// But actually, we just expect one response for SEND.
	
	respData := make([]byte, 0)
	for len(respData) < 8 {
		msg, err := c.ReadMessage(20 * time.Second)
		if err != nil {
			return fmt.Errorf("failed to read sync response: %w", err)
		}

		if msg.Command == Clse {
			return fmt.Errorf("connection closed by remote during sync")
		}

		if msg.Command == Wrte {
			respData = append(respData, msg.Payload...)

			// Ack the WRTE
			okayMsg := &Message{Command: Okay, Arg0: localID, Arg1: remoteID}
			if err := c.WriteMessage(okayMsg); err != nil {
				return err
			}
		}
	}

	id := binary.LittleEndian.Uint32(respData[0:4])
	length := binary.LittleEndian.Uint32(respData[4:8])

	if id == IdFail {
		errMsg := ""
		if len(respData) >= int(8+length) {
			errMsg = string(respData[8 : 8+length])
		} else {
			// Incomplete error message, but we know it failed.
			errMsg = "unknown error (truncated)"
		}
		return fmt.Errorf("sync failed: %s", errMsg)
	}

	if id != IdOkay {
		return fmt.Errorf("expected sync OKAY, got %08x", id)
	}

	// 7. Close connection
	closeMsg := &Message{Command: Clse, Arg0: localID, Arg1: remoteID}
	c.WriteMessage(closeMsg)

	return nil
}