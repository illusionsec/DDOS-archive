package adb

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"math/big"
	"os"
	"strings"
)

// SignToken signs an AUTH token using RSA with SHA-1 pre-hashing
// This implements the ADB authentication signature protocol:
// 1. Hash the token with SHA-1
// 2. Sign the hash using RSA with PKCS#1 v1.5 padding
func (s *Signer) SignToken(token []byte) ([]byte, error) {
	if s.privateKey == nil {
		return nil, fmt.Errorf("no private key available")
	}
	
	// Sign using RSA PKCS#1 v1.5 (not PSS)
	signature, err := rsa.SignPKCS1v15(rand.Reader, s.privateKey, crypto.SHA1, token[:])
	if err != nil {
		return nil, fmt.Errorf("failed to sign token: %w", err)
	}

	return signature, nil
}

// EncodePublicKey encodes the public key in ADB format
// ADB expects: <key_type> <base64_encoded_key> <comment>
// For RSA: the key_type is the base64-encoded RSA public key in a specific format
func (s *Signer) EncodePublicKey() ([]byte, error) {
	if s.privateKey == nil {
		return nil, fmt.Errorf("no private key available")
	}

	pubKey := &s.privateKey.PublicKey

	// ADB uses a custom format for encoding the public key
	// Format: 4-byte length + exponent + 4-byte length + modulus (little-endian)
	encoded := encodeRSAPublicKey(pubKey)

	// Encode as base64
	keyStr := base64.StdEncoding.EncodeToString(encoded)

	// Get user@host for the comment
	hostname, err := os.Hostname()
	if err != nil {
		hostname = "unknown"
	}
	username := os.Getenv("USER")
	if username == "" {
		username = os.Getenv("USERNAME") // Windows
	}
	if username == "" {
		username = "unknown"
	}

	// Format: <base64_key> <user@host>
	fullKey := fmt.Sprintf("%s %s@%s", keyStr, username, hostname)

	// Add null terminator as expected by ADB
	return append([]byte(fullKey), 0), nil
}

// encodeRSAPublicKey encodes an RSA public key in ADB's custom format
// Format:
//   - 4 bytes: length of exponent (little-endian)
//   - N bytes: exponent (big-endian)
//   - 4 bytes: length of modulus in 32-bit words (little-endian)
//   - M bytes: modulus (little-endian, 32-bit words)
func encodeRSAPublicKey(pubKey *rsa.PublicKey) []byte {
	// Get exponent and modulus bytes
	exponent := big.NewInt(int64(pubKey.E))
	exponentBytes := exponent.Bytes()

	modulus := pubKey.N
	modulusBytes := modulus.Bytes()

	// Calculate sizes
	exponentLen := len(exponentBytes)
	modulusLen := len(modulusBytes)

	// Calculate number of 32-bit words needed for modulus
	// Round up to nearest word
	modulusWords := (modulusLen + 3) / 4

	// Build the encoded key
	// Total size: 4 (exp len) + exp bytes + 4 (mod len) + mod bytes (padded to word boundary)
	size := 4 + exponentLen + 4 + (modulusWords * 4)
	encoded := make([]byte, size)

	offset := 0

	// Write exponent length (little-endian)
	encoded[offset] = byte(exponentLen)
	encoded[offset+1] = byte(exponentLen >> 8)
	encoded[offset+2] = byte(exponentLen >> 16)
	encoded[offset+3] = byte(exponentLen >> 24)
	offset += 4

	// Write exponent bytes (big-endian)
	copy(encoded[offset:], exponentBytes)
	offset += exponentLen

	// Write modulus length in words (little-endian)
	encoded[offset] = byte(modulusWords)
	encoded[offset+1] = byte(modulusWords >> 8)
	encoded[offset+2] = byte(modulusWords >> 16)
	encoded[offset+3] = byte(modulusWords >> 24)
	offset += 4

	// Write modulus bytes in little-endian word order
	// ADB expects the modulus as 32-bit words in little-endian byte order
	writeModulusLittleEndian(encoded[offset:], modulusBytes, modulusWords)

	return encoded
}

// writeModulusLittleEndian writes modulus bytes in little-endian 32-bit word format
func writeModulusLittleEndian(dst []byte, modulus []byte, words int) {
	// Reverse the modulus bytes to convert from big-endian to little-endian
	// Process in 32-bit chunks
	for i := 0; i < words; i++ {
		// Calculate source offset (from end of modulus)
		srcOffset := len(modulus) - (i+1)*4
		dstOffset := i * 4

		// Handle partial word at the beginning
		if srcOffset < 0 {
			// Pad with zeros
			for j := 0; j < 4; j++ {
				idx := srcOffset + j
				if idx >= 0 && idx < len(modulus) {
					dst[dstOffset+j] = modulus[idx]
				} else {
					dst[dstOffset+j] = 0
				}
			}
		} else {
			// Copy 4 bytes in little-endian order
			dst[dstOffset] = modulus[srcOffset+3]
			dst[dstOffset+1] = modulus[srcOffset+2]
			dst[dstOffset+2] = modulus[srcOffset+1]
			dst[dstOffset+3] = modulus[srcOffset]
		}
	}
}

// VerifySignature verifies a signature against a token (for testing)
func (s *Signer) VerifySignature(token, signature []byte) error {
	hash := sha1.Sum(token)
	return rsa.VerifyPKCS1v15(&s.privateKey.PublicKey, crypto.SHA1, hash[:], signature)
}

// ParsePublicKeyFromAuth extracts the public key string from an AUTH public key message payload
func ParsePublicKeyFromAuth(payload []byte) string {
	// Remove null terminator if present
	if len(payload) > 0 && payload[len(payload)-1] == 0 {
		payload = payload[:len(payload)-1]
	}
	return strings.TrimSpace(string(payload))
}
