package adb

import (
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"time"
)

// Client represents an ADB transport connection.
type Client struct {
	conn       net.Conn
	signer     *Signer
	maxPayload uint32
	version    uint32

	// writeLock ensures atomic writes to the connection
	writeLock sync.Mutex

	// localID is used to generate unique local stream IDs.
	localID uint32
	idLock  sync.Mutex
}

// NewClient creates a new ADB client.
func NewClient(conn net.Conn) *Client {
	return &Client{
		conn:       conn,
		maxPayload: MaxPayload, // Default, will be updated during handshake
		version:    AdbVersion,
		localID:    1,
	}
}

// SetSigner sets the signer for authentication.
func (c *Client) SetSigner(signer *Signer) {
	c.signer = signer
}

// Close closes the underlying connection.
func (c *Client) Close() error {
	return c.conn.Close()
}

// nextLocalID generates a unique local ID for streams.
func (c *Client) nextLocalID() uint32 {
	c.idLock.Lock()
	defer c.idLock.Unlock()
	c.localID++
	return c.localID
}

// Handshake performs the ADB handshake and authentication.
func (c *Client) Handshake() (string, string, error) {
	// 1. Send CNXN
	msg := NewConnectMessage(AdbClientIdentity, AdbVersion, MaxPayload)
	if err := c.WriteMessage(msg); err != nil {
		return "", "", fmt.Errorf("failed to send CNXN: %w", err)
	}

	// 2. Read response
	resp, err := c.ReadMessage(10 * time.Second)
	if err != nil {
		return "", "", fmt.Errorf("failed to read CNXN response: %w", err)
	}

	// 3. Handle Auth if required
	if resp.Command == Auth {
		if err := c.handleAuth(resp); err != nil {
			return "", "", err
		}
		// After auth, read the final CNXN
		resp, err = c.ReadMessage(10 * time.Second)
		if err != nil {
			return "", "", fmt.Errorf("failed to read post-auth CNXN: %w", err)
		}
	}

	if resp.Command != Cnxn {
		return "", "", fmt.Errorf("expected CNXN, got %s", cmdString(resp.Command))
	}

	// Update max payload from server
	if resp.Arg1 < c.maxPayload {
		c.maxPayload = resp.Arg1
	}

	// Parse device info
	return parseDeviceInfo(resp.Payload)
}

func (c *Client) handleAuth(firstMsg *Message) error {
	if c.signer == nil {
		return ErrAuthorizationRequired
	}

	if firstMsg.Arg0 != AuthToken {
		return fmt.Errorf("expected AuthToken (1), got %d", firstMsg.Arg0)
	}

	// Try signing the token
	token := firstMsg.Payload
	signature, err := c.signer.SignToken(token)
	if err != nil {
		return fmt.Errorf("failed to sign token: %w", err)
	}

	// Send Signature
	if err := c.WriteMessage(NewAuthSignatureMessage(signature)); err != nil {
		return fmt.Errorf("failed to send auth signature: %w", err)
	}

	// Read response
	resp, err := c.ReadMessage(20 * time.Second)
	if err != nil {
		return fmt.Errorf("failed to read auth response: %w", err)
	}

	if resp.Command == Cnxn {
		// Auth successful
		return nil
	}

	if resp.Command == Auth {
		// Signature rejected? Try sending public key.
		// Usually arg0 is 1 (Token) again if failed?
		// If we get AuthToken again, it means signature failed.
		// If we get something else, it's weird.
		// Assuming we need to send public key now.

		pubKey, err := c.signer.EncodePublicKey()
		if err != nil {
			return fmt.Errorf("failed to encode public key: %w", err)
		}

		if err := c.WriteMessage(NewAuthPublicKeyMessage(pubKey)); err != nil {
			return fmt.Errorf("failed to send public key: %w", err)
		}

		resp, err = c.ReadMessage(60 * time.Second) // Wait longer for user confirmation
		if err != nil {
			return fmt.Errorf("failed to read public key auth response: %w", err)
		}

		if resp.Command == Cnxn {
			return nil
		}
	}

	return ErrRejectedAuth
}

// ReadMessage reads a message from the connection with a timeout.
func (c *Client) ReadMessage(timeout time.Duration) (*Message, error) {
	if timeout > 0 {
		c.conn.SetReadDeadline(time.Now().Add(timeout))
	} else {
		c.conn.SetReadDeadline(time.Time{})
	}

	header := make([]byte, 24)
	if _, err := io.ReadFull(c.conn, header); err != nil {
		return nil, err
	}

	msg := &Message{
		Command: binary.LittleEndian.Uint32(header[0:4]),
		Arg0:    binary.LittleEndian.Uint32(header[4:8]),
		Arg1:    binary.LittleEndian.Uint32(header[8:12]),
	}

	dataLength := binary.LittleEndian.Uint32(header[12:16])
	dataCRC := binary.LittleEndian.Uint32(header[16:20])
	magic := binary.LittleEndian.Uint32(header[20:24])

	if magic != (msg.Command ^ 0xffffffff) {
		return nil, fmt.Errorf("invalid magic: expected %08x, got %08x", msg.Command^0xffffffff, magic)
	}

	if dataLength > 0 {
		msg.Payload = make([]byte, dataLength)
		if _, err := io.ReadFull(c.conn, msg.Payload); err != nil {
			return nil, err
		}

		if checksum(msg.Payload) != dataCRC {
			return nil, fmt.Errorf("checksum mismatch")
		}
	}

	return msg, nil
}

// WriteMessage sends a message.
func (c *Client) WriteMessage(msg *Message) error {
	c.writeLock.Lock()
	defer c.writeLock.Unlock()

	data, err := msg.Serialize()
	if err != nil {
		return err
	}

	_, err = c.conn.Write(data)
	return err
}

// OpenStream establishes a new stream to the specified destination.
// It handles the handshake and ignores packets from previous streams.
func (c *Client) OpenStream(destination string) (localID, remoteID uint32, err error) {
	localID = c.nextLocalID()

	msg := &Message{
		Command: Open,
		Arg0:    localID,
		Arg1:    0,
		Payload: append([]byte(destination), 0),
	}

	if err := c.WriteMessage(msg); err != nil {
		return 0, 0, err
	}

	// Wait for OKAY, ignoring packets from other streams
	for {
		resp, err := c.ReadMessage(10 * time.Second)
		if err != nil {
			return 0, 0, err
		}

		if resp.Arg1 == localID {
			if resp.Command == Okay {
				return localID, resp.Arg0, nil
			}
			if resp.Command == Clse {
				return 0, 0, fmt.Errorf("remote closed connection: %s", string(resp.Payload))
			}
			return 0, 0, fmt.Errorf("unexpected command during open: %s", cmdString(resp.Command))
		}
		// Ignore packets for other streams (e.g. late CLSE from previous command)
	}
}

// Shell executes a shell command and writes output to stdout.
func (c *Client) Shell(command string, stdout io.Writer) error {
	localID, remoteID, err := c.OpenStream(fmt.Sprintf("shell:%s", command))
	if err != nil {
		return err
	}

	// Loop to read output
	for {
		msg, err := c.ReadMessage(0) // No timeout for shell output? or maybe keepalive?
		// ADB doesn't send keepalives in this state usually.
		if err != nil {
			return err
		}

		if msg.Arg1 != localID {
			// Ignore messages for other streams if any (though we assume 1 stream)
			// But wait, Arg1 in WRTE/CLSE is the DESTINATION ID (our localID).
			// Arg0 is the SOURCE ID (remoteID).
			// Let's check.
			// OKAY: Arg0 = remoteID, Arg1 = localID (response to OPEN)
			// WRTE: Arg0 = remoteID, Arg1 = localID
			// CLSE: Arg0 = remoteID, Arg1 = localID

			// So msg.Arg1 should be our localID.
			if msg.Arg1 != localID {
				continue
			}
		}

		switch msg.Command {
		case Wrte:
			if stdout != nil {
				_, err := stdout.Write(msg.Payload)
				if err != nil {
					return err
				}
			}

			// Ack with OKAY
			okayMsg := &Message{
				Command: Okay,
				Arg0:    localID,
				Arg1:    remoteID,
			}
			if err := c.WriteMessage(okayMsg); err != nil {
				return err
			}

		case Clse:
			// Ack close
			closeMsg := &Message{
				Command: Clse,
				Arg0:    localID,
				Arg1:    remoteID,
			}
			c.WriteMessage(closeMsg)
			return nil

		default:
			// Ignore unknown or unexpected commands in this state
		}
	}
}

func parseDeviceInfo(payload []byte) (name, model string, err error) {
	s := string(payload)

	// Helper to extract value
	extract := func(key string) string {
		idx := strings.Index(s, key)
		if idx == -1 {
			return ""
		}
		start := idx + len(key)
		end := strings.Index(s[start:], ";")
		if end == -1 {
			return s[start:]
		}
		return s[start : start+end]
	}

	name = extract("ro.product.name=")
	model = extract("ro.product.model=")
	if name == "" {
		name = "unknown"
	}
	if model == "" {
		model = "unknown"
	}
	return name, model, nil
}

func cmdString(cmd uint32) string {
	switch cmd {
	case Cnxn:
		return "CNXN"
	case Auth:
		return "AUTH"
	case Open:
		return "OPEN"
	case Okay:
		return "OKAY"
	case Clse:
		return "CLSE"
	case Wrte:
		return "WRTE"
	case Sync:
		return "SYNC"
	default:
		return fmt.Sprintf("0x%08x", cmd)
	}
}