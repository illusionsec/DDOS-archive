package bytebuf

import (
	"bytes"
	"encoding/binary"
	"math"
	"strings"
)

// Buffer represents a buffer for reading and writing binary data
type Buffer struct {
	buffer   []byte
	position int
}

func New() *Buffer {
	return &Buffer{
		buffer:   make([]byte, 0),
		position: 0,
	}
}

func From(data []byte) *Buffer {
	return &Buffer{
		buffer:   data,
		position: 0,
	}
}

func (b *Buffer) AddUint8(data uint8) *Buffer {
	b.buffer = append(b.buffer, data)
	return b
}

func (b *Buffer) AddUint16(data uint16) *Buffer {
	buf := make([]byte, 2)
	binary.BigEndian.PutUint16(buf, data)
	b.buffer = append(b.buffer, buf...)
	return b
}

func (b *Buffer) AddUint32(data uint32) *Buffer {
	buf := make([]byte, 4)
	binary.BigEndian.PutUint32(buf, data)
	b.buffer = append(b.buffer, buf...)

	return b
}

func (b *Buffer) AddUint64(data uint64) *Buffer {
	buf := make([]byte, 8)
	binary.BigEndian.PutUint64(buf, data)
	b.buffer = append(b.buffer, buf...)

	return b
}

func (b *Buffer) AddFloat64(data float64) *Buffer {
	buf := make([]byte, 8)
	binary.BigEndian.PutUint64(buf, math.Float64bits(data))
	b.buffer = append(b.buffer, buf...)

	return b
}

func (b *Buffer) AddBytes(data []byte) *Buffer {
	b.AddUint32(uint32(len(data)))
	if len(data) > 0 {
		b.buffer = append(b.buffer, data...)
	}

	return b
}

func (b *Buffer) AddString(data string) *Buffer {
	b.AddBytes(encodeUTF8(data))
	return b
}

func (b *Buffer) AddVoid(data any) *Buffer {
	buf := new(bytes.Buffer)
	defer buf.Reset()
	_ = binary.Write(buf, binary.BigEndian, data)
	b.buffer = append(b.buffer, buf.Bytes()...)
	return b
}

func (b *Buffer) AddBuffer(buffer *Buffer) *Buffer {
	b.AddBytes(buffer.Bytes())
	buffer.Reset()
	return b
}

func (b *Buffer) GetUint8() (uint8, bool) {
	if b.position >= len(b.buffer) {
		return 0, false
	}
	val := b.buffer[b.position]
	b.position++
	return val, true
}

func (b *Buffer) GetBool() (bool, bool) {
	data, ok := b.GetUint8()
	return data == 1, ok
}

func (b *Buffer) GetUint16() (uint16, bool) {
	if b.position+2 > len(b.buffer) {
		return 0, false
	}

	val := binary.BigEndian.Uint16(b.buffer[b.position:])
	b.position += 2

	return val, true
}

func (b *Buffer) GetUint32() (uint32, bool) {
	if b.position+4 > len(b.buffer) {
		return 0, false
	}

	val := binary.BigEndian.Uint32(b.buffer[b.position:])
	b.position += 4

	return val, true
}

func (b *Buffer) GetFloat64() (float64, bool) {
	if b.position+8 > len(b.buffer) {
		return 0, false
	}

	bits := binary.BigEndian.Uint64(b.buffer[b.position:])
	b.position += 8

	value := math.Float64frombits(bits)
	return value, true
}

func (b *Buffer) GetUint64() (uint64, bool) {
	if b.position+8 > len(b.buffer) {
		return 0, false
	}

	val := binary.BigEndian.Uint64(b.buffer[b.position:])
	b.position += 8

	return val, true
}

func (b *Buffer) GetBytes() ([]byte, bool) {
	length, ok := b.GetUint32()
	if !ok {
		return nil, false
	}

	if b.position+int(length) > len(b.buffer) {
		return nil, false
	}

	data := b.buffer[b.position : b.position+int(length)]
	b.position += int(length)

	return data, true
}

func (b *Buffer) GetString() (string, bool) {
	data, ok := b.GetBytes()
	if !ok {
		return "", false
	}

	return strings.TrimRight(string(data), "\x00"), true
}

func (b *Buffer) GetVoid(size int) ([]byte, bool) {
	if b.position+size > len(b.buffer) {
		return nil, false
	}
	data := b.buffer[b.position : b.position+size]
	b.position += size
	return data, true
}

func (b *Buffer) Bytes() []byte {
	return b.buffer
}

func (b *Buffer) Reset() {
	b.buffer = make([]byte, 0)
	b.position = 0
}

func (b *Buffer) ResetPos() {
	b.position = 0
}

func (b *Buffer) Length() int {
	return len(b.buffer)
}

func (b *Buffer) Position() int {
	return b.position
}

func encodeUTF8(s string) []byte {
	return []byte(s)
}
