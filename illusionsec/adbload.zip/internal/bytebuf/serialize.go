package bytebuf

import (
	"fmt"
	"reflect"
)

func (b *Buffer) serializeStruct(v reflect.Value) error {
	if v.Kind() == reflect.Pointer {
		v = v.Elem()
	}

	t := v.Type()

	for i := 0; i < t.NumField(); i++ {
		field := v.Field(i)

		if !field.CanInterface() {
			continue
		}

		if err := b.serializeValue(field); err != nil {
			fieldName := t.Field(i).Name
			return fmt.Errorf("error serializing field '%s': %w", fieldName, err)
		}
	}
	return nil
}

// Single function to handle all value serialization
func (b *Buffer) serializeValue(v reflect.Value) error {
	switch v.Kind() {
	case reflect.Uint64:
		b.AddUint64(v.Uint())
	case reflect.Uint32:
		b.AddUint32(uint32(v.Uint()))
	case reflect.Uint16:
		b.AddUint16(uint16(v.Uint()))
	case reflect.Uint8:
		b.AddUint8(uint8(v.Uint()))
	case reflect.Float64:
		b.AddFloat64(v.Float())
	case reflect.Bool:
		if v.Bool() {
			b.AddUint8(1)
		} else {
			b.AddUint8(0)
		}
	case reflect.String:
		b.AddString(v.String())
	case reflect.Struct:
		return b.serializeStruct(v)
	case reflect.Slice, reflect.Array:
		length := v.Len()
		b.AddUint32(uint32(length))

		for i := 0; i < length; i++ {
			if err := b.serializeValue(v.Index(i)); err != nil {
				return fmt.Errorf("array/slice element at index %d: %w", i, err)
			}
		}
	case reflect.Map:
		length := v.Len()
		b.AddUint32(uint32(length))

		for _, key := range v.MapKeys() {
			if err := b.serializeValue(key); err != nil {
				return fmt.Errorf("map key: %w", err)
			}

			if err := b.serializeValue(v.MapIndex(key)); err != nil {
				return fmt.Errorf("map value: %w", err)
			}
		}
	case reflect.Pointer:
		if !v.IsNil() {
			return b.serializeValue(v.Elem())
		}
	default:
		return fmt.Errorf("unsupported type: %s", v.Kind())
	}
	return nil
}

func (b *Buffer) Serialize(input any) error {
	return b.serializeValue(reflect.ValueOf(input))
}

func EncodeNoErr(input any) *Buffer {
	buffer, err := Encode(input)
	if err != nil {
		fmt.Println(err)
		return New()
	}

	return buffer
}

func Encode(input any) (*Buffer, error) {
	buffer := New()
	if err := buffer.Serialize(input); err != nil {
		return nil, err
	}

	return buffer, nil
}
