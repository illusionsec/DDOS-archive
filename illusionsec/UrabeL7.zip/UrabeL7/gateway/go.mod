module dalas

go 1.23.0

toolchain go1.23.9

require (
	golang.org/x/net v0.40.0 // indirect
	golang.org/x/text v0.25.0 // indirect
)
