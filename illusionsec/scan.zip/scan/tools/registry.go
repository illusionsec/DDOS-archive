package tools

import (
	"errors"
	"fmt"
	"strconv"
)


const SKIP_ERROR_CODE = true // Change this if you want to log also failed http grab.

// by dalas, made better by hackerbob
type Result struct {
	IP      string
	Port    int
	Service string
	Banner  string
	Extra   map[string]any
}

type GrabFunc func(ip string) (*Result, error)

var grabbers = map[int]GrabFunc{
	21:   grabFTP,
	22:   grabSSH,
	23:   grabTelnet,
	80:   grabHTTP,
	3306: grabMySQL,
}

func grabTelnet(ip string) (*Result, error) {
	r, err := GrabTelnetBanner(ip)
	if err != nil {
		return nil, err
	}

	return &Result{
		IP:      r.IP,
		Port:    23,
		Service: "telnet",
		Banner:  r.Banner,
		Extra:   map[string]any{
			"version": r.Version,
		},
	}, nil
}

func grabMySQL(ip string) (*Result, error) {
	r, err := GrabMySQLBanner(ip)
	if err != nil {
		return nil, err
	}

	return &Result{
		IP:      r.IP,
		Port:    3306,
		Service: "mysql",
		Banner:  r.Version,
		Extra:   nil,
	}, nil
}



func grabHTTP(ip string) (*Result, error) {
	r, err := GrabHTTPBanner(ip)
	if err != nil {
		return nil, err
	}
	if !SKIP_ERROR_CODE && r.StatusCode >= 400 {
		return nil, errors.New("status code >= 400 (a.k.a error)")
	}

	return &Result{
		IP:      r.IP,
		Port:    80,
		Service: "http",
		Banner:  r.Server + " " + r.Headers["Status"],
		Extra: map[string]any{
    		"title": r.Title,
			"status_code": r.StatusCode,
		},
	}, nil
}

func grabSSH(ip string) (*Result, error) {
	r, err := GrabSSHBanner(ip)
	if err != nil {
		return nil, err
	}

	return &Result{
		IP:      r.IP,
		Port:    22,
		Service: "ssh",
		Banner:  r.Banner,
		Extra:   map[string]any{
			"version": r.Version,
		},
	}, nil
}

func grabFTP(ip string) (*Result, error) {
	r, err := GrabFTPBanner(ip)
	if err != nil {
		return nil, err
	}

	return &Result{
		IP:      r.IP,
		Port:    21,
		Service: "ftp",
		Banner:  r.Banner,
		Extra:   nil,
	}, nil
}

func Register(port int, handler GrabFunc) {
	grabbers[port] = handler
}

func PortFromString(portStr string) int {
	p, _ := strconv.Atoi(portStr)
	return p
}

func Grab(ip string, port int) (*Result, error) {
	handler, ok := grabbers[port]
	if !ok {
		return nil, fmt.Errorf("no grabber for port %d", port)
	}
	return handler(ip)
}

func GetRegisteredPorts() []int {
	ports := make([]int, 0, len(grabbers))
	for p := range grabbers {
		ports = append(ports, p)
	}
	return ports
}