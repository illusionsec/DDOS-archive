package tools

// extractor made by blaze, made better by hackerbob
import (
	"net"
	"regexp"
	"strings"
	"time"
)

type TelnetResult struct {
	IP      string
	Banner  string
	Version string
}

func GrabTelnetBanner(ip string) (*TelnetResult, error) {
	conn, err := net.DialTimeout("tcp", ip+":23", 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	conn.SetDeadline(time.Now().Add(2 * time.Second))

	var raw []byte
	buf := make([]byte, 1)
	for {
		_, err := conn.Read(buf)
		if err != nil {
			break
		}
		// Skip Telnet IAC negotiation sequences (start with 0xFF), Needed
		if buf[0] == 255 { // IAC
			conn.Read(buf) // command
			conn.Read(buf) // option
			continue
		}
		raw = append(raw, buf[0])
		if buf[0] == '\n' {
			break
		}
	}
	banner := string(raw)
	re := regexp.MustCompile(`(?i)(telnetd|inetd)[^\d]*(\d[\d\.]+)`)
	match := re.FindStringSubmatch(banner)
	var ssh_version string
	if len(match) >= 3 {
		ssh_version = match[2]
	} else {
		ssh_version = ""
	}


	return &TelnetResult{
		IP:     ip,
		Banner: strings.TrimSpace(banner),
		Version: ssh_version,
		
	}, nil
}
