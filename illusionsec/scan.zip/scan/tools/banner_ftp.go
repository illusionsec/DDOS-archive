package tools

// made by dalas!
import (
	"bufio"
	"net"
	"strings"
	"time"
)

type FTPResult struct {
	IP     string
	Banner string
}

func GrabFTPBanner(ip string) (*FTPResult, error) {
	conn, err := net.DialTimeout("tcp", ip+":21", 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	conn.SetDeadline(time.Now().Add(2 * time.Second))

	reader := bufio.NewReader(conn)
	banner, err := reader.ReadString('\n')
	if err != nil {
		return nil, err
	}

	return &FTPResult{
		IP:     ip,
		Banner: strings.TrimSpace(banner),
	}, nil
}
