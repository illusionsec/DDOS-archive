package tools

import (
	"bufio"
	"os"
)

// simple parser template from stack

func ParseZMapOutput(path string) ([]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var ips []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		ip := scanner.Text()
		if ip != "" && ip != "saddr" {
			ips = append(ips, ip)
		}
	}

	return ips, scanner.Err()
}
