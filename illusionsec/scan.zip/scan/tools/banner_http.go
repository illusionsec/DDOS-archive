package tools

// extractor made by blaze, made better by hackerbob
import (
	"bufio"
	"net"
	"strconv"
	"strings"
	"time"
)

type HTTPResult struct {
	IP      string
	Banner  string
	Title   string
	StatusCode  int
	Headers map[string]string
	Server  string
}

func GrabHTTPBanner(ip string) (*HTTPResult, error) {
	conn, err := net.DialTimeout("tcp", ip+":80", 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	// Send basic HTTP GET request
	request := "GET / HTTP/1.1\r\nHost: " + ip + "\r\nConnection: close\r\n\r\n"
	conn.Write([]byte(request))

	scanner := bufio.NewScanner(conn)
	headers := make(map[string]string)
	var status string
	var server string
	var bodyLines []string
	readingHeaders := true

	for scanner.Scan() {
		line := scanner.Text()
		if readingHeaders {
			if line == "" {
				readingHeaders = false
			} else 
				if strings.HasPrefix(line, "HTTP/") {
					status = line
				}
				if strings.Contains(line, ":") {
					parts := strings.SplitN(line, ":", 2)
					key := strings.TrimSpace(parts[0])
					val := strings.TrimSpace(parts[1])
					headers[key] = val
					if key == "Server" {
						server = val
					}
				}
			} else {
			bodyLines = append(bodyLines, line)
		}
	}

	status_code,_ := strconv.Atoi(strings.Split(status, " ")[1])

	body := strings.Join(bodyLines, "\n")
	title := extractTitle(body)

	return &HTTPResult{
		IP:      ip,
		Banner:  status,
		Title:   title,
		StatusCode:  status_code,
		Headers: headers,
		Server:  server,
	}, nil
}

func extractTitle(body string) string {
	start := strings.Index(strings.ToLower(body), "<title>")
	end := strings.Index(strings.ToLower(body), "</title>")
	if start >= 0 && end > start {
		return strings.TrimSpace(body[start+7 : end])
	}
	return ""
}
