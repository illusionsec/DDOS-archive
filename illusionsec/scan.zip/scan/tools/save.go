package tools

import (
	"context"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
	"go.mongodb.org/mongo-driver/v2/mongo/readpref"
)


const MONGODB_URL = "mongodb://localhost:27017/aveview"

// stack of
func SaveResults(results []*Result) (string, error) {
	client, _ := mongo.Connect(options.Client().ApplyURI(MONGODB_URL))
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	err := client.Ping(ctx, readpref.Primary())
	if err != nil {
		return "", err
	}
	collection := client.Database("aveview").Collection("results")
	res, err := collection.InsertOne(ctx, bson.M{
			"data":      results,      // []Result
			"timestamp": time.Now(),   // time.Time → BSON Date
		})
	if err != nil {
		return "", err
	}


	var id string
	if oid, ok := res.InsertedID.(bson.ObjectID); ok {
		id = oid.Hex()
	} else {
		id = oid.String()
	}
	if err = client.Disconnect(ctx); err != nil {
		return "", err 
	}
	return id, nil
}

