package tools

// extractor made by blaze
import (
	"net"
	"strings"
	"time"
)

type MySQLResult struct {
	IP      string
	Version string
}

func GrabMySQLBanner(ip string) (*MySQLResult, error) {
	conn, err := net.DialTimeout("tcp", ip+":3306", 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	conn.SetDeadline(time.Now().Add(2 * time.Second))

	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil || n < 5 {
		return nil, err
	}

	versionStart := 5
	versionEnd := versionStart
	for versionEnd < n && buf[versionEnd] != 0x00 {
		versionEnd++
	}
	version := strings.TrimSpace(string(buf[versionStart:versionEnd]))

	return &MySQLResult{
		IP:      ip,
		Version: version,
	}, nil
}
