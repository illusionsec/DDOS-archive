package tools

// extractor made by blaze, made better by hackerbob
import (
	"bufio"
	"net"
	"regexp"
	"strings"
	"time"
)

type SSHResult struct {
	IP      string
	Banner  string
	Version string
}

func GrabSSHBanner(ip string) (*SSHResult, error) {
	conn, err := net.DialTimeout("tcp", ip+":22", 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	conn.SetDeadline(time.Now().Add(2 * time.Second))

	reader := bufio.NewReader(conn)
	banner, err := reader.ReadString('\n')
	if err != nil {
		return nil, err
	}
	re := regexp.MustCompile(`(?i)(openssh)[^\d]*(\d[\d\.p]*)`)
	match := re.FindStringSubmatch(banner)
	var ssh_version string
	if len(match) >= 3 {
		ssh_version = match[2]
	} else {
		ssh_version = ""
	}

	return &SSHResult{
		IP:     ip,
		Banner: strings.TrimSpace(banner),
		Version: ssh_version,
	}, nil
}
