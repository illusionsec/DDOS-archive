# AVEVIEW

Scanning made easy

Made by dalas & hackerbob

### Requirements: golang

Change `MONGODB_URL` in tools/save.go to your Mongodb url instance (with the database name and creds)

Run: `go run main.go [ip_file]`
