package main

import (
	"aveview/tools"
	"bufio"
	"fmt"
	"log"
	"os"
	"strings"
)

func main() {
	ipFile := "data/mysql.txt"
	if len(os.Args) > 1 {
		ipFile = os.Args[1] // Open file in args, if provided
	}
	// Open IPs file
	file, err := os.Open(ipFile)
	if err != nil {
		log.Fatalf("Failed to open IPs file: %v", err)
	}
	defer file.Close()

	var ips []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		ip := strings.TrimSpace(scanner.Text())
		if ip != "" {
			ips = append(ips, ip)
		}
	}
	if err := scanner.Err(); err != nil {
		log.Fatalf("Error reading IPs: %v", err)
	}

	ports := tools.GetRegisteredPorts()
	fmt.Printf("[ave ave ave!] Loaded %d IPs from %s\n", len(ips), ipFile)
	fmt.Printf("[ave ave ave!] Scanning each IP on %d ports: %v\n", len(ports), ports)

	var allResults []*tools.Result

	for _, ip := range ips {
		for _, port := range ports {
			result, err := tools.Grab(ip, port)
			if err != nil {
				fmt.Printf("[lmao] %s:%d failed: %v\n", ip, port, err)
				continue
			}
			allResults = append(allResults, result)
			fmt.Printf("[yes sir!] %s:%d [%s] => %s\n", result.IP, result.Port, result.Service, result.Banner)
			if len(result.Extra) > 0 {
				for k, v := range result.Extra {
					fmt.Printf("    %s: %s\n", k, v)
				}
			}
		}
	}

	fmt.Printf("[*] Done. Total successful results: %d\n", len(allResults))

	if id, err := tools.SaveResults(allResults); err != nil {
		fmt.Printf("[-] Failed to save results: %v\n", err)
	} else {
		fmt.Printf("[+] Results saved as id %s\n", id)
	}
}
