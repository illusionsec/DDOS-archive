module z3ntl3/storm

go 1.23.3

require (
	github.com/spf13/cobra v1.9.1
	github.com/valyala/fasthttp v1.60.0
)

require (
	github.com/andybalholm/brotli v1.1.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/klauspost/compress v1.18.0 // indirect
	github.com/spf13/pflag v1.0.6 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	golang.org/x/net v0.38.0 // indirect
	golang.org/x/text v0.23.0 // indirect
)
