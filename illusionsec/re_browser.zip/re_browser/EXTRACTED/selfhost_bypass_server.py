#!/usr/bin/env python3
"""
自建 CDNFLY/Cloudflare 解题服务 — 兼容 browser 的 /bypass 协议
================================================================
协议(逆自 browser 二进制):
  POST /bypass              提交任务  {"url":..,"proxy":..,"mode":"async",...}
  GET  /bypass/tasks/<id>?wait=25   长轮询  {"status":"pending|running|done|failed","result":{...}}
  GET  /health                     {"ok":true}

解题引擎:提取自 browser 内嵌的 nodebridge(node run.mjs),
通过 stdin/stdout JSON 行通信(字段逆自 cfbrowser bridge 协议)。
"""
import json
import os
import subprocess
import threading
import time
import uuid
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

ENGINE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nodebridge_embed")
PORT = int(os.environ.get("CDNFLY_API_PORT", "8765"))
NODE = os.environ.get("NODE_BIN", "node")

# ---- 任务状态机(与客户端状态机一致) ----
class Task:
    def __init__(self, tid, payload):
        self.id = tid
        self.payload = payload
        self.status = "pending"
        self.result = {}
        self.lock = threading.Lock()
        self.waiter = threading.Condition()

tasks = {}
tasks_lock = threading.Lock()

def run_engine(payload):
    """启动 node 引擎: node run.mjs --json '<payload>'(接口逆自 app.mjs)。"""
    seed = {
        "url": payload.get("url", ""),
        "proxy": payload.get("proxy", ""),
        "cookie_header": payload.get("cookie_header", ""),
        "cookies": payload.get("cookies", ""),
        "user_agent": payload.get("user_agent", ""),
        "headless": payload.get("headless", True),
        "turnstile": payload.get("turnstile", False),
        "ready_timeout_ms": payload.get("ready_timeout_ms", 60000),
        "ready_selector": payload.get("ready_selector", ""),
        "ready_title": payload.get("ready_title", ""),
        "profile_root": payload.get("profile_root", ""),
    }
    seed = {k: v for k, v in seed.items() if v != "" and v is not None}
    cmd = [NODE, "run.mjs", "--json", json.dumps(seed)]
    timeout = int(payload.get("timeout_s", 120))
    try:
        proc = subprocess.run(cmd, cwd=ENGINE_DIR, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "engine timeout"}
    except Exception as e:
        return {"success": False, "error": "engine start failed: %s" % e}
    # 结果 = stdout 最后一个 JSON 对象(失败时可能为空)
    result = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if line.startswith("{"):
            try:
                obj = json.loads(line)
                result = {
                    "success": obj.get("success", False),
                    "mode": obj.get("mode", ""),
                    "error": obj.get("error", ""),
                    "cookies": obj.get("cookies", []),
                    "user_agent": obj.get("user_agent", ""),
                    "page_title": obj.get("page_title", ""),
                    "hostname": obj.get("hostname", ""),
                    "runs": obj.get("runs", 0),
                    "turnstile_token": obj.get("turnstile_token", ""),
                    "round_delay": obj.get("round_delay", 0),
                }
            except json.JSONDecodeError:
                pass
    if not result:
        result = {"success": False, "error": (proc.stderr or "engine no output").strip()[:200]}
    return result

def worker(t: Task):
    t.status = "running"
    try:
        r = run_engine(t.payload)
        t.result = r
        t.status = "done" if r.get("success") else "failed"
    except Exception as e:
        t.result = {"success": False, "error": str(e)}
        t.status = "failed"
    with t.waiter:
        t.waiter.notify_all()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/health":
            return self._json(200, {"ok": True})
        if path.startswith("/bypass/tasks/"):
            tid = path.rsplit("/", 1)[-1]
            wait = 25
            if "wait=" in self.path:
                try:
                    wait = int(self.path.split("wait=")[1])
                except Exception:
                    pass
            with tasks_lock:
                t = tasks.get(tid)
            if not t:
                return self._json(404, {"status": "failed", "result": {"error": "no such task"}})
            # 长轮询
            deadline = time.time() + wait
            while time.time() < deadline:
                with t.waiter:
                    if t.status in ("done", "failed"):
                        break
                    t.waiter.wait(timeout=min(5, max(0.1, deadline - time.time())))
            return self._json(200, {"status": t.status, "result": t.result})
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/bypass":
            return self._json(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._json(400, {"error": "invalid_json"})
        async_mode = payload.get("mode") == "async"
        tid = uuid.uuid4().hex[:16]
        t = Task(tid, payload)
        with tasks_lock:
            tasks[tid] = t
        if async_mode:
            threading.Thread(target=worker, args=(t,), daemon=True).start()
            return self._json(200, {"status": "pending", "task_id": tid})
        # 同步模式:直接执行
        r = run_engine(payload)
        return self._json(200, {"status": "done", "result": r})

if __name__ == "__main__":
    print("[selfhost] 自建解题服务启动: http://127.0.0.1:%d (引擎: %s)" % (PORT, ENGINE_DIR))
    print("[selfhost] 客户端配置: export CDNFLY_API_URL=http://127.0.0.1:%d" % PORT)
    HTTPServer(("127.0.0.1", PORT), H).serve_forever()
