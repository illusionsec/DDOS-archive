#!/usr/bin/env node
import { createRequire } from "node:module";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";


const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

const KEY = crypto.createHash("sha256").update("browser_plus:cf-nodebridge:v2_prb_20260616", "utf8").digest();
const ENC_PATH = path.join(__dirname, "run.cjs.enc");
const BUNDLE_CJS = path.join(__dirname, ".bundle.cjs");
const BUNDLE_JSC = path.join(__dirname, ".bundle.jsc");
const STAMP = path.join(__dirname, ".nodebridge.stamp");
const LOCK = path.join(__dirname, ".compile.lock");
const COMPILE_ONLY = process.argv.includes("--compile-only");
const MIN_JSC_BYTES = 512;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function decrypt(enc) {
  const iv = enc.subarray(0, 12);
  const tag = enc.subarray(12, 28);
  const data = enc.subarray(28);
  const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]);
}

function compileStamp() {
  return `${process.version}:${process.platform}:${process.arch}`;
}

function removeQuiet(...paths) {
  for (const p of paths) {
    try { fs.unlinkSync(p); } catch {}
  }
}

function isCorruptBytecodeError(err) {
  const msg = err && err.message ? String(err.message) : String(err || "");
  const code = err && err.code ? String(err.code) : "";
  return (
    code === "Z_BUF_ERROR" ||
    msg.includes("Z_BUF_ERROR") ||
    msg.includes("unexpected end of file") ||
    msg.includes("Invalid or incompatible cached data")
  );
}

function isValidJscFile(jscPath) {
  try {
    const stat = fs.statSync(jscPath);
    return stat.isFile() && stat.size >= MIN_JSC_BYTES;
  } catch {
    return false;
  }
}

function bytecodeReady(want) {
  try {
    return (
      fs.readFileSync(STAMP, "utf8").trim() === want &&
      isValidJscFile(BUNDLE_JSC)
    );
  } catch {
    return false;
  }
}

async function compileBundle() {
  removeQuiet(BUNDLE_JSC, BUNDLE_CJS, STAMP);
  if (!fs.existsSync(ENC_PATH)) {
    throw new Error("missing run.cjs.enc; redeploy browser binary or run pack-nodebridge");
  }

  const want = compileStamp();
  console.error(`[nodebridge] compiling bytecode (${want}) ...`);
  fs.writeFileSync(BUNDLE_CJS, decrypt(fs.readFileSync(ENC_PATH)));
  const bytenode = require("bytenode");
  await bytenode.compileFile({ filename: BUNDLE_CJS, compileAsModule: true });
  if (!isValidJscFile(BUNDLE_JSC)) {
    throw new Error("bytenode compile failed: .bundle.jsc missing or too small");
  }
  removeQuiet(BUNDLE_CJS);
  fs.writeFileSync(STAMP, want);
  console.error("[nodebridge] bytecode ready");
}

async function prepareBytecode(force = false) {
  const want = compileStamp();
  if (!force && bytecodeReady(want)) {
    return;
  }

  const deadline = Date.now() + 120_000;
  let gotLock = false;
  while (Date.now() < deadline) {
    if (!force && bytecodeReady(want)) {
      return;
    }
    try {
      const fd = fs.openSync(LOCK, "wx");
      fs.closeSync(fd);
      gotLock = true;
      break;
    } catch {
      await sleep(300);
    }
  }

  if (!gotLock) {
    if (!force && bytecodeReady(want)) {
      return;
    }
    throw new Error("nodebridge compile lock timeout");
  }

  try {
    if (!force && bytecodeReady(want)) {
      return;
    }
    await compileBundle();
  } finally {
    removeQuiet(LOCK);
  }
}

function loadBytecode() {
  require("bytenode");
  require(BUNDLE_JSC);
}

const cleanup = () => removeQuiet(BUNDLE_CJS);
process.on("exit", cleanup);
process.on("SIGINT", () => { cleanup(); process.exit(130); });
process.on("SIGTERM", () => { cleanup(); process.exit(143); });

await prepareBytecode();
if (COMPILE_ONLY) {
  process.exit(0);
}
try {
  loadBytecode();
} catch (err) {
  if (!isCorruptBytecodeError(err)) {
    throw err;
  }
  console.error("[nodebridge] corrupt bytecode, recompiling once...");
  removeQuiet(BUNDLE_JSC, STAMP);
  await prepareBytecode(true);
  loadBytecode();
}
