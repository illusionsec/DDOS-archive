var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/auth.js
var require_auth = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/auth.js"(exports2, module2) {
    "use strict";
    function exitIfScriptExpired(_context) {
    }
    module2.exports = {
      exitIfScriptExpired
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/proxy.js
var require_proxy = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/proxy.js"(exports2, module2) {
    "use strict";
    var fs = require("fs");
    var crypto = require("crypto");
    var request = require("request");
    var L7_PLACEHOLDER_DEFAULT_LEN = 8;
    var L7_PLACEHOLDER_MAX_LEN = 4096;
    function normalizeL7PlaceholderBrackets(input) {
      if (input == null) {
        return "";
      }
      return String(input).replace(/\uFF3B/g, "[").replace(/\uFF3D/g, "]");
    }
    function clampL7PlaceholderLen(n, fallback) {
      if (!Number.isFinite(n) || n < 1) {
        return fallback;
      }
      if (n > L7_PLACEHOLDER_MAX_LEN) {
        return L7_PLACEHOLDER_MAX_LEN;
      }
      return Math.floor(n);
    }
    function l7RandomFromAlphabet(len, alphabet) {
      if (len < 1) {
        return "";
      }
      var bytes = crypto.randomBytes(len);
      var out = "";
      var al = alphabet.length;
      var i;
      for (i = 0; i < len; i++) {
        out += alphabet[bytes[i] % al];
      }
      return out;
    }
    var L7_EMAIL_DOMAINS = [
      "gmail.com",
      "outlook.com",
      "yahoo.com",
      "hotmail.com",
      "icloud.com",
      "qq.com",
      "163.com",
      "126.com",
      "foxmail.com"
    ];
    function l7RandomEmail(domain) {
      domain = domain != null ? String(domain).trim() : "";
      if (!domain) {
        domain = L7_EMAIL_DOMAINS[crypto.randomInt(L7_EMAIL_DOMAINS.length)];
      }
      var localLen = 6 + crypto.randomInt(11);
      return l7RandomFromAlphabet(localLen, "abcdefghijklmnopqrstuvwxyz0123456789") + "@" + domain;
    }
    function l7RandomCNMobile() {
      return "1" + String(3 + crypto.randomInt(7)) + l7RandomFromAlphabet(9, "0123456789");
    }
    function l7RandomUSPhone() {
      return String(2 + crypto.randomInt(8)) + l7RandomFromAlphabet(2, "0123456789") + String(2 + crypto.randomInt(8)) + l7RandomFromAlphabet(2, "0123456789") + l7RandomFromAlphabet(4, "0123456789");
    }
    function l7NormalizePhoneLocale(param) {
      var p = param != null ? String(param).trim() : "";
      if (p.charAt(0) === "+") {
        p = p.slice(1);
      }
      return p.toUpperCase();
    }
    function l7FormatIntlMobileSplit(countryCode, a, b) {
      var national = a + b;
      switch (crypto.randomInt(4)) {
        case 0:
          return "+" + countryCode + national;
        case 1:
          return "+" + countryCode + " " + a + " " + b;
        case 2:
          return "+" + countryCode + "-" + a + "-" + b;
        default:
          return "+" + countryCode + " " + a + "-" + b;
      }
    }
    function l7RandomKRPhone() {
      var prefix = "10";
      if (crypto.randomInt(10) === 0) {
        var legacy = ["11", "16", "17", "18", "19"];
        prefix = legacy[crypto.randomInt(legacy.length)];
      }
      return l7FormatIntlMobileSplit("82", prefix, l7RandomFromAlphabet(8, "0123456789"));
    }
    function l7RandomJPPhone() {
      var prefixes = ["90", "80", "70"];
      var prefix = prefixes[crypto.randomInt(prefixes.length)];
      return l7FormatIntlMobileSplit("81", prefix, l7RandomFromAlphabet(8, "0123456789"));
    }
    function l7RandomUKPhone() {
      var sub = "7" + l7RandomFromAlphabet(9, "0123456789");
      return l7FormatIntlMobileSplit("44", sub.slice(0, 4), sub.slice(4));
    }
    function l7RandomINPhone() {
      var sub = String(6 + crypto.randomInt(4)) + l7RandomFromAlphabet(9, "0123456789");
      return l7FormatIntlMobileSplit("91", sub.slice(0, 5), sub.slice(5));
    }
    function l7RandomPhone(param) {
      param = param != null ? String(param).trim() : "";
      if (!param) {
        return l7RandomCNMobile();
      }
      var locale = l7NormalizePhoneLocale(param);
      if (locale === "CN" || locale === "CHINA") {
        return l7RandomCNMobile();
      }
      if (locale === "US" || locale === "USA") {
        return l7RandomUSPhone();
      }
      if (locale === "KR" || locale === "KOREA" || locale === "82") {
        return l7RandomKRPhone();
      }
      if (locale === "JP" || locale === "JAPAN" || locale === "81") {
        return l7RandomJPPhone();
      }
      if (locale === "GB" || locale === "UK" || locale === "GBR" || locale === "BRITAIN" || locale === "44") {
        return l7RandomUKPhone();
      }
      if (locale === "IN" || locale === "INDIA" || locale === "91") {
        return l7RandomINPhone();
      }
      if (/^\d+$/.test(param)) {
        var n = clampL7PlaceholderLen(parseInt(param, 10), 11);
        if (n < 7) {
          n = 11;
        }
        if (n > 15) {
          n = 15;
        }
        if (n === 1) {
          return l7RandomFromAlphabet(1, "123456789");
        }
        return l7RandomFromAlphabet(1, "123456789") + l7RandomFromAlphabet(n - 1, "0123456789");
      }
      return l7RandomCNMobile();
    }
    function expandL7Placeholders(input) {
      if (input == null) {
        return "";
      }
      var s = normalizeL7PlaceholderBrackets(input);
      s = s.replace(/\[EMAIL(?::([^\]]+))?\]/gi, function(match, domain) {
        return l7RandomEmail(domain);
      });
      s = s.replace(/\[PHONE(?::([^\]]+))?\]/gi, function(match, param) {
        return l7RandomPhone(param);
      });
      var re = /\[(RAND|STRING|INT)(?::(\d+))?\]/gi;
      return s.replace(re, function(match, kind, lenStr) {
        var parsed = lenStr != null && lenStr !== "" ? parseInt(lenStr, 10) : L7_PLACEHOLDER_DEFAULT_LEN;
        var n = clampL7PlaceholderLen(parsed, L7_PLACEHOLDER_DEFAULT_LEN);
        var k = String(kind).toUpperCase();
        if (k === "RAND") {
          return l7RandomFromAlphabet(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
        }
        if (k === "STRING") {
          return l7RandomFromAlphabet(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
        }
        if (k === "INT") {
          return l7RandomFromAlphabet(n, "0123456789");
        }
        return match;
      });
    }
    function parseProxyLine(line) {
      const raw = String(line).trim();
      if (!raw) return null;
      var spaceParts = raw.split(/\s+/);
      if (spaceParts.length >= 3 && !/^https?:\/\//i.test(raw)) {
        var hostPort = spaceParts[0];
        var hpColon = hostPort.lastIndexOf(":");
        if (hpColon > 0 && hpColon < hostPort.length - 1) {
          var spHost = hostPort.slice(0, hpColon);
          var spPort = parseInt(hostPort.slice(hpColon + 1), 10);
          if (spHost && Number.isFinite(spPort) && spPort >= 1 && spPort <= 65535) {
            return {
              host: spHost,
              port: spPort,
              username: spaceParts[1],
              password: spaceParts.slice(2).join(" "),
              raw
            };
          }
        }
      }
      if (/^https?:\/\//i.test(raw)) {
        var parsedUrl;
        try {
          parsedUrl = new URL(raw);
        } catch (e) {
          return null;
        }
        var host = parsedUrl.hostname;
        var defPort = parsedUrl.protocol === "https:" ? 443 : 80;
        var port = parsedUrl.port ? parseInt(parsedUrl.port, 10) : defPort;
        if (!host || !Number.isFinite(port)) return null;
        var username = parsedUrl.username ? decodeURIComponent(parsedUrl.username) : "";
        var password = parsedUrl.password ? decodeURIComponent(parsedUrl.password) : "";
        var out = { host, port, raw };
        if (username || password) {
          out.username = username;
          out.password = password;
        }
        return out;
      }
      var parts = raw.split(":");
      if (parts.length < 2) return null;
      var portNum = parseInt(parts[1], 10);
      var isValidPort = Number.isFinite(portNum) && portNum >= 1 && portNum <= 65535;
      if (isValidPort) {
        var hostPart = parts[0];
        if (parts.length === 2) {
          return { host: hostPart, port: portNum, raw };
        }
        if (parts.length === 3) {
          return { host: hostPart, port: portNum, username: parts[2], password: "", raw };
        }
        return { host: hostPart, port: portNum, username: parts[2], password: parts.slice(3).join(":"), raw };
      }
      if (parts.length >= 4) {
        var altPort = parseInt(parts[parts.length - 1], 10);
        if (Number.isFinite(altPort) && altPort >= 1 && altPort <= 65535) {
          var altHost = parts[parts.length - 2];
          var altUser = parts[0];
          var altPass = parts.slice(1, parts.length - 2).join(":");
          if (altHost && altUser) {
            return { host: altHost, port: altPort, username: altUser, password: altPass, raw };
          }
        }
      }
      return null;
    }
    function proxyParsedHasCredentials(p) {
      if (!p) return false;
      return p.username != null && String(p.username).length > 0 || p.password != null && String(p.password).length > 0;
    }
    function maskProxyHostname(_host) {
      return "***";
    }
    function proxyLineForDisplay(line) {
      if (line == null) return "";
      var s = String(line).trim();
      if (s === "(direct)" || s === "") return s;
      var p = parseProxyLine(line);
      if (!p) {
        return s.length > 48 ? s.slice(0, 48) + "\u2026" : s;
      }
      var raw = s;
      if (!proxyParsedHasCredentials(p)) {
        return raw;
      }
      var mh = maskProxyHostname(p.host);
      if (/^https?:\/\//i.test(raw)) {
        var auth = encodeURIComponent(p.username || "") + ":" + encodeURIComponent(p.password || "") + "@";
        var proto = /^https:/i.test(raw) ? "https://" : "http://";
        return proto + auth + mh + ":" + p.port;
      }
      var u = p.username != null ? p.username : "";
      var pw = p.password != null ? p.password : "";
      return mh + ":" + p.port + ":" + u + ":" + pw;
    }
    function proxyUrlForHttpRequest(line) {
      var parsed = parseProxyLine(line);
      if (!parsed) return null;
      if (/^https?:\/\//i.test(String(line).trim())) {
        return String(line).trim();
      }
      if (proxyParsedHasCredentials(parsed)) {
        return "http://" + encodeURIComponent(parsed.username || "") + ":" + encodeURIComponent(parsed.password || "") + "@" + parsed.host + ":" + parsed.port;
      }
      return "http://" + parsed.host + ":" + parsed.port;
    }
    function proxyLineForLog(line) {
      var p = parseProxyLine(line);
      if (!p) {
        return String(line).slice(0, 48);
      }
      if (!proxyParsedHasCredentials(p)) {
        return p.host + ":" + p.port;
      }
      return maskProxyHostname(p.host) + ":" + p.port + " (auth)";
    }
    function readLines(filePath) {
      return fs.readFileSync(filePath).toString().split(/\r?\n/);
    }
    function randList(list) {
      return list[Math.floor(Math.random() * list.length)];
    }
    function removeFirstEqual(arr, item) {
      var index = arr.indexOf(item);
      if (index !== -1) {
        arr.splice(index, 1);
      }
    }
    var PROXY_PRECHECK_URLS = [
      // CF trace（推荐，等价替换）
      // http://checkip.amazonaws.com/         ← 已有
      // https://api.ipify.org/                ← HTTPS、纯 IP
      // https://icanhazip.com/                ← CF 后面
      // https://ipv4.icanhazip.com/           ← 强制 v4
      // https://ifconfig.me/ip
      // https://wtfismyip.com/text
      // http://ip-api.com/line/?fields=query  ← 纯 IP 一行
      // https://nopecha.com/demo/cloudflare/cdn-cgi/trace
      "https://www.cloudflare.com/cdn-cgi/trace",
      "http://checkip.amazonaws.com/"
    ];
    function probeProxyThroughUrl(proxyLine, targetUrl, precheckRequestTimeoutMs) {
      return new Promise(function(resolve, reject) {
        var proxyUrl = proxyUrlForHttpRequest(proxyLine);
        if (!proxyUrl) {
          reject();
          return;
        }
        var settled = false;
        var req;
        function finish(ok) {
          if (settled) {
            return;
          }
          settled = true;
          clearTimeout(hardTimer);
          if (req && typeof req.abort === "function") {
            try {
              req.abort();
            } catch (abortErr) {
            }
          }
          if (ok) {
            resolve();
          } else {
            reject();
          }
        }
        var hardMs = precheckRequestTimeoutMs + 4e3;
        var hardTimer = setTimeout(function() {
          finish(false);
        }, hardMs);
        req = request(
          {
            url: targetUrl,
            proxy: proxyUrl,
            timeout: precheckRequestTimeoutMs,
            headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0" }
          },
          function(err, res) {
            if (!err && res && res.statusCode === 200) {
              finish(true);
            } else {
              finish(false);
            }
          }
        );
        if (req && typeof req.on === "function") {
          req.on("error", function() {
            finish(false);
          });
        }
      });
    }
    function check_proxy(proxy, proxyPrecheckMode, precheckRequestTimeoutMs) {
      var urls = PROXY_PRECHECK_URLS;
      if (!urls || urls.length === 0) {
        return Promise.reject();
      }
      var mode = proxyPrecheckMode;
      if (/^\d+$/.test(mode)) {
        var idx = parseInt(mode, 10) - 1;
        if (idx < 0 || idx >= urls.length) {
          return Promise.reject();
        }
        return probeProxyThroughUrl(proxy, urls[idx], precheckRequestTimeoutMs).then(function() {
          return proxy;
        });
      }
      var probes = urls.map(function(u) {
        return probeProxyThroughUrl(proxy, u, precheckRequestTimeoutMs);
      });
      if (mode === "any" && urls.length > 1) {
        if (typeof Promise.any === "function") {
          return Promise.any(probes).then(function() {
            return proxy;
          }, function() {
            return Promise.reject();
          });
        }
        return Promise.allSettled(probes).then(function(results) {
          for (var i = 0; i < results.length; i++) {
            if (results[i].status === "fulfilled") {
              return proxy;
            }
          }
          return Promise.reject();
        });
      }
      return Promise.all(probes).then(function() {
        return proxy;
      });
    }
    function proxyPrecheckStrategyLogSuffix(proxyPrecheckMode) {
      var mode = proxyPrecheckMode;
      var list = PROXY_PRECHECK_URLS;
      if (/^\d+$/.test(mode)) {
        var idx = parseInt(mode, 10) - 1;
        if (!list || idx < 0 || idx >= list.length) {
          return mode + " \u65E0\u6548";
        }
        return mode;
      }
      if (mode === "any") {
        return "any";
      }
      return "all";
    }
    async function isProxyValid(browserProxy, proxyPrecheckMode, precheckRequestTimeoutMs) {
      try {
        await check_proxy(browserProxy, proxyPrecheckMode, precheckRequestTimeoutMs);
        return browserProxy;
      } catch (error) {
        throw new Error();
      }
    }
    module2.exports = {
      normalizeL7PlaceholderBrackets,
      expandL7Placeholders,
      parseProxyLine,
      proxyParsedHasCredentials,
      maskProxyHostname,
      proxyLineForDisplay,
      proxyUrlForHttpRequest,
      proxyLineForLog,
      readLines,
      randList,
      removeFirstEqual,
      PROXY_PRECHECK_URLS,
      probeProxyThroughUrl,
      check_proxy,
      proxyPrecheckStrategyLogSuffix,
      isProxyValid
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/errors.js
var require_errors = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/errors.js"(exports2, module2) {
    "use strict";
    function isBenignNetworkNoiseError(err) {
      if (err == null || typeof err !== "object") {
        return false;
      }
      var code = err.code;
      if (code === "ECONNRESET" || code === "ECONNREFUSED" || code === "EPIPE" || code === "ETIMEDOUT" || code === "ECONNABORTED") {
        return true;
      }
      if (err.errno === -104 || err.errno === -54) {
        return true;
      }
      var m = err.message != null ? String(err.message) : "";
      if (m && /read ECONNRESET|\bECONNRESET\b/i.test(m)) {
        return true;
      }
      return false;
    }
    function isTunnelAgentRequestNoiseError(err) {
      if (err == null || typeof err !== "object" || err.code !== "ERR_ASSERTION") {
        return false;
      }
      var st = String(err.stack || "");
      return st.indexOf("tunnel-agent") !== -1 || st.indexOf("TunnelingAgent") !== -1;
    }
    function isPuppeteerNavigationNoiseError(err) {
      if (err != null && typeof err === "object" && err.name === "TargetCloseError") {
        return true;
      }
      var msg = "";
      if (err != null && typeof err === "object" && err.message) {
        msg = String(err.message);
      } else if (err != null) {
        msg = String(err);
      }
      if (/net::ERR_[A-Z0-9_]+/i.test(msg)) {
        return true;
      }
      if (err != null && typeof err === "object" && err.code === "UND_ERR_SOCKET" && /other side closed/i.test(msg)) {
        return true;
      }
      if (/Failed to fetch browser webSocket URL/i.test(msg)) {
        return true;
      }
      if (/Target closed|Session closed|The browser has been closed|Navigating frame was detached|Frame was detached|Attempted to use detached Frame|Requesting main frame too early!|Protocol error \([^)]+\): Target closed/i.test(msg)) {
        return true;
      }
      if (err != null && typeof err === "object" && err.name === "TimeoutError" && /navigation timeout/i.test(msg)) {
        return true;
      }
      if (err != null && typeof err === "object" && err.cause) {
        return isPuppeteerNavigationNoiseError(err.cause);
      }
      return false;
    }
    function isGloballySuppressedNoiseError(err) {
      return isGloballySuppressedNoiseErrorDepth(err, 0);
    }
    var NOISE_UNWRAP_MAX_DEPTH = 12;
    function isGloballySuppressedNoiseErrorDepth(err, depth) {
      if (err == null || depth > NOISE_UNWRAP_MAX_DEPTH) {
        return false;
      }
      if (isBenignNetworkNoiseError(err) || isTunnelAgentRequestNoiseError(err) || isPuppeteerNavigationNoiseError(err)) {
        return true;
      }
      if (typeof err !== "object") {
        return false;
      }
      if (isGloballySuppressedNoiseErrorDepth(err.error, depth + 1)) {
        return true;
      }
      if (isGloballySuppressedNoiseErrorDepth(err.cause, depth + 1)) {
        return true;
      }
      return false;
    }
    function shouldSuppressGlobalErrorLog(err) {
      return isGloballySuppressedNoiseError(err);
    }
    function installGlobalErrorHandlers() {
      process.on("uncaughtException", function(error) {
        if (shouldSuppressGlobalErrorLog(error)) {
          return;
        }
        console.log(error);
      });
      process.on("unhandledRejection", function(reason) {
        if (shouldSuppressGlobalErrorLog(reason)) {
          return;
        }
        console.log(reason);
      });
    }
    module2.exports = {
      isBenignNetworkNoiseError,
      isTunnelAgentRequestNoiseError,
      isPuppeteerNavigationNoiseError,
      isGloballySuppressedNoiseError,
      shouldSuppressGlobalErrorLog,
      installGlobalErrorHandlers
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/http_utils.js
var require_http_utils = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/http_utils.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var http = require("http");
    var https = require("https");
    var path = require("path");
    var fs = require("fs");
    function sleep(duration) {
      return new Promise(function(resolve) {
        setTimeout(resolve, duration * 1e3);
      });
    }
    function getL7CaptchaTmpDir() {
      var dir = path.join(process.cwd(), "tmp");
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    }
    function httpPostRequest(fullUrlString, headers, bodyStr, timeoutMs) {
      var timeout = timeoutMs != null && Number.isFinite(timeoutMs) ? timeoutMs : 6e4;
      return new Promise(function(resolve, reject) {
        var settled = false;
        function settle(fn, arg) {
          if (settled) {
            return;
          }
          settled = true;
          fn(arg);
        }
        var parsed;
        try {
          parsed = new URL(fullUrlString);
        } catch (e) {
          reject(new Error("\u65E0\u6548\u7684\u6388\u6743\u670D\u52A1 URL"));
          return;
        }
        var isHttps = parsed.protocol === "https:";
        var lib = isHttps ? https : http;
        var payload = bodyStr != null ? String(bodyStr) : "";
        var hdr = {};
        var k;
        for (k in headers) {
          if (Object.prototype.hasOwnProperty.call(headers, k)) {
            hdr[k] = headers[k];
          }
        }
        hdr["Content-Length"] = Buffer.byteLength(payload, "utf8");
        var options = {
          hostname: parsed.hostname,
          port: parsed.port || (isHttps ? 443 : 80),
          path: parsed.pathname + parsed.search,
          method: "POST",
          headers: hdr
        };
        var req = lib.request(options, function(res) {
          var chunks = [];
          var resDone = false;
          function finishRes(fn, arg) {
            if (resDone) {
              return;
            }
            resDone = true;
            settle(fn, arg);
          }
          res.on("data", function(chunk) {
            chunks.push(chunk);
          });
          res.on("end", function() {
            var buf = Buffer.concat(chunks);
            finishRes(resolve, { statusCode: res.statusCode, body: buf.toString("utf8") });
          });
          res.on("error", function(err) {
            finishRes(reject, err);
          });
        });
        req.setTimeout(timeout, function() {
          req.destroy();
          var te = new Error("\u6388\u6743\u670D\u52A1\u8FDE\u63A5\u8D85\u65F6");
          te.code = "ETIMEDOUT";
          settle(reject, te);
        });
        req.on("error", function(err) {
          settle(reject, err);
        });
        req.write(payload, "utf8");
        req.end();
      });
    }
    function md5Hex(buf) {
      return crypto.createHash("md5").update(buf).digest("hex");
    }
    async function fetchBufferByUrl(url) {
      var opts = {};
      if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
        opts.signal = AbortSignal.timeout(3e4);
      }
      var resp = await fetch(url, opts);
      if (!resp.ok) {
        throw new Error("HTTP " + resp.status);
      }
      var arr = await resp.arrayBuffer();
      return Buffer.from(arr);
    }
    function writeExecutableBinaryUpgrade(localPath, remoteBuf) {
      var tmpPath = localPath + ".upgrade.tmp";
      try {
        fs.writeFileSync(tmpPath, remoteBuf, { mode: 493 });
        fs.renameSync(tmpPath, localPath);
        try {
          fs.chmodSync(localPath, 493);
        } catch (chmodErr) {
        }
      } finally {
        try {
          if (fs.existsSync(tmpPath)) {
            fs.unlinkSync(tmpPath);
          }
        } catch (cleanupErr) {
        }
      }
    }
    function writeBrowserBinaryUpgrade(localBrowserPath, remoteBuf) {
      writeExecutableBinaryUpgrade(localBrowserPath, remoteBuf);
    }
    async function checkAndAutoUpgradeSingleExecutable(licenseKeyValue, serverMd5Raw, ONLINE_UPGRADE_BASE_URL, fileQuery, localBasename, opts) {
      var options = opts || {};
      var needsRestartNote = options.needsRestartNote === true;
      var quietWhenUpToDate = options.quietWhenUpToDate === true;
      var skipDownloadWithoutServerMd5 = options.skipDownloadWithoutServerMd5 === true;
      var displayName = options.displayName != null ? String(options.displayName) : String(localBasename);
      var serverMd5 = String(serverMd5Raw || "").trim().toLowerCase();
      var hasServerMd5 = /^[a-f0-9]{32}$/.test(serverMd5);
      var localPath = path.resolve(process.cwd(), String(localBasename || "").replace(/^[/\\]+/, ""));
      var fq = String(fileQuery || localBasename || "").trim();
      var downloadUrl = ONLINE_UPGRADE_BASE_URL + "?key=" + encodeURIComponent(String(licenseKeyValue || "")) + "&file=" + encodeURIComponent(fq);
      var localMd5 = "";
      if (fs.existsSync(localPath)) {
        localMd5 = md5Hex(fs.readFileSync(localPath));
      }
      if (hasServerMd5) {
        if (!quietWhenUpToDate) {
          console.log(("[*] \u5728\u7EBF\u5347\u7EA7\u68C0\u67E5 (" + displayName + "): \u6BD4\u5BF9\u672C\u5730\u4E0E\u6388\u6743\u4E0B\u53D1\u7684 MD5").cyan);
        }
        if (localMd5 === serverMd5) {
          if (!quietWhenUpToDate) {
            console.log(("[*] \u5728\u7EBF\u5347\u7EA7\u68C0\u67E5 (" + displayName + "): \u672C\u5730\u5DF2\u662F\u6700\u65B0").cyan);
          }
          return;
        }
        console.log(("[!] \u68C0\u6D4B\u5230\u65B0\u7248\u672C (" + displayName + ")\uFF0C\u5F00\u59CB\u81EA\u52A8\u4E0B\u8F7D").yellow);
        var remoteBufAuth = await fetchBufferByUrl(downloadUrl);
        if (!Buffer.isBuffer(remoteBufAuth) || remoteBufAuth.length === 0) {
          throw new Error("\u4E91\u7AEF\u6587\u4EF6\u4E3A\u7A7A");
        }
        var gotMd5Auth = md5Hex(remoteBufAuth);
        if (gotMd5Auth !== serverMd5) {
          throw new Error("\u4E0B\u8F7D\u6587\u4EF6 MD5 \u4E0E\u6388\u6743\u8FD4\u56DE\u4E0D\u4E00\u81F4\uFF0C\u5DF2\u4E2D\u6B62\u66FF\u6362");
        }
        writeExecutableBinaryUpgrade(localPath, remoteBufAuth);
        if (needsRestartNote) {
          console.log(("[\u2713] \u5728\u7EBF\u5347\u7EA7\u5B8C\u6210 (" + displayName + ")\uFF0C\u8BF7\u91CD\u542F\u7A0B\u5E8F\u4EE5\u4F7F\u7528\u65B0\u7248\u672C").green);
        } else {
          console.log(("[\u2713] \u5728\u7EBF\u5347\u7EA7\u5B8C\u6210 (" + displayName + ")\uFF0C\u5DF2\u5199\u5165\u5E76\u8D4B\u4E88\u6267\u884C\u6743\u9650").green);
        }
        return;
      }
      if (skipDownloadWithoutServerMd5) {
        return;
      }
      if (!quietWhenUpToDate) {
        console.log(("[*] \u5728\u7EBF\u5347\u7EA7 (" + displayName + "): \u6388\u6743\u672A\u8FD4\u56DE MD5\uFF0C\u5C06\u62C9\u53D6\u8FDC\u7AEF\u540E\u4E0E\u672C\u5730\u6BD4\u5BF9").cyan);
      }
      var remoteBuf = await fetchBufferByUrl(downloadUrl);
      if (!Buffer.isBuffer(remoteBuf) || remoteBuf.length === 0) {
        throw new Error("\u4E91\u7AEF\u6587\u4EF6\u4E3A\u7A7A");
      }
      var gotMd5 = md5Hex(remoteBuf);
      if (localMd5 === gotMd5) {
        if (!quietWhenUpToDate) {
          console.log(("[*] \u5728\u7EBF\u5347\u7EA7\u68C0\u67E5 (" + displayName + "): \u672C\u5730\u5DF2\u662F\u6700\u65B0").cyan);
        }
        return;
      }
      console.log(("[!] \u68C0\u6D4B\u5230\u65B0\u7248\u672C (" + displayName + ")\uFF0C\u5F00\u59CB\u81EA\u52A8\u4E0B\u8F7D").yellow);
      writeExecutableBinaryUpgrade(localPath, remoteBuf);
      if (needsRestartNote) {
        console.log(("[\u2713] \u5728\u7EBF\u5347\u7EA7\u5B8C\u6210 (" + displayName + ")\uFF0C\u8BF7\u91CD\u542F\u7A0B\u5E8F\u4EE5\u4F7F\u7528\u65B0\u7248\u672C").green);
      } else {
        console.log(("[\u2713] \u5728\u7EBF\u5347\u7EA7\u5B8C\u6210 (" + displayName + ")\uFF0C\u5DF2\u5199\u5165\u5E76\u8D4B\u4E88\u6267\u884C\u6743\u9650").green);
      }
    }
    async function checkAndAutoUpgradeBrowserBinary(licenseKeyValue, serverMd5Raw, ONLINE_UPGRADE_BASE_URL) {
      try {
        await checkAndAutoUpgradeSingleExecutable(
          licenseKeyValue,
          serverMd5Raw,
          ONLINE_UPGRADE_BASE_URL,
          "browser",
          "browser",
          { needsRestartNote: true, quietWhenUpToDate: false, displayName: "browser", skipDownloadWithoutServerMd5: true }
        );
      } catch (err) {
        console.log(("[!] \u5728\u7EBF\u5347\u7EA7\u68C0\u67E5\u5931\u8D25 (browser): " + String(err.message || err)).yellow);
      }
    }
    var FLOOD_ONLINE_UPGRADE_SPECS = [
      { md5Key: "by", fileQuery: "by", localBasename: "by" },
      { md5Key: "cloudflare", fileQuery: "cloudflare", localBasename: "cloudflare" },
      { md5Key: "h1", fileQuery: "h1", localBasename: "h1" },
      { md5Key: "h2", fileQuery: "h2", localBasename: "h2" },
      { md5Key: "install", fileQuery: "install", localBasename: "install" },
      { md5Key: "raw", fileQuery: "raw", localBasename: "raw" },
      { md5Key: "stealth", fileQuery: "stealth", localBasename: "stealth" }
    ];
    async function checkAndAutoUpgradeFloodExecutables(licenseKeyValue, floodLatestMd5, ONLINE_UPGRADE_BASE_URL) {
      var map = floodLatestMd5 && typeof floodLatestMd5 === "object" ? floodLatestMd5 : /* @__PURE__ */ Object.create(null);
      var i;
      for (i = 0; i < FLOOD_ONLINE_UPGRADE_SPECS.length; i++) {
        var spec = FLOOD_ONLINE_UPGRADE_SPECS[i];
        try {
          await checkAndAutoUpgradeSingleExecutable(
            licenseKeyValue,
            map[spec.md5Key],
            ONLINE_UPGRADE_BASE_URL,
            spec.fileQuery,
            spec.localBasename,
            {
              needsRestartNote: false,
              quietWhenUpToDate: true,
              displayName: spec.md5Key,
              skipDownloadWithoutServerMd5: true
            }
          );
        } catch (err) {
          console.log(("[!] \u5728\u7EBF\u5347\u7EA7\u68C0\u67E5\u5931\u8D25 (" + spec.md5Key + "): " + String(err.message || err)).yellow);
        }
      }
    }
    module2.exports = {
      sleep,
      getL7CaptchaTmpDir,
      httpPostRequest,
      md5Hex,
      fetchBufferByUrl,
      writeExecutableBinaryUpgrade,
      writeBrowserBinaryUpgrade,
      checkAndAutoUpgradeSingleExecutable,
      checkAndAutoUpgradeBrowserBinary,
      checkAndAutoUpgradeFloodExecutables,
      FLOOD_ONLINE_UPGRADE_SPECS
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/captcha_api.js
var require_captcha_api = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/captcha_api.js"(exports2, module2) {
    "use strict";
    var http = require("http");
    var https = require("https");
    var { httpPostRequest, sleep } = require_http_utils();
    var ANTICAP_URLS = {
      ANTICAP_API: "",
      // 字点选绕过接口
      ANTICAP_CLICK_API: "",
      // 文字点选绕过接口
      ANTICAP_MATCH_API: "",
      // 算术验证码绕过接口
      ANTICAP_SLIDER_API: "",
      // 单滑块绕过接口
      CURVE_SLIDER_API: "",
      // 曲线/双缺口滑块
      ROTATE_IMAGE_API: "",
      // 旋转图 + 横向滑轨（solve_rotate_cdnfly.js）
      /** slider2 曲线绕过 POST 完整 URL（含路径）。仅 scheme://host:port 时自动补全路径；本项留空 '' 时用 /api/curve/bypass。L7_SLIDER2_URL 非空时优先 */
      // SLIDER2_LOCAL_API: 'http://127.0.0.1:8001/api/curve/bypass'
      SLIDER2_LOCAL_API: ""
    };
    function setAnticapUrls(urls) {
      Object.assign(ANTICAP_URLS, urls);
    }
    function defaultSlider2BypassPathFromAnticap() {
      var fallback = "/api/curve/bypass";
      var cfg = ANTICAP_URLS.SLIDER2_LOCAL_API;
      if (cfg == null || !String(cfg).trim()) {
        return fallback;
      }
      try {
        var u = new URL(String(cfg).trim());
        var p = (u.pathname || "").replace(/\/+$/, "");
        if (p && p !== "/") {
          return p;
        }
      } catch (eCfg) {
      }
      return fallback;
    }
    function resolveSlider2BypassEndpoint(raw) {
      var defaultPath = defaultSlider2BypassPathFromAnticap();
      var pathNeedle = defaultPath.toLowerCase();
      var s = String(raw || "").trim();
      if (!s) {
        return "";
      }
      try {
        var u = new URL(s);
        var p = u.pathname || "";
        if (p === "" || p === "/") {
          u.pathname = defaultPath;
        }
        var out = u.href;
        if (out.charAt(out.length - 1) === "/") {
          out = out.slice(0, -1);
        }
        return out;
      } catch (eUrl) {
        s = s.replace(/\/+$/, "");
        if (s.toLowerCase().indexOf(pathNeedle) !== -1) {
          return s;
        }
        return s + defaultPath;
      }
    }
    function callSlider2LocalBypass(pageUrl, hintsObj, proxyLine, sessionCookies) {
      var envBase = process.env.L7_SLIDER2_URL;
      var base = envBase != null && String(envBase).trim() ? String(envBase).trim() : ANTICAP_URLS.SLIDER2_LOCAL_API != null && String(ANTICAP_URLS.SLIDER2_LOCAL_API).trim() ? String(ANTICAP_URLS.SLIDER2_LOCAL_API).trim() : "";
      var endpoint = resolveSlider2BypassEndpoint(base);
      if (!endpoint) {
        return Promise.resolve(null);
      }
      var bodyObj = { url: pageUrl };
      if (hintsObj != null && typeof hintsObj === "object") {
        let putHint = function(snake, val) {
          if (val != null && String(val).trim()) {
            ch[snake] = String(val).trim();
          }
        };
        if (hintsObj.userAgent != null && String(hintsObj.userAgent).trim()) {
          bodyObj.user_agent = String(hintsObj.userAgent).trim();
        }
        var ch = {};
        putHint("accept_language", hintsObj.acceptLanguage);
        putHint("accept", hintsObj.accept);
        putHint("accept_encoding", hintsObj.acceptEncoding);
        putHint("sec_ch_ua", hintsObj.secChUa);
        putHint("sec_ch_ua_mobile", hintsObj.secChUaMobile);
        putHint("sec_ch_ua_platform", hintsObj.secChUaPlatform);
        if (Object.keys(ch).length > 0) {
          bodyObj.client_hints = ch;
        }
      }
      if (sessionCookies != null && typeof sessionCookies === "object" && Object.keys(sessionCookies).length > 0) {
        bodyObj.cookies = sessionCookies;
      }
      var _proxyStr = proxyLine != null ? String(proxyLine).trim() : "";
      if (_proxyStr && _proxyStr !== "(direct)" && /^[^:]+:\d+/.test(_proxyStr)) {
        bodyObj.proxy = _proxyStr;
      }
      var payload = JSON.stringify(bodyObj);
      return httpPostRequest(endpoint, { "Content-Type": "application/json" }, payload, 18e4).then(function(res) {
        if (res.statusCode !== 200) {
          return { ok: false, error: "HTTP " + res.statusCode };
        }
        try {
          return JSON.parse(res.body);
        } catch (eJson) {
          return { ok: false, error: "bad JSON" };
        }
      }).catch(function(err) {
        return { ok: false, error: err && err.message ? err.message : String(err) };
      });
    }
    function callAnticapClickAPI(imageBase64) {
      var payload = JSON.stringify({ image: imageBase64 });
      return httpPostRequest(ANTICAP_URLS.ANTICAP_CLICK_API, { "Content-Type": "application/json" }, payload).then(function(res) {
        if (res.statusCode !== 200) {
          throw new Error("anticap click API " + res.statusCode + ": " + res.body);
        }
        try {
          return JSON.parse(res.body);
        } catch (e) {
          throw new Error("anticap click API invalid JSON: " + (e && e.message));
        }
      });
    }
    function rc4EncryptForSlider(text, key) {
      var s = [];
      var j = 0;
      var x;
      var res = "";
      var i;
      for (i = 0; i < 256; i++) {
        s[i] = i;
      }
      for (i = 0; i < 256; i++) {
        j = (j + s[i] + key.charCodeAt(i % key.length)) % 256;
        x = s[i];
        s[i] = s[j];
        s[j] = x;
      }
      i = 0;
      j = 0;
      var y;
      for (y = 0; y < text.length; y++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        x = s[i];
        s[i] = s[j];
        s[j] = x;
        res += String.fromCharCode(text.charCodeAt(y) ^ s[(s[i] + s[j]) % 256]);
      }
      return res;
    }
    function binaryStringToBase64(str) {
      return Buffer.from(str, "binary").toString("base64");
    }
    function getPngDimensionsFromBase64(base64) {
      var buf = Buffer.from(base64, "base64");
      return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
    }
    function callSliderMatchAPISolveSingleStyle(targetImageBase64, backgroundImageBase64) {
      return new Promise(function(resolve, reject) {
        var payload = JSON.stringify({
          target_image: targetImageBase64,
          background_image: backgroundImageBase64
        });
        var url;
        try {
          url = new URL(ANTICAP_URLS.ANTICAP_SLIDER_API);
        } catch (e) {
          reject(new Error("\u65E0\u6548\u7684 ANTICAP_SLIDER_API"));
          return;
        }
        var isHttps = url.protocol === "https:";
        var port = url.port || (isHttps ? 443 : 80);
        var pathWithQuery = url.pathname + url.search;
        var requestLib = isHttps ? https : http;
        var req = requestLib.request(
          {
            hostname: url.hostname,
            port,
            path: pathWithQuery,
            method: "POST",
            headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) }
          },
          function(res) {
            var data = "";
            res.on("data", function(chunk) {
              data += chunk;
            });
            res.on("end", function() {
              if (res.statusCode !== 200) {
                reject(new Error("API " + res.statusCode + ": " + data));
                return;
              }
              try {
                resolve(JSON.parse(data));
              } catch (err) {
                reject(err);
              }
            });
          }
        );
        req.on("error", reject);
        req.write(payload);
        req.end();
      });
    }
    function generateHumanTrackForSlider(startX, startY, distance, steps) {
      if (steps == null) {
        steps = 35;
      }
      var points = [];
      var i;
      for (i = 0; i <= steps; i++) {
        var t = i / steps;
        var ease = t < 0.7 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        var x = startX + distance * ease;
        var yJitter = (Math.random() - 0.5) * 3;
        var y = startY + yJitter;
        var dt = Math.floor(Math.random() * 15 + 8);
        points.push({ x, y, dt });
      }
      points.push({ x: startX + distance, y: startY, dt: Math.floor(Math.random() * 30 + 50) });
      return points;
    }
    function callCurveSliderAPISolveStyle(imageBuffer, params) {
      return new Promise(function(resolve, reject) {
        var imageBase64 = imageBuffer.toString("base64");
        var postData = JSON.stringify({ image: imageBase64, type: "slider", params });
        var apiUrl;
        try {
          apiUrl = new URL(ANTICAP_URLS.CURVE_SLIDER_API);
        } catch (e) {
          reject(new Error("\u65E0\u6548\u7684 CURVE_SLIDER_API"));
          return;
        }
        var isHttps = apiUrl.protocol === "https:";
        var lib = isHttps ? https : http;
        var port = apiUrl.port || (isHttps ? 443 : 80);
        var pathWithQuery = apiUrl.pathname + apiUrl.search;
        var req = lib.request(
          {
            hostname: apiUrl.hostname,
            port,
            path: pathWithQuery,
            method: "POST",
            headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(postData) }
          },
          function(res) {
            var data = "";
            res.on("data", function(chunk) {
              data += chunk;
            });
            res.on("end", function() {
              if (res.statusCode !== 200) {
                reject(new Error("curve API " + res.statusCode + ": " + data));
                return;
              }
              try {
                var json = JSON.parse(data);
                if (json.rotation !== void 0) {
                  resolve(json.rotation);
                } else {
                  reject(new Error("curve API response missing rotation: " + data));
                }
              } catch (err) {
                reject(err);
              }
            });
          }
        );
        req.on("error", reject);
        req.write(postData);
        req.end();
      });
    }
    function callRotateImageAPISolveStyle(imageBuffer) {
      return new Promise(function(resolve, reject) {
        var imageBase64 = imageBuffer.toString("base64");
        var postData = JSON.stringify({ image: imageBase64, type: "rotate" });
        var apiUrl;
        try {
          apiUrl = new URL(ANTICAP_URLS.ROTATE_IMAGE_API);
        } catch (e) {
          reject(new Error("\u65E0\u6548\u7684 ROTATE_IMAGE_API"));
          return;
        }
        var isHttps = apiUrl.protocol === "https:";
        var lib = isHttps ? https : http;
        var port = apiUrl.port || (isHttps ? 443 : 80);
        var pathWithQuery = apiUrl.pathname + apiUrl.search;
        var req = lib.request(
          {
            hostname: apiUrl.hostname,
            port,
            path: pathWithQuery,
            method: "POST",
            headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(postData) }
          },
          function(res) {
            var data = "";
            res.on("data", function(chunk) {
              data += chunk;
            });
            res.on("end", function() {
              if (res.statusCode !== 200) {
                reject(new Error("rotate API " + res.statusCode + ": " + data));
                return;
              }
              try {
                var json = JSON.parse(data);
                if (json.rotation !== void 0) {
                  resolve([json.rotation]);
                } else if (json.box) {
                  resolve(json.box);
                } else if (json.result) {
                  resolve(json.result);
                } else if (json.error) {
                  reject(new Error("rotate API error: " + json.error));
                } else {
                  resolve([0]);
                }
              } catch (err) {
                reject(err);
              }
            });
          }
        );
        req.on("error", reject);
        req.write(postData);
        req.end();
      });
    }
    function callMathMatchAPISolveStyle(imageBase64) {
      return new Promise(function(resolve, reject) {
        var payload = JSON.stringify({ image_base64: imageBase64 });
        var apiUrl;
        try {
          apiUrl = new URL(ANTICAP_URLS.ANTICAP_MATCH_API);
        } catch (e) {
          reject(new Error("\u65E0\u6548\u7684 ANTICAP_MATCH_API"));
          return;
        }
        var isHttps = apiUrl.protocol === "https:";
        var lib = isHttps ? https : http;
        var port = apiUrl.port || (isHttps ? 443 : 80);
        var pathWithQuery = apiUrl.pathname + apiUrl.search;
        var req = lib.request(
          {
            hostname: apiUrl.hostname,
            port,
            path: pathWithQuery,
            method: "POST",
            headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) }
          },
          function(res) {
            var data = "";
            res.on("data", function(chunk) {
              data += chunk;
            });
            res.on("end", function() {
              if (res.statusCode !== 200) {
                reject(new Error("math match API " + res.statusCode + ": " + data));
                return;
              }
              try {
                resolve(JSON.parse(data));
              } catch (err) {
                reject(err);
              }
            });
          }
        );
        req.on("error", reject);
        req.write(payload);
        req.end();
      });
    }
    function parseMathCaptchaAnswer(raw) {
      if (raw == null) {
        return null;
      }
      var s = String(raw).trim();
      s = s.replace(/[０-９]/g, function(c) {
        return String.fromCharCode(c.charCodeAt(0) - 65296 + 48);
      });
      s = s.replace(/\s*[=＝]\s*[?？]?\s*$/, "").replace(/\s*[?？]\s*$/, "").trim();
      s = s.replace(/\s+/g, "");
      s = s.replace(/[＋]/g, "+").replace(/[－−‐\u2212\uFF0D]/g, "-").replace(/[×✕✖xX＊\u00D7\uFF0A]/g, "*").replace(/[÷／\u00F7\uFF0F]/g, "/");
      if (/^-?\d+$/.test(s)) {
        return parseInt(s, 10);
      }
      if (!/^[\d+\-*/.()]+$/.test(s)) {
        return null;
      }
      try {
        var v = new Function('"use strict"; return (' + s + ")")();
        return Number.isFinite(v) ? Math.round(v) : null;
      } catch (e) {
        return null;
      }
    }
    module2.exports = {
      ANTICAP_URLS,
      setAnticapUrls,
      callSlider2LocalBypass,
      callAnticapClickAPI,
      rc4EncryptForSlider,
      binaryStringToBase64,
      getPngDimensionsFromBase64,
      callSliderMatchAPISolveSingleStyle,
      generateHumanTrackForSlider,
      callCurveSliderAPISolveStyle,
      callRotateImageAPISolveStyle,
      callMathMatchAPISolveStyle,
      parseMathCaptchaAnswer
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/eval_snippets.js
var require_eval_snippets = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/eval_snippets.js"(exports2, module2) {
    "use strict";
    var EVAL_IN_PAGE_USER_AGENT = "navigator.userAgent";
    var EVAL_SLIDER2_BROWSER_HINTS = '(function () {var langs = navigator.languages && navigator.languages.length ? navigator.languages.slice() : [navigator.language || "en-US"];var al = langs.map(function (lang, i) { return i === 0 ? lang : lang + ";q=" + Math.max(0.1, 0.9 - i * 0.1).toFixed(1); }).join(",");var out = { userAgent: navigator.userAgent, acceptLanguage: al, accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", acceptEncoding: "gzip, deflate, br, zstd" };try {var uad = navigator.userAgentData;if (uad && uad.brands && uad.brands.length) {var q = String.fromCharCode(34);out.secChUa = uad.brands.map(function (b) { return q + b.brand + q + ";v=" + q + b.version + q; }).join(", ");out.secChUaMobile = uad.mobile ? "?1" : "?0";out.secChUaPlatform = q + uad.platform + q;}} catch (e) {}return out;})()';
    var EVAL_IN_PAGE_TURNSTILE_COORDS = '(function(){var coordinates=[];document.querySelectorAll("div").forEach(function(item){try{var itemCoordinates=item.getBoundingClientRect();var itemCss=window.getComputedStyle(item);if(itemCss.margin=="0px"&&itemCss.padding=="0px"&&itemCoordinates.width>290&&itemCoordinates.width<=310&&!item.querySelector("*")){coordinates.push({x:itemCoordinates.x,y:item.getBoundingClientRect().y,w:item.getBoundingClientRect().width,h:item.getBoundingClientRect().height})}}catch(err){}});if(coordinates.length<=0){document.querySelectorAll("div").forEach(function(item){try{var itemCoordinates=item.getBoundingClientRect();if(itemCoordinates.width>290&&itemCoordinates.width<=310&&!item.querySelector("*")){coordinates.push({x:itemCoordinates.x,y:item.getBoundingClientRect().y,w:item.getBoundingClientRect().width,h:item.getBoundingClientRect().height})}}catch(err){}})}return coordinates})()';
    var EVAL_IN_PAGE_CF_SLIDER = '(function(){var rectangleContainer=document.querySelector("#rectangleContainer");var cloudflareCaptcha=document.querySelector("#cloudflare_captcha");if(rectangleContainer)rectangleContainer.style.display="none";if(cloudflareCaptcha)cloudflareCaptcha.style.display="block";})()';
    var EVAL_ON_NEW_DOC_PLATFORM = 'Object.defineProperty(navigator,"platform",{get:function(){return"Win32";}});';
    function evalOnNewDocumentUserAgentDataSource(versionLiteral) {
      return '(function(version){Object.defineProperty(navigator,"userAgentData",{get:function(){return{brands:[{brand:"Chromium",version:version},{brand:"Google Chrome",version:version},{brand:"Not;A=Brand",version:"99"}],mobile:false,platform:"Windows"};}}});})(' + JSON.stringify(String(versionLiteral)) + ")";
    }
    function buildNavigatorFingerprintPatch(meta) {
      var platformId = meta.platformId || "";
      var mobile = !!meta.mobile;
      var glVendor = meta.webglVendor || "";
      var glRenderer = meta.webglRenderer || "";
      var uad = meta.userAgentData || null;
      var parts = ["(function(){"];
      parts.push("try{");
      if (platformId) {
        parts.push('Object.defineProperty(navigator,"platform",{get:function(){return ' + JSON.stringify(platformId) + ";},configurable:true});");
      }
      if (mobile) {
        parts.push('Object.defineProperty(navigator,"maxTouchPoints",{get:function(){return 5;},configurable:true});');
      }
      parts.push("}catch(e){}");
      if (uad) {
        parts.push("try{");
        parts.push("var _b=" + JSON.stringify(uad.brands || []) + ";");
        parts.push("var _fvl=" + JSON.stringify(uad.fullVersionList || []) + ";");
        parts.push("var _plat=" + JSON.stringify(uad.platform || "") + ";");
        parts.push("var _pv=" + JSON.stringify(uad.platformVersion || "") + ";");
        parts.push("var _arch=" + JSON.stringify(uad.architecture || "x86") + ";");
        parts.push("var _model=" + JSON.stringify(uad.model || "") + ";");
        parts.push("var _fv=" + JSON.stringify(uad.uaFullVersion || "") + ";");
        parts.push("var _mob=" + (mobile ? "true" : "false") + ";");
        parts.push('var _all={architecture:_arch,bitness:"64",brands:_b,fullVersionList:_fvl,mobile:_mob,model:_model,platform:_plat,platformVersion:_pv,uaFullVersion:_fv,wow64:false};');
        parts.push('var _d={brands:_b,mobile:_mob,platform:_plat,getHighEntropyValues:function(h){var o={brands:_b,mobile:_mob,platform:_plat};if(h&&h.length){for(var i=0;i<h.length;i++){if(_all.hasOwnProperty(h[i]))o[h[i]]=_all[h[i]];}}return Promise.resolve(o);},toJSON:function(){return {brands:_b,mobile:_mob,platform:_plat};}};try{Object.defineProperty(navigator,"userAgentData",{get:function(){return _d;},configurable:true});}catch(e){}');
        parts.push("}catch(e){}");
      }
      if (glVendor && glRenderer) {
        parts.push("try{var glV=" + JSON.stringify(glVendor) + ";var glR=" + JSON.stringify(glRenderer) + ';var patch=function(proto){if(!proto||!proto.getParameter)return;var gp=proto.getParameter;if(gp.__l7p)return;var np=function(p){if(p===37445)return glV;if(p===37446)return glR;return gp.apply(this,arguments);};np.__l7p=true;try{Object.defineProperty(np,"toString",{value:gp.toString.bind(gp)});}catch(e){}proto.getParameter=np;};if(typeof WebGLRenderingContext!=="undefined")patch(WebGLRenderingContext.prototype);if(typeof WebGL2RenderingContext!=="undefined")patch(WebGL2RenderingContext.prototype);}catch(e){}');
      }
      parts.push("})();");
      return parts.join("");
    }
    var EVAL_CLICKABLE_STYLE = new Function("el", 'return el.getAttribute("style") || "";');
    var EVAL_CLICKABLE_RECT = new Function(
      "el",
      "var r = el.getBoundingClientRect(); return { x: r.left, y: r.top, width: r.width, height: r.height };"
    );
    var EVAL_CDNFLY_PUZZLE_PIECE_HIDE = new Function(
      'var el = document.querySelector(".puzzle-piece"); if (el) { el.style.visibility = "hidden"; }'
    );
    var EVAL_CDNFLY_PUZZLE_PIECE_SHOW = new Function(
      'var el = document.querySelector(".puzzle-piece"); if (el) { el.style.visibility = "visible"; }'
    );
    var EVAL_CDNFLY_PUZZLE_BG_URL = new Function(
      "sel",
      `var el = document.querySelector(sel);if (!el) return null;var bg = window.getComputedStyle(el).backgroundImage;if (!bg || bg === "none") return null;var m = bg.match(/url\\(['"]?(.*?)['"]?\\)/);return m ? m[1] : null;`
    );
    var EVAL_CDNFLY_FETCH_URL_TO_B64 = new Function(
      "url",
      'return fetch(url).then(function (res) { return res.blob(); }).then(function (blob) {return new Promise(function (resolve, reject) {var r = new FileReader();r.onload = function () { resolve(r.result.split(",")[1]); };r.onerror = function () { reject(new Error("FileReader")); };r.readAsDataURL(blob);});});'
    );
    var EVAL_EDGE_ONE_MAIN_PASS_CHECK = new Function(
      `var ck = document.cookie || "";
if (ck.indexOf("tads_cap") !== -1) return true;
if (document.getElementById("tcaptcha_iframe_eo")) return false;
if (document.getElementById("tcaptcha_wrapper_transform_eo")) return false;
if (document.querySelector('iframe[src*="gcaptcha.eo.gtimg.com"]')) return false;
if (document.querySelector('script[src*="TEOCaptchaWidgetV1"]')) return false;
return true;`
    );
    var EVAL_CDNFLY_CURVE_SLIDER_METRICS = new Function(
      'var handleEl = document.querySelector(".slider-handle");var trackEl = document.querySelector(".slider");if (!handleEl || !trackEl) return null;var handleRect = handleEl.getBoundingClientRect();var trackRect = trackEl.getBoundingClientRect();var sliderMaxLeft = trackEl.offsetWidth - handleEl.offsetWidth;return {sliderMaxLeft: sliderMaxLeft,handleCenter: { x: handleRect.left + handleRect.width / 2, y: handleRect.top + handleRect.height / 2 },trackRect: { left: trackRect.left, top: trackRect.top, width: trackRect.width, height: trackRect.height }};'
    );
    var EVAL_LECDN_SLIDER_PTS = new Function(
      'var root = document.querySelector("#slider");var h = root && root.querySelector(".handler");if (!root || !h) return null;var rr = root.getBoundingClientRect();var hr = h.getBoundingClientRect();var x0 = hr.left + hr.width / 2;var y0 = hr.top + hr.height / 2;var x1 = rr.right - hr.width / 2;if (x1 <= x0 || rr.width < 8) return null;return { x0: x0, y0: y0, x1: x1, y1: y0 };'
    );
    var EVAL_ALIYUN_SLIDER_PTS = new Function(
      'var handle = document.querySelector("#aliyunCaptcha-sliding-slider");if (!handle) return null;var track = handle.closest(".nc-container");if (!track) track = handle.parentElement;if (!track) return null;var hr = handle.getBoundingClientRect();var tr = track.getBoundingClientRect();var x0 = hr.left + hr.width / 2;var y0 = hr.top + hr.height / 2;var x1 = tr.right - hr.width / 2 - 2;if (x1 <= x0 || tr.width < 20) return null;return { x0: x0, y0: y0, x1: x1, y1: y0 };'
    );
    var EVAL_MATH_CAPTCHA_SCALE_B64 = new Function(
      "base64",
      "scale",
      'return new Promise(function (resolve, reject) {\nvar img = new Image();\nimg.onload = function () {\n  var w = img.naturalWidth * scale;\n  var h = img.naturalHeight * scale;\n  var canvas = document.createElement("canvas");\n  canvas.width = w;\n  canvas.height = h;\n  var ctx = canvas.getContext("2d");\n  ctx.imageSmoothingEnabled = true;\n  ctx.imageSmoothingQuality = "high";\n  ctx.drawImage(img, 0, 0, w, h);\n  var dataUrl = canvas.toDataURL("image/png");\n  resolve(dataUrl.replace(/^data:image\\/\\w+;base64,/, ""));\n};\nimg.onerror = function () { reject(new Error("Scale image load failed")); };\nimg.src = "data:image/png;base64," + base64;\n});'
    );
    var EVAL_EDGE_ONE_WIDGET_READY = new Function(
      'if (document.getElementById("tcaptcha_iframe_eo")) { return true; }if (document.getElementById("tcaptcha_wrapper_transform_eo")) { return true; }if (document.querySelector("iframe[src*=\\"gcaptcha.eo.gtimg.com\\"]")) { return true; }if (document.querySelector("script[src*=\\"TEOCaptchaWidgetV1\\"]")) { return true; }if (document.querySelector("script[src*=\\"TEOCaptcha\\"]")) { return true; }return false;'
    );
    var EVAL_EDGE_ONE_SCROLL_CHECKBOX = new Function(
      'var el = document.querySelector("#verifyCheckbox");if (el && el.scrollIntoView) { el.scrollIntoView({ block: "center", inline: "nearest" }); }'
    );
    var EVAL_EDGE_ONE_DISPATCH_CHECKBOX = new Function(
      'var el = document.querySelector("#verifyCheckbox");if (!el || !(el instanceof Element)) { return false; }el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window, button: 0 }));return true;'
    );
    var EVAL_EDGE_ONE_CLICK_BODY_WRAP = new Function(
      'var bw = document.querySelector("#bodyWrap");if (!bw) { return false; }var r = bw.getBoundingClientRect();var x = r.left + Math.min(32, Math.max(12, r.width * 0.1));var y = r.top + r.height / 2;var target = document.elementFromPoint(x, y);if (!target) { return false; }["mousedown", "mouseup", "click"].forEach(function (type) {  target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 }));});return true;'
    );
    var EVAL_EDGE_ONE_SUCCESS_VISIBLE = new Function(
      'var s = document.getElementById("success");if (!s) { return false; }var st = window.getComputedStyle(s);if (st.display === "none" || st.visibility === "hidden") { return false; }var r = s.getBoundingClientRect();return r.width > 2 && r.height > 2;'
    );
    var EVAL_CDNFLY_MATH_SUBMIT_CLICK = new Function(
      'var buttons = document.querySelectorAll("button, input[type=submit], [role=button], .btn");var i;for (i = 0; i < buttons.length; i++) {var b = buttons[i];var t = ((b.textContent || b.value || "") + "").trim();if (/\u63D0\u4EA4|Submit|\u786E\u5B9A|\u9A8C\u8BC1/i.test(t)) { b.click(); return true; }}return false;'
    );
    var EVAL_HK_CLOUD_VERIFIED = new Function(
      'var btn = document.getElementById("verifyBtn");return !!(btn && btn.classList.contains("verified"));'
    );
    var EVAL_HK_CLOUD_TRIGGER_VERIFY = new Function(
      'var btn = document.getElementById("verifyBtn");if (!btn || btn.classList.contains("loading") || btn.classList.contains("verified")) { return false; }var r = btn.getBoundingClientRect();var x = r.left + r.width / 2;var y = r.top + r.height / 2;btn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));return true;'
    );
    module2.exports = {
      EVAL_IN_PAGE_USER_AGENT,
      EVAL_SLIDER2_BROWSER_HINTS,
      EVAL_IN_PAGE_TURNSTILE_COORDS,
      EVAL_IN_PAGE_CF_SLIDER,
      EVAL_ON_NEW_DOC_PLATFORM,
      evalOnNewDocumentUserAgentDataSource,
      buildNavigatorFingerprintPatch,
      EVAL_CLICKABLE_STYLE,
      EVAL_CLICKABLE_RECT,
      EVAL_CDNFLY_PUZZLE_PIECE_HIDE,
      EVAL_CDNFLY_PUZZLE_PIECE_SHOW,
      EVAL_CDNFLY_PUZZLE_BG_URL,
      EVAL_CDNFLY_FETCH_URL_TO_B64,
      EVAL_EDGE_ONE_MAIN_PASS_CHECK,
      EVAL_EDGE_ONE_WIDGET_READY,
      EVAL_EDGE_ONE_SCROLL_CHECKBOX,
      EVAL_EDGE_ONE_DISPATCH_CHECKBOX,
      EVAL_EDGE_ONE_CLICK_BODY_WRAP,
      EVAL_EDGE_ONE_SUCCESS_VISIBLE,
      EVAL_CDNFLY_CURVE_SLIDER_METRICS,
      EVAL_LECDN_SLIDER_PTS,
      EVAL_ALIYUN_SLIDER_PTS,
      EVAL_MATH_CAPTCHA_SCALE_B64,
      EVAL_CDNFLY_MATH_SUBMIT_CLICK,
      EVAL_HK_CLOUD_VERIFIED,
      EVAL_HK_CLOUD_TRIGGER_VERIFY
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slider_single.js
var require_cdnfly_slider_single = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slider_single.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var fs = require("fs");
    require("colors");
    var { sleep, getL7CaptchaTmpDir } = require_http_utils();
    var {
      callSliderMatchAPISolveSingleStyle,
      generateHumanTrackForSlider,
      getPngDimensionsFromBase64
    } = require_captcha_api();
    var {
      EVAL_CDNFLY_PUZZLE_PIECE_HIDE,
      EVAL_CDNFLY_PUZZLE_PIECE_SHOW
    } = require_eval_snippets();
    var EVAL_CDNFLY_PUZZLE_PIECE_START_LEFT = new Function(
      'var el = document.querySelector(".puzzle-piece");if (!el) { return 0; }var v = parseFloat(window.getComputedStyle(el).left);return Number.isFinite(v) ? v : 0;'
    );
    async function handleCDNFlySingleSliderCaptcha(page) {
      var bgSelector = ".puzzle-image";
      try {
        await page.mouse.up();
      } catch (_) {
      }
      var mousePressed = false;
      try {
        try {
          await page.waitForSelector(bgSelector, { timeout: 8e3 });
        } catch (waitErr) {
          console.log(`${"[!] No captcha found on page".bold.yellow}`);
          return false;
        }
        await sleep(2);
        var bgEl = await page.$(bgSelector);
        var pieceEl = await page.$(".puzzle-piece");
        if (!bgEl || !pieceEl) {
          console.log(`${"[!] Could not find captcha elements".bold.yellow}`);
          return false;
        }
        var bgBox = await bgEl.boundingBox();
        var pieceBox = await pieceEl.boundingBox();
        var pieceStartLeft = 0;
        try {
          pieceStartLeft = await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_START_LEFT);
        } catch (_) {
        }
        if (!pieceStartLeft && bgBox && pieceBox) {
          pieceStartLeft = Math.max(0, pieceBox.x - bgBox.x);
        }
        var pieceScreenshot = await pieceEl.screenshot({ encoding: "base64" });
        await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_HIDE);
        var bgScreenshot = await bgEl.screenshot({ encoding: "base64" });
        await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_SHOW);
        var pairId = String(process.pid) + "_" + String(Date.now()) + "_" + Math.random().toString(36).slice(2, 10);
        try {
          var d = getL7CaptchaTmpDir();
          fs.writeFileSync(path.join(d, "temp_bg_" + pairId + ".png"), Buffer.from(bgScreenshot, "base64"));
          fs.writeFileSync(path.join(d, "temp_piece_" + pairId + ".png"), Buffer.from(pieceScreenshot, "base64"));
        } catch (saveErr) {
        }
        var apiResult;
        try {
          apiResult = await callSliderMatchAPISolveSingleStyle(pieceScreenshot, bgScreenshot);
        } catch (apiErr) {
          return false;
        }
        var gapX;
        var targetArr = apiResult.result && apiResult.result.target;
        if (targetArr && targetArr.length >= 4) {
          gapX = Number(targetArr[0]);
        } else if (targetArr && targetArr.length) {
          gapX = Number(targetArr[0]);
        } else if (apiResult.distance != null) {
          gapX = Number(apiResult.distance);
        } else if (apiResult.x != null) {
          gapX = Number(apiResult.x);
        } else {
          gapX = Number(apiResult.slide_distance);
        }
        if (gapX == null || isNaN(gapX)) {
          console.log(`${"[!] Could not parse slide distance from API response".bold.red}`);
          return false;
        }
        var bgImgSize = getPngDimensionsFromBase64(bgScreenshot);
        var pieceImgSize = getPngDimensionsFromBase64(pieceScreenshot);
        var slideTravel = gapX - pieceStartLeft;
        var maxPieceTravel = bgImgSize.width - pieceImgSize.width - pieceStartLeft;
        if (maxPieceTravel <= 0) {
          maxPieceTravel = bgImgSize.width - pieceImgSize.width;
          slideTravel = gapX;
        }
        if (slideTravel < 0) {
          slideTravel = 0;
        }
        if (slideTravel > maxPieceTravel) {
          slideTravel = maxPieceTravel;
        }
        var handle = await page.$(".slider-handle");
        var track = await page.$(".slider");
        if (!handle || !track) {
          console.log(`${"[!] Slider elements not found".bold.yellow}`);
          return false;
        }
        var handleBox = await handle.boundingBox();
        var trackBox = await track.boundingBox();
        var actualTrackWidth = trackBox.width - handleBox.width;
        var scaledDistance = maxPieceTravel > 0 ? slideTravel / maxPieceTravel * actualTrackWidth : slideTravel;
        scaledDistance = Math.max(0, Math.min(scaledDistance, actualTrackWidth));
        var startX = handleBox.x + handleBox.width / 2;
        var startY = handleBox.y + handleBox.height / 2;
        var trackPoints = generateHumanTrackForSlider(startX, startY, scaledDistance);
        await page.mouse.move(startX, startY);
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 200 + 100);
        });
        await page.mouse.down();
        mousePressed = true;
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 80 + 30);
        });
        var pi;
        for (pi = 0; pi < trackPoints.length; pi++) {
          var pt = trackPoints[pi];
          await page.mouse.move(pt.x, pt.y);
          await new Promise(function(r) {
            setTimeout(r, pt.dt);
          });
        }
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 100 + 50);
        });
        await page.mouse.up();
        mousePressed = false;
        console.log(`${"[+] Slider drag completed".bold.green}`);
        var navigated = false;
        try {
          await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 8e3 });
          navigated = true;
        } catch (eNav) {
        }
        if (!navigated) {
          await sleep(2.5);
        }
        try {
          await page.screenshot({ path: path.join(getL7CaptchaTmpDir(), "slider_result_" + pairId + ".png") });
        } catch (shotErr) {
        }
        return true;
      } catch (err) {
        console.log(`${"[!] CDNFly single slider:".bold.red}`, err && err.message ? err.message : err);
        return false;
      } finally {
        if (mousePressed) {
          try {
            await page.mouse.up();
          } catch (_) {
          }
        }
      }
    }
    module2.exports = { handleCDNFlySingleSliderCaptcha };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/waf_cookie_jar.js
var require_waf_cookie_jar = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/waf_cookie_jar.js"(exports2, module2) {
    "use strict";
    async function collectPageCookieJarForWafFollowup(page, opts) {
      var exclude = /* @__PURE__ */ new Set(["guardret"]);
      if (opts && opts.excludeNames != null) {
        var raw = opts.excludeNames;
        if (raw instanceof Set) {
          raw.forEach(function(n) {
            if (n) {
              exclude.add(String(n));
            }
          });
        } else if (Array.isArray(raw)) {
          var ri;
          for (ri = 0; ri < raw.length; ri++) {
            if (raw[ri]) {
              exclude.add(String(raw[ri]));
            }
          }
        }
      }
      var out = {};
      try {
        var pageCookies = await page.cookies();
        var sci;
        for (sci = 0; sci < pageCookies.length; sci++) {
          var sc = pageCookies[sci];
          if (!sc || !sc.name) {
            continue;
          }
          if (exclude.has(sc.name)) {
            continue;
          }
          out[sc.name] = sc.value;
        }
      } catch (_) {
      }
      return out;
    }
    module2.exports = { collectPageCookieJarForWafFollowup };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slider_curve.js
var require_cdnfly_slider_curve = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slider_curve.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var fs = require("fs");
    var { getL7CaptchaTmpDir } = require_http_utils();
    var { collectPageCookieJarForWafFollowup } = require_waf_cookie_jar();
    var {
      callSlider2LocalBypass,
      callCurveSliderAPISolveStyle,
      generateHumanTrackForSlider,
      rc4EncryptForSlider,
      binaryStringToBase64
    } = require_captcha_api();
    var {
      EVAL_SLIDER2_BROWSER_HINTS,
      EVAL_CDNFLY_PUZZLE_BG_URL,
      EVAL_CDNFLY_PUZZLE_PIECE_HIDE,
      EVAL_CDNFLY_PUZZLE_PIECE_SHOW,
      EVAL_CDNFLY_FETCH_URL_TO_B64,
      EVAL_CDNFLY_CURVE_SLIDER_METRICS
    } = require_eval_snippets();
    async function trySlider2LocalBypassOnPage(page, browserProxy) {
      var hintsForSlider2 = await page.evaluate(EVAL_SLIDER2_BROWSER_HINTS);
      var sessionCookies = await collectPageCookieJarForWafFollowup(page);
      var localBypass = await callSlider2LocalBypass(await page.url(), hintsForSlider2, browserProxy, sessionCookies);
      if (localBypass == null) {
        return false;
      }
      if (!localBypass.ok || !localBypass.cookies || typeof localBypass.cookies !== "object") {
        return false;
      }
      try {
        var bypassPageUrl = await page.url();
        var bu = new URL(bypassPageUrl);
        var bhost = bu.hostname;
        var cnames = Object.keys(localBypass.cookies);
        var bx;
        for (bx = 0; bx < cnames.length; bx++) {
          await page.setCookie({ name: cnames[bx], value: String(localBypass.cookies[cnames[bx]]), domain: bhost, path: "/" });
        }
        await page.reload({ waitUntil: "domcontentloaded" });
        await new Promise(function(r) {
          setTimeout(r, 2500);
        });
        var htmlAfterLocal = await page.content();
        if (htmlAfterLocal.indexOf("_guard/html.js") === -1) {
          console.log(`${"[+] CDNFly cleared via slider2 HTTP API (no drag)".bold.green}`);
          var jarCheck = [];
          try {
            jarCheck = await page.cookies();
          } catch (_) {
          }
          if (!jarCheck || jarCheck.length === 0) {
            console.log(
              `${"[!] Cookie jar empty after slider2 reload".bold.yellow}${" \u2014 flood may still see WAF (check Set-Cookie domain / HttpOnly)".yellow}`
            );
          }
          return true;
        }
      } catch (localEx) {
        console.log(`${"[!] Local slider2 bypass error:".bold.red}`, localEx && localEx.message ? localEx.message : localEx);
      }
      return false;
    }
    async function handleCDNFlyCurveSliderCaptcha(page, browserProxy) {
      var bgSelector = ".puzzle-image";
      try {
        var slider2MaxTries = 3;
        var slider2i;
        for (slider2i = 1; slider2i <= slider2MaxTries; slider2i++) {
          if (slider2i > 1) {
            console.log(
              `${"[*] SLIDER2_LOCAL_API retry ".bold.cyan}${slider2i - 1}${"/".cyan}${slider2MaxTries - 1}${" (refreshing guardword)".bold.cyan}`
            );
            await new Promise(function(r) {
              setTimeout(r, 2e3);
            });
          }
          if (await trySlider2LocalBypassOnPage(page, browserProxy)) {
            return true;
          }
        }
        var hasSliderHandle = false;
        var hasPuzzleImg = false;
        try {
          hasSliderHandle = !!await page.$(".slider-handle");
        } catch (_) {
        }
        try {
          hasPuzzleImg = !!await page.$(".puzzle-image");
        } catch (_) {
        }
        if (hasSliderHandle && !hasPuzzleImg) {
          console.log(`${"[*] Simple drag slider (no puzzle-image), computing guardret from guardword...".bold.cyan}`);
          try {
            var simpleCookies = await page.cookies();
            var simpleGuardword = null;
            var sgi;
            for (sgi = 0; sgi < simpleCookies.length; sgi++) {
              if (simpleCookies[sgi].name === "guardword") {
                simpleGuardword = simpleCookies[sgi];
                break;
              }
            }
            var simplePercentage = 1;
            if (simpleGuardword) {
              var simpleParts = simpleGuardword.value.split("_");
              if (simpleParts.length >= 6) {
                simplePercentage = 1;
              }
              try {
                var simpleCipher = binaryStringToBase64(rc4EncryptForSlider(simplePercentage.toFixed(2), simpleGuardword.value.substring(0, 8)));
                await page.setCookie({ name: "guardret", value: simpleCipher, domain: new URL(page.url()).hostname, path: "/" });
              } catch (encSimpleErr) {
              }
            }
            var simpleHandle = await page.$(".slider-handle");
            var simpleTrack = await page.$(".slider");
            if (simpleHandle && simpleTrack) {
              var simpleHandleBox = await simpleHandle.boundingBox();
              var simpleTrackBox = await simpleTrack.boundingBox();
              var simpleDist = (simpleTrackBox.width - simpleHandleBox.width) * simplePercentage;
              var simpleStartX = simpleHandleBox.x + simpleHandleBox.width / 2;
              var simpleStartY = simpleHandleBox.y + simpleHandleBox.height / 2;
              var simpleTrack2 = generateHumanTrackForSlider(simpleStartX, simpleStartY, simpleDist);
              await page.mouse.move(simpleStartX, simpleStartY);
              await new Promise(function(r) {
                setTimeout(r, Math.random() * 200 + 100);
              });
              await page.mouse.down();
              await new Promise(function(r) {
                setTimeout(r, Math.random() * 80 + 30);
              });
              var sti;
              for (sti = 0; sti < simpleTrack2.length; sti++) {
                var spt = simpleTrack2[sti];
                await page.mouse.move(spt.x, spt.y);
                await new Promise(function(r) {
                  setTimeout(r, spt.dt);
                });
              }
              await new Promise(function(r) {
                setTimeout(r, Math.random() * 100 + 50);
              });
              await page.mouse.up();
              console.log(`${"[+] Simple drag slider completed".bold.green}`);
              await new Promise(function(r) {
                setTimeout(r, 2e3);
              });
              return true;
            }
          } catch (simpleErr) {
            console.log(`${"[!] Simple drag slider fallback error:".bold.red}`, simpleErr && simpleErr.message ? simpleErr.message : simpleErr);
          }
          return false;
        }
        console.log(`${"[*] All SLIDER2_LOCAL_API attempts failed, falling back to image-based CURVE_SLIDER_API...".bold.cyan}`);
        try {
          await page.waitForSelector(bgSelector, { timeout: 5e3 });
        } catch (eWait) {
          return false;
        }
        await new Promise(function(r) {
          setTimeout(r, 1500);
        });
        console.log(`${"[!] Found CDNFly Slider Challenge(New) \u3010CDNFly-\u65B0\u7248-\u6ED1\u5757\u9A8C\u8BC1(\u56F0\u96BE)\u3011".bold.magenta}`);
        var bgImage = await page.evaluate(EVAL_CDNFLY_PUZZLE_BG_URL, bgSelector);
        if (!bgImage) {
          console.log(`${"[!] No background image found on .puzzle-image".bold.yellow}`);
          return false;
        }
        var imageBuffer;
        try {
          if (bgImage.indexOf("data:") === 0) {
            imageBuffer = Buffer.from(bgImage.split(",")[1], "base64");
          } else {
            await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_HIDE);
            var imageBase64;
            try {
              imageBase64 = await page.evaluate(EVAL_CDNFLY_FETCH_URL_TO_B64, bgImage);
            } finally {
              await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_SHOW);
            }
            if (!imageBase64) {
              console.log(`${"[!] Failed to fetch captcha background image".bold.red}`);
              return false;
            }
            imageBuffer = Buffer.from(imageBase64, "base64");
          }
        } catch (imgErr) {
          try {
            await page.evaluate(EVAL_CDNFLY_PUZZLE_PIECE_SHOW);
          } catch (eShow) {
          }
          console.log(`${"[!] Failed to download curve captcha image:".bold.red}`, imgErr && imgErr.message ? imgErr.message : imgErr);
          return false;
        }
        var pairId = String(process.pid) + "_" + String(Date.now()) + "_" + Math.random().toString(36).slice(2, 10);
        try {
          fs.writeFileSync(path.join(getL7CaptchaTmpDir(), "curve_captcha_" + pairId + ".png"), imageBuffer);
        } catch (eSave) {
        }
        var cookies = await page.cookies();
        var guardCookie = null;
        var cj;
        for (cj = 0; cj < cookies.length; cj++) {
          if (cookies[cj].name === "guardword") {
            guardCookie = cookies[cj];
            break;
          }
        }
        var guardData;
        var guardParsed = false;
        if (guardCookie) {
          var parts = guardCookie.value.split("_");
          if (parts.length >= 6) {
            var nums = [];
            var pk;
            for (pk = 0; pk < 6; pk++) {
              var nv = Number(parts[pk]);
              if (!Number.isFinite(nv)) {
                nums = null;
                break;
              }
              nums.push(nv);
            }
            if (nums) {
              guardData = { cx: nums[0], cy: nums[1], radius: nums[2], initX: nums[3], initY: nums[4], f: nums[5] };
              guardParsed = true;
            }
          }
        }
        if (!guardParsed) {
          console.log(`${"[!] No valid guardword params; using curve defaults".bold.yellow}`);
          guardData = { cx: 100, cy: 200, radius: 50, initX: 30, initY: 40, f: 120 };
        }
        var isUpward = guardData.initY > guardData.cy;
        var rotation;
        try {
          console.log(`${"[*] Calling curve slider API...".bold.cyan}`);
          rotation = await callCurveSliderAPISolveStyle(imageBuffer, [guardData.cx, guardData.cy, guardData.radius, guardData.initX, guardData.initY, guardData.f]);
          console.log(`${("[i] API returned rotation: " + rotation).bold.green}`);
        } catch (apiErr) {
          console.log(`${"[!] Curve API error:".bold.red}`, apiErr && apiErr.message ? apiErr.message : apiErr);
          return false;
        }
        var adjustedRotation = rotation;
        if (isUpward && rotation > 0) {
          adjustedRotation = -rotation;
          console.log(`${("[!] Adjusted rotation sign (UPWARD): " + adjustedRotation).bold.yellow}`);
        } else if (!isUpward && rotation < 0) {
          adjustedRotation = Math.abs(rotation);
          console.log(`${("[!] Adjusted rotation sign (DOWNWARD): " + adjustedRotation).bold.yellow}`);
        }
        if (!guardData.f || guardData.f === 0) {
          guardData.f = 120;
        }
        var percentageRaw = Math.abs(adjustedRotation) / guardData.f;
        if (percentageRaw > 1) {
          percentageRaw = 1;
        }
        if (percentageRaw < 0) {
          percentageRaw = 0;
        }
        var percentage = Math.round(percentageRaw * 100) / 100;
        if (guardCookie && guardCookie.value) {
          try {
            var curveCipher = binaryStringToBase64(rc4EncryptForSlider(percentage.toFixed(2), guardCookie.value.substring(0, 8)));
            await page.setCookie({ name: "guardret", value: curveCipher, domain: new URL(page.url()).hostname, path: "/" });
          } catch (encErr) {
          }
        }
        var handle = await page.$(".slider-handle");
        var track = await page.$(".slider");
        if (!handle || !track) {
          console.log(`${"[!] Slider elements not found".bold.yellow}`);
          return false;
        }
        var metrics = await page.evaluate(EVAL_CDNFLY_CURVE_SLIDER_METRICS);
        if (!metrics) {
          console.log(`${"[!] Slider metrics not found".bold.yellow}`);
          return false;
        }
        var sliderMaxLeft = metrics.sliderMaxLeft || 0;
        var distance = sliderMaxLeft * percentage;
        var startX = metrics.handleCenter.x;
        var startY = metrics.handleCenter.y;
        var curveTrack = generateHumanTrackForSlider(startX, startY, distance);
        await page.mouse.move(startX, startY);
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 200 + 100);
        });
        await page.mouse.down();
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 80 + 30);
        });
        var ti;
        for (ti = 0; ti < curveTrack.length; ti++) {
          var cpt = curveTrack[ti];
          await page.mouse.move(cpt.x, cpt.y);
          await new Promise(function(r) {
            setTimeout(r, cpt.dt);
          });
        }
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 100 + 50);
        });
        await page.mouse.up();
        await new Promise(function(r) {
          setTimeout(r, 3e3);
        });
        try {
          await page.screenshot({ path: path.join(getL7CaptchaTmpDir(), "curve_result_" + pairId + ".png") });
        } catch (eShot) {
        }
        return true;
      } catch (err) {
        console.log(`${"[!] CDNFly curve slider:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleCDNFlyCurveSliderCaptcha, trySlider2LocalBypassOnPage };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_rotate.js
var require_cdnfly_rotate = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_rotate.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var fs = require("fs");
    require("colors");
    var { sleep, getL7CaptchaTmpDir } = require_http_utils();
    var { callRotateImageAPISolveStyle } = require_captcha_api();
    var { EVAL_CDNFLY_PUZZLE_BG_URL, EVAL_CDNFLY_FETCH_URL_TO_B64 } = require_eval_snippets();
    var EVAL_READ_PUZZLE_IMAGE_ROTATION = new Function(
      'var el = document.querySelector(".puzzle-image");if (!el) { return null; }var s = el.getAttribute("style") || "";var m = s.match(/rotate\\(\\s*(-?[0-9.]+)\\s*deg\\s*\\)/);if (m) { return parseFloat(m[1]); }var cs = window.getComputedStyle(el);var t = cs && cs.transform;if (t && t !== "none") {  var mat = t.match(/matrix\\(([^)]+)\\)/);  if (mat) {    var n = mat[1].split(",").map(function (x) { return parseFloat(x); });    if (n.length >= 4 && isFinite(n[0]) && isFinite(n[1])) {      return Math.atan2(n[1], n[0]) * 180 / Math.PI;    }  }}return null;'
    );
    async function handleCDNFlyRotateImageCaptcha(page) {
      var bgSelector = ".puzzle-image";
      try {
        await page.mouse.up();
      } catch (_) {
      }
      var mousePressed = false;
      try {
        try {
          await page.waitForSelector(bgSelector, { timeout: 5e3 });
        } catch (eWait) {
          return false;
        }
        await sleep(1.5);
        var bgImage = await page.evaluate(EVAL_CDNFLY_PUZZLE_BG_URL, bgSelector);
        if (!bgImage) {
          console.log(`${"[!] No background image found on .puzzle-image".bold.yellow}`);
          return false;
        }
        var imageBuffer;
        try {
          if (bgImage.indexOf("data:") === 0) {
            imageBuffer = Buffer.from(bgImage.split(",")[1], "base64");
          } else {
            var b64Remote = await page.evaluate(EVAL_CDNFLY_FETCH_URL_TO_B64, bgImage);
            if (!b64Remote) {
              console.log(`${"[!] Failed to fetch rotate captcha image".bold.red}`);
              return false;
            }
            imageBuffer = Buffer.from(b64Remote, "base64");
          }
        } catch (imgErr) {
          console.log(`${"[!] Failed to download rotate image:".bold.red}`, imgErr && imgErr.message ? imgErr.message : imgErr);
          return false;
        }
        var pairId = String(process.pid) + "_" + String(Date.now()) + "_" + Math.random().toString(36).slice(2, 10);
        try {
          fs.writeFileSync(path.join(getL7CaptchaTmpDir(), "rotate_captcha_" + pairId + ".png"), imageBuffer);
        } catch (eSave) {
        }
        var box;
        try {
          box = await callRotateImageAPISolveStyle(imageBuffer);
        } catch (apiErr) {
          return false;
        }
        if (!box || !box.length) {
          return false;
        }
        var rawApiAngle = Number(box[0]);
        if (!Number.isFinite(rawApiAngle)) {
          console.log(`${"[!] API returned non-finite angle".bold.yellow}`);
          return false;
        }
        var apiAngle = (rawApiAngle % 360 + 360) % 360;
        if (apiAngle < 0.5) {
          apiAngle = 0.5;
        }
        var handle = await page.$(".slider-handle");
        var track = await page.$(".slider");
        if (!handle || !track) {
          console.log(`${"[!] Slider elements not found".bold.yellow}`);
          return false;
        }
        var handleBox = await handle.boundingBox();
        var trackBox = await track.boundingBox();
        if (!handleBox || !trackBox) {
          console.log(`${"[!] Slider box missing".bold.yellow}`);
          return false;
        }
        var maxTravel = trackBox.width - handleBox.width;
        if (maxTravel <= 0) {
          console.log(`${"[!] Slider maxTravel <= 0".bold.yellow}`);
          return false;
        }
        var startX = handleBox.x + handleBox.width / 2;
        var startY = handleBox.y + handleBox.height / 2;
        await page.mouse.move(startX, startY);
        await sleep(0.1 + Math.random() * 0.15);
        await page.mouse.down();
        mousePressed = true;
        await sleep(0.04 + Math.random() * 0.06);
        var probeDistance = 30;
        var probeSteps = 8;
        var pi;
        for (pi = 1; pi <= probeSteps; pi++) {
          var px = startX + pi / probeSteps * probeDistance;
          var py = startY + (Math.random() - 0.5) * 2;
          await page.mouse.move(px, py);
          await sleep(0.012 + Math.random() * 0.015);
        }
        await sleep(0.25);
        var probeRotation = await page.evaluate(EVAL_READ_PUZZLE_IMAGE_ROTATION);
        var degreesPerPixel = null;
        if (probeRotation != null && Number.isFinite(probeRotation) && Math.abs(probeRotation) > 0.05) {
          degreesPerPixel = probeRotation / probeDistance;
        }
        var targetDistance;
        if (degreesPerPixel != null) {
          targetDistance = apiAngle / Math.abs(degreesPerPixel);
          console.log(
            `${("[*] Rotate self-calibration: probed " + probeDistance + "px \u2192 image rotated " + probeRotation.toFixed(2) + "\xB0  \u2192  degPerPx=" + degreesPerPixel.toFixed(3) + "  \u2192  derived f=" + (degreesPerPixel * maxTravel).toFixed(1) + "\xB0  \u2192  target drag=" + targetDistance.toFixed(1) + "px (apiAngle=" + apiAngle.toFixed(1) + "\xB0)").bold.cyan}`
          );
        } else {
          targetDistance = apiAngle / 360 * maxTravel;
          console.log(`${("[!] Rotate self-calibration: probe rotation missing (got " + probeRotation + "), falling back to f=360 \u2192 drag " + targetDistance.toFixed(1) + "px").bold.yellow}`);
        }
        if (targetDistance > maxTravel - 1) {
          targetDistance = maxTravel - 1;
        }
        if (targetDistance < probeDistance + 1) {
          targetDistance = probeDistance + 1;
        }
        var fromX = startX + probeDistance;
        var toX = startX + targetDistance;
        var deltaX = toX - fromX;
        var moveSteps = 25;
        var mi;
        for (mi = 1; mi <= moveSteps; mi++) {
          var t = mi / moveSteps;
          var ease = 1 - Math.pow(1 - t, 3);
          var x = fromX + deltaX * ease;
          var y = startY + (Math.random() - 0.5) * 3;
          await page.mouse.move(x, y);
          await sleep(8e-3 + Math.random() * 0.014);
        }
        await sleep(0.1 + Math.random() * 0.1);
        await page.mouse.up();
        mousePressed = false;
        var navigated = false;
        try {
          await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 6e3 });
          navigated = true;
        } catch (eNav) {
        }
        if (!navigated) {
          await sleep(2.5);
        }
        try {
          await page.screenshot({ path: path.join(getL7CaptchaTmpDir(), "rotate_result_" + pairId + ".png") });
        } catch (eShot) {
        }
        return true;
      } catch (err) {
        console.log(`${"[!] CDNFly rotate captcha:".bold.red}`, err && err.message ? err.message : err);
        return false;
      } finally {
        if (mousePressed) {
          try {
            await page.mouse.up();
          } catch (_) {
          }
        }
      }
    }
    module2.exports = { handleCDNFlyRotateImageCaptcha };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_math.js
var require_cdnfly_math = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_math.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var fs = require("fs");
    var { getL7CaptchaTmpDir } = require_http_utils();
    var { callMathMatchAPISolveStyle, parseMathCaptchaAnswer, rc4EncryptForSlider, binaryStringToBase64 } = require_captcha_api();
    var { EVAL_MATH_CAPTCHA_SCALE_B64, EVAL_CDNFLY_MATH_SUBMIT_CLICK } = require_eval_snippets();
    async function handleCDNFlyMathCaptcha(page) {
      var captchaImgSelector = 'img[src*="_guard/captcha"], img[src*="captcha.png"]';
      try {
        try {
          await page.waitForSelector(captchaImgSelector, { timeout: 8e3 });
        } catch (eWait) {
          console.log(`${"[!] No calculate captcha found on page".bold.yellow}`);
          return false;
        }
        await new Promise(function(r) {
          setTimeout(r, 1500);
        });
        var imgEl = await page.$(captchaImgSelector);
        if (!imgEl) {
          console.log(`${"[!] Could not find captcha image".bold.yellow}`);
          return false;
        }
        var captchaBase64 = await imgEl.screenshot({ encoding: "base64" });
        var pairId = String(process.pid) + "_" + String(Date.now()) + "_" + Math.random().toString(36).slice(2, 10);
        try {
          fs.writeFileSync(path.join(getL7CaptchaTmpDir(), "math_captcha_" + pairId + ".png"), Buffer.from(captchaBase64, "base64"));
        } catch (eSave) {
        }
        try {
          captchaBase64 = await page.evaluate(EVAL_MATH_CAPTCHA_SCALE_B64, captchaBase64, 2);
        } catch (eScale) {
          console.log(`${"[!] Scale failed, using original:".bold.yellow}`, eScale && eScale.message ? eScale.message : eScale);
        }
        var apiResult;
        try {
          apiResult = await callMathMatchAPISolveStyle(captchaBase64);
        } catch (eApi) {
          console.log(`${"[!] Math API error:".bold.red}`, eApi && eApi.message ? eApi.message : eApi);
          return false;
        }
        var rawResult = apiResult.result != null ? apiResult.result : apiResult.expression != null ? apiResult.expression : apiResult.answer;
        var answer = parseMathCaptchaAnswer(rawResult);
        if (answer == null) {
          console.log(`${"[!] Could not parse math result:".bold.red}`, rawResult);
          return false;
        }
        var cookies = await page.cookies();
        var guardCookie = null;
        var ci;
        for (ci = 0; ci < cookies.length; ci++) {
          if (cookies[ci].name === "guardword") {
            guardCookie = cookies[ci];
            break;
          }
        }
        if (guardCookie) {
          try {
            var mcipher = binaryStringToBase64(rc4EncryptForSlider(String(answer), guardCookie.value.substring(0, 8)));
            await page.setCookie({ name: "guardret", value: mcipher, domain: new URL(page.url()).hostname, path: "/" });
          } catch (eEnc) {
          }
        }
        var inputSelector = 'input[type="text"]:not([type="hidden"]), input[name="value"], input#value, input[placeholder*="\u8BA1\u7B97"], input[placeholder*="result"]';
        var input = await page.$(inputSelector);
        if (!input) {
          var firstInput = await page.$('form input[type="text"], input[type="number"]');
          if (!firstInput) {
            console.log(`${"[!] No answer input found".bold.red}`);
            return false;
          }
          await firstInput.click({ delay: 50 });
          await firstInput.type(String(answer), { delay: 80 });
        } else {
          await input.click({ delay: 50 });
          await input.type(String(answer), { delay: 80 });
        }
        var submitBtn = await page.$('button[type="submit"]') || await page.$('input[type="submit"]') || await page.$(".btn-primary");
        if (!submitBtn) {
          var clicked = await page.evaluate(EVAL_CDNFLY_MATH_SUBMIT_CLICK);
          if (!clicked) {
            console.log(`${"[!] Submit button not found".bold.red}`);
            return false;
          }
        } else {
          await submitBtn.click();
        }
        await new Promise(function(r) {
          setTimeout(r, 2e3);
        });
        try {
          await page.screenshot({ path: path.join(getL7CaptchaTmpDir(), "math_result_" + pairId + ".png") });
        } catch (eShot) {
        }
        return true;
      } catch (err) {
        return false;
      }
    }
    module2.exports = { handleCDNFlyMathCaptcha };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_text.js
var require_cdnfly_text = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_text.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { callAnticapClickAPI } = require_captcha_api();
    var { EVAL_CLICKABLE_STYLE, EVAL_CLICKABLE_RECT, EVAL_CDNFLY_FETCH_URL_TO_B64 } = require_eval_snippets();
    async function handleCDNFlyTextClickCaptcha(page) {
      try {
        var clickableSelector = ".clickableImg";
        var clickableEl = await page.$(clickableSelector);
        if (!clickableEl) {
          console.log(`${"[!] CDNFly: no .clickableImg".bold.yellow}`);
          return false;
        }
        var style = await clickableEl.evaluate(EVAL_CLICKABLE_STYLE);
        var urlMatch = style.match(/url\(["']?(.*?)["']?\)/);
        if (!urlMatch) {
          console.log(`${"[!] CDNFly: no background image in style".bold.yellow}`);
          return false;
        }
        var imgUrl = urlMatch[1];
        if (imgUrl.indexOf("/") === 0) {
          var currentUrl = page.url();
          var parsed = new URL(currentUrl);
          imgUrl = parsed.protocol + "//" + parsed.host + imgUrl;
        }
        var b64 = await page.evaluate(EVAL_CDNFLY_FETCH_URL_TO_B64, imgUrl);
        if (!b64) {
          console.log(`${"[!] CDNFly: failed to download captcha image".bold.red}`);
          return false;
        }
        var apiResult;
        try {
          apiResult = await callAnticapClickAPI(b64);
        } catch (e) {
          return false;
        }
        if (!apiResult.success) {
          return false;
        }
        var clicks = apiResult.clicks;
        if (!clicks || clicks.length === 0) {
          console.log(`${"[!] No click coordinates".bold.red}`);
          return false;
        }
        var rect = await clickableEl.evaluate(EVAL_CLICKABLE_RECT);
        var j;
        for (j = 0; j < clicks.length; j++) {
          var pt = clicks[j];
          await page.mouse.click(rect.x + pt.x, rect.y + pt.y);
          await sleep(0.3);
        }
        console.log(`${"[+] CDNFly text clicks done".bold.green}`);
        var k;
        for (k = 0; k < 5; k++) {
          await sleep(2);
          var html = await page.content();
          if (html.indexOf("/_guard/html.js") === -1 && html.indexOf(".clickableImg") === -1) {
            return true;
          }
        }
        return (await page.content()).indexOf("/_guard/html.js") === -1;
      } catch (err) {
        console.log(`${"[!] CDNFly text captcha:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    async function handleCDNFlyClick(page) {
      try {
        console.log(`${"[*] CDNFly Click...".bold.cyan}`);
        var clickableEl = await page.$(".clickableImg");
        if (clickableEl) {
          console.log(`${"[*] .clickableImg found, text captcha flow".bold.cyan}`);
          return await handleCDNFlyTextClickCaptcha(page);
        }
        var accessBtn = await page.$("#access");
        if (!accessBtn) {
          console.log(`${"[!] CDNFly: no #access".bold.yellow}`);
          return false;
        }
        await accessBtn.click();
        var i;
        for (i = 0; i < 5; i++) {
          await sleep(2);
          var content = await page.content();
          if (content.indexOf("/_guard/html.js") === -1) {
            return true;
          }
          var newClickable = await page.$(".clickableImg");
          if (newClickable) {
            console.log(`${"[*] .clickableImg appeared after #access".bold.cyan}`);
            return await handleCDNFlyTextClickCaptcha(page);
          }
        }
        return (await page.content()).indexOf("/_guard/html.js") === -1;
      } catch (err) {
        console.log(`${"[!] handleCDNFlyClick:".bold.yellow}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleCDNFlyTextClickCaptcha, handleCDNFlyClick };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_delay.js
var require_cdnfly_delay = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_delay.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    function isPageContextDestroyedError(err) {
      if (err == null) {
        return false;
      }
      var msg = err.message || String(err);
      return /context was destroyed|Execution context|Session closed|Target closed/i.test(msg);
    }
    async function handleCDNFlyDelayShield(page) {
      console.log(`${"[*] CDNFly delay-jump shield: waiting for redirect...".bold.cyan}`);
      var i;
      for (i = 0; i < 5; i++) {
        await sleep(3);
        var delayContent;
        try {
          delayContent = await page.content();
        } catch (e) {
          if (isPageContextDestroyedError(e)) {
            return true;
          }
          throw e;
        }
        if (delayContent.indexOf("/_guard/html.js") === -1) {
          await sleep(1);
          return true;
        }
        if (delayContent.indexOf("Access denied") !== -1 || delayContent.indexOf("403") !== -1 || delayContent.indexOf("Forbidden") !== -1) {
          return false;
        }
      }
      try {
        var finalDelayContent = await page.content();
        if (finalDelayContent.indexOf("/_guard/html.js?js=delay_jump_html") !== -1) {
          return false;
        }
        return true;
      } catch (e2) {
        if (isPageContextDestroyedError(e2)) {
          return true;
        }
        throw e2;
      }
    }
    module2.exports = { handleCDNFlyDelayShield, isPageContextDestroyedError };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slide_simple.js
var require_cdnfly_slide_simple = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cdnfly_slide_simple.js"(exports2, module2) {
    "use strict";
    require("colors");
    var { sleep } = require_http_utils();
    var { generateHumanTrackForSlider } = require_captcha_api();
    async function handleCDNFlySimpleSlide(page) {
      try {
        var btn = await page.$("#slider #btn, #btn");
        var track = await page.$("#slider #track, #track");
        var slider = await page.$("#slider");
        if (!btn || !track) {
          console.log(`${"[!] Simple slide: #btn / #track not found".bold.yellow}`);
          return false;
        }
        var btnBox = await btn.boundingBox();
        var trackBox = await track.boundingBox();
        var sliderBox = slider ? await slider.boundingBox() : trackBox;
        if (!btnBox || !trackBox) {
          console.log(`${"[!] Simple slide: bounding boxes missing".bold.yellow}`);
          return false;
        }
        var OVERSHOOT_PX = 30;
        var containerRight = sliderBox && sliderBox.width ? sliderBox.x + sliderBox.width : trackBox.x + trackBox.width;
        var startX = btnBox.x + btnBox.width / 2;
        var startY = btnBox.y + btnBox.height / 2;
        var targetX = containerRight - btnBox.width / 2 + OVERSHOOT_PX;
        var distance = targetX - startX;
        if (distance <= 0) {
          console.log(`${"[!] Simple slide: invalid drag distance".bold.yellow}`);
          return false;
        }
        var trackPoints = generateHumanTrackForSlider(startX, startY, distance);
        await page.mouse.move(startX, startY);
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 200 + 100);
        });
        await page.mouse.down();
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 80 + 30);
        });
        var i;
        for (i = 0; i < trackPoints.length; i++) {
          var pt = trackPoints[i];
          await page.mouse.move(pt.x, pt.y);
          await new Promise(function(r) {
            setTimeout(r, pt.dt);
          });
        }
        await new Promise(function(r) {
          setTimeout(r, Math.random() * 100 + 50);
        });
        await page.mouse.up();
        console.log(`${"[+] Simple slide drag completed, waiting for verify+redirect...".bold.green}`);
        var navigated = false;
        try {
          await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 8e3 });
          navigated = true;
        } catch (eNav) {
        }
        if (!navigated) {
          var rounds;
          for (rounds = 0; rounds < 8; rounds++) {
            await sleep(0.5);
            var pollContent = "";
            try {
              pollContent = await page.content();
            } catch (_) {
            }
            if (pollContent && pollContent.indexOf("/_guard/slide.js") === -1 && pollContent.indexOf("/_guard/html.js") === -1) {
              break;
            }
          }
        }
        await sleep(1);
        return true;
      } catch (err) {
        console.log(`${"[!] CDNFly simple slide:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleCDNFlySimpleSlide };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cloudflare.js
var require_cloudflare = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/cloudflare.js"(exports2, module2) {
    "use strict";
    var { EVAL_IN_PAGE_TURNSTILE_COORDS, EVAL_IN_PAGE_CF_SLIDER } = require_eval_snippets();
    function checkTurnstile(args) {
      const page = args.page;
      return new Promise(function(resolve) {
        var settled = false;
        var timeoutId = setTimeout(function() {
          if (settled) {
            return;
          }
          settled = true;
          resolve(false);
        }, 5e3);
        function finish(value) {
          if (settled) {
            return;
          }
          settled = true;
          clearTimeout(timeoutId);
          resolve(value);
        }
        (async function() {
          try {
            const elements = await page.$$('[name="cf-turnstile-response"]');
            if (elements.length <= 0) {
              const coordinates = await page.evaluate(EVAL_IN_PAGE_TURNSTILE_COORDS);
              for (const item of coordinates) {
                try {
                  await page.mouse.click(item.x + 30, item.y + item.h / 2);
                } catch (err) {
                }
              }
              finish(true);
              return;
            }
            for (const element of elements) {
              try {
                const parentElement = await element.evaluateHandle(new Function("el", "return el.parentElement"));
                const box = await parentElement.boundingBox();
                await page.mouse.click(box.x + 30, box.y + box.height / 2);
              } catch (err) {
              }
            }
            finish(true);
          } catch (err) {
            finish(false);
          }
        })();
      });
    }
    async function handleCloudflare(page) {
      try {
        await page.evaluate(EVAL_IN_PAGE_CF_SLIDER);
      } catch (e) {
      }
      var i;
      for (i = 0; i < 10; i++) {
        var done = await checkTurnstile({ page });
        if (done) {
          break;
        }
        await new Promise(function(r) {
          setTimeout(r, 1e3);
        });
      }
      await new Promise(function(r) {
        setTimeout(r, 3e3);
      });
      return true;
    }
    module2.exports = { checkTurnstile, handleCloudflare };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/goedge_delay.js
var require_goedge_delay = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/goedge_delay.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { isPageContextDestroyedError } = require_cdnfly_delay();
    async function handleGoedgeDelayShield(page) {
      console.log(`${"[*] GoEdge 5_sec_checking: waiting...".bold.yellow}`);
      var gi;
      for (gi = 0; gi < 5; gi++) {
        await sleep(3);
        var geContent;
        try {
          geContent = await page.content();
        } catch (eGe) {
          if (isPageContextDestroyedError(eGe)) {
            return true;
          }
          throw eGe;
        }
        if (geContent.indexOf("5_sec_checking") === -1) {
          await sleep(1);
          return true;
        }
        if (geContent.indexOf("Access denied") !== -1 || geContent.indexOf("403") !== -1) {
          return false;
        }
      }
      var finalGe;
      try {
        finalGe = await page.content();
      } catch (eFin) {
        if (isPageContextDestroyedError(eFin)) {
          return true;
        }
        throw eFin;
      }
      if (finalGe.indexOf("5_sec_checking") !== -1) {
        console.log(`${"[!] GoEdge delay shield timeout".bold.red}`);
        return false;
      }
      return true;
    }
    module2.exports = { handleGoedgeDelayShield };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/aliyun_slider.js
var require_aliyun_slider = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/aliyun_slider.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { EVAL_ALIYUN_SLIDER_PTS } = require_eval_snippets();
    async function handleAliyunSlide(page) {
      try {
        await page.waitForSelector("#aliyunCaptcha-sliding-slider", { timeout: 3e4 });
        await sleep(0.5);
        var pts = await page.evaluate(EVAL_ALIYUN_SLIDER_PTS);
        if (!pts) {
          console.log(`${"[!] Aliyun: slider pts null".bold.yellow}`);
          return false;
        }
        var distance = pts.x1 - pts.x0;
        var steps = Math.max(18, Math.round(distance / 8));
        await page.mouse.move(pts.x0, pts.y0);
        await page.mouse.down();
        await new Promise(function(r) {
          setTimeout(r, 120 + Math.random() * 80);
        });
        var j;
        for (j = 0; j <= steps; j++) {
          var t = j / steps;
          var ease = t < 0.7 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
          var cx = pts.x0 + distance * ease;
          var cy = pts.y0 + (Math.random() - 0.5) * 2;
          await page.mouse.move(cx, cy);
          await new Promise(function(r) {
            setTimeout(r, Math.floor(Math.random() * 14 + 6));
          });
        }
        await page.mouse.move(pts.x1, pts.y1);
        await new Promise(function(r) {
          setTimeout(r, 80 + Math.random() * 60);
        });
        await page.mouse.up();
        await sleep(2);
        var content = await page.content();
        return content.indexOf("AliyunCaptcha.js") === -1 || content.indexOf("initAliyunCaptcha") === -1;
      } catch (err) {
        console.log(`${"[!] Aliyun slider:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleAliyunSlide };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/tencent_edgeone.js
var require_tencent_edgeone = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/tencent_edgeone.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var {
      EVAL_EDGE_ONE_MAIN_PASS_CHECK,
      EVAL_EDGE_ONE_WIDGET_READY,
      EVAL_EDGE_ONE_SCROLL_CHECKBOX,
      EVAL_EDGE_ONE_DISPATCH_CHECKBOX,
      EVAL_EDGE_ONE_CLICK_BODY_WRAP,
      EVAL_EDGE_ONE_SUCCESS_VISIBLE
    } = require_eval_snippets();
    var { isPageContextDestroyedError } = require_cdnfly_delay();
    function findEdgeOneCaptchaFrame(page) {
      var frames = page.frames();
      var i;
      var fu;
      for (i = 0; i < frames.length; i++) {
        fu = frames[i].url();
        if (fu.indexOf("widget_ele_global_eo") !== -1) {
          return frames[i];
        }
      }
      for (i = 0; i < frames.length; i++) {
        fu = frames[i].url();
        if (fu.indexOf("gcaptcha.eo.gtimg.com") !== -1 && (fu.indexOf("/template/") !== -1 || fu.indexOf("widget") !== -1)) {
          return frames[i];
        }
      }
      for (i = 0; i < frames.length; i++) {
        fu = frames[i].url();
        if (fu.indexOf("gcaptcha.eo.gtimg.com") !== -1) {
          return frames[i];
        }
      }
      for (i = 0; i < frames.length; i++) {
        fu = frames[i].url();
        if (fu.indexOf("eo.gtimg.com") !== -1) {
          return frames[i];
        }
      }
      return null;
    }
    function waitForEdgeOneCaptchaFrame(page, timeoutMs) {
      return new Promise(function(resolve) {
        var done = false;
        function finish(frame) {
          if (done) {
            return;
          }
          done = true;
          page.off("frameattached", onEvent);
          page.off("framenavigated", onEvent);
          clearTimeout(timer);
          resolve(frame);
        }
        function onEvent() {
          if (done) {
            return;
          }
          var frame = findEdgeOneCaptchaFrame(page);
          if (frame) {
            finish(frame);
          }
        }
        page.on("frameattached", onEvent);
        page.on("framenavigated", onEvent);
        var immediate = findEdgeOneCaptchaFrame(page);
        if (immediate) {
          finish(immediate);
          return;
        }
        var timer = setTimeout(function() {
          finish(null);
        }, timeoutMs || 15e3);
      });
    }
    async function findEdgeOneFrameViaDOM(page) {
      var selectors = ["#tcaptcha_iframe_eo", 'iframe[src*="gcaptcha.eo.gtimg.com"]', 'iframe[src*="eo.gtimg.com"]'];
      for (var si = 0; si < selectors.length; si++) {
        try {
          var el = await page.$(selectors[si]);
          if (el) {
            var f = await el.contentFrame();
            if (f) {
              return f;
            }
          }
        } catch (e) {
        }
      }
      return null;
    }
    async function handleTencentEdgeOneClickCaptcha(page) {
      try {
        try {
          await page.waitForFunction(EVAL_EDGE_ONE_WIDGET_READY, { timeout: 42e3, polling: 550 });
        } catch (eShell) {
        }
        await sleep(0.05 + Math.random() * 0.1);
        var captchaFrame = await waitForEdgeOneCaptchaFrame(page, 15e3);
        if (!captchaFrame) {
          captchaFrame = await findEdgeOneFrameViaDOM(page);
        }
        if (!captchaFrame) {
          console.log(`${"[!] EdgeOne: captcha iframe frame not found".bold.yellow}`);
          return false;
        }
        await captchaFrame.waitForSelector("#verifyCheckbox", { timeout: 2e4 });
        await captchaFrame.evaluate(EVAL_EDGE_ONE_SCROLL_CHECKBOX);
        await sleep(0.08);
        var clickDelay = 28 + Math.floor(Math.random() * 52);
        var clicked = false;
        try {
          await captchaFrame.click("#verifyCheckbox", { delay: clickDelay, force: true });
          clicked = true;
        } catch (eClick) {
          try {
            clicked = await captchaFrame.evaluate(EVAL_EDGE_ONE_DISPATCH_CHECKBOX);
          } catch (eEval) {
            clicked = false;
          }
          if (!clicked) {
            try {
              clicked = await captchaFrame.evaluate(EVAL_EDGE_ONE_CLICK_BODY_WRAP);
            } catch (eWrap) {
              clicked = false;
            }
          }
        }
        if (!clicked) {
          console.log(`${"[!] EdgeOne: could not trigger checkbox click".bold.yellow}`);
          return false;
        }
        try {
          await page.waitForFunction(EVAL_EDGE_ONE_MAIN_PASS_CHECK, { timeout: 4e4, polling: 120 });
          return true;
        } catch (eWaitDone) {
          if (isPageContextDestroyedError(eWaitDone)) {
            return true;
          }
        }
        var fj;
        for (fj = 0; fj < 32; fj++) {
          await sleep(0.22);
          try {
            var quickPass = await page.evaluate(EVAL_EDGE_ONE_MAIN_PASS_CHECK);
            if (quickPass) {
              return true;
            }
            var frFb = findEdgeOneCaptchaFrame(page);
            if (frFb) {
              var innerOkFb = await frFb.evaluate(EVAL_EDGE_ONE_SUCCESS_VISIBLE);
              if (innerOkFb) {
                return true;
              }
            }
          } catch (eFb) {
            if (isPageContextDestroyedError(eFb)) {
              return true;
            }
          }
        }
        return false;
      } catch (err) {
        console.log(`${"[!] Tencent EdgeOne click:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleTencentEdgeOneClickCaptcha, findEdgeOneCaptchaFrame };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/lecdn_slider.js
var require_lecdn_slider = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/lecdn_slider.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { EVAL_LECDN_SLIDER_PTS } = require_eval_snippets();
    async function handleLeCDNSlider(page) {
      try {
        await page.waitForSelector(".slideBox", { timeout: 15e3 });
        await page.waitForSelector("#slider", { timeout: 25e3 });
        await page.waitForSelector("#slider .handler", { timeout: 5e3 }).catch(function() {
        });
        var pts = await page.evaluate(EVAL_LECDN_SLIDER_PTS);
        if (!pts) {
          var slider = await page.$("#slider");
          if (!slider) {
            console.log(`${"[!] LeCDN: #slider missing".bold.yellow}`);
            return false;
          }
          var box = await slider.boundingBox();
          if (!box) {
            console.log(`${"[!] LeCDN: slider boundingBox null".bold.yellow}`);
            return false;
          }
          var half = Math.min(20, box.width / 4);
          pts = { x0: box.x + half, y0: box.y + box.height / 2, x1: box.x + box.width - half, y1: box.y + box.height / 2 };
        }
        await page.mouse.move(pts.x0, pts.y0);
        await page.mouse.down();
        await page.mouse.move(pts.x1, pts.y1, { steps: 28 });
        await page.mouse.up();
        await sleep(2);
        var still = await page.$(".slideBox");
        return !still;
      } catch (err) {
        return false;
      }
    }
    module2.exports = { handleLeCDNSlider };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/guard_auto_shell.js
var require_guard_auto_shell = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/guard_auto_shell.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { isPageContextDestroyedError } = require_cdnfly_delay();
    async function handleGuardAutoBootstrap(page) {
      var deadline = Date.now() + 22e3;
      while (Date.now() < deadline) {
        var html = "";
        try {
          html = await page.content();
        } catch (e) {
          if (isPageContextDestroyedError(e)) {
            return;
          }
          throw e;
        }
        if (html.indexOf("/_guard/html.js") !== -1) {
          return;
        }
        if (html.indexOf("/_guard/") === -1) {
          return;
        }
        await Promise.race([
          page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 6e3 }).catch(function() {
          }),
          sleep(0.45)
        ]);
      }
    }
    module2.exports = { handleGuardAutoBootstrap };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/hkcloud_verify.js
var require_hkcloud_verify = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/bypass/hkcloud_verify.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { EVAL_HK_CLOUD_TRIGGER_VERIFY, EVAL_HK_CLOUD_VERIFIED } = require_eval_snippets();
    var { isPageContextDestroyedError } = require_cdnfly_delay();
    async function handleHkCloudVerify(page) {
      try {
        await page.waitForSelector("#verifyBtn", { timeout: 15e3 });
        await page.waitForFunction(
          'typeof CryptoJS !== "undefined" && !!document.getElementById("verifyBtn")',
          { timeout: 12e3 }
        ).catch(function() {
        });
        var navPromise = page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 28e3 }).catch(function() {
        });
        var clicked = false;
        try {
          await page.click("#verifyBtn", { delay: 40 + Math.floor(Math.random() * 90) });
          clicked = true;
        } catch (eClick) {
          try {
            clicked = await page.evaluate(EVAL_HK_CLOUD_TRIGGER_VERIFY);
          } catch (_) {
            clicked = false;
          }
        }
        if (!clicked) {
          console.log(`${"[!] \u9999\u6E2F\u4E91 WAF: \u65E0\u6CD5\u89E6\u53D1\u9A8C\u8BC1\u6309\u94AE".bold.yellow}`);
          return false;
        }
        try {
          await page.waitForFunction(EVAL_HK_CLOUD_VERIFIED, { timeout: 18e3, polling: 250 });
        } catch (eWait) {
          if (isPageContextDestroyedError(eWait)) {
            await navPromise;
            await sleep(1.5);
            return true;
          }
        }
        await navPromise;
        await sleep(1.5);
        var html = "";
        try {
          html = await page.content();
        } catch (eContent) {
          if (isPageContextDestroyedError(eContent)) {
            return true;
          }
          throw eContent;
        }
        return html.indexOf("verifyBtn") === -1 || html.indexOf("/_waf/_") === -1;
      } catch (err) {
        console.log(`${"[!] \u9999\u6E2F\u4E91 WAF verify:".bold.red}`, err && err.message ? err.message : err);
        return false;
      }
    }
    module2.exports = { handleHkCloudVerify };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/detect.js
var require_detect = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/detect.js"(exports2, module2) {
    "use strict";
    var { sleep } = require_http_utils();
    var { proxyLineForDisplay } = require_proxy();
    var { handleCDNFlySingleSliderCaptcha } = require_cdnfly_slider_single();
    var { handleCDNFlyCurveSliderCaptcha } = require_cdnfly_slider_curve();
    var { handleCDNFlyRotateImageCaptcha } = require_cdnfly_rotate();
    var { handleCDNFlyMathCaptcha } = require_cdnfly_math();
    var { handleCDNFlyTextClickCaptcha, handleCDNFlyClick } = require_cdnfly_text();
    var { handleCDNFlyDelayShield } = require_cdnfly_delay();
    var { handleCDNFlySimpleSlide } = require_cdnfly_slide_simple();
    var { checkTurnstile } = require_cloudflare();
    var { handleGoedgeDelayShield } = require_goedge_delay();
    var { handleAliyunSlide } = require_aliyun_slider();
    var { handleTencentEdgeOneClickCaptcha } = require_tencent_edgeone();
    var { handleLeCDNSlider } = require_lecdn_slider();
    var { handleGuardAutoBootstrap } = require_guard_auto_shell();
    var { handleHkCloudVerify } = require_hkcloud_verify();
    var { EVAL_IN_PAGE_CF_SLIDER } = require_eval_snippets();
    var L7_FP_PROBE_SRC = '(function(){var glR=null;try{var c=document.createElement("canvas");var g=c.getContext("webgl")||c.getContext("experimental-webgl");if(g){var e=g.getExtension("WEBGL_debug_renderer_info");glR=e?g.getParameter(e.UNMASKED_RENDERER_WEBGL):null;}}catch(_){}var uad=null;try{uad=navigator.userAgentData?navigator.userAgentData.platform:null;}catch(_){}var hev=false;try{hev=!!(navigator.userAgentData&&typeof navigator.userAgentData.getHighEntropyValues==="function");}catch(_){}return {platform:navigator.platform,uad:uad,hev:hev,gl:glR};})()';
    async function debugDumpFrameFingerprints(page) {
      if (process.env.L7_DEBUG !== "1") {
        return;
      }
      try {
        var frames = page.frames();
        for (var i = 0; i < frames.length; i++) {
          var f = frames[i];
          var url = (f.url() || "").slice(0, 55);
          try {
            var info = await f.evaluate(L7_FP_PROBE_SRC);
            console.log("[L7_DEBUG] frame=" + url + " platform=" + info.platform + " uadPlatform=" + info.uad + " hasHEV=" + info.hev + " webgl=" + info.gl);
          } catch (e) {
            console.log("[L7_DEBUG] frame=" + url + " eval-failed: " + (e && e.message));
          }
        }
      } catch (_) {
      }
    }
    async function pollUntilCfClearance(page, tickFn, maxWaitMs) {
      var limit = Number.isFinite(maxWaitMs) && maxWaitMs > 0 ? maxWaitMs : 4e4;
      await new Promise(function(resolve) {
        var elapsed = 0;
        var iv = setInterval(async function() {
          elapsed += 1e3;
          try {
            await tickFn();
          } catch (_) {
          }
          try {
            var cks = await page.cookies();
            if (cks.some(function(c) {
              return c.name === "cf_clearance";
            })) {
              clearInterval(iv);
              resolve();
              return;
            }
          } catch (_) {
          }
          if (elapsed >= limit) {
            clearInterval(iv);
            resolve();
          }
        }, 1e3);
      });
    }
    function pageHtmlLooksLikeAliyunWafGate(content) {
      if (!content || content.length < 120) {
        return false;
      }
      if (content.indexOf("initAliyunCaptcha") !== -1) {
        return true;
      }
      if (content.indexOf("AliyunCaptcha.js") !== -1 && (content.indexOf("captcha-element") !== -1 || content.indexOf("h5_captcha-element") !== -1)) {
        return true;
      }
      if (content.indexOf("CF_APP_WAF") !== -1 && (content.indexOf("nc-container") !== -1 || content.indexOf("waf-nc-h5") !== -1 || content.indexOf("waf_nc_h5") !== -1)) {
        return true;
      }
      if (content.indexOf("aliyunCaptcha") !== -1 && content.indexOf("aliyunCaptcha-sliding-slider") !== -1) {
        return true;
      }
      return false;
    }
    function pageHtmlLooksLikeTencentEdgeOne(content) {
      if (!content || content.length < 40) {
        return false;
      }
      if (content.indexOf("TEOCaptchaWidgetV1-global.js") !== -1) {
        return true;
      }
      if (content.indexOf("gcaptcha.eo.gtimg.com") !== -1) {
        return true;
      }
      if (content.indexOf("tcaptcha_wrapper_transform_eo") !== -1 || content.indexOf("tcaptcha_iframe_eo") !== -1) {
        return true;
      }
      if (content.indexOf("Tencent Cloud EdgeOne") !== -1) {
        return true;
      }
      if (content.indexOf("EO_Bot_Ssid") !== -1) {
        return true;
      }
      return false;
    }
    function pageHtmlLooksLikeLeCdnWaf(content) {
      if (!content || content.indexOf(".slideBox") === -1) {
        return false;
      }
      return content.indexOf("LeCDN") !== -1 || content.indexOf("/_waf/") !== -1 || content.indexOf("WAF \u5B89\u5168\u9632\u62A4") !== -1;
    }
    function pageHtmlLooksLikeHkCloudWaf(content) {
      if (!content || content.length < 80) {
        return false;
      }
      if (content.indexOf("verifyBtn") !== -1 && content.indexOf("/_waf/_") !== -1) {
        return true;
      }
      if (content.indexOf("\u9999\u6E2F\u4E91WAF") !== -1 || content.indexOf("\u9999\u6E2F\u4E91 WAF") !== -1) {
        return true;
      }
      if (content.indexOf("verify-card") !== -1 && content.indexOf("crypto-js") !== -1 && content.indexOf("/_waf/") !== -1) {
        return true;
      }
      return false;
    }
    function isBypassUnresolved(response) {
      var title = response && response.title ? String(response.title) : "";
      var cookies = response && response.cookies ? String(response.cookies) : "";
      var content = response && response.content ? String(response.content) : "";
      if (/just\s*a\s*moment/i.test(title)) return true;
      if (/请稍候/i.test(title)) return true;
      if (/security verification|安全验证|人机验证|安全校验|attention required!\s*\|\s*cloudflare|请完成.*验证|checking your browser|滑动验证页面/i.test(title)) return true;
      if (/验证码中间页|香港云WAF/i.test(title)) return true;
      if (content.indexOf("/_guard/html.js") !== -1) return true;
      if (content.indexOf("/_guard/auto.js") !== -1 && content.indexOf("/_guard/html.js") === -1) return true;
      if (pageHtmlLooksLikeLeCdnWaf(content)) return true;
      if (pageHtmlLooksLikeHkCloudWaf(content)) return true;
      if (pageHtmlLooksLikeAliyunWafGate(content)) return true;
      if (pageHtmlLooksLikeTencentEdgeOne(content)) return true;
      var hasGuard = false;
      var hasCfClearance = false;
      var hasCfChallengeCookie = false;
      var parts = cookies.split(";");
      var p;
      for (p = 0; p < parts.length; p++) {
        var seg = parts[p].trim();
        var eq = seg.indexOf("=");
        if (eq <= 0) continue;
        var name = seg.slice(0, eq).trim().toLowerCase();
        if (name === "guard") hasGuard = true;
        if (name === "cf_clearance") hasCfClearance = true;
        if (name.indexOf("cf_chl") === 0) hasCfChallengeCookie = true;
      }
      if (hasGuard && /验证|verification|security|captcha|waf|人机/i.test(title)) return true;
      if (hasCfChallengeCookie && !hasCfClearance) return true;
      return false;
    }
    var DETECT_CHALLENGE_MAX_CHAIN = 4;
    async function detectChallenge(browserProxy, page, chainDepth) {
      chainDepth = Number.isFinite(chainDepth) ? chainDepth : 0;
      if (chainDepth > DETECT_CHALLENGE_MAX_CHAIN) {
        console.log(`${"[!] detectChallenge: chain depth exceeded, stop re-dispatch".bold.yellow} - ` + proxyLineForDisplay(browserProxy).italic);
        return;
      }
      var [_titleRes, _contentRes] = await Promise.allSettled([page.title(), page.content()]);
      const title = _titleRes.status === "fulfilled" ? _titleRes.value : "";
      const content = _contentRes.status === "fulfilled" ? _contentRes.value : "";
      if (title === "Attention Required! | Cloudflare") {
        console.log("Proxy blocked");
        throw new Error("Proxy blocked");
      }
      if (content.includes("challenge-platform") && content.includes("sliderContainer")) {
        console.log(`${"Found CloudFlare challenge (with custom page slider)".bold.magenta} - ` + proxyLineForDisplay(browserProxy).italic);
        await sleep(1);
        await debugDumpFrameFingerprints(page);
        await pollUntilCfClearance(page, async function() {
          await page.evaluate(EVAL_IN_PAGE_CF_SLIDER);
          await checkTurnstile({ page });
        });
        return;
      }
      if (content.includes("challenge-platform")) {
        console.log(`${"Found CloudFlare challenge".bold.magenta} - ` + proxyLineForDisplay(browserProxy).italic);
        await sleep(1);
        await debugDumpFrameFingerprints(page);
        await pollUntilCfClearance(page, async function() {
          await checkTurnstile({ page });
        });
        return;
      }
      if (content.indexOf("5_sec_checking") !== -1) {
        console.log(`${"Found GoEdge 5 second delay shield".bold.magenta} ${"\u30105_sec_checking\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
        await handleGoedgeDelayShield(page);
        await sleep(5);
        return;
      }
      if (content.indexOf("/_guard/auto.js") !== -1 && content.indexOf("/_guard/html.js") === -1) {
        console.log(
          `${"Found guard auto.js bootstrap".bold.magenta} ${"\u3010auto.js \u2192 reload \u2192 html.js\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
        );
        await handleGuardAutoBootstrap(page);
        await sleep(1);
        return await detectChallenge(browserProxy, page, chainDepth + 1);
      }
      if (pageHtmlLooksLikeAliyunWafGate(content)) {
        console.log(`${"Found Aliyun / ESA WAF slider".bold.magenta} ${"\u3010AliyunCaptcha\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
        await handleAliyunSlide(page);
        await sleep(5);
        return;
      }
      if (pageHtmlLooksLikeTencentEdgeOne(content)) {
        console.log(`${"Found Tencent EdgeOne captcha".bold.magenta} ${"\u3010EdgeOne \u70B9\u51FB\u9A8C\u8BC1\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
        await handleTencentEdgeOneClickCaptcha(page);
        await sleep(2);
        return;
      }
      if (pageHtmlLooksLikeHkCloudWaf(content)) {
        console.log(`${"Found \u9999\u6E2F\u4E91 WAF BrowserVerify".bold.magenta} ${"\u3010\u70B9\u51FB\u76FE\u724C\u9A8C\u8BC1\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
        await handleHkCloudVerify(page);
        await sleep(2);
        return;
      }
      if (pageHtmlLooksLikeLeCdnWaf(content)) {
        console.log(`${"Found LeCDN WAF slider".bold.magenta} - ` + proxyLineForDisplay(browserProxy).italic);
        await handleLeCDNSlider(page);
        await sleep(5);
        return;
      }
      if (content.includes("/_guard/html.js")) {
        if (content.indexOf("delay_jump_html") !== -1 || content.indexOf("js=delay_jump_html") !== -1) {
          console.log(`${"Found CDNFly delay-jump shield".bold.magenta} ${"\u30105s \u7B49\u5F85\u8DF3\u8F6C\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlyDelayShield(page);
          await sleep(2);
          return await detectChallenge(browserProxy, page, chainDepth + 1);
        }
        var hasPuzzleHtml = content.indexOf("puzzle-image") !== -1 || content.indexOf("puzzle-piece") !== -1;
        var captchaImgSel = 'img[src*="_guard/captcha"], img[src*="captcha.png"]';
        var hasMathCaptchaDom = false;
        try {
          hasMathCaptchaDom = !!await page.$(captchaImgSel);
        } catch (eMc) {
        }
        var hasMathCaptchaHtml = (content.indexOf("_guard/captcha") !== -1 || content.indexOf("captcha.png") !== -1) && content.indexOf("img[") !== -1;
        var hasClickHint = content.indexOf("clickableImg") !== -1;
        var hasClickableDom = false;
        try {
          hasClickableDom = !!await page.$(".clickableImg");
        } catch (eCl) {
        }
        if (!hasPuzzleHtml && !hasClickHint && !hasClickableDom && (hasMathCaptchaDom || hasMathCaptchaHtml)) {
          console.log(`${"Found CDNFly math / calculate captcha".bold.magenta} ${"\u3010\u7B97\u5F0F\u9A8C\u8BC1\u7801\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlyMathCaptcha(page);
          await sleep(5);
          return;
        }
        if (content.indexOf("js=captcha_html") !== -1 || content.indexOf("captcha_html") !== -1) {
          console.log(
            `${"Found CDNFly captcha_html shell (nested)".bold.magenta} ${"\u3010\u58F3\u9875 \u2192 \u53CC\u66F2\u7EBF\u6ED1\u5757\uFF0C\u4F18\u5148 SLIDER2_LOCAL_API\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
          );
          await handleCDNFlyCurveSliderCaptcha(page, browserProxy);
          await sleep(5);
          return;
        }
        if (content.indexOf("easy_slider_html") !== -1 || content.indexOf("js=easy_slider_html") !== -1 || content.indexOf("wafonline") !== -1) {
          console.log(
            `${"Found CDNFly easy_slider_html shell (nested)".bold.magenta} ${"\u3010\u58F3\u9875 \u2192 \u5355\u7F3A\u53E3\u62FC\u56FE\u6ED1\u5757\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
          );
          await handleCDNFlySingleSliderCaptcha(page);
          await sleep(2);
          return await detectChallenge(browserProxy, page, chainDepth + 1);
        }
        if (content.indexOf("rotate_html") !== -1 || content.indexOf("js=rotate_html") !== -1) {
          console.log(
            `${"Found CDNFly rotate_html shell (nested)".bold.magenta} ${"\u3010\u58F3\u9875 \u2192 \u65CB\u8F6C\u56FE\u6ED1\u8F68\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
          );
          await handleCDNFlyRotateImageCaptcha(page);
          await sleep(5);
          return;
        }
        var hasPuzzleDom = false;
        try {
          hasPuzzleDom = !!await page.$(".puzzle-image");
        } catch (eP) {
        }
        if (hasPuzzleDom || hasPuzzleHtml) {
          var rotateHtml = content.indexOf("rotate_html") !== -1 || content.indexOf("js=rotate_html") !== -1;
          var easySlider = content.indexOf("easy_slider_html") !== -1 || content.indexOf("js=easy_slider_html") !== -1;
          var wafOnline = content.indexOf("wafonline") !== -1;
          if (rotateHtml) {
            console.log(`${"Found CDNFly rotate image slider captcha".bold.magenta} ${"\u3010\u65CB\u8F6C\u56FE\u6ED1\u8F68\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
            await handleCDNFlyRotateImageCaptcha(page);
          } else if (easySlider || wafOnline) {
            console.log(`${"Found CDNFly puzzle single-slider captcha".bold.magenta} ${"\u3010\u5355\u7F3A\u53E3\u62FC\u56FE\u6ED1\u5757\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
            await handleCDNFlySingleSliderCaptcha(page);
            await sleep(2);
            return await detectChallenge(browserProxy, page, chainDepth + 1);
          } else {
            console.log(`${"Found CDNFly curve / double-gap slider captcha".bold.magenta} ${"\u3010\u66F2\u7EBF/\u53CC\u7F3A\u53E3\u6ED1\u5757\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
            await handleCDNFlyCurveSliderCaptcha(page, browserProxy);
          }
          await sleep(5);
          return;
        }
        var hasClickTextDom = false;
        try {
          hasClickTextDom = !!await page.$(".clickableImg");
        } catch (e) {
        }
        var hasClickTextHtml = content.indexOf("clickableImg") !== -1;
        if (hasClickTextDom || hasClickTextHtml) {
          console.log(`${"Found CDNFly text click captcha".bold.magenta} ${"\u3010\u6587\u5B57\u70B9\u9009\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlyTextClickCaptcha(page);
          await sleep(5);
          return;
        }
        if (content.indexOf("click_html") !== -1 || content.indexOf("js=click_html") !== -1) {
          console.log(`${"Found CDNFly guard (click)".bold.magenta} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlyClick(page);
          await sleep(5);
          return;
        }
        var domSimpleBtn = false;
        var domSimpleTrack = false;
        try {
          domSimpleBtn = !!await page.$('#slider #btn, #slider .button[id="btn"]');
        } catch (_) {
        }
        try {
          domSimpleTrack = !!await page.$('#slider #track, #slider .track[id="track"]');
        } catch (_) {
        }
        if (domSimpleBtn && domSimpleTrack) {
          console.log(
            `${"Found CDNFly simple slide widget".bold.magenta} ${"\u3010\u5411\u53F3\u6ED1\u52A8\u9A8C\u8BC1\xB7\u76F4\u63A5\u62D6\u62FD\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
          );
          await handleCDNFlySimpleSlide(page);
          await sleep(3);
          return;
        }
        var domSliderHandle = false;
        var domPuzzleImage = false;
        var domPuzzlePiece = false;
        var domClickable = false;
        try {
          domSliderHandle = !!await page.$(".slider-handle");
        } catch (_) {
        }
        try {
          domPuzzleImage = !!await page.$(".puzzle-image");
        } catch (_) {
        }
        try {
          domPuzzlePiece = !!await page.$(".puzzle-piece");
        } catch (_) {
        }
        try {
          domClickable = !!await page.$(".clickableImg");
        } catch (_) {
        }
        if (domClickable) {
          console.log(`${"Found CDNFly text click captcha (DOM)".bold.magenta} ${"\u3010\u6587\u5B57\u70B9\u9009\xB7DOM\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlyTextClickCaptcha(page);
          await sleep(5);
          return;
        }
        if (domSliderHandle && (domPuzzleImage || domPuzzlePiece)) {
          console.log(`${"Found CDNFly puzzle single-slider captcha (DOM)".bold.magenta} ${"\u3010\u5355\u7F3A\u53E3\u62FC\u56FE\u6ED1\u5757\xB7DOM\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic);
          await handleCDNFlySingleSliderCaptcha(page);
          await sleep(2);
          return await detectChallenge(browserProxy, page, chainDepth + 1);
        }
        if (domSliderHandle && !domPuzzleImage) {
          console.log(
            `${"Found CDNFly simple drag slider (DOM)".bold.magenta} ${"\u3010\u5411\u53F3\u6ED1\u52A8\u9A8C\u8BC1\xB7\u4F18\u5148 SLIDER2_LOCAL_API\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
          );
          await handleCDNFlyCurveSliderCaptcha(page, browserProxy);
          await sleep(5);
          return;
        }
        console.log(
          `${"Found CDNFly guard (unknown sub-type)".bold.magenta} ${"\u3010\u9ED8\u8BA4\u6309\u53CC\u66F2\u7EBF\u6ED1\u5757\uFF0C\u4F18\u5148 SLIDER2_LOCAL_API\u3011".white} - ` + proxyLineForDisplay(browserProxy).italic
        );
        await handleCDNFlyCurveSliderCaptcha(page, browserProxy);
        await sleep(5);
        return;
      }
      console.log(`${"No challenge detected".bold.magenta} - ` + proxyLineForDisplay(browserProxy).italic);
      try {
        await page.waitForNetworkIdle({ idleTime: 1500, timeout: 8e3 });
      } catch (_) {
      }
      await sleep(2);
      return;
    }
    function _mergeCookiesByName(a, b) {
      var map = /* @__PURE__ */ Object.create(null);
      var i;
      for (i = 0; i < (a || []).length; i++) {
        var ca = a[i];
        if (ca && ca.name) {
          map[ca.name] = ca;
        }
      }
      for (i = 0; i < (b || []).length; i++) {
        var cb = b[i];
        if (cb && cb.name) {
          map[cb.name] = cb;
        }
      }
      return Object.keys(map).map(function(k) {
        return map[k];
      });
    }
    async function readPageStateAfterBypass(page, targetURL) {
      try {
        await page.waitForNetworkIdle({ idleTime: 1e3, timeout: 6e3 });
      } catch (_) {
      }
      await sleep(1);
      async function cookiesForTarget() {
        var merged = [];
        try {
          var u = new URL(targetURL);
          var hrefNoHash = u.href.split("#")[0];
          var originSlash = u.origin + "/";
          var c1 = [];
          var c2 = [];
          try {
            c1 = await page.cookies(hrefNoHash);
          } catch (_) {
          }
          try {
            c2 = await page.cookies(originSlash);
          } catch (_) {
          }
          merged = _mergeCookiesByName(c1, c2);
          if (merged.length > 0) {
            return merged;
          }
        } catch (_) {
        }
        try {
          return await page.cookies();
        } catch (_) {
          return [];
        }
      }
      var results = await Promise.allSettled([
        page.title(),
        cookiesForTarget(),
        page.content()
      ]);
      return {
        title: results[0].status === "fulfilled" ? results[0].value : "",
        cookies: results[1].status === "fulfilled" ? results[1].value : [],
        content: results[2].status === "fulfilled" ? results[2].value : ""
      };
    }
    module2.exports = {
      pageHtmlLooksLikeAliyunWafGate,
      pageHtmlLooksLikeTencentEdgeOne,
      pageHtmlLooksLikeLeCdnWaf,
      pageHtmlLooksLikeHkCloudWaf,
      isBypassUnresolved,
      detectChallenge,
      readPageStateAfterBypass
    };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/browser_core.js
var require_browser_core = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/browser_core.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var _prbRoot = path.dirname(require.resolve("puppeteer-real-browser"));
    var _prbPageController = require(path.join(_prbRoot, "module/pageController.js"));
    var _origPageController = _prbPageController.pageController;
    _prbPageController.pageController = async function(config) {
      var page = config && config.page;
      if (!page && config && config.browser) {
        var pages = await config.browser.pages();
        page = pages.find(Boolean);
        if (!page) {
          try {
            page = await config.browser.newPage();
          } catch (_) {
          }
        }
        if (page) {
          config.page = page;
        }
      }
      if (!page) {
        return null;
      }
      return _origPageController(config);
    };
    var { connect } = require("puppeteer-real-browser");
    var { exitIfScriptExpired } = require_auth();
    var { parseProxyLine, proxyLineForDisplay } = require_proxy();
    var { isGloballySuppressedNoiseError } = require_errors();
    var { detectChallenge, readPageStateAfterBypass, isBypassUnresolved } = require_detect();
    var { EVAL_IN_PAGE_USER_AGENT, buildNavigatorFingerprintPatch } = require_eval_snippets();
    var { sleep } = require_http_utils();
    function ensureConnectedPage(connected, browserProxy) {
      if (!connected || !connected.browser) {
        throw new Error("Browser connect failed: no browser instance");
      }
      if (connected.page) {
        return connected;
      }
      throw new Error("Browser connect failed: no page for " + proxyLineForDisplay(browserProxy));
    }
    var GOTO_SETTLE_MS = 3e3;
    var _activeBrowsers = /* @__PURE__ */ new Set();
    function trackBrowser(browser) {
      if (!browser) {
        return;
      }
      _activeBrowsers.add(browser);
      browser.once("disconnected", function() {
        _activeBrowsers.delete(browser);
      });
    }
    async function closeAllBrowsers() {
      var list = Array.from(_activeBrowsers);
      _activeBrowsers.clear();
      await Promise.all(list.map(function(b) {
        return b.close().catch(function() {
        });
      }));
    }
    var CHROME_BUILD_BY_MAJOR = {
      146: "146.0.7390.54",
      144: "144.0.7339.82"
    };
    var FLOODER_ALIGNED_CHROME_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7390.54 Safari/537.36";
    function pickChromiumBrandMeta(major) {
      var m = parseInt(major, 10) || 146;
      if (m > 146) {
        m = 146;
      }
      var notBrand;
      var notVer;
      if (m >= 146) {
        notBrand = "Not/A)Brand";
        notVer = "99";
      } else if (m >= 144) {
        notBrand = "Not)A;Brand";
        notVer = "99";
      } else if (m >= 131) {
        notBrand = "Not(A:Brand";
        notVer = "99";
      } else {
        notBrand = "Not_A Brand";
        notVer = "24";
      }
      var maj = String(m);
      var full = CHROME_BUILD_BY_MAJOR[m] || maj + ".0.0.0";
      return {
        brands: [
          { brand: "Chromium", version: maj },
          { brand: "Google Chrome", version: maj },
          { brand: notBrand, version: notVer }
        ],
        fullVersionList: [
          { brand: "Chromium", version: full },
          { brand: "Google Chrome", version: full },
          { brand: notBrand, version: notVer + ".0.0.0" }
        ],
        fullVersion: full
      };
    }
    function parseUaPlatformVersion(ua, platform) {
      var m;
      if (platform === "iOS") {
        m = ua.match(/iPhone OS (\d+)[_.](\d+)/);
        if (m) {
          return m[1] + "." + m[2] + ".0";
        }
        return "17.0.0";
      }
      if (platform === "Android") {
        m = ua.match(/Android (\d+)/);
        if (m) {
          return m[1] + ".0.0";
        }
        return "14.0.0";
      }
      if (platform === "macOS") {
        m = ua.match(/Mac OS X (\d+)[_.](\d+)/);
        if (m) {
          return m[1] + "." + m[2] + ".0";
        }
        return "15.0.0";
      }
      if (platform === "Linux") {
        return "6.8.0";
      }
      if (platform === "Windows") {
        return "15.0.0";
      }
      return "";
    }
    function webglForPlatform(platform) {
      if (platform === "Windows") {
        return {
          vendor: "Google Inc. (Intel)",
          renderer: "ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)"
        };
      }
      if (platform === "macOS") {
        return {
          vendor: "Google Inc. (Intel Inc.)",
          renderer: "ANGLE (Intel Inc., Intel(R) Iris(TM) Plus Graphics OpenGL Engine, OpenGL 4.1)"
        };
      }
      return { vendor: "", renderer: "" };
    }
    function parseUaHints(ua) {
      var mobile = /Mobile|Android|iPhone|iPad/i.test(ua);
      var platform = "Windows";
      var platformId = "Win32";
      if (/iPhone|iPad|iPod/i.test(ua)) {
        platform = "iOS";
        platformId = "iPhone";
        mobile = true;
      } else if (/Android/i.test(ua)) {
        platform = "Android";
        platformId = "Linux armv81";
        mobile = true;
      } else if (/Macintosh/i.test(ua)) {
        platform = "macOS";
        platformId = "MacIntel";
      } else if (/Linux/i.test(ua)) {
        platform = "Linux";
        platformId = "Linux x86_64";
      }
      var gl = webglForPlatform(platform);
      var criosMatch = ua.match(/CriOS\/(\d+)/);
      if (criosMatch) {
        return {
          mobile,
          platform,
          platformId,
          family: "chromium",
          major: criosMatch[1],
          platformVersion: parseUaPlatformVersion(ua, platform),
          architecture: "arm",
          webglVendor: gl.vendor,
          webglRenderer: gl.renderer
        };
      }
      var chromeMatch = ua.match(/Chrome\/(\d+)/);
      if (chromeMatch) {
        var arch = mobile ? "arm" : /Macintosh/i.test(ua) && !/Intel/i.test(ua) ? "arm" : "x86";
        return {
          mobile,
          platform,
          platformId,
          family: "chromium",
          major: chromeMatch[1],
          platformVersion: parseUaPlatformVersion(ua, platform),
          architecture: arch,
          webglVendor: gl.vendor,
          webglRenderer: gl.renderer
        };
      }
      if (/Firefox\//i.test(ua)) {
        return {
          mobile,
          platform,
          platformId,
          family: "firefox",
          major: "",
          platformVersion: "",
          architecture: "x86",
          webglVendor: "",
          webglRenderer: ""
        };
      }
      return {
        mobile,
        platform,
        platformId,
        family: "other",
        major: "",
        platformVersion: "",
        architecture: "x86",
        webglVendor: "",
        webglRenderer: ""
      };
    }
    function buildCdpUaOverride(userAgent, hints) {
      var override = {
        userAgent,
        acceptLanguage: "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        platform: hints.platformId
      };
      if (hints.family === "chromium" && hints.major) {
        var brandMeta = pickChromiumBrandMeta(hints.major);
        override.userAgentMetadata = {
          brands: brandMeta.brands,
          fullVersionList: brandMeta.fullVersionList,
          fullVersion: brandMeta.fullVersion,
          platform: hints.platform,
          platformVersion: hints.platformVersion || "",
          architecture: hints.architecture || "x86",
          model: hints.mobile ? hints.platform === "iOS" ? "iPhone" : "" : "",
          mobile: !!hints.mobile,
          bitness: "64",
          wow64: false
        };
      }
      return override;
    }
    async function getPageCdpClient(page) {
      try {
        if (typeof page.createCDPSession === "function") {
          return await page.createCDPSession();
        }
        if (typeof page.target === "function") {
          return await page.target().createCDPSession();
        }
      } catch (_) {
      }
      if (page && typeof page._client === "function") {
        try {
          return page._client();
        } catch (_) {
        }
      }
      return null;
    }
    function buildChromeLaunchArgs(platform) {
      if (platform !== "linux") {
        return [];
      }
      return [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-blink-features=AutomationControlled",
        "--window-size=1920,1080",
        // VPS 环境 /dev/shm 默认 64MB，Chrome 130+ 共享内存用量上升；
        // 不加此标志会导致 Chrome 在 bypass 过程中静默崩溃或 IPC 超时。
        "--disable-dev-shm-usage",
        // Linux 服务器无 GPU：强制启用 SwiftShader 软件渲染，让 WebGL 真正可用。
        // 否则 navigator 声明 Windows/Mac 却 webgl=null，与真实桌面矛盾被 CF 判死。
        // 渲染器名（默认 "Google SwiftShader"）再由注入脚本改写为 Intel。
        "--use-gl=angle",
        "--use-angle=swiftshader",
        "--enable-unsafe-swiftshader",
        "--ignore-gpu-blocklist",
        "--enable-webgl",
        // 防止 Chrome 因沙箱与 xvfb/VPS 环境兼容性问题产生 GPU 进程崩溃
        "--disable-gpu-sandbox",
        // 禁用会暴露自动化特征的功能
        "--disable-features=AutomationControlled,ChromeWhatsNewUI",
        // 禁用后台节流，防止 Turnstile 定时器被挂起导致挑战超时
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding"
      ];
    }
    function wireCfChallengeFrames(page, cdpClient, uaOverride) {
      var client = cdpClient;
      if (!client && page && typeof page._client === "function") {
        try {
          client = page._client();
        } catch (_) {
        }
      }
      if (!client || typeof client.send !== "function" || !page) {
        return;
      }
      if (page._l7CfFrameWired) {
        return;
      }
      page._l7CfFrameWired = true;
      page.on("framenavigated", function(frame) {
        try {
          if (frame.url().indexOf("challenges.cloudflare.com") === -1) {
            return;
          }
          if (uaOverride) {
            client.send("Network.setUserAgentOverride", uaOverride).catch(function() {
            });
          }
        } catch (_) {
        }
      });
    }
    async function applyPageUserAgent(page, userAgent) {
      if (!page || !userAgent) {
        return;
      }
      var hints = parseUaHints(userAgent);
      var override = buildCdpUaOverride(userAgent, hints);
      var brandMeta = hints.family === "chromium" && hints.major ? pickChromiumBrandMeta(hints.major) : null;
      var uad = brandMeta ? {
        brands: brandMeta.brands,
        fullVersionList: brandMeta.fullVersionList,
        uaFullVersion: brandMeta.fullVersion,
        platform: hints.platform,
        platformVersion: hints.platformVersion || "",
        architecture: hints.architecture || "x86",
        model: hints.mobile ? hints.platform === "iOS" ? "iPhone" : "" : ""
      } : null;
      var initScript = buildNavigatorFingerprintPatch({
        platformId: hints.platformId,
        mobile: hints.mobile,
        webglVendor: hints.webglVendor,
        webglRenderer: hints.webglRenderer,
        userAgentData: uad
      });
      if (typeof page.evaluateOnNewDocument === "function") {
        try {
          await page.evaluateOnNewDocument(initScript);
        } catch (_) {
        }
      }
      if (hints.mobile && typeof page.setViewport === "function") {
        await page.setViewport({
          width: hints.platform === "iOS" ? 390 : 412,
          height: hints.platform === "iOS" ? 844 : 915,
          deviceScaleFactor: 3,
          isMobile: true,
          hasTouch: true
        });
      } else if (typeof page.setViewport === "function") {
        await page.setViewport({
          width: 1920,
          height: 1080,
          deviceScaleFactor: 1,
          isMobile: false,
          hasTouch: false
        });
      }
      if (typeof page.setUserAgent === "function") {
        try {
          if (override.userAgentMetadata) {
            await page.setUserAgent(userAgent, override.userAgentMetadata);
          } else {
            await page.setUserAgent(userAgent);
          }
        } catch (_) {
          try {
            await page.setUserAgent(userAgent);
          } catch (e2) {
          }
        }
      }
      var cdpClient = await getPageCdpClient(page);
      if (cdpClient && typeof cdpClient.send === "function") {
        try {
          await cdpClient.send("Network.setUserAgentOverride", override);
        } catch (_) {
        }
        wireCfChallengeFrames(page, cdpClient, override);
      } else {
        wireCfChallengeFrames(page, null, null);
      }
    }
    async function resolvePageUserAgent(page, desiredUA) {
      if (desiredUA) {
        await applyPageUserAgent(page, desiredUA);
        return desiredUA;
      }
      await applyPageUserAgent(page, FLOODER_ALIGNED_CHROME_UA);
      wireCfChallengeFrames(page, null, null);
      return FLOODER_ALIGNED_CHROME_UA;
    }
    async function openBrowser(targetURL, browserProxy, desiredUA) {
      const promise = async function(resolve, reject) {
        exitIfScriptExpired("browser");
        var parsedProxy = parseProxyLine(browserProxy);
        if (!parsedProxy) {
          reject(`${"Invalid proxy line".bold.red} - ` + proxyLineForDisplay(browserProxy).italic);
          return;
        }
        var proxyForConnect = { host: parsedProxy.host, port: parsedProxy.port };
        if (parsedProxy.username && parsedProxy.password) {
          proxyForConnect.username = parsedProxy.username;
          proxyForConnect.password = parsedProxy.password;
        }
        var browser = null;
        try {
          const connected = ensureConnectedPage(await connect({
            headless: false,
            args: [],
            customConfig: {},
            turnstile: false,
            connectOption: { defaultViewport: null },
            disableXvfb: false,
            ignoreAllFlags: false,
            proxy: proxyForConnect
          }), browserProxy);
          browser = connected.browser;
          var page = connected.page;
          console.log(`${"Started browser".bold.yellow} - ` + proxyLineForDisplay(browserProxy).italic);
          page.setDefaultNavigationTimeout(60 * 1e3);
          const userAgent = await resolvePageUserAgent(page, desiredUA);
          await page.goto(targetURL, { waitUntil: "domcontentloaded" });
          await sleep(GOTO_SETTLE_MS / 1e3);
          await detectChallenge(browserProxy, page);
          var afterBypass = await readPageStateAfterBypass(page, targetURL);
          const title = afterBypass.title;
          const cookies = afterBypass.cookies;
          const parsedURL = new URL(targetURL);
          const hostname = parsedURL.hostname;
          resolve({
            title,
            browserProxy,
            cookies: cookies.map(function(cookie) {
              return cookie.name + "=" + cookie.value;
            }).join("; ").trim(),
            userAgent,
            content: afterBypass.content,
            hostname
          });
        } catch (exception) {
          if (process.env.L7_DEBUG === "1" && exception && !isGloballySuppressedNoiseError(exception)) {
            console.error(exception);
          }
          reject(exception != null ? exception : new Error("openBrowser failed"));
          return;
        } finally {
          if (browser) {
            try {
              await browser.close();
            } catch (closeErr) {
              if (process.env.L7_DEBUG === "1" && !isGloballySuppressedNoiseError(closeErr)) {
                console.error(closeErr);
              }
            }
          }
        }
      };
      return new Promise(promise);
    }
    async function openBrowserDebug(targetURL, proxyLine, desiredUA) {
      const promise = async function(resolve, reject) {
        exitIfScriptExpired("browser-debug");
        var rawDbg = proxyLine != null && String(proxyLine).trim() ? String(proxyLine).trim() : "";
        var parsedDbg = rawDbg ? parseProxyLine(rawDbg) : null;
        var browserProxy = parsedDbg ? rawDbg : "(direct)";
        if (rawDbg && !parsedDbg) {
          console.log(`${"[!] --debug-proxy ignored (invalid line):".bold.yellow} ` + String(rawDbg).italic);
        }
        var browser = null;
        try {
          var connectOptsDbg = {
            headless: false,
            args: [],
            customConfig: {},
            turnstile: false,
            connectOption: { defaultViewport: null },
            disableXvfb: false,
            ignoreAllFlags: false
          };
          if (parsedDbg) {
            connectOptsDbg.proxy = { host: parsedDbg.host, port: parsedDbg.port };
            if (parsedDbg.username && parsedDbg.password) {
              connectOptsDbg.proxy.username = parsedDbg.username;
              connectOptsDbg.proxy.password = parsedDbg.password;
            }
          }
          const connected = ensureConnectedPage(await connect(connectOptsDbg), browserProxy);
          browser = connected.browser;
          var page = connected.page;
          console.log(`${"Started browser".bold.yellow} - ` + proxyLineForDisplay(browserProxy).italic);
          page.setDefaultNavigationTimeout(60 * 1e3);
          const userAgent = await resolvePageUserAgent(page, desiredUA);
          await page.goto(targetURL, { waitUntil: "domcontentloaded" });
          await sleep(GOTO_SETTLE_MS / 1e3);
          await detectChallenge(browserProxy, page);
          var afterBypassDbg = await readPageStateAfterBypass(page, targetURL);
          const title = afterBypassDbg.title;
          const cookies = afterBypassDbg.cookies;
          const parsedURL = new URL(targetURL);
          const hostname = parsedURL.hostname;
          resolve({
            title,
            browserProxy,
            cookies: cookies.map(function(cookie) {
              return cookie.name + "=" + cookie.value;
            }).join("; ").trim(),
            userAgent,
            content: afterBypassDbg.content,
            hostname
          });
        } catch (exception) {
          if (process.env.L7_DEBUG === "1" && exception && !isGloballySuppressedNoiseError(exception)) {
            console.error(exception);
          }
          reject(exception != null ? exception : new Error("openBrowserDebug failed"));
          return;
        } finally {
          if (browser) {
            try {
              await browser.close();
            } catch (closeErr) {
              if (process.env.L7_DEBUG === "1" && !isGloballySuppressedNoiseError(closeErr)) {
                console.error(closeErr);
              }
            }
          }
        }
      };
      return new Promise(promise);
    }
    async function openBrowserWithRetry(targetURL, browserProxy, maxAttempts, onRetry, desiredUA) {
      var parsedProxy = parseProxyLine(browserProxy);
      if (!parsedProxy) {
        throw new Error("Invalid proxy line: " + String(browserProxy));
      }
      var proxyForConnect = { host: parsedProxy.host, port: parsedProxy.port };
      if (parsedProxy.username && parsedProxy.password) {
        proxyForConnect.username = parsedProxy.username;
        proxyForConnect.password = parsedProxy.password;
      }
      var browser = null;
      try {
        const connected = ensureConnectedPage(await connect({
          headless: false,
          args: [],
          customConfig: {},
          turnstile: false,
          connectOption: { defaultViewport: null },
          disableXvfb: false,
          ignoreAllFlags: false,
          proxy: proxyForConnect
        }), browserProxy);
        browser = connected.browser;
        trackBrowser(browser);
        var page = connected.page;
        console.log(`${"Started browser".bold.yellow} - ` + proxyLineForDisplay(browserProxy).italic);
        page.setDefaultNavigationTimeout(60 * 1e3);
        const userAgent = await resolvePageUserAgent(page, desiredUA);
        var att;
        var lastErr = null;
        var lastResult = null;
        for (att = 1; att <= maxAttempts; att++) {
          try {
            if (att > 1 && typeof onRetry === "function") {
              await onRetry(att, maxAttempts);
            }
            await page.goto(targetURL, { waitUntil: "domcontentloaded" });
            await sleep(GOTO_SETTLE_MS / 1e3);
            await detectChallenge(browserProxy, page);
            var afterBypass = await readPageStateAfterBypass(page, targetURL);
            var parsedURL = new URL(targetURL);
            lastResult = {
              title: afterBypass.title,
              browserProxy,
              cookies: afterBypass.cookies.map(function(c) {
                return c.name + "=" + c.value;
              }).join("; ").trim(),
              userAgent,
              content: afterBypass.content,
              hostname: parsedURL.hostname
            };
            if (!isBypassUnresolved(lastResult)) {
              return lastResult;
            }
            lastErr = null;
          } catch (attErr) {
            lastErr = attErr;
            lastResult = null;
            if (process.env.L7_DEBUG === "1" && attErr && !isGloballySuppressedNoiseError(attErr)) {
              console.error(attErr);
            }
            if (att === maxAttempts) {
              throw attErr;
            }
          }
        }
        if (lastResult) {
          return lastResult;
        }
        throw lastErr || new Error("openBrowserWithRetry: all attempts failed");
      } finally {
        if (browser) {
          _activeBrowsers.delete(browser);
          try {
            await browser.close();
          } catch (closeErr) {
            if (process.env.L7_DEBUG === "1" && !isGloballySuppressedNoiseError(closeErr)) {
              console.error(closeErr);
            }
          }
        }
      }
    }
    async function createDebugBrowser(proxyLine, desiredUA) {
      exitIfScriptExpired("browser-debug");
      var rawDbg = proxyLine != null && String(proxyLine).trim() ? String(proxyLine).trim() : "";
      var parsedDbg = rawDbg ? parseProxyLine(rawDbg) : null;
      var browserProxy = parsedDbg ? rawDbg : "(direct)";
      if (rawDbg && !parsedDbg) {
        console.log(`${"[!] --debug-proxy ignored (invalid line):".bold.yellow} ` + String(rawDbg).italic);
      }
      var connectOptsDbg = {
        headless: false,
        args: [],
        customConfig: {},
        turnstile: false,
        connectOption: { defaultViewport: null },
        disableXvfb: false,
        ignoreAllFlags: false
      };
      if (parsedDbg) {
        connectOptsDbg.proxy = { host: parsedDbg.host, port: parsedDbg.port };
        if (parsedDbg.username && parsedDbg.password) {
          connectOptsDbg.proxy.username = parsedDbg.username;
          connectOptsDbg.proxy.password = parsedDbg.password;
        }
      }
      const connected = ensureConnectedPage(await connect(connectOptsDbg), browserProxy);
      const browser = connected.browser;
      var page = connected.page;
      console.log(`${"Started browser".bold.yellow} - ` + proxyLineForDisplay(browserProxy).italic);
      page.setDefaultNavigationTimeout(60 * 1e3);
      const userAgent = await resolvePageUserAgent(page, desiredUA);
      return { browser, page, userAgent, browserProxy };
    }
    async function openBypass(targetURL, browserProxy, desiredUA, maxAttempts, onRetry, extra) {
      var options = extra || {};
      var attempts = Number.isFinite(maxAttempts) && maxAttempts > 0 ? maxAttempts : 1;
      var proxyLabel = browserProxy && String(browserProxy).trim() ? browserProxy : "(direct)";
      var connectOpts = {
        headless: options.headless === true,
        args: buildChromeLaunchArgs(process.platform),
        customConfig: {},
        turnstile: false,
        connectOption: { defaultViewport: null },
        // Go 侧 buildBridgeCommand 在无 DISPLAY 的 Linux 上已包 xvfb-run，避免 PRB 再起一套 Xvfb。
        disableXvfb: true,
        ignoreAllFlags: false
      };
      var parsedProxy = browserProxy ? parseProxyLine(browserProxy) : null;
      if (parsedProxy) {
        connectOpts.proxy = { host: parsedProxy.host, port: parsedProxy.port };
        if (parsedProxy.username && parsedProxy.password) {
          connectOpts.proxy.username = parsedProxy.username;
          connectOpts.proxy.password = parsedProxy.password;
        }
      }
      var browser = null;
      try {
        const connected = ensureConnectedPage(await connect(connectOpts), proxyLabel);
        browser = connected.browser;
        trackBrowser(browser);
        var page = connected.page;
        console.log(`${"Started browser".bold.yellow} - ` + proxyLineForDisplay(proxyLabel).italic);
        page.setDefaultNavigationTimeout(60 * 1e3);
        const userAgent = await resolvePageUserAgent(page, desiredUA);
        var att;
        var lastErr = null;
        var lastResult = null;
        for (att = 1; att <= attempts; att++) {
          try {
            if (att > 1 && typeof onRetry === "function") {
              await onRetry(att, attempts);
            }
            await page.goto(targetURL, { waitUntil: "domcontentloaded" });
            await sleep(GOTO_SETTLE_MS / 1e3);
            await detectChallenge(proxyLabel, page);
            var afterBypass = await readPageStateAfterBypass(page, targetURL);
            var parsedURL = new URL(targetURL);
            lastResult = {
              title: afterBypass.title,
              browserProxy: proxyLabel,
              cookies: afterBypass.cookies.map(function(c) {
                return c.name + "=" + c.value;
              }).join("; ").trim(),
              userAgent,
              content: afterBypass.content,
              hostname: parsedURL.hostname
            };
            if (!isBypassUnresolved(lastResult)) {
              return lastResult;
            }
            lastErr = null;
          } catch (attErr) {
            lastErr = attErr;
            lastResult = null;
            if (process.env.L7_DEBUG === "1" && attErr && !isGloballySuppressedNoiseError(attErr)) {
              console.error(attErr);
            }
            if (att === attempts) {
              throw attErr;
            }
          }
        }
        if (lastResult) {
          return lastResult;
        }
        throw lastErr || new Error("openBypass: all attempts failed");
      } finally {
        if (browser) {
          _activeBrowsers.delete(browser);
          try {
            await browser.close();
          } catch (closeErr) {
            if (process.env.L7_DEBUG === "1" && !isGloballySuppressedNoiseError(closeErr)) {
              console.error(closeErr);
            }
          }
        }
      }
    }
    async function probeBypass2(targetURL, browserProxy, desiredUA, cookieHeader) {
      var proxyLabel = browserProxy && String(browserProxy).trim() ? browserProxy : "(direct)";
      var connectOpts = {
        headless: true,
        args: buildChromeLaunchArgs(process.platform),
        customConfig: {},
        turnstile: false,
        connectOption: { defaultViewport: null },
        disableXvfb: true,
        ignoreAllFlags: false
      };
      var parsedProxy = browserProxy ? parseProxyLine(browserProxy) : null;
      if (parsedProxy) {
        connectOpts.proxy = { host: parsedProxy.host, port: parsedProxy.port };
        if (parsedProxy.username && parsedProxy.password) {
          connectOpts.proxy.username = parsedProxy.username;
          connectOpts.proxy.password = parsedProxy.password;
        }
      }
      var browser = null;
      try {
        const connected = ensureConnectedPage(await connect(connectOpts), proxyLabel);
        browser = connected.browser;
        trackBrowser(browser);
        var page = connected.page;
        console.log(`${"Started browser (probe)".bold.yellow} - ` + proxyLineForDisplay(proxyLabel).italic);
        page.setDefaultNavigationTimeout(60 * 1e3);
        const userAgent = await resolvePageUserAgent(page, desiredUA);
        var parsedURL = new URL(targetURL);
        var cookies = parseCookieHeaderForPage(cookieHeader, parsedURL);
        if (cookies.length > 0) {
          try {
            await page.setCookie.apply(page, cookies);
          } catch (_) {
          }
        }
        await page.goto(targetURL, { waitUntil: "domcontentloaded" });
        await sleep(2);
        var afterProbe = await readPageStateAfterBypass(page, targetURL);
        return {
          title: afterProbe.title,
          browserProxy: proxyLabel,
          cookies: afterProbe.cookies.map(function(c) {
            return c.name + "=" + c.value;
          }).join("; ").trim(),
          userAgent,
          content: afterProbe.content,
          hostname: parsedURL.hostname
        };
      } finally {
        if (browser) {
          _activeBrowsers.delete(browser);
          try {
            await browser.close();
          } catch (closeErr) {
            if (process.env.L7_DEBUG === "1" && !isGloballySuppressedNoiseError(closeErr)) {
              console.error(closeErr);
            }
          }
        }
      }
    }
    function parseCookieHeaderForPage(cookieHeader, parsedURL) {
      var out = [];
      var raw = cookieHeader != null ? String(cookieHeader) : "";
      if (!raw.trim() || !parsedURL) {
        return out;
      }
      var secure = parsedURL.protocol === "https:";
      var pairs = raw.split(";");
      var i;
      for (i = 0; i < pairs.length; i++) {
        var seg = pairs[i].trim();
        if (!seg) {
          continue;
        }
        var eq = seg.indexOf("=");
        if (eq <= 0) {
          continue;
        }
        out.push({
          name: seg.slice(0, eq).trim(),
          value: seg.slice(eq + 1).trim(),
          domain: parsedURL.hostname,
          path: "/",
          secure
        });
      }
      return out;
    }
    module2.exports = { openBrowser, openBrowserWithRetry, openBrowserDebug, createDebugBrowser, closeAllBrowsers, openBypass, probeBypass: probeBypass2 };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/bridge_runner.js
var require_bridge_runner = __commonJS({
  "browser_core/internal/bypass/cfbrowser/nodebridge/engine/lib/bridge_runner.js"(exports2, module2) {
    "use strict";
    require("colors");
    var { openBypass, probeBypass: probeBypass2 } = require_browser_core();
    var { isBypassUnresolved } = require_detect();
    function hostnameOf(rawUrl) {
      try {
        return new URL(rawUrl).hostname;
      } catch (_) {
        return "";
      }
    }
    var CF_CLEARANCE_RE = /(?:^|;\s*)cf_clearance=/i;
    var CF_TURNSTILE_RE = /(?:^|;\s*)cf-turnstile-response=[^;]{10,}/i;
    var CF_BM_RE = /(?:^|;\s*)__cf_bm=/i;
    function pickMode(cookieHeader) {
      var h = cookieHeader || "";
      if (CF_CLEARANCE_RE.test(h)) {
        return "cloudflare";
      }
      if (CF_TURNSTILE_RE.test(h) || CF_BM_RE.test(h)) {
        return "turnstile";
      }
      return "browser";
    }
    function extractPassCookie(cookieHeader) {
      var h = cookieHeader || "";
      var m = h.match(/(?:^|;\s*)(cf_clearance)=/i);
      if (m) {
        return m[1];
      }
      m = h.match(/(?:^|;\s*)(cf-turnstile-response)=/i);
      if (m) {
        return m[1];
      }
      m = h.match(/(?:^|;\s*)(_ok[0-9a-z_]*)=/i);
      if (m) {
        return m[1];
      }
      return "";
    }
    function toContract(engineResult, payload, solved) {
      var cookieHeader = engineResult && engineResult.cookies ? String(engineResult.cookies) : "";
      return {
        success: solved === true,
        mode: solved === true ? pickMode(cookieHeader) : "browser",
        pass_cookie: solved === true ? extractPassCookie(cookieHeader) : "",
        cookie_header: cookieHeader,
        user_agent: engineResult && engineResult.userAgent ? String(engineResult.userAgent) : "",
        hostname: engineResult && engineResult.hostname || hostnameOf(payload && payload.url),
        page_title: engineResult && engineResult.title ? String(engineResult.title) : "",
        error: solved === true ? "" : "bypass unresolved (challenge still active)"
      };
    }
    function failureResult(rawUrl, error) {
      return {
        success: false,
        mode: "browser",
        pass_cookie: "",
        cookie_header: "",
        user_agent: "",
        hostname: hostnameOf(rawUrl),
        page_title: "",
        error: error || "bypass failed"
      };
    }
    function positiveInt(value, fallback) {
      var n = Number(value);
      if (!Number.isFinite(n) || n <= 0) {
        return fallback;
      }
      return Math.floor(n);
    }
    async function runBypass2(payload) {
      var url = String(payload && payload.url || "").trim();
      if (!url) {
        return failureResult(url, "missing_url");
      }
      var proxyLine = String(payload && payload.proxy || "").trim();
      var desiredUA = String(payload && payload.user_agent || "").trim();
      var headless = payload && payload.headless === true;
      var attempts = positiveInt(payload && payload.max_attempts, 1);
      var result = await openBypass(url, proxyLine, desiredUA, attempts, null, { headless });
      var solved = !isBypassUnresolved(result);
      return toContract(result, payload, solved);
    }
    async function probeBypassPayload(payload) {
      var url = String(payload && payload.url || "").trim();
      var cookieHeader = String(payload && (payload.cookie_header || payload.cookies) || "").trim();
      var userAgent = String(payload && payload.user_agent || "").trim();
      if (!url) {
        return failureResult(url, "missing_url");
      }
      if (!cookieHeader || !userAgent) {
        return failureResult(url, "missing_cached_ticket");
      }
      var proxyLine = String(payload && payload.proxy || "").trim();
      var result = await probeBypass2(url, proxyLine, userAgent, cookieHeader);
      var solved = !isBypassUnresolved(result);
      if (!solved) {
        var fail = toContract(result, payload, false);
        fail.error = "stale_ticket";
        return fail;
      }
      return toContract(result, payload, true);
    }
    module2.exports = { runBypass: runBypass2, probeBypass: probeBypassPayload };
  }
});

// browser_core/internal/bypass/cfbrowser/nodebridge/app.mjs
var import_bridge_runner = __toESM(require_bridge_runner(), 1);
function failure(message) {
  return {
    success: false,
    mode: "browser",
    pass_cookie: "",
    cookie_header: "",
    user_agent: "",
    hostname: "",
    page_title: "",
    error: message
  };
}
async function main() {
  const jsonIndex = process.argv.indexOf("--json");
  if (jsonIndex < 0 || !process.argv[jsonIndex + 1]) {
    console.error("usage: node run.mjs --json '{...}'");
    process.exit(2);
  }
  const payload = JSON.parse(process.argv[jsonIndex + 1]);
  let result;
  try {
    result = payload.probe_only ? await (0, import_bridge_runner.probeBypass)(payload) : await (0, import_bridge_runner.runBypass)(payload);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    result = failure(message);
  }
  process.stdout.write(`${JSON.stringify(result)}
`);
  process.exit(result.success ? 0 : 1);
}
main().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  process.stdout.write(`${JSON.stringify(failure(message))}
`);
  process.exit(1);
});
