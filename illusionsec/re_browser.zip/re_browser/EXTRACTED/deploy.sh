#!/bin/bash
# 自建解题服务部署脚本(从 browser 二进制提取的引擎)
# 用法: ./deploy.sh   # 安装依赖并启动服务
set -e
cd "$(dirname "$0")"

echo "[1/4] 检查依赖..."
command -v node >/dev/null || { echo "需要 node.js (>=18)"; exit 1; }
command -v npm >/dev/null || { echo "需要 npm"; exit 1; }

echo "[2/4] 安装引擎依赖(bytenode/puppeteer-real-browser)..."
(cd nodebridge_embed && npm install --silent)

echo "[3/4] 编译引擎字节码..."
(cd nodebridge_embed && node run.mjs --compile-only 2>&1 | tail -1)

echo "[4/4] 启动解题服务..."
CHROME_PATH="${CHROME_PATH:-$(command -v chromium-browser || command -v chromium || command -v google-chrome || echo '')}"
if [ -z "$CHROME_PATH" ]; then
  echo "警告: 未找到 Chrome/Chromium,请设置 CHROME_PATH 环境变量"
fi
export CHROME_PATH
exec python3 selfhost_bypass_server.py
