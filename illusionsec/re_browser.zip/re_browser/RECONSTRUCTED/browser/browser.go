package main

import (
	"fmt"
	"os"

	"browser_plus/browser_core/internal/app"
	"browser_plus/browser_core/internal/config"
)

func main() {
	cfg, err := config.ParseCliArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		config.PrintUsage()
		os.Exit(1)
	}
	if cfg.Help {
		config.PrintUsage()
		return
	}
	if cfg.Version {
		config.PrintVersion()
		return
	}
	if err := app.Run(cfg); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
