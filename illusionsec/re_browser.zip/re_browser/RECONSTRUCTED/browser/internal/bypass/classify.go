
package bypass

import (
	"net/http"
	"net/url"
	"strings"
)

func classifyHostKey(host string) string {
	if u, err := url.Parse("http://" + host); err == nil {
		if h, _ := urlSplitHostPort(u.Host); h != "" {
			host = h
		}
	}
	return strings.ToLower(strings.TrimSpace(host))
}

func hasCDNFLYGuardPage(body string) bool {
	if strings.Contains(body, "_guard/html.js") {
		return true
	}
	if strings.Contains(body, "/_guard/auto.js") {
		return true
	}
	i := strings.Index(body, "/_guard/")
	if i >= 0 {
		rest := body[i:]
		if j := strings.Index(rest, ".js"); j >= 0 && j < 200 {
			return true
		}
	}
	return false
}

func needsBrowserWAF(body string) bool {
	
	for _, marker := range []string{"5_sec_checking", "cdnfly", "waf"} {
		if strings.Contains(strings.ToLower(body), marker) {
			return true
		}
	}
	return false
}

func isCloudflareChallenge(resp *http.Response, body string) bool {
	s := strings.ToLower(body)
	if strings.Contains(s, "cloudflare") {
		return true
	}
	if strings.Contains(strings.ToLower(resp.Header.Get("Server")), "cloudflare") {
		return true
	}
	return false
}

func hasCFBodyMarker(body string) bool {
	return strings.Contains(body, "cf-chl")
}

func classifyResponseHeadersOnly(resp *http.Response) string {
	h := strings.ToLower(resp.Header.Get("Server"))
	if strings.Contains(h, "cloudflare") {
		return "cloudflare"
	}
	if strings.Contains(h, "cdnfly") || strings.Contains(h, "waf") {
		return "cdnfly"
	}
	if resp.StatusCode == 503 && resp.Header.Get("Set-Cookie") != "" {
		return "cdnfly"
	}
	return "unknown"
}

func classifyResponse(resp *http.Response, body string) string {
	if hasCDNFLYGuardPage(body) || needsBrowserWAF(body) {
		return "cdnfly"
	}
	if isCloudflareChallenge(resp, body) {
		return "cloudflare"
	}
	if hasCFBodyMarker(body) {
		return "cloudflare"
	}
	return classifyResponseHeadersOnly(resp)
}
