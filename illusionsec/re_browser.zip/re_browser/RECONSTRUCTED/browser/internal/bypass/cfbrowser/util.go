package cfbrowser

import "os"

func getenv(k string) string { return os.Getenv(k) }

func homeDir() (string, error) { return os.UserHomeDir() }

func tmpDir() string { return os.TempDir() }
