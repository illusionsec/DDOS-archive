package cfbrowser

import (
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"
	"sync"
)

type Result struct {
	Success      bool   `json:"success"`
	Mode         string `json:"mode"`
	PassCookie   string `json:"pass_cookie"`
	CookieHeader string `json:"cookie_header"`
	UserAgent    string `json:"user_agent"`
	Hostname     string `json:"hostname"`
	PageTitle    string `json:"page_title"`
	Error        string `json:"error"`
}

var (
	mu     sync.Mutex
	active []*exec.Cmd
)

func cacheDir() string {
	if v := envOr("BROWSER_BYPASS_CACHE_DIR"); v != "" {
		return v
	}
	if home, err := homeDir(); err == nil {
		return home + "/.browser_bypass"
	}
	return tmpDir() + "/.browser_bypass"
}

func nodeBridgeRoot() string {
	return "nodebridge_embed"
}

func RunSeed(payload map[string]any) (Result, error) {
	bin := "node"
	args, _ := json.Marshal(payload)
	cmd := exec.Command(bin, "run.mjs", "--json", string(args))
	cmd.Dir = nodeBridgeRoot()
	out, err := cmd.CombinedOutput()
	if err != nil && len(out) == 0 {
		return Result{}, err
	}
	return parseBridgeResult(string(out))
}

func parseBridgeResult(output string) (Result, error) {
	for _, line := range strings.Split(output, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "{") {
			var r Result
			if err := json.Unmarshal([]byte(line), &r); err == nil {
				return r, nil
			}
		}
	}
	return Result{}, fmt.Errorf("browser bridge: no json output")
}

func KillAllBridgeProcesses() {
	mu.Lock()
	defer mu.Unlock()
	for _, c := range active {
		if c.Process != nil {
			_ = c.Process.Kill()
		}
	}
	active = nil
}

func envOr(k string) string { return getenv(k) }
