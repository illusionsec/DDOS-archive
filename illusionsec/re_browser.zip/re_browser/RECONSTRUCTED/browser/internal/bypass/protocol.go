
package bypass

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"strconv"
	"strings"

	"browser_plus/browser_core/internal/paths"
	"time"
)

func bypassAPIBaseFromEnv() string {
	v := os.Getenv("CDNFLY_API_URL")
	if v == "" {
		v = "http://127.0.0.1:8765"
	}
	return strings.TrimRight(v, "/")
}

func isLocalBypassAPI(raw string) bool {
	raw = strings.TrimSpace(raw)
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}
	host, _ := urlSplitHostPort(u.Host)
	host = strings.ToLower(host)
	switch host {
	case "::1", "127.0.0.1", "localhost":
		return true
	}
	return false
}

func localBypassAPIPort() int {
	if v := os.Getenv("CDNFLY_API_PORT"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	u, err := url.Parse("http://127.0.0.1:8765")
	if err == nil {
		_, port := urlSplitHostPort(u.Host)
		if n, err := strconv.Atoi(port); err == nil && n > 0 {
			return n
		}
	}
	return 8765
}

func ProxyLineToArg(line string) string {
	line = strings.TrimSpace(line)
	if line == "" {
		return ""
	}
	if strings.Contains(line, "@") {
		return line
	}
	if u, err := parseHTTPProxy(line); err == nil && u != nil && u.User != nil {
		user := u.User.Username()
		pass, _ := u.User.Password()
		return user + ":" + pass + "@" + u.Host
	}
	return line
}

func bypassScriptPath() string {
	return paths.CDNFLYBypassScript()
}

type taskPollResponse struct {
	Status       string       `json:"status"`
	BypassResult BypassResult `json:"result,omitempty"`
}

type asyncSubmitResponse struct {
	TaskID string `json:"task_id"`
	Error  string `json:"error"`
}

func postBypassAPISync(baseURL string, payload map[string]any, timeout time.Duration) (BypassResult, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	url := baseURL + "/bypass"
	status, body, err := httpRequest(ctx, "POST", url, payload, timeout)
	if err != nil {
		return BypassResult{}, err
	}
	return parseBypassResponse(status, body)
}

func parseBypassResponse(status int, body []byte) (BypassResult, error) {
	if len(body) == 0 {
		return BypassResult{}, fmt.Errorf("bypass api invalid response: empty")
	}
	var resp asyncSubmitResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return BypassResult{}, fmt.Errorf("bypass api invalid response: %s", string(body))
	}
	if resp.Error != "" {
		return BypassResult{}, fmt.Errorf("bypass api server error: %d", status)
	}
	return BypassResult{}, nil
}

func pollBypassTask(baseURL, taskID string, overallTimeout time.Duration) (BypassResult, error) {
	deadline := time.Now().Add(overallTimeout)
	url := baseURL + "/bypass/tasks/" + taskID + "?wait=25"
	for {
		if time.Now().After(deadline) {
			return BypassResult{}, fmt.Errorf("CDNFLY task timeout: %s", taskID)
		}
		timeout := 35 * time.Second
		if until := time.Until(deadline); until < timeout {
			timeout = until
		}
		if timeout < 1 {
			return BypassResult{}, fmt.Errorf("CDNFLY task timeout: %s", taskID)
		}
		status, body, err := httpRequest(context.Background(), "GET", url, nil, timeout)
		if err != nil {
			time.Sleep(500 * time.Millisecond)
			continue
		}
		var resp taskPollResponse
		if err := json.Unmarshal(body, &resp); err != nil {
			s := string(body)
			if len(s) > 200 {
				s = s[:200]
			}
			return BypassResult{}, fmt.Errorf("CDNFLY task poll invalid response: %s", s)
		}
		switch resp.Status {
		case "done":
			if status > 499 {
				return BypassResult{}, fmt.Errorf("CDNFLY api server error: %d", status)
			}
			return resp.BypassResult, nil
		case "failed":
			msg := resp.BypassResult.Error
			if msg == "" {
				msg = "task_failed"
			}
			return BypassResult{}, fmt.Errorf("CDNFLY task failed: %s", msg)
		case "pending", "running":
			continue
		default:
			return BypassResult{}, fmt.Errorf("CDNFLY task unknown status: %s", resp.Status)
		}
	}
}

func postBypassAPI(baseURL string, payload map[string]any, timeout time.Duration) (BypassResult, error) {
	payload["mode"] = "async"
	resp, err := postBypassAPISync(baseURL, payload, timeout)
	if err != nil {
		return BypassResult{}, err
	}
	_ = resp
	return pollBypassTask(baseURL, respTaskID(resp), timeout)
}

func EnsureBypassApi() error {
	base := bypassAPIBaseFromEnv()
	if err := waitForHealth(base, 10*time.Second); err == nil {
		return nil
	}
	if !isLocalBypassAPI(base) {
		if os.Getenv("CDNFLY_AUTO_START") == "0" {
			return fmt.Errorf("CDNFLY bypass API offline at %s (CDNFLY_AUTO_START=0)", base)
		}
		return fmt.Errorf("CDNFLY bypass API offline at %s", base)
	}
	return startLocalAPIServer()
}

func waitForHealth(base string, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if CheckHealth(base) {
			return nil
		}
		time.Sleep(time.Second)
	}
	return fmt.Errorf("CDNFLY bypass API not ready: %s", base)
}

