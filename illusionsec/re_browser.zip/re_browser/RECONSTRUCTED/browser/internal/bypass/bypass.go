
package bypass

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"time"
)

type Provider string

const (
	ProviderAuto       Provider = "auto"
	ProviderCloudflare Provider = "cloudflare"
	ProviderCDNFLY     Provider = "cdnfly"
	ProviderNone       Provider = "none"
	ProviderBrowser    Provider = "browser"
	ProviderTurnstile  Provider = "turnstile"
	ProviderStealth    Provider = "stealth"
)

type BypassResult struct {
	Status       string   `json:"status"`
	Success      bool     `json:"success"`
	PassCookie   string   `json:"pass_cookie,omitempty"`
	CookieHeader string   `json:"cookie_header,omitempty"`
	Mode         string   `json:"mode"`
	Error        string   `json:"error"`
	Cookies      []Cookie `json:"cookies,omitempty"`
	UserAgent    string   `json:"user_agent,omitempty"`
	PageTitle    string   `json:"page_title,omitempty"`
	Hostname     string   `json:"hostname,omitempty"`
	Runs         int      `json:"runs,omitempty"`
	TurnstileTkn string   `json:"turnstile_token,omitempty"`
	RoundDelay   int      `json:"round_delay,omitempty"`
	ReadyTitle   string   `json:"ready_title,omitempty"`
	ReadySel     string   `json:"ready_selector,omitempty"`
}

type Cookie struct {
	Name  string `json:"name"`
	Value string `json:"value"`
}

type CachedTicket struct {
	Hostname   string    `json:"hostname"`
	UserAgent  string    `json:"user_agent"`
	PageTitle  string    `json:"page_title"`
	ObtainedAt time.Time `json:"obtained_at"`
	PassCookie string    `json:"pass_cookie"`
}

func httpRequest(ctx context.Context, method, url string, payload any, timeout time.Duration) (int, []byte, error) {
	var body *bytes.Reader
	if payload != nil {
		b, err := json.Marshal(payload)
		if err != nil {
			return 0, nil, err
		}
		body = bytes.NewReader(b)
	} else {
		body = bytes.NewReader(nil)
	}
	req, err := http.NewRequestWithContext(ctx, method, url, body)
	if err != nil {
		return 0, nil, err
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{Timeout: timeout}
	resp, err := client.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return resp.StatusCode, nil, err
	}
	return resp.StatusCode, data, nil
}

func CheckHealth(base string) bool {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	status, data, err := httpRequest(ctx, "GET", base+"/health", nil, 5*time.Second)
	if err != nil || status >= 500 {
		return false
	}
	var h map[string]any
	if err := json.Unmarshal(data, &h); err != nil {
		return false
	}
	ok, _ := h["ok"].(bool)
	return ok
}

func startLocalAPIServer() error {
	port := localBypassAPIPort()
	cmd := exec.Command(bypassScriptPath(), "--compile-only")
	cmd.Env = os.Environ()
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("CDNFLY bypass API not ready: %s", err)
	}
	base := fmt.Sprintf("http://127.0.0.1:%d", port)
	return waitForHealth(base, 30*time.Second)
}

func respTaskID(resp BypassResult) string {
	if resp.Error != "" {
		return ""
	}
	return resp.Status
}
