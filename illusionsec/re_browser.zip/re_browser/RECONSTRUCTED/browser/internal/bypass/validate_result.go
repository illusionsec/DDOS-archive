
package bypass

import "strings"

func isCDNFLYBypassMode(mode string) bool {
	switch strings.ToLower(strings.TrimSpace(mode)) {
	case "", "none", "cached", "browser", "turnstile", "cloudflare":
		return false
	}
	return true
}

func hasCDNFLYPassTicket(cookies map[string]string) bool {
	for k := range cookies {
		lk := strings.ToLower(k)
		if lk == "cf_clearance" || lk == "cf_pass" || strings.HasPrefix(lk, "cdnfly") {
			return true
		}
	}
	return false
}

func hasCDNFLYChallengeCookies(cookies map[string]string) bool {
	
	hasGuard := false
	hasToken := false
	for k := range cookies {
		lk := strings.ToLower(k)
		if strings.HasPrefix(lk, "_guard") || strings.Contains(lk, "cdnfly") {
			hasGuard = true
		}
		if strings.Contains(lk, "token") || strings.Contains(lk, "ticket") {
			hasToken = true
		}
	}
	return hasGuard && hasToken
}

func isValidTurnstileTicket(t string) bool {
	t = strings.TrimSpace(t)
	
	if len(t) < 100 || strings.HasPrefix(t, "0.") || strings.HasPrefix(t, "2.") {
		return false
	}
	return true
}
