
package bypass

import (
	"net"

	"browser_plus/browser_core/internal/proxy"
	"net/url"
	"strconv"
	"strings"
)

func NormalizeProvider(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "", "auto":
		return "auto"
	case "cf", "prb", "cloudflare":
		return "cloudflare"
	case "cdnfly":
		return "cdnfly"
	case "none":
		return "none"
	case "browser":
		return "browser"
	case "turnstile":
		return "turnstile"
	case "stealth":
		return "stealth"
	}
	return s
}

func urlSplitHostPort(hostport string) (string, string) {
	h, p, err := net.SplitHostPort(hostport)
	if err != nil {
		return hostport, ""
	}
	return h, p
}

func parseHTTPProxy(s string) (*url.URL, error) {
	return proxy.ParseHTTPProxy(s)
}

func atoi(s string) (int, error) { return strconv.Atoi(s) }
