

package bypass

import (
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

func TargetHost(raw string) string {
	host := strings.TrimSpace(raw)
	if u, err := url.Parse(raw); err == nil {
		if h, _ := urlSplitHostPort(u.Host); h != "" {
			host = h
		}
	}
	return strings.ToLower(strings.TrimSpace(host))
}

func cookieCacheKey(target string) string {
	return TargetHost(target)
}

type CookieCache struct {
	mu       sync.Mutex
	entries  map[string]*cacheEntry
	filePath string
	dirty    bool
}

type cacheEntry struct {
	ticket    CachedTicket
	runCount  int
	persistAt time.Time
}

type storedTicketFile struct {
	PollURL  string         `json:"poll_url"`
	Tickets  []CachedTicket `json:"tickets"`
	SavedAt  time.Time      `json:"saved_at"`
}

func OpenCookieCache(dir string) (*CookieCache, error) {
	cc := &CookieCache{
		entries:  make(map[string]*cacheEntry),
		filePath: filepath.Join(dir, "CDNFLY_tickets.json"),
	}
	if err := cc.loadFromFile(); err != nil && !os.IsNotExist(err) {
		return nil, err
	}
	return cc, nil
}

func (cc *CookieCache) loadFromFile() error {
	data, err := os.ReadFile(cc.filePath)
	if err != nil {
		return err
	}
	var f storedTicketFile
	if err := json.Unmarshal(data, &f); err != nil {
		return fmt.Errorf("cookie cache parse: %w", err)
	}
	cc.mu.Lock()
	defer cc.mu.Unlock()
	for _, t := range f.Tickets {
		cc.entries[strings.ToLower(t.Hostname)] = &cacheEntry{ticket: t}
	}
	return nil
}

func (cc *CookieCache) CountForTarget(target string) int {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	if e, ok := cc.entries[cookieCacheKey(target)]; ok {
		return e.runCount
	}
	return 0
}

func (cc *CookieCache) beginRun(target string) {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	k := cookieCacheKey(target)
	e, ok := cc.entries[k]
	if !ok {
		e = &cacheEntry{}
		cc.entries[k] = e
	}
	e.runCount++
}

func (cc *CookieCache) endRun(target string) {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	if e, ok := cc.entries[cookieCacheKey(target)]; ok && e.runCount > 0 {
		e.runCount--
	}
}

func (cc *CookieCache) Get(target string) CachedTicket {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	if e, ok := cc.entries[cookieCacheKey(target)]; ok {
		return e.ticket
	}
	return CachedTicket{}
}

func (cc *CookieCache) Put(target string, t CachedTicket) {
	cc.mu.Lock()
	k := cookieCacheKey(target)
	cc.entries[k] = &cacheEntry{ticket: t}
	cc.dirty = true
	cc.mu.Unlock()
	cc.schedulePersistLocked()
}

func (cc *CookieCache) Delete(target string) {
	cc.mu.Lock()
	delete(cc.entries, cookieCacheKey(target))
	cc.dirty = true
	cc.mu.Unlock()
}

func (cc *CookieCache) Flush() error {
	return cc.persistNow()
}

func (cc *CookieCache) schedulePersistLocked() {
	go func() {
		time.Sleep(2 * time.Second)
		_ = cc.persistNow()
	}()
}

func (cc *CookieCache) persistNow() error {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	if !cc.dirty {
		return nil
	}
	var f storedTicketFile
	for _, e := range cc.entries {
		f.Tickets = append(f.Tickets, e.ticket)
	}
	f.SavedAt = time.Now()
	data, err := json.MarshalIndent(&f, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(cc.filePath), 0755); err != nil {
		return err
	}
	if err := os.WriteFile(cc.filePath, data, 0644); err != nil {
		return err
	}
	cc.dirty = false
	return nil
}

func CachedTicketFromResult(target string, r BypassResult) CachedTicket {
	return CachedTicket{
		Hostname:   TargetHost(target),
		UserAgent:  r.UserAgent,
		PageTitle:  r.PageTitle,
		ObtainedAt: time.Now(),
		PassCookie: cookieHeaderFrom(r.Cookies),
	}
}

func cookieHeaderFrom(cs []Cookie) string {
	var sb strings.Builder
	for i, c := range cs {
		if i > 0 {
			sb.WriteString("; ")
		}
		sb.WriteString(c.Name + "=" + c.Value)
	}
	return sb.String()
}
