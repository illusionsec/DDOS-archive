package bypass

import (
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"
	"time"
)

func ClassifyTarget(target string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	status, body, err := httpRequest(ctx, "GET", target, nil, 10*time.Second)
	if err != nil {
		return "cdnfly"
	}
	return classifyResponseFromParts(status, body)
}

func classifyResponseFromParts(status int, body []byte) string {
	s := string(body)
	if hasCDNFLYGuardPage(s) || needsBrowserWAF(s) {
		return "cdnfly"
	}
	if strings.Contains(strings.ToLower(s), "cloudflare") || hasCFBodyMarker(s) {
		return "cloudflare"
	}
	if status == 503 {
		return "cdnfly"
	}
	return "none"
}

func SetClassifiedProvider(p string) string {
	return NormalizeProvider(p)
}

func EnsureApi() error {
	return EnsureBypassApi()
}

func ShutdownApi() {}

func ShutdownBypassApi() {}

func Resolve(target string) string {
	return ClassifyTarget(target)
}

func Probe(target string) string {
	return ClassifyTarget(target)
}

func FormatBypassResponse(r BypassResult) string {
	b, _ := json.Marshal(r)
	return string(b)
}

func BrowserBypass(target, proxy, ua, cookies string) BypassResult {
	cmd := exec.Command("node", nodeBridgePath(), "--json",
		fmt.Sprintf(`{"url":%q,"proxy":%q,"user_agent":%q,"cookie_header":%q}`,
			target, proxy, ua, cookies))
	out, err := cmd.Output()
	if err != nil {
		return BypassResult{Success: false, Error: err.Error()}
	}
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "{") {
			var r BypassResult
			if json.Unmarshal([]byte(line), &r) == nil {
				return r
			}
		}
	}
	return BypassResult{Success: false, Error: "bridge no output"}
}

func BrowserProbe(target, proxy, ua, cookies string) BypassResult {
	return BrowserBypass(target, proxy, ua, cookies)
}

func nodeBridgePath() string {
	return "nodebridge_embed/run.mjs"
}

func ProtocolBypass(target, proxy string) BypassResult {
	base := bypassAPIBaseFromEnv()
	payload := map[string]any{"url": target, "proxy": proxy, "mode": "async"}
	r, err := postBypassAPI(base, payload, 180*time.Second)
	if err != nil {
		return BypassResult{Success: false, Error: err.Error()}
	}
	return r
}

func ProtocolProbe(target, proxy string) BypassResult {
	return ProtocolBypass(target, proxy)
}

func ValidateBypassResult(r BypassResult) bool {
	return r.Success
}

func ValidateBypassFailureReason(r BypassResult) string {
	if r.Error == "" {
		return "unknown"
	}
	return r.Error
}
