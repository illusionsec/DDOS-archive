package nodebin

import (
	"os"
	"path/filepath"
	"strings"
)

func Resolve(baseDir string) string {
	if n := nvmDefaultNode(); n != "" {
		return n
	}
	return "node"
}

func NPM(baseDir string) string {
	if v := os.Getenv("NPM_BIN"); v != "" {
		return v
	}
	return "npm"
}

func nvmDefaultNode() string {
	if dir := os.Getenv("NVM_DIR"); dir != "" {
		entries, err := os.ReadDir(filepath.Join(dir, "versions", "node"))
		if err == nil && len(entries) > 0 {
			for i := len(entries) - 1; i >= 0; i-- {
				if entries[i].IsDir() && strings.HasPrefix(entries[i].Name(), "v") {
					return filepath.Join(dir, "versions", "node", entries[i].Name(), "bin", "node")
				}
			}
		}
	}
	return ""
}
