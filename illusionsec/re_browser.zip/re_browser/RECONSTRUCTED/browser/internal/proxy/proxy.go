
package proxy

import (
	"fmt"
	"net/url"
	"strings"
)

func ParseHTTPProxy(s string) (*url.URL, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, nil
	}
	if strings.Contains(s, "://") {
		u, err := url.Parse(s)
		if err != nil {
			return nil, err
		}
		if u.Scheme == "" {
			u.Scheme = "http"
		}
		return u, nil
	}
	parts := strings.SplitN(s, ":", 4)
	if len(parts) < 2 {
		return nil, fmt.Errorf("invalid proxy: use host:port or host:port:user:pass")
	}
	hostPort := parts[0] + ":" + parts[1]
	if strings.Contains(parts[0], ":") {
		hostPort = "[" + parts[0] + "]:" + parts[1]
	}
	switch len(parts) {
	case 2:
		return &url.URL{Scheme: "http", Host: hostPort}, nil
	case 3:
		return &url.URL{Scheme: "http", Host: hostPort, User: url.User(parts[2])}, nil
	case 4:
		return &url.URL{Scheme: "http", Host: hostPort,
			User: url.UserPassword(parts[2], parts[3])}, nil
	}
	return nil, fmt.Errorf("invalid proxy: use host:port or host:port:user:pass")
}
