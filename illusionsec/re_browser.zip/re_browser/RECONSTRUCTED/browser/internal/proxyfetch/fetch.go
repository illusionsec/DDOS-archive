package proxyfetch

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

func FetchFromURL(rawURL string) ([]string, error) {
	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Get(rawURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return nil, fmt.Errorf("proxy fetch: HTTP %d: %s", resp.StatusCode, rawURL)
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	text := strings.TrimSpace(string(data))
	if strings.HasPrefix(text, "[") || strings.HasPrefix(text, "{") {
		var arr []string
		if err := json.Unmarshal([]byte(text), &arr); err == nil {
			return arr, nil
		}
	}
	if strings.Contains(strings.ToLower(text), "<html") {
		return nil, fmt.Errorf("proxy fetch: response looks like HTML, not a list")
	}
	var out []string
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line != "" && !strings.HasPrefix(line, "#") {
			out = append(out, line)
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("proxy fetch: empty url")
	}
	return out, nil
}
