

package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Config struct {
	Target       string
	Threads      int
	ProxyFile    string
	Rate         float64
	ProxyDur     int
	RunDur       int
	FloodOn      bool

	BypassType string
	BypassURL  string
	ProxyURL   string
	ProxyTime  int
	CookieTTL  int
	Method     string
	Data       string
	Pattern    string
	Referer    string
	Headers    string
	HostIPs    string
	UA         string
	RateReset  string
	Drop       string
	DropProxy  bool
	LogFlooder bool
	Precheck   string
	PrecheckMode string
	PrecheckThreads int
	PrecheckTimeout int
	ProxyFetchRounds  int
	ProxyFetchInterval int
	CookieCacheFile string
	CookieCacheRuns int
	CookieReuse bool
	Protocol  string
	Timeout   int
	Verbose   bool
	PV        bool
	Help      bool
	Version   bool
}

func Default() *Config {
	return &Config{
		Threads: 1, Rate: 1, ProxyDur: 300, RunDur: 3600, FloodOn: true,
		BypassType: envOr("BYPASS_TYPE", "auto"),
		UA:         os.Getenv("L7_UA"),
		Data:       os.Getenv("POST_DATA"),
		Method:     "GET",
		Pattern:    "auto",
		Drop:       "none",
		Protocol:   "auto",
		Timeout:    30,
	}
}

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func ParseCliArgs(args []string) (*Config, error) {
	c := Default()
	if len(args) == 0 {
		c.Help = true
		return c, nil
	}
	pos := []string{}
	i := 0
	next := func() (string, bool) {
		if i+1 < len(args) {
			i++
			return args[i], true
		}
		return "", false
	}
	for i = 0; i < len(args); i++ {
		a := args[i]
		if !strings.HasPrefix(a, "-") {
			pos = append(pos, a)
			continue
		}
		v, _ := next()
		switch strings.TrimPrefix(a, "-") {
		case "help", "h":
			c.Help = true
		case "version", "v":
			c.Version = true
		case "bypass-type":
			c.BypassType = v
		case "bypass-url", "bu":
			c.BypassURL = v
		case "proxy-url":
			c.ProxyURL = v
		case "proxy-time":
			c.ProxyTime = atoiD(v, 0)
		case "cookie-ttl":
			c.CookieTTL = atoiD(v, 0)
		case "method":
			c.Method = v
		case "data":
			c.Data = v
		case "pattern":
			c.Pattern = v
		case "referer":
			c.Referer = v
		case "headers", "headersfile":
			c.Headers = v
		case "host":
			c.HostIPs = v
		case "ua", "u":
			c.UA = v
		case "ratereset":
			c.RateReset = v
		case "drop":
			c.Drop = v
		case "drop-proxy", "dropProxy":
			c.DropProxy = true
		case "log-flooder":
			c.LogFlooder = true
		case "precheck":
			c.Precheck = v
		case "precheck-mode":
			c.PrecheckMode = v
		case "precheck-threads":
			c.PrecheckThreads = atoiD(v, 0)
		case "precheck-timeout":
			c.PrecheckTimeout = atoiD(v, 0)
		case "proxy-fetch-rounds":
			c.ProxyFetchRounds = atoiD(v, 0)
		case "proxy-fetch-interval":
			c.ProxyFetchInterval = atoiD(v, 0)
		case "cookie-cache-file":
			c.CookieCacheFile = v
		case "cookie-cache-runs":
			c.CookieCacheRuns = atoiD(v, 0)
		case "cookie-reuse":
			c.CookieReuse = true
		case "protocol", "p":
			c.Protocol = v
		case "h1":
			c.Protocol = "h1"
		case "h2":
			c.Protocol = "h2"
		case "timeout":
			c.Timeout = atoiD(v, 30)
		case "threads":
			c.Threads = atoiD(v, 1)
		case "rate", "r":
			c.Rate = atofD(v, 1)
		case "pv":
			c.PV = true
		case "verbose":
			c.Verbose = true
		default:
			return nil, fmt.Errorf("flag provided but not defined: -%s", strings.TrimPrefix(a, "-"))
		}
	}
	
	if len(pos) >= 1 {
		c.Target = pos[0]
	}
	if len(pos) >= 2 {
		c.Threads = atoiD(pos[1], c.Threads)
	}
	if len(pos) >= 3 {
		c.ProxyFile = pos[2]
	}
	if len(pos) >= 4 {
		c.Rate = atofD(pos[3], c.Rate)
	}
	if len(pos) >= 5 {
		c.ProxyDur = atoiD(pos[4], c.ProxyDur)
	}
	if len(pos) >= 6 {
		c.RunDur = atoiD(pos[5], c.RunDur)
	}
	if len(pos) >= 7 {
		c.FloodOn = normalizeOnOff(pos[6])
	}
	if c.Target == "" {
		return nil, fmt.Errorf("URL is required.")
	}
	return c, nil
}

func atoiD(s string, def int) int {
	if n, err := strconv.Atoi(strings.TrimSpace(s)); err == nil {
		return n
	}
	return def
}

func atofD(s string, def float64) float64 {
	if f, err := strconv.ParseFloat(strings.TrimSpace(s), 64); err == nil {
		return f
	}
	return def
}

func normalizeOnOff(s string) bool {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "off", "0", "false", "no", "disable":
		return false
	}
	return true
}

func normalizeBypassMode(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "disable", "0", "off", "none":
		return "disable"
	default:
		return strings.ToLower(strings.TrimSpace(s))
	}
}

func PrintVersion() {
	fmt.Fprintln(os.Stdout, "喵喵逆向版  MiaoMiao-RE")
}

func PrintUsage() {
	fmt.Fprintln(os.Stdout, "「 喵喵逆向版browser · 授权已移除 」")
	fmt.Fprintln(os.Stdout, "")
	fmt.Fprintln(os.Stdout, "用法: ./browser 目标 线程 代理 速率 代理时长 运行时长 洪水开关 [可选参数]")
	fmt.Fprintln(os.Stdout, "")
	flags := [][3]string{
				{"-bypass-type", "auto", "后端 auto/CDNFLY/cloudflare/none"},
		{"-bypass-url", "", "Turnstile 绕过页 URL"},
		{"-proxy-url", "", "代理列表 HTTP 接口"},
		{"-proxy-time", "300", "单代理洪水时长(秒)"},
		{"-cookie-ttl", "0", "通过 cookie 有效期"},
		{"-method", "GET", "请求方法"},
		{"-data", "POST_DATA", "POST 体"},
		{"-pattern", "auto", "时序模式 auto/burst/jitter/off"},
		{"-referer", "", "Referer(Random=15 站点随机)"},
		{"-headers", "", "自定义请求头文件"},
		{"-host", "", "l7 直连 IP"},
		{"-ua", "L7_UA", "浏览器 UA"},
		{"-ratereset", "off", "429 自动降速"},
		{"-drop", "none", "403/429 处理"},
		{"-drop-proxy", "", "代理丢弃"},
		{"-log-flooder", "", "打印 Flooder 命令行"},
		{"-precheck", "on", "代理预检"},
		{"-precheck-mode", "", "预检模式"},
		{"-proxy-fetch-rounds", "2", "代理拉取轮数"},
		{"-proxy-fetch-interval", "3", "接口刷新间隔"},
		{"-cookie-cache-file", "", "cookie 缓存文件"},
		{"-cookie-cache-runs", "", "cookie 复用次数"},
		{"-cookie-reuse", "", "磁盘复用"},
		{"-protocol", "auto", "h1/h2/auto"},
		{"-timeout", "30", "超时(ms)"},
		{"-pv", "", "代理预检详情"},
		{"-verbose", "", "逐条打印失败"},
		{"-help", "", "帮助"},
		{"-version", "", "版本"},
	}
	for _, f := range flags {
		fmt.Fprintf(os.Stdout, "  %-22s %-10s %s\n", f[0], f[1], f[2])
	}
}
