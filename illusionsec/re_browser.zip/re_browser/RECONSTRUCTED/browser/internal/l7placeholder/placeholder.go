package l7placeholder

import (
	"math/rand/v2"
	"strconv"
	"strings"
)

const (
	charsetAlnum = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	charsetAlpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	charsetDigit = "0123456789"
)

func GenerateRandomString(n int, charset string) string {
	b := make([]byte, n)
	for i := range b {
		b[i] = charset[rand.Uint64N(uint64(len(charset)))]
	}
	return string(b)
}

func RandAllSeq(n int) string { return GenerateRandomString(n, charsetAlnum) }
func RandIntSeq(n int) string { return GenerateRandomString(n, charsetDigit) }
func RandStrSeq(n int) string { return GenerateRandomString(n, charsetAlpha) }

func NormalizeSyntax(s string) string {
	s = strings.ReplaceAll(s, "［", "[")
	s = strings.ReplaceAll(s, "］", "]")
	return s
}

func HasPlaceholder(s string) bool {
	if strings.IndexByte(s, '[') >= 0 || strings.IndexByte(s, ']') >= 0 {
		return true
	}
	return strings.IndexAny(s, "［］") >= 0
}

func Replace(s string) string {
	if !HasPlaceholder(s) {
		return s
	}
	s = NormalizeSyntax(s)
	var b strings.Builder
	for i := 0; i < len(s); {
		if s[i] != '[' {
			b.WriteByte(s[i])
			i++
			continue
		}
		end := strings.IndexByte(s[i+1:], ']')
		if end < 0 {
			b.WriteByte(s[i])
			i++
			continue
		}
		inner := s[i+1 : i+1+end]
		if repl, ok := expand(inner); ok {
			b.WriteString(repl)
			i += end + 2
		} else {
			b.WriteByte(s[i])
			i++
		}
	}
	return b.String()
}

func expand(inner string) (string, bool) {
	low := strings.ToLower(inner)
	gen := func(f func(int) string) (string, bool) {
		if idx := strings.IndexByte(inner, ':'); idx >= 0 {
			if v, err := strconv.Atoi(inner[idx+1:]); err == nil && v > 0 {
				if v > 4096 {
					v = 4096
				}
				return f(v), true
			}
			return f(8), true
		}
		n := 0
		for n < len(inner) && inner[n] >= '0' && inner[n] <= '9' {
			n++
		}
		if n > 0 {
			if v, err := strconv.Atoi(inner[:n]); err == nil && v >= 0 {
				return f(v), true
			}
		}
		return "", false
	}
	if strings.HasPrefix(low, "rand") {
		return gen(RandAllSeq)
	}
	if strings.HasPrefix(low, "int") {
		return gen(RandIntSeq)
	}
	if strings.HasPrefix(low, "str") {
		return gen(RandStrSeq)
	}
	if strings.HasPrefix(low, "email") {
		dom := ""
		if strings.HasPrefix(low, "email:") {
			dom = inner[6:]
		}
		if dom == "" {
			dom = "gmail.com"
		}
		return RandStrSeq(8) + "@" + dom, true
	}
	if strings.HasPrefix(low, "phone") {
		return "1" + string(byte(rand.Uint64N(7))+'3') + RandIntSeq(9), true
	}
	return "", false
}
