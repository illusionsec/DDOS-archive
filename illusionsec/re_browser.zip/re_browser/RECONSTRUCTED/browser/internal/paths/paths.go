
package paths

import (
	"os"
	"path/filepath"
)

func CDNFLYBypassScript() string {
	p := filepath.Join("cdnfly_bypass", "cdnfly_bypass.py")
	if _, err := os.Stat(p); err == nil {
		return p
	}
	return p
}

func ResolveFromRoot(name string) string {
	if exe, err := os.Executable(); err == nil {
		p := filepath.Join(filepath.Dir(exe), name)
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return name
}
