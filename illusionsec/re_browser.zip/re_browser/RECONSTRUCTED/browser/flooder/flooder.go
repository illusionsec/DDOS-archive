package flooder

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

var (
	floodMu     sync.Mutex
	activeProcs []*exec.Cmd
)

func binaryNameForProtocol(protocol string) string {
	switch protocol {
	case "h1":
		return "h1"
	default:
		return "h2"
	}
}

func protocolLabelForLog(protocol string) string {
	switch protocol {
	case "h1":
		return "Flooder h1"
	default:
		return "Flooder h2"
	}
}

func resolveFlooderBinary(protocol string) string {
	name := binaryNameForProtocol(protocol)
	if exe, err := os.Executable(); err == nil {
		p := filepath.Join(filepath.Dir(exe), name)
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	if p, err := exec.LookPath(name); err == nil {
		return p
	}
	return name
}

func buildFlooderArgs(url, method, referer, ua, proxy, data, headers, host, ratereset, dropProxy, pattern string, rps float64, timeSec int, cookies string) []string {
	args := []string{"-url", url, "-method", method, "-rps", strconv.FormatFloat(rps, 'f', -1, 64), "-time", strconv.Itoa(timeSec)}
	if cookies != "" {
		args = append(args, "-cookies", cookies)
	}
	if ua != "" {
		args = append(args, "-ua", ua)
	}
	if proxy != "" {
		args = append(args, "-proxy", proxy)
	}
	if data != "" {
		args = append(args, "-data", data)
	}
	if headers != "" {
		args = append(args, "-headers", headers)
	}
	if host != "" {
		args = append(args, "-host", host)
	}
	if referer != "" {
		args = append(args, "-referer", referer)
	}
	if ratereset != "" {
		args = append(args, "-ratereset", ratereset)
	}
	if dropProxy != "" {
		args = append(args, "-dropProxy", dropProxy)
	}
	if pattern != "" {
		args = append(args, "-pattern", pattern)
	}
	return args
}

func formatFlooderCommand(protocol string, args []string) string {
	return binaryNameForProtocol(protocol) + " " + strings.Join(args, " ")
}

func StartFlooder(protocol, url, method, referer, ua, proxy, data, headers, host, ratereset, dropProxy, pattern string, rps float64, timeSec int, cookies string) (*exec.Cmd, error) {
	bin := resolveFlooderBinary(protocol)
	args := buildFlooderArgs(url, method, referer, ua, proxy, data, headers, host, ratereset, dropProxy, pattern, rps, timeSec, cookies)
	cmd := exec.Command(bin, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	floodMu.Lock()
	activeProcs = append(activeProcs, cmd)
	floodMu.Unlock()
	return cmd, nil
}

func KillAll() {
	floodMu.Lock()
	defer floodMu.Unlock()
	for _, c := range activeProcs {
		if c.Process != nil {
			_ = c.Process.Kill()
		}
	}
	activeProcs = nil
}

func ingestStatsLine(stats map[int]int, line string) {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "{") {
		return
	}
	var m map[string]int
	dec := json.NewDecoder(strings.NewReader(line))
	if err := dec.Decode(&m); err != nil {
		return
	}
	for k, v := range m {
		if n, err := strconv.Atoi(k); err == nil {
			stats[n] += v
		}
	}
}

func recordRateEventLine(sb *strings.Builder, line string) {
	sc := bufio.NewScanner(strings.NewReader(line))
	for sc.Scan() {
		t := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(t, "{") {
			sb.WriteString(t)
			sb.WriteString("\n")
		}
	}
}

func LogBypassSummaryPanel(lines []string) {
	fmt.Println(strings.Join(lines, "\n"))
}
