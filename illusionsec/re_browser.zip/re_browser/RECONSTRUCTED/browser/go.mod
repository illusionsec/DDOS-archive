module browser_plus/browser_core

go 1.25
