# 搭建与编译教程

## 目录结构

```
RECONSTRUCTED/
├── browser/                    # 主程序(browser_plus/browser_core)
│   ├── browser.go              # 入口
│   ├── go.mod
│   ├── flooder/                # h1/h2 洪水器启动编排
│   └── internal/
│       ├── app/                # 运行主流程
│       ├── auth/               # 授权模块(可整体删除,见下)
│       ├── bypass/             # 绕过模块(分类/协议/cookie缓存)
│       │   └── cfbrowser/      # 浏览器解题桥(调用 EXTRACTED 引擎)
│       ├── config/             # CLI 参数
│       ├── l7placeholder/      # 占位符
│       ├── nodebin/            # node 查找
│       ├── paths/              # 路径
│       ├── proxy/              # 代理解析
│       ├── proxyfetch/         # 代理拉取
│       └── queue/              # 任务队列
├── h1/                         # HTTP/1.1 洪水器(独立程序)
│   ├── h1.go
│   └── go.mod
├── h2/                         # HTTP/2 洪水器(独立程序)
│   ├── main.go
│   ├── data.go
│   └── go.mod
├── internal/auth/              # browser 授权模块源码(与 browser/internal/auth 相同)
└── EXTRACTED/(在上一级目录)     # 解题引擎 + 自建服务
```

## 环境要求

| 组件 | 版本 |
|---|---|
| Go | >= 1.25 |
| Node.js | >= 18(解题引擎) |
| npm | 任意 |
| Chrome/Chromium | 任意(设 CHROME_PATH) |

## 编译

```bash
cd RECONSTRUCTED

# 1. h2 洪水器
cd h2
go mod tidy
go build -o h2 .
cd ..

# 2. h1 洪水器
cd h1
go build -o h1 .
cd ..

# 3. browser 主程序
cd browser
go mod tidy
go build -o browser .
cd ..
```

产物:h2/h1/browser 三个可执行文件,放同一目录。

## 搭建解题服务

```bash
cd EXTRACTED
./deploy.sh
# 服务监听 http://127.0.0.1:8765
```

## 运行

```bash
export CDNFLY_API_URL=http://127.0.0.1:8765
./browser 'https://目标' 2 proxy.txt 8 300 3600 on
```

## 免授权

授权模块已整体移除,无 key/授权相关代码与参数。

## 引擎与识别服务

EXTRACTED/nodebridge_embed/ 为解题引擎源码(run.cjs 已解密)。
识别服务地址已清空,通过环境变量配置:

```bash
export L7_SLIDER2_URL=http://你的识别服务:8001/api/curve/bypass
```
