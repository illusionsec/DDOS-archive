
package main

var profilePool = []browserProfile{
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"149\", \"Google Chrome\";v=\"149\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"149.0.7827.54\", \"Google Chrome\";v=\"149.0.7827.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"149\", \"Google Chrome\";v=\"149\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"149.0.7827.54\", \"Google Chrome\";v=\"149.0.7827.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"macOS\"", platformVer: "\"15.0.0\"", arch: "\"arm\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"149\", \"Google Chrome\";v=\"149\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"149.0.7827.54\", \"Google Chrome\";v=\"149.0.7827.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Linux\"", platformVer: "\"6.8.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"148\", \"Google Chrome\";v=\"148\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"148.0.7778.254\", \"Google Chrome\";v=\"148.0.7778.254\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"148\", \"Google Chrome\";v=\"148\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"148.0.7778.254\", \"Google Chrome\";v=\"148.0.7778.254\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"macOS\"", platformVer: "\"15.0.0\"", arch: "\"arm\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"148\", \"Google Chrome\";v=\"148\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"148.0.7778.254\", \"Google Chrome\";v=\"148.0.7778.254\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Linux\"", platformVer: "\"6.8.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"147\", \"Google Chrome\";v=\"147\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"147.0.7450.60\", \"Google Chrome\";v=\"147.0.7450.60\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"147\", \"Google Chrome\";v=\"147\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"147.0.7450.60\", \"Google Chrome\";v=\"147.0.7450.60\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"macOS\"", platformVer: "\"15.0.0\"", arch: "\"arm\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"147\", \"Google Chrome\";v=\"147\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"147.0.7450.60\", \"Google Chrome\";v=\"147.0.7450.60\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Linux\"", platformVer: "\"6.8.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"146\", \"Google Chrome\";v=\"146\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"146.0.7390.54\", \"Google Chrome\";v=\"146.0.7390.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"146\", \"Google Chrome\";v=\"146\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"146.0.7390.54\", \"Google Chrome\";v=\"146.0.7390.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"macOS\"", platformVer: "\"14.6.1\"", arch: "\"arm\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"146\", \"Google Chrome\";v=\"146\", \"Not/A)Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"146.0.7390.54\", \"Google Chrome\";v=\"146.0.7390.54\", \"Not/A)Brand\";v=\"99.0.0.0\"", platform: "\"Linux\"", platformVer: "\"6.5.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"144\", \"Google Chrome\";v=\"144\", \"Not)A;Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"144.0.7339.82\", \"Google Chrome\";v=\"144.0.7339.82\", \"Not)A;Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"144\", \"Google Chrome\";v=\"144\", \"Not)A;Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"144.0.7339.82\", \"Google Chrome\";v=\"144.0.7339.82\", \"Not)A;Brand\";v=\"99.0.0.0\"", platform: "\"macOS\"", platformVer: "\"14.5.0\"", arch: "\"arm\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0", secChUa: "\"Chromium\";v=\"144\", \"Microsoft Edge\";v=\"144\", \"Not)A;Brand\";v=\"99\"", fullVer: "\"Chromium\";v=\"144.0.7339.82\", \"Microsoft Edge\";v=\"144.0.3296.56\", \"Not)A;Brand\";v=\"99.0.0.0\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"133\", \"Not(A:Brand\";v=\"99\", \"Google Chrome\";v=\"133\"", fullVer: "\"Chromium\";v=\"133.0.6943.127\", \"Not(A:Brand\";v=\"99.0.0.0\", \"Google Chrome\";v=\"133.0.6943.127\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"133\", \"Not(A:Brand\";v=\"99\", \"Google Chrome\";v=\"133\"", fullVer: "\"Chromium\";v=\"133.0.6943.127\", \"Not(A:Brand\";v=\"99.0.0.0\", \"Google Chrome\";v=\"133.0.6943.127\"", platform: "\"macOS\"", platformVer: "\"14.4.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0", secChUa: "\"Chromium\";v=\"133\", \"Not(A:Brand\";v=\"99\", \"Microsoft Edge\";v=\"133\"", fullVer: "\"Chromium\";v=\"133.0.6943.127\", \"Not(A:Brand\";v=\"99.0.0.0\", \"Microsoft Edge\";v=\"133.0.3065.82\"", platform: "\"Windows\"", platformVer: "\"15.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36", secChUa: "\"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\", \"Google Chrome\";v=\"131\"", fullVer: "\"Chromium\";v=\"131.0.6778.265\", \"Not_A Brand\";v=\"24.0.0.0\", \"Google Chrome\";v=\"131.0.6778.265\"", platform: "\"Windows\"", platformVer: "\"10.0.0\"", arch: "\"x86\"", bitness: "\"64\"", mobile: "?0"},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0", secChUa: "", fullVer: "", platform: "", platformVer: "", arch: "", bitness: "", mobile: ""},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:147.0) Gecko/20100101 Firefox/147.0", secChUa: "", fullVer: "", platform: "", platformVer: "", arch: "", bitness: "", mobile: ""},
	{ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0", secChUa: "", fullVer: "", platform: "", platformVer: "", arch: "", bitness: "", mobile: ""},
	{ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15", secChUa: "", fullVer: "", platform: "", platformVer: "", arch: "", bitness: "", mobile: ""},
	{ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1", secChUa: "", fullVer: "", platform: "", platformVer: "", arch: "", bitness: "", mobile: ""},
}

var acceptLanguages = []string{
	"en-US,en;q=0.9",
	"en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
	"zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
	"en-GB,en-US;q=0.9,en;q=0.8",
	"ru,en-US;q=0.9,en;q=0.8",
	"de,en-US;q=0.9,en;q=0.8",
	"fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
	"ja,en-US;q=0.9,en;q=0.8",
	"ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
	"es-ES,es;q=0.9,en;q=0.8",
	"pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
	"zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7",
}

var emailDomains = []string{
	"gmail.com",
	"outlook.com",
	"yahoo.com",
	"hotmail.com",
	"icloud.com",
	"qq.com",
	"163.com",
	"126.com",
	"foxmail.com",
}