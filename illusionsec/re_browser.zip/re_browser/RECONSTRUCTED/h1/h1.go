

package main

import (
	"flag"
	"fmt"
	"io"
	"math/rand/v2"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const scriptExpiry = "2026-08-10 12:00:00"

var (
	urlFlag     = flag.String("url", "", "目标 URL")
	methodFlag  = flag.String("method", "GET", "请求方法")
	cookiesFlag = flag.String("cookies", "", "固定 cookie 串")
	uaFlag      = flag.String("ua", "", "UA(空则 Go 默认)")
	proxyFlag   = flag.String("proxy", "", "代理")
	rpsFlag     = flag.Float64("rps", 10.0, "速率")
	hostFlag    = flag.String("host", "", "l7 -host 直连 IP")
	timeFlag    = flag.Int("time", 60, "运行秒数")
	dataFlag    = flag.String("data", "", "POST 体")
	headersFlag = flag.String("headers", "", "头文件")
	refererFlag = flag.String("referer", "", "referer")
)

const (
	charsetAlnum = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	charsetAlpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	charsetDigit = "0123456789"
)

func generateRandomString(n int, charset string) string {
	b := make([]byte, n)
	for i := range b {
		b[i] = charset[rand.Uint64N(uint64(len(charset)))]
	}
	return string(b)
}

func recentTimestamp(minAge, maxAge, unit int64) string {
	now := time.Now().UnixNano() / unit
	ts := now - minAge - int64(rand.Uint64N(uint64(maxAge-minAge)))
	return strconv.FormatInt(ts, 10)
}

var cookieGenerators = []func() string{
	func() string { 
		return "_ga=GA1.2." + randNonZeroIntSeq(10) + "." +
			recentTimestamp(7*24*3600*1e9, 730*24*3600*1e9, 1e9)
	},
	func() string { 
		return "_gid=GA1.2." + randNonZeroIntSeq(10) + "." +
			recentTimestamp(0, 24*3600*1e9, 1e9)
	},
	func() string { 
		return "_ga_" + generateRandomString(10, charsetAlnum) + "=GS1.1." +
			recentTimestamp(300*1e9, 7200*1e9, 1e9) + "." +
			strconv.FormatUint(rand.Uint64()+1, 10)
	},
	func() string { 
		return "PHPSESSID=" + generateRandomString(26, charsetAlnum)
	},
	func() string { 
		return "_fbp=fb.1." + recentTimestamp(0, 90*24*3600*1e6, 1e6) + "." +
			randNonZeroIntSeq(10)
	},
	func() string { 
		return "__cf_bm=" +
			generateRandomString(23, charsetAlnum) + "_" +
			generateRandomString(19, charsetAlnum) + "-" +
			recentTimestamp(0, 300*1e9, 1e9) + "-1-" +
			generateRandomString(4, charsetAlnum) + "/" +
			generateRandomString(65, charsetAlnum) + "+" +
			generateRandomString(16, charsetAlnum) + "="
	},
	func() string { 
		return "csrftoken=" + generateRandomString(64, charsetAlnum)
	},
	func() string { 
		return "cf_clearance=" + generateRandomString(24, charsetAlnum)
	},
	func() string { 
		return "JSESSIONID=" + generateRandomString(32, charsetAlnum) + "; "
	},
	func() string { 
		return "session_id=" + generateRandomString(24, charsetAlnum)
	},
}

func randNonZeroIntSeq(n int) string {
	if n < 1 {
		return ""
	}
	b := make([]byte, n)
	b[0] = byte(rand.Uint64N(9)) + '1'
	for i := 1; i < n; i++ {
		b[i] = charsetDigit[rand.Uint64N(10)]
	}
	return string(b)
}

func generateRealisticCookie() string {
	if rand.Float64() < 0.25 {
		return ""
	}
	n := rand.Uint64N(uint64(len(cookieGenerators))) + 1
	seen := make(map[uint64]bool, n)
	var parts []string
	for uint64(len(parts)) < n {
		i := rand.Uint64N(uint64(len(cookieGenerators)))
		if !seen[i] {
			seen[i] = true
			parts = append(parts, cookieGenerators[i]())
		}
	}
	return strings.Join(parts, "; ")
}

var refererSites = []string{
	"https://www.google.com/", "https://www.google.com/search?q=",
	"https://www.bing.com/search?q=", "https://www.yahoo.com/",
	"https://duckduckgo.com/?q=", "https://www.baidu.com/s?wd=",
	"https://yandex.ru/search/?text=", "https://www.facebook.com/",
	"https://twitter.com/", "https://t.co/", "https://www.reddit.com/",
	"https://www.youtube.com/", "https://www.instagram.com/",
	"https://www.linkedin.com/", "https://www.tiktok.com/",
	"https://www.wikipedia.org/", "https://www.amazon.com/",
}

var (
	reChromeMajor = regexp.MustCompile(`Chrome/(\d+)`)
	reEdgMajor    = regexp.MustCompile(`Edg/(\d+)`)
)

func buildSecChUa(ua string) map[string]string {
	h := map[string]string{}
	var m []string
	if mm := reEdgMajor.FindStringSubmatch(ua); mm != nil {
		m = mm
	} else if mm := reChromeMajor.FindStringSubmatch(ua); mm != nil {
		m = mm
	}
	if m == nil {
		return h
	}
	v := m[1]
	brand := "Google Chrome"
	if strings.Contains(ua, "Edg/") {
		brand = "Microsoft Edge"
	}
	h["Sec-Ch-Ua"] = fmt.Sprintf(
		`"Chromium";v="%s", "%s";v="%s", "Not/A)Brand";v="99"`, v, brand, v)
	h["Sec-Ch-Ua-Mobile"] = "?0"
	switch {
	case strings.Contains(ua, "Windows"):
		h["Sec-Ch-Ua-Platform"] = `"Windows"`
	case strings.Contains(ua, "Macintosh"):
		h["Sec-Ch-Ua-Platform"] = `"macOS"`
	case strings.Contains(ua, "X11"):
		h["Sec-Ch-Ua-Platform"] = `"Linux"`
	}
	return h
}

type statusStats struct {
	total   [1000]atomic.Int64
	current [1000]atomic.Int64
	totErr  atomic.Int64
}

func emitStatsLine(stats *statusStats) {
	h := make(map[int]int)
	for code := 100; code < 1000; code++ {
		n := int(stats.current[code].Swap(0))
		if n > 0 {
			h[code] = n
		}
	}
	var sb strings.Builder
	sb.WriteByte('{')
	first := true
	for k := 100; k < 1000; k++ {
		if v, ok := h[k]; ok {
			if !first {
				sb.WriteByte(',')
			}
			first = false
			sb.WriteString(strconv.Quote(strconv.Itoa(k)))
			sb.WriteByte(':')
			sb.WriteString(strconv.Itoa(v))
		}
	}
	sb.WriteByte('}')
	fmt.Println(sb.String())
}

func main() {
	
	if t, err := time.Parse("2006-01-02 15:04:05", scriptExpiry); err == nil {
		if time.Now().After(t) {
			fmt.Fprintf(os.Stderr, "Script expired on %s\n", scriptExpiry)
		}
	}

	flag.Parse()

	if *urlFlag == "" {
		fmt.Fprintln(os.Stderr, "URL is required.")
		return
	}
	if *rpsFlag <= 0 {
		fmt.Fprintln(os.Stderr, "rps must be > 0")
		return
	}

	
	target := *urlFlag
	u, err := url.Parse(target)
	if err != nil || u.Host == "" {
		fmt.Fprintln(os.Stderr, "invalid url")
		return
	}
	if *hostFlag != "" {
		
	}

	
	staticHeaders := map[string]string{}
	if *headersFlag != "" {
		if data, err := os.ReadFile(*headersFlag); err == nil {
			for _, line := range strings.Split(string(data), "\n") {
				line = strings.TrimSpace(line)
				if line == "" || line[0] == '#' {
					continue
				}
				if i := strings.IndexByte(line, ':'); i > 0 {
					staticHeaders[strings.TrimSpace(line[:i])] =
						strings.TrimSpace(line[i+1:])
				}
			}
		}
	}

	
	body := ""
	if *dataFlag != "" {
		if b, err := os.ReadFile(*dataFlag); err == nil {
			body = string(b)
		} else {
			body = *dataFlag
		}
	}

	client := &http.Client{}
	if *proxyFlag != "" {
		if pu, err := url.Parse(*proxyFlag); err == nil {
			client.Transport = &http.Transport{Proxy: http.ProxyURL(pu)}
		}
	}

	stats := &statusStats{}
	interval := time.Duration(1e9 / *rpsFlag)

	go func() {
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for range t.C {
			emitStatsLine(stats)
		}
	}()

	method := strings.ToUpper(*methodFlag)
	var wg sync.WaitGroup
	sem := make(chan struct{}, 8)
	deadline := time.Now().Add(time.Duration(*timeFlag) * time.Second)

	
	ua := *uaFlag 
	secHeaders := buildSecChUa(ua)

	for time.Now().Before(deadline) {
		select {
		case sem <- struct{}{}:
		default:
			time.Sleep(time.Millisecond)
			continue
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			defer func() { <-sem }()

			req, err := http.NewRequest(method, target, strings.NewReader(body))
			if err != nil {
				stats.totErr.Add(1)
				return
			}
			
			req.Header.Set("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
			req.Header.Set("Accept-Language",
				"zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6")
			req.Header.Set("Cache-Control",
				"no-cache, no-store, must-revalidate, max-age=0")
			req.Header.Set("Pragma", "no-cache")
			req.Header.Set("Upgrade-Insecure-Requests", "1")

			
			cookie := *cookiesFlag
			if cookie == "" {
				cookie = generateRealisticCookie()
			}
			if cookie != "" {
				req.Header.Set("Cookie", cookie)
			}

			
			ref := *refererFlag
			if ref == "" {
				site := refererSites[rand.Uint64N(uint64(len(refererSites)))]
				if strings.HasSuffix(site, "=") {
					site += generateRandomString(int(rand.Uint64N(12))+4, charsetAlpha)
				}
				ref = site
			}
			req.Header.Set("Referer", ref)

			
			if ua != "" {
				req.Header.Set("User-Agent", ua)
			}

			
			if method == "GET" && body == "" {
				req.Header.Set("Sec-Fetch-Mode", "navigate")
				req.Header.Set("Sec-Fetch-User", "?1")
				req.Header.Set("Sec-Fetch-Dest", "document")
			} else {
				req.Header.Set("Sec-Fetch-Mode", "cors")
				req.Header.Set("Sec-Fetch-Dest", "empty")
			}
			req.Header.Set("Sec-Fetch-Site", "same-site")

			
			for k, v := range secHeaders {
				req.Header.Set(k, v)
			}

			
			for k, v := range staticHeaders {
				req.Header.Set(k, v)
			}

			resp, err := client.Do(req)
			if err != nil {
				stats.totErr.Add(1)
				return
			}
			_, _ = io.Copy(io.Discard, resp.Body)
			resp.Body.Close()
			code := resp.StatusCode
			if code >= 1 && code <= 999 {
				stats.total[code].Add(1)
				stats.current[code].Add(1)
			} else {
				stats.totErr.Add(1)
			}
		}()
		time.Sleep(interval)
	}
	wg.Wait()
	emitStatsLine(stats)
	fmt.Fprintf(os.Stderr, "Duration %ds reached, exiting...\n", *timeFlag)
}
