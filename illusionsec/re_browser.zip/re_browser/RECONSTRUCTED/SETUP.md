# 安装

## 引擎依赖(node)

cd EXTRACTED/nodebridge_embed && npm install

依赖(package.json 已声明):bytenode / puppeteer-real-browser / colors / request

## 编译(Go)

cd h2 && go build -o h2 .
cd ../h1 && go build -o h1 .
cd ../browser && go mod tidy && go build -o browser .

## 运行

export CDNFLY_API_URL=http://127.0.0.1:8765
python3 EXTRACTED/selfhost_bypass_server.py &
./browser 'https://目标' 2 proxy.txt 8 300 3600 on
