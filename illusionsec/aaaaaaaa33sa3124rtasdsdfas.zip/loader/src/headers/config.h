#pragma once

#define HTTP_SERVER "206.81.16.233"
#define HTTP_PORT 80

#define TFTP_SERVER "206.81.16.233"
