#pragma once

#define HTTP_SERVER "103.67.244.57"
#define HTTP_PORT 80

#define TFTP_SERVER "103.67.244.57"
