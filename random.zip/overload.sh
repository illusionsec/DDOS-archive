#!/bin/sh
apt install python3-pip && pip install python-socks && pip install async_timeout && pip install user_agent && python3 -m pip install python-socks[asyncio] && echo '>>>>>>>>>>>>>>> FINISH YOU CAN UPLOAD FILES NOW'
