ulimit -n 999999
screen -S cnc ./cnc 9931 9999 750
sh screen.sh