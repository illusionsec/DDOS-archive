#pragma once

#define HTTP_SERVER "45.61.188.189"
#define HTTP_PORT 80

#define TFTP_SERVER "45.61.188.189"
