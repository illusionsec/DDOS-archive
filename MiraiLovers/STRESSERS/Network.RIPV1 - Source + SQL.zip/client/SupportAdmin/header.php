
<?php
require_once '../complex/configuration.php';
require_once '../complex/init.php';
if (!$user -> LoggedIn()){
    header('Location: login.php');
    exit;
}
$userInfoData = $odb->query("SELECT * FROM `users` WHERE `id` = '" . $_SESSION['ID'] . "' LIMIT 1");
$userInfo = $userInfoData->fetch(PDO::FETCH_BOTH);

if(!$userInfo["rank"]==2 || !$userInfo["rank"]==1)
{
    header('Location: login.php');
    exit;
}
function hasBNAccess($db){
	$stmt = $db->prepare("SELECT botnet FROM users WHERE username=:login");
	$stmt->bindParam("login", $_SESSION['username'], PDO::PARAM_STR);
	$stmt->execute();
	$value = $stmt->fetchColumn(0);
	return $value;
}

                                        
$lastactive = $odb -> prepare("UPDATE `users` SET activity=UNIX_TIMESTAMP() WHERE username=:username");
$lastactive -> execute(array(':username' => $_SESSION['username']));

 $onedayago = time() - 86400;

 $twodaysago = time() - 172800;
 $twodaysago_after = $twodaysago + 86400;

 $threedaysago = time() - 259200;
 $threedaysago_after = $threedaysago + 86400;

 $fourdaysago = time() - 345600;
 $fourdaysago_after = $fourdaysago + 86400;

 $fivedaysago = time() - 432000;
 $fivedaysago_after = $fivedaysago + 86400;

 $sixdaysago = time() - 518400;
 $sixdaysago_after = $sixdaysago + 86400;

 $sevendaysago = time() - 604800;
 $sevendaysago_after = $sevendaysago + 86400;
 
 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date");
 $SQL -> execute(array(":date" => $onedayago));
 $count_one = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
 $count_two = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
 $count_three = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
 $count_four = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
 $count_five = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
 $count_six = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
 $count_seven = $SQL->fetchColumn(0);
 
 $date_one = date('d/m/Y', $onedayago);
 $date_two = date('d/m/Y', $twodaysago);
 $date_three = date('d/m/Y', $threedaysago);
 $date_four = date('d/m/Y', $fourdaysago);
 $date_five = date('d/m/Y', $fivedaysago);
 $date_six = date('d/m/Y', $sixdaysago);
 $date_seven = date('d/m/Y', $sevendaysago);

     $plansql = $odb -> prepare("SELECT `users`.`expire`, `plans`.`name`, `plans`.`concurrents`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id");
     $plansql -> execute(array(":id" => $_SESSION['ID']));
     $row = $plansql -> fetch(); 
     $date = date("m-d-Y, h:i:s a", $row['expire']);
     if (!$user->hasMembership($odb)){
         $row['mbt'] = 0;
         $row['concurrents'] = 0;
         $row['name'] = 'No membership';
         $date = '0-0-0';
     }
     
     $SQL = $odb -> prepare("SELECT * FROM `users` WHERE `username` = :usuario");
             $SQL -> execute(array(":usuario" => $_SESSION['username']));
             $balancebyripx = $SQL -> fetch();
             $balance = $balancebyripx['balance'];
     
 
?>
<!doctype html>
<html lang="en" class="no-focus"><!--<![endif]--><head>
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <title><?php echo $sitename; ?> | <?php echo $page; ?></title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon"/>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="ProxyDown is the most reliable stresser on the market. We only use the most dedicated and up-to-date hardware available, and put our focus
          on security and customer safety first. Specializing in powerful layer-4 and layer-7 attacks ProxyDown is the only stresser you'll ever need.">
<meta name="keywords" content="booter, stresser, ip stresser, ip booter, ddoser, ddos tool, ddos, best booter, best stresser, Ark Bypass, minecraft ddos, minecraft stresser, minecraft booter, Ark Bypass, cheap booter, cheap stresser, skype resolver, cloudflare resolver, ssyn, udp, tcp, dns, stress testing">
<meta name="author" content="proxy-down">
<link rel="icon" type="image/" sizes="16x16" href="../assets/images/favicon.ico">
 <!--favicon-->
  <link rel="icon" type="image/" sizes="16x16" href="../assets/images/favicon.ico">
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css">
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css">
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet">
        <script async="" src="http://www.google-analytics.com/analytics.js"></script><script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','http://www.google-analytics.com/analytics.js','ga');ga('create', 'UA-16158021-6', 'auto');ga('send', 'pageview');</script>
</head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="ProxyDown is the most reliable stresser on the market. We only use the most dedicated and up-to-date hardware available, and put our focus
          on security and customer safety first. Specializing in powerful layer-4 and layer-7 attacks ProxyDown is the only stresser you'll ever need.">
<meta name="keywords" content="booter, stresser, ip stresser, ip booter, ddoser, ddos tool, ddos, best booter, best stresser, Ark Bypass, minecraft ddos, minecraft stresser, minecraft booter, Ark Bypass, cheap booter, cheap stresser, skype                  resolver, cloudflare resolver, ssyn, udp, tcp, dns, stress testing">
<meta name="author" content="255stresser">
<link rel="icon" type="image/" sizes="16x16" href="../assets/images/favicon.ico">
 <!--favicon-->
  <link rel="icon" type="image/" sizes="16x16" href="assets/images/favicon.ico">
 <link href="../assets/plugins/fullcalendar/css/fullcalendar.min.css" rel='stylesheet' />
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

<link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet" />

<link href="../assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />

<link href="../assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">

<link href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

<link href="../assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.11.2/css/all.css" integrity="sha384-zrnmn8R8KkWl12rAZFt4yKjxplaDaT7/EUkKm7AovijfrQItFWR7O/JJn4DAa/gx" crossorigin="anonymous">

<link href="assets/plugins/horizontal-timeline/css/horizontal-timeline.css" rel="stylesheet" />

<link href="../assets/plugins/ion-rangeslider/css/ion.rangeSlider.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/ion-rangeslider/css/ion.rangeSlider.skinNice.css" rel="stylesheet" type="text/css" />

<link href="../assets/plugins/vertical-timeline/css/vertical-timeline.css" rel="stylesheet" />

<link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

<link rel="stylesheet" href="../assets/plugins/notifications/css/lobibox.min.css" />

<link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />

<link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

<link href="../assets/plugins/fullcalendar/css/fullcalendar.min.css" rel='stylesheet' />

<link href="../assets/plugins/switchery/css/switchery.min.css" rel="stylesheet" />
<link href="../assets/plugins/bootstrap-switch/bootstrap-switch.min.css" rel="stylesheet">

<link href="../assets/plugins/morris/css/morris.css" rel="stylesheet">

<link href="../assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="../assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

<link href="assets/plugins/ion-rangeslider/css/ion.rangeSlider.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/ion-rangeslider/css/ion.rangeSlider.skinNice.css" rel="stylesheet" type="text/css" />

<link href="../assets/css/animate.css" rel="stylesheet" type="text/css" />

<link href="../assets/css/icons.css" rel="stylesheet" type="text/css" />

<link href="../assets/css/sidebar-menu.css" rel="stylesheet" />

<link href="assets/css/app-style.css" rel="stylesheet" />
<script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
 <link href="assets/toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css">
    <!--Morris JavaScript -->
  <script src="../assets/plugins/raphael/raphael-min.js"></script>
  <script src="../assets/plugins/morris/js/morris.js"></script>
  <script src="../assets/plugins/morris/js/morris-data.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.1/Chart.bundle.js"></script>
<link href="../includes/theme/css/animate.css" rel="stylesheet">
<!--snoww Fail -->
  <script src="//code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="let-it-snow.min.js"></script>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>


<body class="bg-theme bg-theme1">

<!-- start loader -->
   <div id="pageloader-overlay" class="visible incoming snowfall"><div class="loader-wrapper-outer"><div class="loader-wrapper-inner" ><div class="loader"></div></div></div></div>
   <!-- end loader -->
<script>
//js encrypted for security
eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--){d[c]=k[c]||c}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('0=3(2(){1.4(\'5\').7();6(0)},8);',9,9,'SendPop|document|function|setTimeout|getElementById|r|clearTimeout|click|100'.split('|'),0,{}))
</script>
 <div id="wrapper">
 <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="home.php">
       <img src="assets/images/favicon.ico" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">𝙋𝙧𝙤𝙭𝙮𝘿𝙤𝙬𝙣</h5>
     </a>
</div>
   <div class="user-details">
    <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
      <div class="avatar"><img class="mr-3 side-user-img" src="assets/images/avatars/user1.jpg" alt="user avatar"></div>
       <div class="media-body">
       <h6 class="side-user-namehrefdata"-toggle="dropdown" href="#"><b><?php echo ucfirst($_SESSION['username']); ?></b> </a>
      </div>
</div>

 <center>
  <a href="javascript:void(0)" class="link-effect text-dual-primary-dark" onclick="ShowMyIp()">
     <i class="fas fa-eye-slash"> </i>
  </a>
  <a href="javascript:void(0)" class="link-effect text-dual-primary-dark" onclick="logOutByRiPx()">
     <i class="fas fa-power-off"></i>
  </a>
  </center> 

<div id="user-dropdown" class="collapse">
<ul class="user-setting-menu">
      <ul class="user-setting-menu">
      
      <li><a href="javascript:void(0)"><i class="icon-user"></i>Rank: <span class="badge badge-primary shadow-primary m-1"> Visitor</p>
     <li><a href="javascript:void(0)"><i class="icon-settings"></i>Plan name: <span class="sbadge badge-primary shadow-primary m-"><?php echo $row['name']; ?></p>
      <li><a href="javascript:void(0)"><i class="icon-clock"></i>Seconde: <span class="badge badge-primary shadow-primary m-"><?php echo $row['mbt']+$atime; ?></p>
    <li><a href="javascript:void(0)"><i class="fa fa-money"></i>Balance: <span class="badge badge-primary shadow-primary m-1"><?php echo number_format((float)$balance, 2, '.', ''); ?></span></a></li>
    </ul>
</div>
</div>


<ul class="sidebar-menu do-nicescrol">
<li class="sidebar-header">MAIN NAVIGATION</li>
<li><a href="home.php" class="waves-effect"><i class="fad fa-laptop-code" style="color: #0074d3"></i> <span>Dasboard</span></a></li>
<li>

<li><a href="adjustes.php" class="waves-effect"><i class="fad fa-cogs" style="color: red"></i> <span>Settings</span></a></li>
<li>

<li><a href="plansm.php" class="waves-effect"><i class="fad fa-cart-plus text-success" style="color: #0074d3"></i> <span>Plans manager</span></a></li>
<li>

<li><a href="liveattacks.php" class="waves-effect"><i class="fad fa-fire" style="color: red"></i> <span>LiveAttacks</span></a></li>
<li>

<li><a href="blacklist.php" class="waves-effect"><i class="fad fa-syringe" style="color: chartreuse"></i> <span>Blacklist</span></a></li>
<li>

<li><a href="attacklogs.php" class="waves-effect"><i class="fad fa-spider" style="color: red"></i> <span>Attacks Logs</span></a></li>
<li>

<li><a href="loginlogs.php" class="waves-effect"><i class="fa fa-drupal" style="color: yellow"></i> <span>Login Logs</span></a></li>
<li>

<li><a href="news.php" class="waves-effect"><i class="fad fa-bezier-curve" style="color: chartreuse"></i></i> <span>News Manager</span></a></li>
<li>

<li><a href="../home.php" class="waves-effect"><i class="fad fa-laptop-code" style="color: #0074d3"></i> <span>Back Up</span></a></li>
<li>

<?php         
                  $Adminnn = $odb->query("SELECT * FROM `users` WHERE `rank` = '69'");

                  while($rowAdmins = $Adminnn->fetch(PDO::FETCH_BOTH)){
                    $timeoffline = time() - $rowAdmins['activity'];
                                        $conline = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username  AND {$timeoffline} < 60");
                    $conline->execute(array(':username' => $rowAdmins['username']));
                    $onlineripx = $conline->fetchColumn(0);

                            if($rowAdmins['username'] == "error"){
                       $emojis = "";
                    }elseif($rowAdmins['username'] == "error"){
                         $emojis = ""; 
                    }elseif($rowAdmins['username'] == "error"){
                     $emojis = "";
                    }else{
                       $emojis = "";
                    }
                    $logo = "fa fa-ban";
                    if($onlineripx == "1"){  
                                        echo '<li><a href="#"><i class="fa fa-circle-o text-success"></i><span class="sidebar-mini-hide"> [<bb class="text-success">Admin</bb>] '. $rowAdmins['username'] .''.$emojis.'</span></a></li>';
                                        } 
                    else {
                     echo '<li><a href="#"><i class="fa fa-cog text-danger"></i><span class="sidebar-mini-hide"> [<bb class="text-danger">Admin</bb>] '. $rowAdmins['username'].''.$emojis.'</span></a></li>';
                                        }
                  }
                  
                  $Supportt = $odb->query("SELECT * FROM `users` WHERE `rank` = '15'");

                  while($rowSupports = $Supportt->fetch(PDO::FETCH_BOTH)){
                    $timeofflinex = time() - $rowSupports['activity'];
                                        $conlinex = $odb->prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username  AND {$timeofflinex} < 60");
                    $conlinex->execute(array(':username' => $rowSupports['username']));
                    $onlinesupportripx = $conlinex->fetchColumn(0);

                    if($rowSupports['username'] == "BotnetUmbrella"){
                       $emojis = "";
                    }elseif($rowSupports['username'] == "BotnetUmbrella"){
                     $emojis = "";
                    }else{
                       $emojis = "";
                    }
                    
                    $logo = "fa fa-ban";
                    if($onlinesupportripx == "1"){  
                                        echo '<li><a href="#"><i class="fa fa-circle-o text-success"></i><span class="sidebar-mini-hide"> [<bb class="text-success">Mod</bb>] '. $rowSupports['username'] .''.$emojis.'</span></a></li>';
                                        } 
                    else {
                     echo '<li><a href="#"><i class="fa fa-circle-o text-danger"></i><span class="sidebar-mini-hide"> [<bb class="text-danger">Mod</bb>] '. $rowSupports['username'] .''.$emojis.'</span></a></li>';
                                        }
                  }
                ?>
    </span></a></li>          
   </ul>
</div>
<script>
				    window.setInterval(function(){
					var xmlhttp;
					if (window.XMLHttpRequest){
				    xmlhttp = new XMLHttpRequest();
					}
					else{
				    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.open("GET","../ripx/check.php",true);
					xmlhttp.send(); 
					}, 5000);
</script>