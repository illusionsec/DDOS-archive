<?php
date_default_timezone_set('America/New_York');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'fvrhqldbpk3y_13');
	define('DB_USERNAME', 'fvrhqldbpk3y_13');
	define('DB_PASSWORD', 'J5i^i46o');
	define('ERROR_MESSAGE', '<style>
body 
{
	background-color: black;
	color:white;
}
.alert-danger
{
	color:#e400ff;
}
.alert-success
{
	color:lime;
}
</style><span style="color: red;">Zero-Two is Offline maybe Refresh :)');

	try {
		$odb = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD);
	} catch( PDOException $Exception ) {
		error_log('ERROR: '.$Exception->getMessage().' - '.$_SERVER['REQUEST_URI'].' at '.date('l jS \of F, Y, h:i:s A')."\n", 3, 'dedede.log');
		die(ERROR_MESSAGE);
	}

	function error($string){  
		return '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><strong>ERROR:</strong> '.$string.'</div>';
	}

	function success($string) {
		return '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><strong>SUCCESS:</strong> '.$string.'</div>';
	}

?>
