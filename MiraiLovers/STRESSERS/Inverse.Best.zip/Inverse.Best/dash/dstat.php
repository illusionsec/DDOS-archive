<?php

$pagename = "DStat";
include 'header.php';


?>

<div class="main">
    <div class="container mt-5 px-4">
      <div class="row g-4">
        <div class="col-md-12">
        <iframe src="https://dstat.cc/" height="1000" frameborder="2" style="width:100%;" id="iframeIdx"></iframe>
        <audio controls autoplay hidden>
        <source src="song.mp3" type="audio/mpeg">
        </audio>

        </div>
    </div>
</div>



<?php include 'footer.php'; ?>