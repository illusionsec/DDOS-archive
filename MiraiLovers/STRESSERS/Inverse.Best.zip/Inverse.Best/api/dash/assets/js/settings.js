tailwind.config = {
    darkMode: 'class',
    important: true,
}