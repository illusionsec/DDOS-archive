


    <script src="assets/vendor/js/jquery.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>

	<script src="assets/vendor/js/sweetalert2.all.min.js"></script>
	<script type="text/javascript" src="assets/vendor/js/toastify.js"></script>
	<script type="text/javascript" src="assets/vendor/js/jquery.dataTables.min.js"></script>
	
	<script src="assets/js/main.js?v=<?php echo time(); ?>"></script>



</body>
</html>