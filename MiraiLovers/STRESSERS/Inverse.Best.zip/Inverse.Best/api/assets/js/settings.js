tailwind.config = {
    darkMode: 'class',
}