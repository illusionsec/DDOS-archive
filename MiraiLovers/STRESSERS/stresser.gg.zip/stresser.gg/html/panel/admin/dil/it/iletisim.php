<?php

return array (
  'optdesc' => 'È possibile parlare con il servizio clienti CekilisGram 24 ore al giorno tramite supporto live.',
  'optdesc2' => 'The biggest Instagram raffle site in the world.',
  'baslik' => 'Contattaci',
  'isim' => 'Nome cognome',
  'email' => 'E-Mail',
  'mesaj' => 'Il tuo messaggio',
  'gonder' => 'Invia',
  'email2' => 'Non condividiamo mai il tuo indirizzo e-mail con nessuno.',
  'sifre' => 'Parola d\'ordine',
  'sifrenizimi' => 'Hai dimenticato la password?',
  'hala' => 'Non sei un membro?',
  'kayitol' => 'Iscriviti',
  'sifretekrar' => 'Ripeti password',
  'telefon' => 'Numero di telefono',
  'hala2' => 'Sei un membro?',
);
