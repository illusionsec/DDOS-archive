<?php

return array (
  'iletisim' => 'kontakt',
  'cekilis' => 'instagram-lotereyu',
  'cerez' => 'cookies',
  'iade' => 'politika-vozvrata',
  'girisyap' => 'login',
  'gizlilik' => 'politika-konfidentsialnosti',
  'hakkimizda' => 'o-nas',
  'referanslarimiz' => 'ssylki',
  'kurumsal' => 'korporativnyye-svyaz',
  'fiyat' => 'tseny',
  'ozellik' => 'kharakteristiki',
  'kontrol' => 'upravleniya',
  'cekilis1' => 'lotereyu',
  'destek' => 'podderzhka',
);
