<?php

return array (
  'anasayfa' => 'Un sitio de sorteo de Instagram rifa y confiable que puede usar para hacer un sorteo de Instagram. Todos usan este programa de rifa para la rifa de Instagram.',
  'cerez' => 'Puede conocer la política de cookies de Cekilisgram desde esta página.',
  'gizlilik' => 'Puede conocer la política de privacidad de Cekilisgram desde esta página.',
  'hakkimizda' => 'Puede encontrar toda la información sobre CekilisGram.',
  'iletisim' => 'Puede conocer la información de contacto de CekilisGram desde esta página. Número de teléfono de CekilisGram.',
  'iptal' => 'Puede conocer la política de reembolso de Cekilisgram en esta página.',
  'kurumsal' => 'Puede visitar esta página para contactar a CekilisGram institucionalmente.',
  'fiyat' => 'Puede obtener información sobre los precios de la rifa de Instagram y los paquetes de rifa de Instagram en esta página.',
);
