<?php

return array (
  'anasayfa' => 'Un sito di lotteria Instagram gratuito e affidabile che puoi utilizzare per fare lotteria di Instagram. Tutti usano questo programma di lotteria per la lotteria di Instagram.',
  'cerez' => 'Puoi imparare la politica sui cookie di Cekilisgram da questa pagina.',
  'gizlilik' => 'Puoi imparare l\'informativa sulla privacy di Cekilisgram da questa pagina.',
  'hakkimizda' => 'Puoi trovare tutte le informazioni sul CekilisGram.',
  'iletisim' => 'Puoi imparare le informazioni di contatto di CekilisGram da questa pagina. Numero di telefono di CekilisGram.',
  'iptal' => 'Puoi conoscere la politica di rimborso di Cekilisgram in questa pagina.',
  'kurumsal' => 'Puoi visitare questa pagina per contattare CekilisGram istituzionalmente.',
  'fiyat' => 'Puoi trovare informazioni sui prezzi della lotteria di Instagram e sui pacchetti della lotteria di Instagram in questa pagina.',
);
