<?php

return array (
  'optdesc' => 'Usted puede hablar con el servicio al cliente CekilisGram las 24 horas del día a través de soporte en vivo.',
  'optdesc2' => 'El sitio más grande sorteo Instagram en el mundo.',
  'baslik' => 'Contacta con nosotros',
  'isim' => 'Nombre Apellido',
  'email' => 'correo electrónico',
  'mesaj' => 'Tu mensaje',
  'gonder' => 'Enviar',
  'email2' => 'Nunca compartimos su dirección de correo electrónico con nadie.',
  'sifre' => 'Contraseña',
  'sifrenizimi' => 'Olvidaste tu contraseña?',
  'hala' => 'No es usted un miembro?',
  'kayitol' => 'Registrese',
  'sifretekrar' => 'Vuelva a escribir la contraseña',
  'telefon' => 'Número de teléfono',
  'hala2' => 'Es usted miembro?',
);
