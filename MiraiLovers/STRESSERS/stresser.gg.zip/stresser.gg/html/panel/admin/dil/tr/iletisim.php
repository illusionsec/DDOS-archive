<?php

return array (
  'optdesc' => 'CekilisGram müşteri hizmetlerine günün 24 saati canlı destek üzerinden ulaşabilirsiniz.',
  'optdesc2' => "Türkiye'nin en büyük çekiliş sitesi CekilisGram",
  'baslik' => 'İletişime Geç',
  'isim' => 'İsim soyisim',
  'email' => 'Email Adresi',
  'email2' => 'Mail adresinizi kimse ile paylaşmayacağız.',
  'mesaj' => 'Mesajınız',
  'gonder' => 'Gönder',
  'sifrenizimi' => 'Şifrenizi mi unuttunuz?',
  'sifre' => 'Şifre',
  'hala' => 'Hala üye değil misin?',
  'kayitol' => 'Kayıt ol',
  'sifretekrar' => 'Şifrenizi tekrar yazın',
  'telefon' => 'Telefon Numarası',
  'hala2' => 'Zaten üye misiniz?',
);
