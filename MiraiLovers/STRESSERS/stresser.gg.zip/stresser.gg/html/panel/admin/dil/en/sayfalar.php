<?php

return array (
  'iptal-iade' => '<h1 class="font-weight-bold" style="color:#3a00ff">Return policy</h1>
Cekilisgram® agrees to return all unused balances. You do not need to provide any reason for the return. Just send your return request to info@cekilisgram.com.',
  'hakkimizda' => '<h1 class="font-weight-bold" style="color:#3a00ff">About Us</h1<br>
Cekilisgram® is a global internet project. It is undisputedly the most successful Instagram raffle site with its unique algorithm, 100% secure raffle system that cannot be interfered with its results, and a great interface. Cekilisgram, which is always being developed by our R&D department for the constantly renewing algorithms of Instagram; has become the preference of many phenomena that regulate Instagram raffle. The Cekilisgram, which has hosted hundreds of thousands of sweepstakes since its establishment and has led to almost a million people winning gifts; continues to grow day by day with more than ten thousand members. You can review our free and paid lottery packages to realize your Instagram raffle.',
  'cerez' => '<h1 class="font-weight-bold" style="color:#3a00ff">Cookies</h1>

           Cekilisgram® uses some cookies in order to offer a faster experience to its users and visitors and to reduce internet consumption. Everyone who visits our site accepts our cookie policy. Cekilisgram® Cookie Policy is as follows:

            <ol>
                <li>Cookies called "cookies" on the internet and translated as "web cookies" into our language can be defined as small text files that can be transported by the website you visit or download to your desktop device by the relevant site. The cookies such as the IP address you accessed, the web session information, and the web pages you browse on the relevant site are stored in the cookie files. Websites using cookies; Keeps you signed in to sites that require membership, stores your browsing preferences during site visits, displays content based on your interests. While it is possible to categorize cookie files in many ways, they are generally divided into two as first-party (cookies used by the site itself) and third party (cookies from other websites). It is also possible to classify cookies based on their temporary and permanent.</li>
           
                <li>
The main use of cookies is to increase the speed of the website and to reduce internet consumption. Apart from this, session information is also stored and it is aimed to increase the user experience positively. The purpose of using content-based cookies is to bring the content of interest to the visitor.
</li>
         
                <li>
Cekilisgram; It uses both first-party cookies and third-party cookies. All third party cookies belong to world-renowned web companies such as Google, Yandex, Windows, Alexa. When we add new ones to our third-party cookies, we announce them through this policy page
</li>
        
                <li>
It is possible to block the cookies you do not want to use from the web browser you access. However, if you block some cookie files, some features on the system may not be available. In this context, we advise you not to block the cookies needed by Cekilisgram®. Because cookies have no known harm to the device and software you use during the visit. You can still use the links below to manage cookies:
</li>
            </ol>
            <a href="https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&amp;hl=tr"><span data-contrast="none">Google Chorme</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://yandex.com.tr/support/browser/personal-data-protection/cookies.html"><span data-contrast="none">Yandex Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://www.opera.com/tr/privacy/cookies"><span data-contrast="none">Opera Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.apple.com/tr-tr/guide/safari/sfri11471/mac"><span data-contrast="none">Safari Browser</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer"><span data-contrast="none">Mozilla Firefox</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://help.vivaldi.com/article/cookies/"><span data-contrast="none">Vivaldi</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
            <br><br>
            <a href="https://support.microsoft.com/tr-tr/help/17442/windows-internet-explorer-delete-manage-cookies"><span data-contrast="none">Internet Explorer</span></a><span data-ccp-props="{&quot;201341983&quot;:0,&quot;335559739&quot;:200,&quot;335559740&quot;:276}"> </span>
<br><br>If you are using a browser other than the ones listed above, you can learn how to manage cookies from the help page of the relevant browser.',
  'gizlilik' => '<h1 class="font-weight-bold" style="color:#3a00ff">Privacy Policy
</h1>



<br><br>
Cekilisgram®; accepts and undertakes that all members, users, and persons visiting the site for any reason will not share their information with third parties. However, the following cases are exceptions from the previous sentence:
<br><br>
Turkish Republic, the judicial institutions, law enforcement agencies, BTK, the information requested in writing by institutions such as the TK; It is forwarded to the said institutions within the period determined by law.
<br><br>
Cekilisgram does not store IP address records in terms of user privacy and security. In addition, since the payments made by credit card and the password information entered in each area of ​​the site are hidden in the 256 bit SSL certificate; It cannot be viewed by the raffle program.
<br><br>
Web servers where Cekilisgram site, Instagram lottery software, customer records are stored; protected by high-security software. However, it is not correct to say that all the measures taken on the internet are 100% safe. For this reason, we strongly recommend that you do not use the passwords you use on our site in another account.
<br><br>
Cekilisgram; reserves the right to change the privacy policy written on this page periodically in order to keep up with current technology and changing laws. In this context, we strongly recommend that you check this page and the last update date at the end of the article each time you visit the site.
<br><br>
Last Updated: 03.01.2021',
  'kurumsal' => '<h1 class="font-weight-bold" style="color:#3a00ff">Corporate communications</h1><br>

The contact numbers and e-mail addresses we publish on this page are related only to corporate communication. For our customer service, please contact the methods on the contact page.
<br><br>

<h2>Law Department</h2>
<br><br>

You can send an e-mail to hukuk@cekilisgram.com for information or any legal information about our site and our company. Department officials will provide you with information within 7 days.
<br><br>

<h2>Buyer Department</h2>
<br><br>

You can send an e-mail to buy@cekilisgram.com to quote a price related to any product you think our company needs. No quotations sent from access channels other than this e-mail address are considered. If we are interested in your offer, you will be provided with a return.
<br><br>

<h3>Corporate Accounting</h3>
<br><br>

If you are a business with the current account method, you can send all accounting-related information, especially accounting reconciliation and invoices, to institutional kurumsalmuhasebe@cekilisgram.com.
<br><br>

<h3>Ads Department</h3>
<br><br>

You can use the e-mail address of reklam@cekilisgram.com to advertise on our website.
<br><br>',
);
