<?php

return array (
  'hosgeldiniz' => 'Willkommen bei der Verlosung',
  'asagi' => 'Sie können die Ergebnisse der Verlosung auf dieser Seite sehen.',
  'kaydedildi' => 'Ergebnisse gespeichert',
  'paylas' => 'Sie können diese seite teilen.',
  'kaydedildi2' => 'Diese Seite wurde öffentlich veröffentlicht.',
  'busayfa' => 'Jeder kann die ergebnisse der verlosung auf dieser Seite sehen.',
  'guvenli' => 'Beweisen Sie Ihren Anhängern, dass Sie vertrauenswürdig sind.',
  'kodu' => 'Lotterie Code',
  'kopyala' => 'Kopieren',
  'kazanan' => 'Gewinner/Gewinnerinnen',
  'araciligi' => '<span class="text-black-50">Mit </span> Cekilisgram.com',
  'yedek' => 'Reservesieger',
);
