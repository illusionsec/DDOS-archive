<?php

return array (
  'optdesc' => 'Sie können rund um die Uhr über den Live-Support mit dem CekilisGram-Kundendienst sprechen.',
  'optdesc2' => 'Die größte Instagram-Verlosungsseite der Welt.',
  'baslik' => 'Kontaktiere uns',
  'isim' => 'Vorname Nachname',
  'email' => 'Email',
  'mesaj' => 'Deine Nachricht',
  'gonder' => 'Einreichen',
  'email2' => 'Wir geben Ihre E-Mail-Adresse niemals an Dritte weiter.',
  'sifre' => 'Passwort',
  'sifrenizimi' => 'Passwort vergessen?',
  'hala' => 'Sie sind kein Mitglied?',
  'kayitol' => 'Melden wir uns an',
  'sifretekrar' => 'Passwort erneut eingeben',
  'telefon' => 'Telefonnummer',
  'hala2' => 'Bist du ein Mitglied?',
);
