<?php

return array (
  'iletisim' => 'contatto',
  'cekilis' => 'instagram-lotteria',
  'cerez' => 'cookies',
  'iade' => 'politica-di-ritorno',
  'girisyap' => 'accesso',
  'gizlilik' => 'politica-sulla-riservatezza',
  'hakkimizda' => 'riguardo-a-noi',
  'referanslarimiz' => 'riferimenti',
  'kurumsal' => 'comunicazioni-aziendali',
  'fiyat' => 'prezzi',
  'ozellik' => 'specificazioni',
  'kontrol' => 'pannello-controllo',
  'cekilis1' => 'lotteria',
  'destek' => 'supporto',
);
