<?php

return array (
  'iletisim' => 'kontakt',
  'cekilis' => 'instagram-verlosung',
  'cerez' => 'cookies',
  'iade' => 'rücknahmegarantie',
  'girisyap' => 'anmeldung',
  'gizlilik' => 'datenschutz-bestimmungen',
  'hakkimizda' => 'uber-uns',
  'referanslarimiz' => 'verweise',
  'kurumsal' => 'unternehmenskommunikation',
  'fiyat' => 'preise',
  'ozellik' => 'spezifikationen',
  'kontrol' => 'steuerplatine',
  'cekilis1' => 'verlosung',
  'destek' => 'unterstutzung',
);
