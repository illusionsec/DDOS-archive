<?php

return array (
  'optdesc' => 'You can talk to CekilisGram customer service 24 hours a day via live support.',
  'optdesc2' => 'The biggest Instagram raffle site in the world.',
  'baslik' => 'Contact Us',
  'isim' => 'Name surname',
  'email' => 'Email',
  'mesaj' => 'Your Message',
  'email2' => 'We never share your email address with anyone.',
  'gonder' => 'Submit',
  'sifre' => 'Password',
  'sifrenizimi' => 'Forgot your password?',
  'hala' => 'You are not a member?',
  'kayitol' => 'Let\'s sign up',
  'sifretekrar' => 'Retype Password',
  'telefon' => 'Phone number',
  'hala2' => 'Are you a member?',
);
