module.exports = (server, socket) => {
	console.log('TCP BOTNET SERVER CLOSED!');
}