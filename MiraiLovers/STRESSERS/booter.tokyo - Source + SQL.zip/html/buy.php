<?php

	ob_start();
	session_start();
	require_once 'includes/app/config.php';
	require_once 'includes/app/init.php';
	
	if(isset($_GET['id']) && Is_Numeric($_GET['id']) && $user -> LoggedIn()){
	
		$id = (int)$_GET['id'];
		$row = $odb -> query("SELECT * FROM `plans` WHERE `ID` = '$id'") -> fetch();
		
		$concurrents = $_GET['concurrents'];
		$api = $_GET['api'];
		
		$priceConcs = "1.00";
		$priceAPI = "15.00";
		
		// Maths EWWWW
		
		$planPrice = $row['price']; 
	
		// Concurrents
		
		if($concurrents > 0)
		{
			$concPrice = ($priceConcs * $concurrents);
		}
		else {
			$concPrice = "0";
		}
		
		// API 
		if($api == 1)
		{
		   $totalPrice = ($priceAPI + $planPrice + $concPric);
		}
		else {
			$totalPrice = ($planPrice + $concPric);
		}
		

		$query = array(
			"cmd" => "_pay",
			"reset" => "1",
			"ipn_url" => "http://". $_SERVER['SERVER_NAME'] ."/paypal_ipn2.php",
			"merchant" => $coinpayments,
			"item_name" => 'Game: ' . rand(5994, 19963), 
			"currency" => "USD",
			"amountf" => $totalPrice,
			"quantity" => "1",
			"custom" => $id . "_" . $_SESSION['ID'],
			"allow_quantity" => "0",
			"want_shipping" => "0",
			"allow_extra" => "0" 
		);
   
   $plansql = $odb -> prepare("SELECT * FROM `plans` WHERE `ID` = :id");
	$plansql -> execute(array(":id" => $id));
	$row = $plansql -> fetch();
	if($row === NULL) { die("Bad ID"); }

		$header = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&amount=".urlencode($row['price'])."&business=Del.ti@o2.pl&item_name=".urlencode($row['name'])."&item_number=".urlencode($row['ID']."_".$_SESSION['ID'])."&return=http://bootme.club/"."&rm=2&notify_url=http://bootme.club/paypal_ipn2.php"."&cancel_return=http://bootme.club/"."&no_note=1&currency_code=USD";
		header('Location: ' . $header);
		exit;
	
	}
	else{
		header('Location: home.php');
		exit;
	}

?>