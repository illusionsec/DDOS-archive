<?php 

	ob_start();
	require_once 'includes/app/config.php';
	require_once 'includes/app/init.php';
	require_once 'includes/mail/class.phpmailer.php';
	require_once 'includes/mail/class.smtp.php';

	$mail = new PHPMailer;

	if (!(empty($maintaince))) {
		header('Location: maintenace.php');
		exit;
	}
 
 
 

 

	//Set IP (are you using cloudflare?)
	if ($cloudflare == 1){
		$ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
	}
	else{
    
		$ip = $user -> realIP();
	}
 
  if (filter_var($ip, FILTER_VALIDATE_IP)) {
    
} else {
    header('Location: https://booter.tokyo');
}
 
 

	//Are you already logged in?
	if ($user -> LoggedIn()){
		header('Location: home.php');
		exit;
	}


	if(isset($_POST['doLogin'])){
		$username = $_POST['login-username'];
		$password = $_POST['login-password'];
		
		
		$date = strtotime('-1 hour', time());
		$attempts = $odb->query("SELECT COUNT(*) FROM `loginlogs` WHERE `ip` = '$ip' AND `username` LIKE '%failed' AND `date` BETWEEN '$date' AND UNIX_TIMESTAMP()")->fetchColumn(0);
		if ($attempts > 2) {
			$date = strtotime('+1 hour', $waittime = $odb->query("SELECT `date` FROM `loginlogs` WHERE `ip` = '$ip' ORDER BY `date` DESC LIMIT 1")->fetchColumn(0) - time());
			//$error = 'Too many failed attempts. Please wait '.$date.' seconds and try again.';
		}
		
		if(empty($username) || empty($password)){
			$error = error("Please enter all fields");
		}
		
		//if(!($user -> captcha($_POST['g-recaptcha-response'], $google_secret))){
		//	$error = error("The captcha was incorrect");
		//}

		/// Main Checks Against the Inputs
		
		$SQLCheckLogin = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username");
		$SQLCheckLogin -> execute(array(':username' => $username));
		$countLogin = $SQLCheckLogin -> fetchColumn(0);
		if (!($countLogin == 1)){
			$SQL = $odb -> prepare("INSERT INTO `loginlogs` VALUES(:username, :ip, UNIX_TIMESTAMP(), 'XX')");
			$SQL -> execute(array(':username' => $username." - failed",':ip' => $ip));
			$error = error("The username does not exist in our system.");
		}
		
		$SQLCheckLogin = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `password` = :password");
		$SQLCheckLogin -> execute(array(':username' => $username, ':password' => SHA1($password)));
		$countLogin = $SQLCheckLogin -> fetchColumn(0);
		if (!($countLogin == 1)){
			$SQL = $odb -> prepare("INSERT INTO `loginlogs` VALUES(:username, :ip, UNIX_TIMESTAMP(), 'XX')");
			$SQL -> execute(array(':username' => $username." - failed login",':ip' => $ip));
			$error = error('The password you entered is invalid.');
		}
		
		$SQL = $odb -> prepare("SELECT `status` FROM `users` WHERE `username` = :username");
		$SQL -> execute(array(':username' => $username));
		$status = $SQL -> fetchColumn(0);
		if ($status == 1){
			$ban = $odb -> query("SELECT `reason` FROM `bans` WHERE `username` = '$username'") -> fetchColumn(0);
			if(empty($ban)){ $ban = "No reason given."; }
			$error = error('You are banned. Reason: '.htmlspecialchars($ban));
		}
		// Check if 2auth enabled
		if(empty($error)){

			$SQL = $odb -> prepare("SELECT * FROM `users` WHERE `username` = :username");		$SQL -> execute(array(':username' => $username));
			$userInfo = $SQL -> fetch();
			$ipcountry = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip)) -> {'geoplugin_countryName'};
			if (empty($ipcountry)) {$ipcountry = 'XX';}
			$SQL = $odb -> prepare('INSERT INTO `loginlogs` VALUES(:username, :ip, UNIX_TIMESTAMP(), :ipcountry)');
			$SQL -> execute(array(':ip' => $ip, ':username' => $username, ':ipcountry' => $ipcountry));
			$_SESSION['username'] = $userInfo['username'];
			$_SESSION['ID'] = $userInfo['ID'];
			setcookie("username", $userInfo['username'], time() + 720000);
			header('Location: home.php');
			exit;

		}
	}

	if(isset($_POST['forgotPw']))	

	{
		$value = $_POST['input'];

		
		if(empty($value))
		{
			$error = error('The email was empty please try again.');
		}

		$SQL = $odb -> prepare("SELECT COUNT(`email`) FROM `users` WHERE `email` = :email");
		$SQL -> execute(array(':email' => $value));
		$status = $SQL -> fetchColumn(0);
		if ($status == 0){
			$error = error('Email does not exist!');
		}
			
			/// Change Password Here
			if(empty($error))
			{
			function generateRandomString($length = 10) {
				$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				$charactersLength = strlen($characters);
				$randomString = '';
				for ($i = 0; $i < $length; $i++) {
					$randomString .= $characters[rand(0, $charactersLength - 1)];
				}
				return $randomString;
			}
			$newpass = generateRandomString();

			//$SQL = $odb -> query("UPDATE `users` SET `password` = {$newpass} WHERE `ID` = {$userID}");

			$SQLUpdate = $odb -> prepare("UPDATE `users` SET `password` = :password WHERE `email` = :id");
			$SQLUpdate -> execute(array(':password' => SHA1($newpass), ':id' => $value));
			
			
			/// Email Send Here
			$mail->isSMTP();                         // Set mailer to use SMTP
			$mail->Host = $Shost;  // Specify main and backup SMTP servers
			$mail->SMTPAuth = $SAuth;                               // Enable SMTP authentication
			$mail->Username = $Susername;                 // SMTP username
			$mail->Password = $Spassword;                           // SMTP password
			$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
			$mail->Port = $Sport;                                    // TCP port to connect to
			$mail->setFrom($Susername, $sitename);
			$mail->addAddress($value, $sitename);     // Add a recipient             // Name is optional
			$mail->addReplyTo('no-reply@dead.com', 'Sorry Guys!');
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = ''.$sitename.' - Password Rest';
			$mail->Body    = '<h3> You requested your password to be reset </h3> <br> Your new password is: <b>'.$newpass.'</b>  <br/> Please change this as soon as you can to make sure your safe. <br/> If you worry about your account being hacked enable 2auth using any authenticator app and setup 2auth for your account so guranteed safety!';

			if(!$mail->send()) {
				$error = success('Message could not be sent.');
				$error = success('Mailer Error: ' . $mail->ErrorInfo);
			} else {
				$error = success('Email has been sent with new passsword!');
			}
		}
	}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $sitename;?> - Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="BootMeClub is the most reliable stresser on the market. We only use the most dedicated and up-to-date hardware available, and put our focus
          on security and customer safety first. Specializing in powerful layer-4 and layer-7 attacks BootMeClub is the only stresser you'll ever need.">
<meta name="keywords" content="booter, stresser, ip stresser, ip booter, ddoser, ddos tool, ddos, best booter, best stresser, minecraft ddos, minecraft stresser, minecraft booter, cheap booter, cheap stresser, skype                  resolver, cloudflare resolver, ssyn, udp, tcp, dns, stress testing">
<meta name="author" content="BootMeClub GmbH">
  
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/simple-line-icon/css/simple-line-icons.css">
  <link rel="stylesheet" href="vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" type="image/" sizes="16x16" href="../plugins/images/favicon.png">
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
        <div class="row w-100 mx-auto">
          <div class="col-lg-4 mx-auto">
          <h2 class="text-center mb-4">Sign-In</h2>
                      	    <?php
					if(!empty($error)){
						echo ($error);
					}
					if(!empty($done)){
						echo ($done);
					}
				?>
            <div class="auto-form-wrapper">
              <form id="loginform" method="post">
                <div class="form-group">
                  <label class="label">Username</label>
                  <div class="input-group">
                    <input type="text" class="form-control" name="login-username" placeholder="Username">
                    <div class="input-group-append">
                      <span class="input-group-text"><i class="icon-check"></i></span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="label">Password</label>
                  <div class="input-group">
                    <input type="password" class="form-control" name="login-password" placeholder="*********">
                    <div class="input-group-append">
                      <span class="input-group-text"><i class="icon-check"></i></span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <button name="doLogin" class="btn btn-primary submit-btn btn-block">Login</button>
                </div>
                <div class="text-block text-center my-3">
                  <span class="text-small font-weight-semibold">Not a member ?</span>
                  <a href="register.php" class="text-small">Create new account</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/template.js"></script>
  <!-- endinject -->
</body>

</html>
