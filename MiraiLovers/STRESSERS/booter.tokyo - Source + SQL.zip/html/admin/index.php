<?php 

	header('Location: https://booter.tokyo/admin/home.php');
	
?>