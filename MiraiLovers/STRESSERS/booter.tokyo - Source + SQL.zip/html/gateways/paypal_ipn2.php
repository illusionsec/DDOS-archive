<?php
define("_VALID_PHP", true);
    require_once("../includes/app/config.php");
    require_once("../includes/app/init.php");
    set_time_limit(0);
    function verifyTxnId($txn_id, $odb)
    {
        $sql = $odb->prepare("SELECT COUNT(id) FROM `payments` WHERE `tid` = :tid LIMIT 1");
		$sql -> execute(array(':tid' => $txn_id));
        if ($sql->fetchColumn(0) > 0)
            return false;
        else
            return true;
    }
    $demo = false;
    $url  = 'www.paypal.com';
    $header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
    $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
    $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
    $fp = fsockopen($url, 80, $errno, $errstr, 30);
    $payment_status = $_POST['payment_status'];
    $receiver_email = $_POST['business'];
    list($membership_id, $user_id) = explode("_", $_POST['item_number']);
    $mc_gross = $_POST['mc_gross'];
    $txn_id   = $_POST['txn_id'];
    $getxn_id = verifyTxnId($txn_id, $odb);
    $SQL = $odb->prepare("SELECT * FROM `plans` WHERE `ID` = :membership_id");
	$SQL -> execute(array(':membership_id' => $membership_id));
	$plan = $SQL -> fetch(PDO::FETCH_ASSOC);
    $key = strtoupper($_GET['key']);
                        $data = array(
                            ':tid' => $txn_id,
                            ':plan' => (int) $membership_id,
                            ':email' => $_POST['payer_email'],
                            ':user' => (int) $user_id,
                            ':paid' => (float) $mc_gross
                        );
                        $odb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
                        $insertsql = $odb -> prepare("INSERT INTO `payments` VALUES(NULL, :paid, :plan, :user, :email, :tid, UNIX_TIMESTAMP())");
                        $insertsql->execute($data);

                        $getPlanInfo = $odb -> prepare("SELECT `unit`,`length` FROM `plans` WHERE `ID` = :plan");
                        $getPlanInfo -> execute(array(':plan' => (int)$membership_id));
                        $plan = $getPlanInfo -> fetch(PDO::FETCH_ASSOC);
                        $unit = $plan['unit'];
                        $length = $plan['length'];
                        $newExpire = strtotime("+{$length} {$unit}");
                        $updateSQL = $odb -> prepare("UPDATE `users` SET `expire` = :expire, `membership` = :plan WHERE `ID` = :id");
                        $updateSQL -> execute(array(':expire' => $newExpire, ':plan' => (int)$membership_id, ':id' => (int)$user_id));