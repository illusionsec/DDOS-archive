<?php
	$page = "Api System";
	require_once 'header.php'; 
?>


<?php
	if(isset($_POST['gen_key'])){
		if(isset($_SESSION['username'])){
			genKey($_SESSION['username'], $odb);
			header('Location: api.php');
		}
	}
	if(isset($_POST['disable_key'])){
		if(isset($_SESSION['username'])){
			disableKey($_SESSION['username'], $odb);
			header('Location: api.php');
		}
	}

	function genKey($username, $odb){
		$newkey = generateRandomString(16);
		$stmt2 = $odb->query("UPDATE users SET apikey='$newkey' WHERE username='$username'");
	}
	function disableKey($username, $odb){
		$stmt2 = $odb->query("UPDATE users SET apikey='0' WHERE username='$username'");
	}
	function generateRandomString($length = 10){
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
		$charactersLength = strlen($characters);
		$randomString = '';
		for($i=0;$i<$length;$i++){
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	$stmt = $odb->prepare("SELECT apikey FROM users WHERE username=:login");
	$stmt->bindParam("login", $_SESSION['username'], PDO::PARAM_STR);
	$stmt->execute();
	$key = $stmt->fetchColumn(0);
?>

  <!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title"><?php echo $page; ?></h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
          <ol class="breadcrumb">
            <li><a href="#"><?php echo $sitename; ?></a></li>
            <li class="active"><?php echo $page; ?></li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- .row -->

      <!--/.row -->
      <!-- .row -->
	  <div class="widget-content">

</div> 
          <div class="white-box">
		  	<h3 class="box-title">Api URL</h3>
		  	<form method="POST">
		  		<?php if($key == '0'){?>
	            <input class="form-control" type="text" value="API is unavailable or api-key is disabled! Click 'Generate new api-key'." readonly="" style="color:black;">
	            <?php }else{?>
				<?php if($user->isVip($odb)){?>
	            <input class="form-control" type="text" value="https://api.bootme.club/?key=<?php echo $key;?>&host=<IPv4/URL>&port=<PORT>&time=<SECONDS>&method=<METHOD/STOP>&vip=<1/0>" readonly="" style="color:black;">
	            <?php }else{?>
				<input class="form-control" type="text" value="https://api.bootme.club/?key=<?php echo $key;?>&host=<IPv4/URL>&port=<PORT>&time=<SECONDS>&method=<METHOD/STOP>" readonly="" style="color:black;">
				<?php }?>
				<?php }?>
	            <br><button type="submit" class="btn btn-primary" name="gen_key">Generate new api-key</button> <button type="submit" class="btn btn-danger" name="disable_key">Disable api-key</button>
	        </form>
          </div>
		  
<div class="white-box">
<h3 class="box-title">Available methods</h3>
<table class="table table-dark mb-0">
<thead>
<tr>
<th>Method</th>
<th>OSI</th>
<th>USE</th>
<th width="400">RECOMMENDATIONS</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>NTP</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Home connection.</span></td>
</tr>
<tr>
<td><strong>VSE</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>LDAP</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Home connection.</span></td>
</tr>
<tr>
<td><strong>ESSYN</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>VAR</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Coming soon.</span></td>
</tr>
<tr>
<td><strong>RST</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>SYN</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>PSH</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>FIN</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>URG</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>ECE</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>CWR</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Little server.</span></td>
</tr>
<tr>
<td><strong>BOX</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Home connection protected.</span></td>
</tr>
<tr>
<td><strong>BLAZED</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Blazingfast.</span></td>
</tr>
<tr>
<td><strong>FORTNITE</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Fortnite server/Game server.</span></td>
 </tr>
<tr>
<td><strong>MEZTLI</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Protected server.</span></td>
</tr>
<tr>
<td><strong>BLAZING</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">BlazingFast.</span></td>
</tr>
<tr>
<td><strong>MYSQL</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Mysql server.</span></td>
</tr>
<tr>
<td><strong>TCP</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">SMALL SERVER / HOME IP</span></td>
</tr>
<tr>
<td><strong>ESP</strong></td>
<td><span class="label label-rounded label-dark">Layer 4</span></td>
<td><span class="label label-rounded label-dark">IPv4 1.1.1.1</span></td>
<td><span class="label label-rounded label-dark">Game server.</span></td>
</tr>
<tr>
<td><strong>GET (HTTP-GET)</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
<tr>
<td><strong>BYPASS</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
<tr>
<td><strong>POST (HTTP-POST)</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
<tr>
<td><strong>HEAD (HTTP-HEAD)</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
<tr>
<td><strong>NUKE</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
<tr>
<td><strong>CFBYPASS</strong></td>
<td><span class="label label-rounded label-dark">Layer 7</span></td>
<td><span class="label label-rounded label-dark">Websites http://host/</span></td>
<td><span class="label label-rounded label-dark">Websites.</span></td>
</tr>
</tbody>
</table>
</div> 

<?php

	require_once 'footer.php';
	
?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/596b6ef81dc79b329518e91e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->