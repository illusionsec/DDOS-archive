<?php
	$page = "Attack Hub";
	require_once 'header.php'; 
?>


  <!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title"><?php echo $page; ?> <i style="display: none;" id="alerts" class="fa fa-cog fa-spin"></i></h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
          <ol class="breadcrumb">
            <li><a href="#"><?php echo $sitename; ?></a></li>
            <li class="active"><?php echo $page; ?></li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- .row -->

      <!--/.row -->
      
	
	   <div class="col-lg-12" id="div"></div>
	     <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="white-box">
		  		<?php
if(isset($_POST['deposer']))
{
$points = $_POST['quantite'];
$total = $points/100;

if ($points < 500)
{
echo '
<div class="col-md-12"><div class="alert alert-danger">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
<h4>An error has occurred</h4>
The minimum deposit value is 500 points.
</div>
</div>';
} else {
			
$emailsql = $odb -> prepare("SELECT `email` FROM `users` WHERE id = :id");
$emailsql -> execute(array(":id" => $_SESSION['ID']));
$email = $emailsql -> fetchColumn(0);
$marchantid = "cbb19b6f64b35b2cfada8959bb22afa1";
$ipnurl = "https://www.coinpayments.net/index.php?cmd=_pay&reset=1&merchant=".urlencode($marchantid)."&item_name=".urlencode("Addition of ".$points." points")."&currency=EUR&amountf=".
urlencode($total)."&quantity=1&allow_quantity=0&want_shipping=0&allow_extra=0&item_number=".urlencode($points."_".$_SESSION['ID'])."&ipn_url=".urlencode($url."includes/ptsipn.php")."&cancel_url=https://bootme.club/home.php"."&success_url=https://bootme.club/home.php"."&first_name=".$_SESSION['username']."";

header("Location: ".$ipnurl);
}
}
?>
		  <form method="POST">
		  <center><h3 class="m-b-0 box-title">New deposit ( Bitcoin & PAYPAL )<i style="display: none;" id="image" class="fa fa-cog fa-spin"></i></h3></center>
		  <br>
              <div class="form-group col-md-6">
                <center><label>Number of points</label></center>
                  <input class="form-control" type="text" name="quantite" id="quantite" onkeyup="javascript:calcul('total');" placeholder="Minimum deposit: 500 points">
              </div>
			                <div class="form-group col-md-6">
                <center><label>Price</label></center>
				<input type="text" id="total" value="<?=sprintf('%.1f',$total)?>€" class="form-control">              </div>
			  <div class="form-group">
			  <button class="btn btn-success btn-block" name="deposer" type="submit"><i class="fa fa-bolt"></i> Deposit</button>
			  </div>
            </form>
          </div>
        </div>
		 
      </div>
        </div>  
<?php

	require_once 'footer.php';
	
?>
<script type="text/javascript">
function calcul()
{
var quantite = document.getElementById("quantite").value;

var total = parseFloat(quantite) /100;
document.getElementById('total').value = total.toFixed(2)+"€";
}
</script>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/596b6ef81dc79b329518e91e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
