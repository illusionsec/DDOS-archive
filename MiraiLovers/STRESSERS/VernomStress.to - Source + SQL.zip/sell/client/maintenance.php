 s<?php

$paginaname = 'Maintenance';


?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php 
			
			include("@/header.php");

			?>
                    <div id="page-content">
            
                        <div class="row">	
						</br>
						</br>
						</br>
						</br>
	<center> <h1> <strong> Maintenance </strong></h1></br>
	<h4> Fixing power..</br>
	</br>
	Retry in 30 minutes
	</br>
	</br>

<img src="http://rsby.wbhealth.gov.in/Images/page-under-maintenance.png">


					</div>
							</div>
						</div>
					</div>
				</div>
               </div>
               </div>
             
          </div>

		<?php include("@/script.php"); ?>
    </body>

</html>