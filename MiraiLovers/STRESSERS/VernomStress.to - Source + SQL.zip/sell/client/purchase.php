<?php

$paginaname = 'Purchase';


?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php 
			
			include("@/header.php");

			?>
                    <div id="page-content">
            
                        

		


								<h4 style="display:inline-block; color:#939caa; ">Packages</h4>
								<br>
								<br>


								<div style="position: relative; width: auto" class="slimScrollDiv">
									<div id="stats">
										<table class="table table-striped">
											<tbody>
												
												<?php
												$SQLGetPlans = $odb -> query("SELECT * FROM `plans` WHERE `private` = 0 ORDER BY `ID` ASC");
												while ($getInfo = $SQLGetPlans -> fetch(PDO::FETCH_ASSOC))
												{

													$name = $getInfo['name'];
													$price = $getInfo['price'];
													$length = $getInfo['length'];
													$unit = $getInfo['unit'];
													$concurrents = $getInfo['concurrents'];
													$mbt = $getInfo['mbt'];
													$apiaccess = $getInfo['apiaccess'];
													$ID = $getInfo['ID'];
													$servers = $getInfo['servers'];
													$powerl4 = $servers * 15;
													$powerl7 = $servers * 30;

													//disable or enable discounts:
													$discounts = "enabled"; //put enabled if you wanna enable or disabled if you wanna disable
													$howmuchdiscount = 0.25;  //discount's percent (0.3 = 30%)
													$minplan = 9; //minimum price where the offer can be applied
													
													if($discounts == "enabled" && $price > $minplan){
														$p = $price;
														$percent = $p * $howmuchdiscount;
														$price = $p - $percent;
													} else {
														$price = $price;
													}

													//duration check
													if($_GET['length'] == "3Months"){
														$price = $price * 1.8;
														$length = 3;
														if($discounts == "enabled"){
															$p = $p * 1.8;
														}
													} else if($_GET['length'] == "LT"){
														$price = $price * 4.5;
														$length = "Lifetime";
														$unit = "";
														if($discounts == "enabled"){
															$p = $p * 4.5;
														}
													}


													//api check
													/*if($apiaccess == "Yes")
														$apistatus = '<i class="fas fa-check"></i>'; 
													else
														$apistatus = '<i class="fas fa-times"></i>';
													*/
													
													echo '
													<div class="col-sm-3">
													<div class="widget" style="padding:20px;">
													
														<center style="margin-top:20px;">'.htmlspecialchars($name).'</center>

														<center><h3 style="color:#fff;">$'.$price.'&nbsp;<del><small>'.$p.'</small></del> </h3></center>

														<center style="color: #b02e9e;font-size: 10px;margin-top: -16px;margin-bottoM: 20px;">'.$length.' '.htmlspecialchars($unit).'</center>
														<center><i class="fa fa-vcard"></i> '.$mbt.'sec & '.$concurrents.' concurrents</center>
														<center><span class="label label-success" style="background:linear-gradient(to right, #523b93 1%,#d11f75 55%,#e9464b 98%);color: #000;">'.$powerl4.' Gbps & '.$powerl7.'K r/s </span></center>
														<center>VIP Hub access </center>
														<center>Starting with '.$servers.' servers </center>
														<center><span class="label label-success" style="background:linear-gradient(to right, #523b93 1%,#d11f75 55%,#e9464b 98%);color: #000;">API Access: '.$apiaccess.' </span></center>
														<center>Unlimited daily attacks </center>

														
														
														<center style="margin-bottom:10px; margin-top:30px;"><a href="buyplan.php?id='.$ID.'"><button class="btn btn-primary" id="myBtn" >Cryptocurrency</button></center></a>
														<!--<center><a href="tickets.php"><button class="btn btn-primary" id="myBtn" >- - - </button></center></a>-->
													
													</div> 
													</div>

													';
												}
												?>




												
											</tbody>
										</table>
									</div>
								</div>




		<?php include("@/script.php"); ?>
    </body>

</html>