<?php
include("header.php");
?>
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
 <center> <h4> Si sto fixando non rompere lol </h4> </center>
                
            </div>
            <div class="page-sidebar"></div>
			                        </br>
						</br>
						</br>
						</br>
						</br>
			<center> <h2> torna nella index e non rompere xd
        </div>
    </body>
</html>
