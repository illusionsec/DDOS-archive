<?php
include("header.php");
?>
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-title">Tickets</div>
                            <div class="page-toolbar-subtitle">Ticket Center</div>
                        </div>
                        
                        <div class="page-toolbar-block pull-right">
                            <div class="widget-info">
                                <div class="widget-info-title">Registered users</div>
                                <div class="widget-info-value"><?php echo $stats -> totalUsers($odb); ?></div>
                            </div>
                            <div class="widget-info">
                                <div class="widget-info-title">Users with memberships</div>
                                <div class="widget-info-value"><?php echo $stats -> activeUsers($odb); ?></div>
                            </div>                                                       
                        </div>         
                        
                    </div>                    

                    <div class="row">                        
                        <div class="col-md-4">
                   
                                <div class="window window-success window-npb">

</span>
                                </div>
                                <div class="window window-dark">
                                    <div class="window-block">
                                    </div>
                                </div>
                            </div>
                        </div>
<div class="col-md-6">
                            <div class="block">
                                <div class="block-content">
                                    <h2>Tickets awaiting reply</h2>
                                </div>                                
                                <div class="block-content np">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Subject</th><th>Sender</th><th>Date</th>
                                        </tr>
			<?php 
			$SQLGetTickets = $odb -> query("SELECT * FROM `tickets` WHERE `status` = 'Waiting for admin response' ORDER BY `date` DESC LIMIT 99999999");
			while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
			{
				$username = $getInfo['username'];
				$id = $getInfo['id'];
				$subject = $getInfo['subject'];
				$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
				$userid = $odb->query("SELECT `ID` FROM `users` WHERE `username` = '$username'")->fetchColumn(0);
				echo '<tr><td><a href="ticket.php?id='.$id.'">'.htmlspecialchars($subject).'</a></td><td><a href="user.php?id='.$userid.'">'.htmlspecialchars($username).'</a></td><td>'.$date.'</td></tr>';
			}
			?>                                               
                                    </table>

</div>
                        </div>
<div class="col-md-6">
                            <div class="block">
                                <div class="block-content">
                                    <h2>Tickets awaiting reply from user</h2>
                                </div>                                
                                <div class="block-content np">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Subject</th><th>Sender</th><th>Date</th>
                                        </tr>
			<?php 
			$SQLGetTickets = $odb -> query("SELECT * FROM `tickets` WHERE `status` = 'Waiting for user response' ORDER BY `date` DESC LIMIT 99999999");
			while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
			{
				$username = $getInfo['username'];
				$id = $getInfo['id'];
				$subject = $getInfo['subject'];
				$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
				$userid = $odb->query("SELECT `ID` FROM `users` WHERE `username` = '$username'")->fetchColumn(0);
				echo '<tr><td><a href="ticket.php?id='.$id.'">'.htmlspecialchars($subject).'</a></td><td><a href="user.php?id='.$userid.'">'.htmlspecialchars($username).'</a></td><td>'.$date.'</td></tr>';
			}
			?>                                               
                                    </table>



</span>


</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                            <div class="block">
                                <div class="block-content">
                                    <h2>Tickets Closed</h2>
                                </div>                                
                                <div class="block-content np">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Subject</th><th>Sender</th><th>Date</th>
                                        </tr>
			<?php 
			$SQLGetTickets = $odb -> query("SELECT * FROM `tickets` WHERE `status` = 'Closed' ORDER BY `date` DESC LIMIT 20");
			while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
			{
				$username = $getInfo['username'];
				$id = $getInfo['id'];
				$subject = $getInfo['subject'];
				$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
				$userid = $odb->query("SELECT `ID` FROM `users` WHERE `username` = '$username'")->fetchColumn(0);
				echo '<tr><td><a href="ticket.php?id='.$id.'">'.htmlspecialchars($subject).'</a></td><td><a href="user.php?id='.$userid.'">'.htmlspecialchars($username).'</a></td><td>'.$date.'</td></tr>';
			}
			?>
                </div>
            </div>
    </body>
</html>
