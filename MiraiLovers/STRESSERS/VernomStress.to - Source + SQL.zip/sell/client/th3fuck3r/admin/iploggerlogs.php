<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}

if (isset($_POST['users']))
{
$SQL = $odb -> query("DELETE FROM `users` WHERE `membership` = 0");
}
if (isset($_POST['payments']))
{
$SQL = $odb -> query("TRUNCATE `payments`");
}
if (isset($_POST['deletechats']))
{
$SQL = $odb -> query("TRUNCATE `shoutbox`");

$content = 'Chat has been cleared!';
$sender = 'Chat Bot';

$SQLinsert = $odb -> prepare("INSERT INTO `shoutbox` VALUES(NULL, :content, :sender, UNIX_TIMESTAMP())");
$SQLinsert -> execute(array(':content' => $content, ':sender' => $sender));
}
if (isset($_POST['logins']))
{
$SQL = $odb -> query("TRUNCATE `loginlogs`");
}
if (isset($_POST['removeiploggerlogs']))
{
$delete = $_POST['removeiploggerlogs'];
$SQL = $odb -> query("DELETE FROM `iplogs` WHERE `ID` = '$delete'");

}
?>
<form method="post">
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-title">IP Logger</div>
                            <div class="page-toolbar-subtitle">IP addresses</div>
                        </div>        
                       <ul class="page-toolbar-tabs">
                            <li class="active"><a href="#page-tab-1">Logs</a></li>
                        </ul>
                    </div>                    
<div class="row page-toolbar-tab active" id="page-tab-1">
                            <div class="block">
                                <div class="block-head">
                                    <h2>Logs <button type="submit" class="btn btn-link btn-xs" name="deletechats">Delete all IP</button></h2>
                                </div>
                            <div class="block">
                                <div class="block-head">
                                </div>
                                <div class="block-content np">
                                    <table class="table table-bordered table-striped sortable">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
												<th>Content & Name</th>
                                                <th>Remove</th>
                                                <th></th>
                                                <th>Date</th>                                    
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
$SQLGetLogs = $odb -> query("SELECT * FROM `iplogs` ORDER BY `date` DESC");
while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
{
	$id = $getInfo['id'];
	$logged = $getInfo['logged'];
	$userID = $getInfo['userID'];
	$date = $getInfo['date'];
	echo '<tr><td>'.htmlspecialchars($id).'</td><td>'.htmlspecialchars($logged).$port.' ('.htmlspecialchars($userID).')<br></td><td><center><button name="removemessage" value="'.$id.'" class="btn btn-primary">X</button></center>'.$time.'</td><td>'.htmlspecialchars($handler).'</td><td>'.$date.'</td></tr>';
}
?>								
                                        </tbody>
                                    </table>                                                                        
                                </div>
                            </div>

</div>

                </div>
                
            </div>
			</form>
            <div class="page-sidebar"></div>
        </div>
    </body>
</html>
