<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}
?>

						<script>
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("attacksdiv").innerHTML=xmlhttp.responseText;
						eval(document.getElementById("ajax").innerHTML);
						}
					  }
					xmlhttp.open("GET","ajax/hub.php?type=attacks",true);
					xmlhttp.send();

					function start()
					{
					launch.disabled = true;
					var host=$('#host').val();
					var port=$('#port').val();
					var time=$('#time').val();
					var method=$('#method').val();
					document.getElementById("div").style.display="none"; 
					document.getElementById("image").style.display="inline"; 
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						launch.disabled = false;
						document.getElementById("div").innerHTML=xmlhttp.responseText;
						document.getElementById("image").style.display="none";
						document.getElementById("div").style.display="inline";
						if (xmlhttp.responseText.search("success") != -1)
						{
						attacks();
						window.setInterval(ping(host),10000);
						}
						}
					  }
					xmlhttp.open("GET","../../ajax/hub.php?type=start" + "&host=" + host + "&port=" + port + "&time=" + time + "&method=" + method,true);
					xmlhttp.send();
					}			

					function renew(id)
					{
					rere.disabled = true;
					document.getElementById("div").style.display="none";
					document.getElementById("image").style.display="inline"; 
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						rere.disabled = false;
						document.getElementById("div").innerHTML=xmlhttp.responseText;
						document.getElementById("image").style.display="none";
						document.getElementById("div").style.display="inline";
						if (xmlhttp.responseText.search("success") != -1)
						{
						attacks();
						window.setInterval(ping(host),10000);
						}
						}
					  }
					xmlhttp.open("GET","../../ajax/hub.php?type=renew" + "&id=" + id,true);
					xmlhttp.send();
					}

					function stop(id)
					{
					st.disabled = true;
					document.getElementById("div").style.display="none";
					document.getElementById("image").style.display="inline"; 
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						st.disabled = false;
						document.getElementById("div").innerHTML=xmlhttp.responseText;
						document.getElementById("image").style.display="none";
						document.getElementById("div").style.display="inline";
						if (xmlhttp.responseText.search("success") != -1)
						{
						attacks();
						window.setInterval(ping(host),10000);
						}
						}
					  }
					xmlhttp.open("GET","../../ajax/hub.php?type=stop" + "&id=" + id,true);
					xmlhttp.send();
					}

					function attacks()
					{
					document.getElementById("attacksdiv").style.display="none";
					document.getElementById("attacksimage").style.display="inline"; 
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("attacksdiv").innerHTML=xmlhttp.responseText;
						document.getElementById("attacksimage").style.display="none";
						document.getElementById("attacksdiv").style.display="inline-block";
						document.getElementById("attacksdiv").style.width="100%";
						eval(document.getElementById("ajax").innerHTML);
						}
					  }
					xmlhttp.open("GET","ajax/hub.php?type=attacks",true);
					xmlhttp.send();
					}

					function adminattacks()
					{
					document.getElementById("attacksdiv").style.display="none";
					document.getElementById("attacksimage").style.display="inline"; 
					var xmlhttp;
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("attacksdiv").innerHTML=xmlhttp.responseText;
						document.getElementById("attacksimage").style.display="none";
						document.getElementById("attacksdiv").style.display="inline-block";
						document.getElementById("attacksdiv").style.width="100%";
						eval(document.getElementById("ajax").innerHTML);
						}
					  }
					xmlhttp.open("GET","../../ajax/hub.php?type=adminattacks",true);
					xmlhttp.send();
					}
					</script>
					
					
 <div class="page-content">
					<div class="col-lg-8">
					<form method="POST">
				
					<div class="widget">
						<div class="widget-content widget-content-mini themed-background-dark text-light-op">
								<span class="pull-right text-muted"><?php echo $sitename; ?></span>
								<i class="fa fa-refresh"></i> <b>Manage Attacks</b>
						</div>
						<div style="position: relative; width: auto" class="slimScrollDiv">
							<table class="table">
								  <thead>
									  <tr>
										<th>#</th>
										<th>Host</th>
										<th>Time Left</th>
										<th>Method</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$SQLSelect = $odb -> query("SELECT * FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0 ORDER BY `id` DESC");
									while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
									{
									$user = $show['user'];
									$ip = $show['ip'];
									$port = $show['port'];
									$time = $show['time'];
									$method = $show['method'];
									$rowID = $show['id'];
									echo '<tr><td><input type="checkbox" name="stopCheck[]" value="'.$rowID.'"/></td><td>'.$ip.'</td><td>';
										
									//echo date("r", ($show['time'] + $show['date'])) . "<br />";
										
									?>
									<div id='att-<?php echo $rowID; ?>'></div>
									<script>
									var i<?php echo $rowID; ?> = <?php echo abs(time() - ($show['date'] + $show['time'])); ?>;
									var time<?php echo $rowID; ?> = setInterval(function(){
										document.getElementById("att-<?php echo $rowID; ?>").innerHTML="Attack ending in "+(i<?php echo $rowID; ?>--)+" seconds"
										if (i<?php echo $rowID; ?> == 0){
											clearInterval(time<?php echo $rowID; ?>);
											document.getElementById("att-<?php echo $rowID; ?>").innerHTML="Attack Finished!"
										}
									},1000);
									</script>
									<?php echo '</td><td>'.$method.'</td><td><span class="label label-success">Running</span></td><td><input type="submit" name="stopbtn" value="Stop" class="btn btn-danger" onclick="stop('.$rowID.')" /></td></tr>';
									}
									$SQLSelectRunningAttack = $odb -> prepare("SELECT * FROM `logs` WHERE user= :user AND (`time` + `date` < UNIX_TIMESTAMP() OR `stopped` != 'No') ORDER BY `ID` DESC LIMIT 100;");
									   $SQLSelectRunningAttack->execute(array(":user" => $_SESSION['user']));
										if ($SQLSelectRunningAttack->rowCount() != 0) {
									  while ($show = $SQLSelectRunningAttack -> fetch(PDO::FETCH_ASSOC))
									  {
										$ip = htmlentities($show['ip']);
										$user = htmlentities($show['user']);
										$port = htmlentities($show['port']);
										$time = htmlentities($show['time']);
										$method = htmlentities($show['method']);
										$rowID = htmlentities($show['ID']);
										echo '<tr class="spacer"></tr><tr><td>'.$rowID.'</td><td>'.$user.'</td><td>'.$ip.'</td><td>'.$time.'</td><td>'.$method.'</td><td><span class="label label-warning">Restart</span></td><td><form method="post" action="">
											<div class="g_10"><button type="submit" name="attackBtn" class="btn btn-success">Renew</button>
													<input name="host" type="hidden" value="' . $user . '"/>
													<input name="host" type="hidden" value="' . $ip . '"/>
													<input name="port" type="hidden" value="' . $port . '"/>
													<input name="time" type="hidden" value="' . $time . '"/>
													<input name="method" type="hidden" value="' . $method . '"/>
											</div></form></td></tr>
												'; 
									  } }
									  
									  else {
										echo "<tr class=\"spacer\"></tr><tr><td colspan='6'>You have no previous boots</td></tr>";
									  }
									 ?>
								</tbody>
							 </table>     
						</div>
					   </form>
					</div>
				</div>