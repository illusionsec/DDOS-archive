<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}

header("Refresh:60");

?>
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-title">Dashboard</div>
                            <div class="page-toolbar-subtitle">Admin dashboard</div>
                        </div>
                        
                        <div class="page-toolbar-block pull-right">
                            <div class="widget-info">
                                <div class="widget-info-title">Registered users</div>
                                <div class="widget-info-value"><?php echo $stats -> totalUsers($odb); ?></div>
                            </div>
                            <div class="widget-info">
                                <div class="widget-info-title">Users with memberships</div>
                                <div class="widget-info-value"><?php echo $stats -> activeUsers($odb); ?></div>
                            </div>
                            <div class="widget-info">
                                <div class="widget-info-title">Paid users (about)</div>
                                <div class="widget-info-value"><?php echo $stats -> paidUsers($odb); ?></div>
                            </div>                                                     
							

                        </div>         
                        
                    </div>                    

                        
<div class="col-md-6">

                            <div class="block">
                                <div class="block-content">
                                    <h2>Tickets awaiting reply</h2>
                                </div>                                
                                <div class="block-content np">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Subject</th><th>Sender</th><th>Date</th>
                                        </tr>
			<?php 
			$SQLGetTickets = $odb -> query("SELECT * FROM `tickets` WHERE `status` = 'Waiting for admin response' ORDER BY `date` DESC");
			while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
			{
				$username = $getInfo['username'];
				$id = $getInfo['id'];
				$subject = $getInfo['subject'];
				$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
				$userid = $odb->query("SELECT `ID` FROM `users` WHERE `username` = '$username'")->fetchColumn(0);
				echo '<tr><td><a href="ticket.php?id='.$id.'">'.htmlspecialchars($subject).'</a></td><td><a href="user.php?id='.$userid.'">'.htmlspecialchars($username).'</a></td><td>'.$date.'</td></tr>';
			}
			?>                                       
                                    </table>
                                </div>
                            </div>
							
                    </div>

                    
                    <div class="col-md-6">
 <div class="block"> 
                                <div class="block-content">
                                    <h2>Tickets On Hold</h2>
                                </div>                                
                                <div class="block-content np">
                                    <table class="table table-striped">
                                        <tr>
                                            <th>Subject</th><th>Sender</th><th>Date</th>
                                        </tr>
            <?php 
            $SQLGetTickets = $odb -> query("SELECT * FROM `tickets` WHERE `status` = 'onHold' ORDER BY `date` DESC");
            while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
            {
                $username = $getInfo['username'];
                $id = $getInfo['id'];
                $subject = $getInfo['subject'];
                $date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
                $userid = $odb->query("SELECT `ID` FROM `users` WHERE `username` = '$username'")->fetchColumn(0);
                echo '<tr><td><a href="ticket.php?id='.$id.'">'.htmlspecialchars($subject).'</a></td><td><a href="user.php?id='.$userid.'">'.htmlspecialchars($username).'</a></td><td>'.$date.'</td></tr>';
            }
            ?>                                       
                                    </table>
                                </div>
                            </div>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
 
                                    </table>
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="page-sidebar"></div>
        </div>
    </body>
</html>
