<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}

if (isset($_POST['payments']))
{
$SQL = $odb -> query("TRUNCATE `payments`");
}
if (isset($_POST['logins']))
{
$SQL = $odb -> query("TRUNCATE `loginlogs`");
}

?>
<form method="post">
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-subtitle">Logins IP </div>
                        </div>        
                       <ul class="page-toolbar-tabs">
                            <li class="active"><a href="#page-tab-1">Login Logs</a></li>
                        </ul>
                    </div>                    
<div class="row page-toolbar-tab active" id="page-tab-1">
                            <div class="block">
                                <div class="block-head">
								                                    <h2>Logs <button type="submit" class="btn btn-link btn-xs" name="logins">Delete all loginlogs</button></h2>

                                </div>
                                <div class="block-content np">
                                    <table class="table table-bordered table-striped sortable">
                                        <thead>
                                            <tr>
                                                <th></th>
                    <th>User</th>
                    <th>IP</th>
                    <th>Date</th>
                    <th>Country</th>                                    
                                            </tr>
                                        </thead>
                                        <tbody>
<?php 
$SQLGetUsers = $odb -> query("SELECT * FROM `loginlogs` ORDER BY `date` DESC");
while ($getInfo = $SQLGetUsers -> fetch(PDO::FETCH_ASSOC))
{
	$username = $getInfo['username'];
	$ip = $getInfo['ip'];
	$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
	$country = $getInfo['country'];
	echo '<tr><td></td><td>'.htmlspecialchars($username).'</td><td>'.htmlspecialchars($ip).'</td><td>'.$date.'</td><td>'.htmlspecialchars($country).'</td></tr>';
}
?>										
                                        </tbody>
                                    </table>                                                                        
                                </div>
                            </div>

</div>

                </div>
                
            </div>
			</form>
            <div class="page-sidebar"></div>
        </div>
    </body>
</html>
