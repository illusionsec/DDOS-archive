<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}

if (isset($_POST['users']))
{
$SQL = $odb -> query("DELETE FROM `users` WHERE `membership` = 0");
}
if (isset($_POST['payments']))
{
$SQL = $odb -> query("TRUNCATE `payments`");
}
if (isset($_POST['attacks']))
{
$SQL = $odb -> query("TRUNCATE `logs`");
}
if (isset($_POST['logins']))
{
$SQL = $odb -> query("TRUNCATE `loginlogs`");
}

?>
<form method="post">
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-title">Attack logs</div>
                            <div class="page-toolbar-subtitle">Attacks</div>
                        </div>
                        <ul class="page-toolbar-tabs">
                            <li><a href="#page-tab-3">Attacks</a></li>
                        </ul>      
                    </div>                    
<div class="row page-toolbar-tab active" id="page-tab-3">
                            <div class="block">
                                <div class="block-head">
                                    <h2>Attacks </h2>
                                </div>
                                <div class="block-content np">
                                    <table class="table table-bordered table-striped sortable">
                                        <thead>
                                            <tr>
                    <th>User</th>
                    <th>Host</th>
                    <th>Time</th>
                    <th>Handler</th>
                    <th>Date</th>                               
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
$SQLGetLogs = $odb -> query("SELECT * FROM `logs` ORDER BY `date` DESC");
while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
{
	$user = $getInfo['user'];
	$host = $getInfo['ip'];
	if (filter_var($host, FILTER_VALIDATE_URL)) {$port='';} else {$port=':'.$getInfo['port'];}
	$time = $getInfo['time'];
	$method = $getInfo['method'];
	$handler = $getInfo['handler'];
	$date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
	echo '<tr><td>'.htmlspecialchars($user).'</td><td>'.htmlspecialchars($host).$port.' ('.htmlspecialchars($method).')<br></td><td>'.$time.'</td><td>'.htmlspecialchars($handler).'</td><td>'.$date.'</td></tr>';
}
?>
                                        </tbody>
                                    </table>                                                                        
                                </div>
                            </div>
</div>
                </div>
                
            </div>
			</form>
            <div class="page-sidebar"></div>
        </div>
    </body>
</html>
