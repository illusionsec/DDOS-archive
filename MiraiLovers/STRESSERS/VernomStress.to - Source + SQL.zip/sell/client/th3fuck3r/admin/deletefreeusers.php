<?php
include("header.php");
if (!($user -> isAdmin($odb)))
{
	header('location: ../index.php');
	die();
}

if (isset($_POST['deletefree']))
{
$SQL = $odb -> query("DELETE FROM `users` WHERE `membership` = 74");
}
if (isset($_POST['payments']))
{
$SQL = $odb -> query("TRUNCATE `payments`");
}
if (isset($_POST['attacks']))
{
$SQL = $odb -> query("TRUNCATE `logs`");
}
if (isset($_POST['logins']))
{
$SQL = $odb -> query("TRUNCATE `loginlogs`");
}
if (isset($_POST['setfreeusers']))
{
$SQL = $odb -> query("UPDATE `users` SET `membership` = :55 ");
}
?>
<form method="post">
            <div class="page-content">

                <div class="container">
                    <div class="page-toolbar">
                        
                        <div class="page-toolbar-block">
                            <div class="page-toolbar-title">Logs & Users</div>
                            <div class="page-toolbar-subtitle">Users, Payments, Attacks and Logins</div>
                        </div>  
                              <div class="block">
                                <div class="block-head">
                                    <button type="submit" class="btn btn-link btn-xs" name="deletefree">Delete all Free users</button>
                                </div>    </div>    

                       <ul class="page-toolbar-tabs">
                            <li class="active"><a href="#page-tab-1">Users</a></li>
                        </ul>
                    </div>                    
<div class="row page-toolbar-tab active" id="page-tab-1">

                            <div class="block">
                                <div class="block-head">
                                </div>
                                <div class="block-content np">
                                    <table class="table table-bordered table-striped sortable">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Username</th>
                                                <th>Email</th>
                                                <th>Rank</th>
                                                <th>Membership</th>                                    
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
$SQLGetUsers = $odb -> query("SELECT * FROM `users` ORDER BY `ID` DESC");
while ($getInfo = $SQLGetUsers -> fetch(PDO::FETCH_ASSOC))
{
	$id = $getInfo['ID'];
	$user = $getInfo['username'];
	$email = $getInfo['email'];
	if ($getInfo['expire']>time()) {$plan = $odb -> query("SELECT `plans`.`name` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = '$id'") -> fetchColumn(0);} else {$plan='No membership';}
	$rank = $getInfo['rank'];
		if ($rank == 1)
		{
			$rank = 'Admin';
		}
		elseif ($rank == 3)
		{
			$rank = 'VIP';
		}
		elseif ($rank == 8)
		{
			$rank = 'Basic';
		}
		elseif ($rank == 7)
		{
			$rank = 'VipPlus';
		}
		else
		{
			$rank = 'Member';
		}
	echo '<tr><td></td><td><a href="user.php?id='.$id.'">'.htmlspecialchars($user).'</a></td><td>'.htmlspecialchars($email).'</td><td>'.$rank.'</td><td>'.htmlspecialchars($plan).'</td></tr>';
}
?>											
                                        </tbody>
                                    </table>                                                                        
                                </div>
                            </div>

</div>

                </div>
                
            </div>
			</form>
            <div class="page-sidebar"></div>
        </div>
    </body>
</html>
