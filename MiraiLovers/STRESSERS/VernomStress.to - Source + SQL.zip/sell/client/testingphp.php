<?php
echo $_SERVER['HTTP_X_REAL_IP'];
?>