<?php

$paginaname = 'Bitcoin Checkout';

	ob_start();
	session_start();
	require_once("@/config.php");
	require_once("@/init.php");
	
		if($_GET['id'] == "")
	{ 
		header("Location: index.php");
	} else {
			
	if(isset($_GET['id']) && Is_Numeric($_GET['id']) && $user -> LoggedIn())
	{
	$id = (int)$_GET['id'];
	$row = $odb -> query("SELECT * FROM `plans` WHERE `ID` = '$id'") -> fetch();
	if($row == "")
	{
	 header("Location: index.php");
	} else {

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<meta charset="utf-8">

        <title><?php echo htmlspecialchars($sitename); ?> - <?php echo $paginaname; ?></title>

        <meta name="description" content="<?php echo htmlspecialchars($description); ?>">
        <meta name="author" content="StrikeREAD">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="shortcut icon" href="img/favicon.png">
        <link rel="apple-touch-icon" href="img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="img/icon152.png" sizes="152x152">
        <link rel="apple-touch-icon" href="img/icon180.png" sizes="180x180">
        <link rel="stylesheet" href="css/bootstrap.min-black-new4.css">
        <link rel="stylesheet" href="css/plugins.css">
        <link rel="stylesheet" href="css/azuremain8.css">
        <link rel="stylesheet" href="css/themes/azure11.css" id="theme-link">
        <link rel="stylesheet" href="css/themesdark2.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
  <body>
        <div id="page-wrapper" class="page-loading">
            <div class="preloader">
                <div class="inner">
                    <!-- Animation spinner for all modern browsers -->
                    <div class="preloader-spinner themed-background hidden-lt-ie10"></div>

                    <!-- Text for IE9 -->
                    <h3 class="text-primary visible-lt-ie10"><strong>Loading..</strong></h3>
                </div>
            </div>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                <div id="sidebar-alt" tabindex="-1" aria-hidden="true">
                    <a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>

                    <div id="sidebar-scroll-alt">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Profile -->
                         
                        </div>
                      
                    </div>
                   
                </div>
                
			
				
                <div id="sidebar">
                 
                    <div id="sidebar-brand" class="themed-background">
                        <a href="index.php" class="sidebar-title">
                            <i class="fa fa-globe"></i> <span class="sidebar-nav-mini-hide"><strong><?php echo htmlspecialchars($sitename); ?></strong></span>
                        </a>
                    </div>
            

                 
                    <div id="sidebar-scroll">
                 
                        <div class="sidebar-content">
                    
                            <ul class="sidebar-nav">
                                <li>
                                    <a class="active"><i class="fa fa-exclamation-triangle sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Purchasing Package</span></a>
                                </li>
                                <li class="sidebar-separator">
                                    <i class="fa fa-ellipsis-h"></i>
                                </li>
						<li>
                                    <a href="purchase.php" ><i class="fa fa-shopping-cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Purchase</span></a>
                                </li>
								<li class="sidebar-separator">
                                    <i class="fa fa-ellipsis-h"></i>
                                </li>
								<li>
                                    <a href="tickets.php" ><i class="fa fa-envelope sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Tickets</span></a>
                                </li>
                            </ul>

                        </div>
                 
                    </div>
                 

               
                    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="text-center">
                            <small><?php echo htmlspecialchars($sitename); ?> </small><br>
                            <small></span> 2018 &copy; <a href="<?php echo htmlspecialchars($siteurl); ?>" target="_blank"><?php echo htmlspecialchars($sitename); ?></a></small>
                        </div>
                    </div>
         
                </div>
				<div id="main-container">
				<header class="navbar navbar-inverse navbar-fixed-top">
                       
                        <ul class="nav navbar-nav-custom">
                          
                            <li>
                                <a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');">
                                    <i class="fa fa-ellipsis-v fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
                                    <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>
                                </a>
                            </li>
                           

                      
                            <li class="hidden-xs animation-fadeInQuick">
                                <a href=""><strong><?php echo $paginaname; ?></strong></a>
                            </li>
                         
                        </ul>
               
                        <ul class="nav navbar-nav-custom pull-right">

                            <li class="dropdown">
                                
                               
                            </li>
                          
                        </ul>
						
						
						
                       
                    </header>
				
				<div id="page-content">
<div class="content-header">

            <div class="content-page">
                <div class="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <ol class="breadcrumb pull-right">
                                        <li><a href="#">RackStress</a></li>
                                        <li class="active">Bitcoin</li>
                                    </ol>
                                    <h4 class="page-title">Bitcoin</h4>
                                </div>
                            </div>
                        </div>

<br/>
                        <div class="row">	
<div class="col-lg-3"></div>						
<center><div class="col-lg-6">






                                <div class="card-box">
                                    <h4 class="text-dark  header-title m-t-0"><?php echo $row['name']; ?> - Bitcoin Checkout</h4>
                                    <p class="text-muted m-b-25 font-13">
                                        
                                    </p>

                                    <div class="table-responsive">
                                        Please send <b><?php echo $row['price']; ?></b>€ to <input class="form-control" id="host" style="margin-top: 10px;" value="<?php echo $bitcoin; ?>" type="text" readonly> <br/> <b>TAX INCLUDED ONLY </b>and after open a ticket with bitcoin transation link or screenshot of payment
										<br/>
										<br/>
										
									Thanks
                                    </div>
									<br/>
								
                                </div>
                            </div>
							
							</center>
							
							
                        </div>



						</div>

                        </div>
</div>
</div>
</div>
</div></center>
		
<?php
	}
	}
	}
?>
			
                    <? // NO BORRAR LOS TRES DIVS! ?>
               </div>         
          </div>
	</div>

		<?php include("@/script.php"); ?>
    </body>
</html>