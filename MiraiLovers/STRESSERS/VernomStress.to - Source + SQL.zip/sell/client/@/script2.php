        <script src="js/plugins/jquery/jquery.min.js"></script>
        <script src="js/plugins/chartjs/Chart.min.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>