<?php
/* 
------------------
Language: English
------------------
*/

$themec = array();

$themec['CSS'] = 'amethyst';

?>