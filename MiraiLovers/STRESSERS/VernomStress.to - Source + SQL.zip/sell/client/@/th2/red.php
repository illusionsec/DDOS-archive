<?php
/* 
-----------------
Language: Spanish
-----------------
*/

$themec = array();

$themec['CSS'] = 'passion';
?>