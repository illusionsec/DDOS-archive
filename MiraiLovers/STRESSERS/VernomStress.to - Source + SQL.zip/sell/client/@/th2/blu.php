<?php
/* 
-----------------
Language: German
-----------------
*/

$themec = array();

$themec['CSS'] = 'flat';
?>