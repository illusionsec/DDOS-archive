<?php 
// Before of all your CODE.
require('firewall/waf.php');
$xWAF = new xWAF();
$xWAF->start();
// Your code below.

//ssl force
if($_SERVER["HTTPS"] != "on"){
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

if (basename($_SERVER['SCRIPT_FILENAME']) == basename(__FILE__)) {exit("NOT ALLOWED");}
ob_start();
require_once '@/config.php';
require_once '@/init.php';
/*if (!(empty($maintaince))) {
die($maintaince);
}*/
if (!($user -> LoggedIn()) || !($user -> notBanned($odb)))
{
	header('location: login.php');
	die();
}
?>
<head>
        <meta charset="utf-8">

        <title><?php echo htmlspecialchars($sitename); ?> - <?php echo $paginaname; ?></title>

        <meta name="description" content="<?php echo htmlspecialchars($description); ?>">
        <meta name="author" content="VenomStress">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="apple-touch-icon" href="img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="img/icon152.png" sizes="152x152">
        <link rel="apple-touch-icon" href="img/icon180.png" sizes="180x180">
        <link rel="stylesheet" href="css/bootstrap.min-black-new6.css">
        <link rel="stylesheet" href="css/plugins.css">
        <link rel="stylesheet" href="css/azuremain13.css">
		<link rel="stylesheet" href="css/themes/azure13.css" id="theme-link">
        <link rel="stylesheet" href="css/themesdark2.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<link href="js/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" /> 

		<link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet">

    </head>
    <body>
        <div id="page-wrapper" class="page-loading">
            
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                <div id="sidebar-alt" tabindex="-1" aria-hidden="true">
                    <a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>

                    <div id="sidebar-scroll-alt">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Profile -->
                         
                        </div>
                      
                    </div>
                   
                </div>
                

				
                <div id="sidebar">
                 
                    <div id="sidebar-brand" class="themed-background">
					
                        <a href="index.php" class="sidebar-title" >
						
                             <img src="venom.png" style="height:40px; margin-top:13px; margin-bottom:0px; margin-left:0px;

animation: pulse 3s infinite; ">
                        </a>

                    </div>

				
                    <div id="sidebar-scroll">
                 
				 
                        <div class="sidebar-content">
                    
                            <ul class="sidebar-nav" style="margin-left:20px; padding:3px; margin-top:20px;">
							                        

                            	<small> <li class="menu-title" style="margin-bottom:5px;">&nbsp &nbsp NAVIGATION</li></small>


							<li>
                                    <a href="index.php" <?php if (basename($_SERVER['PHP_SELF']) == "index.php") { ?> class="active" <?php } ?>><i class="fa fa-home sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Dashboard</span></a>
													
								
															                        
								
								
														<?php if ($user->hasMembership($odb)) { 
															if(!($user->isVIP($odb))) { ?>
						<li>
                                    <a href="hub.php" <?php if (basename($_SERVER['PHP_SELF']) == "hub.php") { ?> class="active" <?php } ?> ><i class="fa fa-crosshairs sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">FREE Hub</span></a>
                                </li>

                                </li>
								
						<?php
						} 
					} else { ?>
						<?php } ?>
						<?php
						if ($user -> isAdmin($odb) || $user -> isVIP($odb) ) {
						?>
						<li>
						<a href="vipstress.php" <?php if (basename($_SERVER['PHP_SELF']) == "vipstress.php") { ?> class="active" <?php } ?> ><i class="fa fa-bolt sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">VIP Hub</span></a>
                                </li>		  			
						<?php
						}
						?>
						<li>
						<a href="api-manager.php" <?php if (basename($_SERVER['PHP_SELF']) == "api-manager.php") { ?> class="active" <?php } ?> ><i class="fa fa-key sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">API Manager</span></a>
                                </li>		

                              </li>	
                                </li>

						

							  

							  
								
                                <li>
                                    <a href="powerproof.php" <?php if (basename($_SERVER['PHP_SELF']) == "powerproof.php") { ?> class="active" <?php } ?>><i style="color:gold;" class="fas fa-check sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide"><font color=gold>Reviews</font></span></a>
                              </li>



							  <li>
                                    <a href="purchase.php" <?php if (basename($_SERVER['PHP_SELF']) == "purchase.php") { ?> class="active" <?php } ?>><i class="fa fa-shopping-cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Purchase <!--<span class="label label-danger">15% OFF!</span>--> </span></a>
                              </li>
							  

								
								


							  					
		  
							  						<li>
                                    <a href="tickets.php" <?php if (basename($_SERVER['PHP_SELF']) == "tickets.php") { ?> class="active" <?php } ?>><i class="fa fa-envelope sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Support</span></a>
                              </li>
							  
							  <!--<li>
                                    <a href="faq.php" <?php if (basename($_SERVER['PHP_SELF']) == "faq.php") { ?> class="active" <?php } ?>><i class="fa fa-question-circle sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">FAQ</span></a>
                              </li>-->
							  
							  
						<?php
						if ($user -> isAdmin($odb) ) {
						?>
						<li>
						<a href="th3fuck3r/admin/" <?php if (basename($_SERVER['PHP_SELF']) == "th3fuck3r/admin/") { ?> class="active" <?php } ?> ><i class="fa fa-lock sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Admin Panel</span></a>
                                </li>							  			
						<?php
						}
						?>

						<!--<br>
						<small> <li class="menu-title" style="margin-bottom:5px;">&nbsp &nbsp ADVERTISING</li></small>
						-->
							                                  						
							  
							  </font>



                            </ul>

                        </div>
                 
                    </div>
                 

               
                    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="push-bit">
                            <span class="pull-right">
                                <a href="javascript:void(0)" class="text-light"></a>
                            </span>
                            <small><strong class="text-light"><?php echo $stats -> runningboots($odb) ?>/<?php echo $maxattacks; ?></strong> Running Tests</small>
                        </div>
                        <div class="progress progress-mini push-bit">
                            <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="20" aria-valuemin="20" aria-valuemax="20" style="width: <?php echo $stats -> runningboots($odb) ?>0%"></div>
                        </div>
                        <div class="text-center">
                           
                            
                        </div>
                    </div>
         
                </div>
				<div id="main-container">
				<header class="navbar navbar-inverse navbar-fixed-top">
                       
                        <ul class="nav navbar-nav-custom">


                        	<li style="margin-top:50%">
                                <a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');">
                                    <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
                                    <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>
                                </a>
                            </li>


                          
                            
                           

                      
                         
                        </ul>
               
			   
			   
                        <ul class="nav navbar-nav-custom pull-right">

                        	

                            <li class="dropdown" style="margin-top:8%;">
                                <a href="#modal-cp" data-toggle="modal" >
                                            <i class="fa fa-cogs fa-fw "></i>
                                            Settings
                                        </a>
                                                       </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    
									
								
	
									
                                    <li style="display:inline-block;">
							
                                        <a href="#modal-cp" data-toggle="modal" style="display:inline-block;">
                                            <i class="fa fa-user fa-fw pull-right"></i>
                                            UserCP
                                        </a>
                                    
							
                                        <a href="logout.php" style="display:inline-block;">
                                            <i class="fa fa-unlock fa-fw pull-right"></i>
                                           Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                          
                        </ul>
                        <ul class="nav navbar-nav-custom pull-right">

                            <li class="dropdown">
                                
								
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li class="dropdown-header">
                                    
									
								<font color=white> Tickets waiting for your reply: </br>
	<?php
$tickets = $odb->query("SELECT COUNT(*) FROM `tickets` WHERE `username` = '{$_SESSION['username']}' AND `status` = 'Waiting for user response' ORDER BY `id` DESC")->fetchColumn(0);
?>
<?php 
$SQLGetTickets = $odb -> prepare("SELECT * FROM `tickets` WHERE `username` = :username AND `status` = 'Waiting for user response' ORDER BY `id` DESC");
$SQLGetTickets -> execute(array(':username' => $_SESSION['username']));
while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
{
$id = $getInfo['id'];
$subject = $getInfo['subject'];
$status = $getInfo['status'];
$content = $getInfo['content'];
$date = date("m-d-Y" ,$getInfo['date']);
echo '<a href="../boot/view.php?id='.$id.'" class="list-item"><div class="list-item-content"><br><p>'.htmlspecialchars(substr($subject, 0, 30)).'...</p><span class="date">'.$date.'</span></div></a>';
}
?>    
                                        </a>
                                    </li>
									</li>
                                </ul></font>
                            </li>
                          
                        </ul>
						<script>
						function pass()
						{
						var password=$('#password').val();
						var npassword=$('#npassword').val();
						var rpassword=$('#rpassword').val();
						var idpass=$('#idpass').val();
						var userpass=$('#userpass').val();
						document.getElementById("passdiv").style.display="none";
						document.getElementById("passimage").style.display="inline";
						var xmlhttp;
						if (window.XMLHttpRequest)
						  {// code for IE7+, Firefox, Chrome, Opera, Safari
						  xmlhttp=new XMLHttpRequest();
						  }
						else
						  {// code for IE6, IE5
						  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
						  }
						xmlhttp.onreadystatechange=function()
						  {
						  if (xmlhttp.readyState==4 && xmlhttp.status==200)
							{
							document.getElementById("passdiv").innerHTML=xmlhttp.responseText;
							document.getElementById("passimage").style.display="none";
							document.getElementById("passdiv").style.display="inline";
							}
						  }
						xmlhttp.open("POST","ajax/usercp.php?type=pass",true);
						xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
							xmlhttp.send("password=" + password + "&npassword=" + npassword + "&rpassword=" + rpassword + "&userpass=" + userpass + "&idpass=" + idpass);

						}
						function code()
						{
						var code=$('#code').val();
						var codepass=$('#codepass').val();
						var ncode=$('#ncode').val();
						var idcode=$('#idcode').val();
						document.getElementById("codediv").style.display="none";
						document.getElementById("codeimage").style.display="inline";
						var xmlhttp;
						if (window.XMLHttpRequest)
						  {// code for IE7+, Firefox, Chrome, Opera, Safari
						  xmlhttp=new XMLHttpRequest();
						  }
						else
						  {// code for IE6, IE5
						  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
						  }
						xmlhttp.onreadystatechange=function()
						  {
						  if (xmlhttp.readyState==4 && xmlhttp.status==200)
							{
							document.getElementById("codediv").innerHTML=xmlhttp.responseText;
							document.getElementById("codeimage").style.display="none";
							document.getElementById("codediv").style.display="inline";
							}
						  }
						xmlhttp.open("POST","ajax/usercp.php?type=code",true);
						xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
							xmlhttp.send("codepass=" + codepass + "&code=" + code + "&ncode=" + ncode + "&idcode=" + idcode);

						}
						
						
						</script>
						<div id="modal-cp" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog">
									<div class="modal-content">
									<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h3 class="modal-title"><strong>UserCP</strong></h3>
									</div>
									<div class="modal-body">
									<div class="form-horizontal form-bordered">
									<div class="form-group">
									<div class="col-md-12">
									<a href="#modal-password" class="btn btn-effect-ripple btn-primary btn-block" data-toggle="modal">Change Password</a>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a href="#modal-code" class="btn btn-effect-ripple btn-primary btn-block" data-toggle="modal">Change Security Code</a>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a href="#modal-logs" class="btn btn-effect-ripple btn-primary btn-block" data-toggle="modal">View Logs</a>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a href="logout.php" class="btn btn-effect-ripple btn-primary btn-block">Logout</a>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a class="btn btn-effect-ripple btn-danger btn-block" data-dismiss="modal" aria-hidden="true" >Close</a>
									</div>
									</div>
									</div>
									</div>							
									</div>
									</div>
						</div>
						

						<div id="modal-password" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog">
									<div class="modal-content">
									<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h3 class="modal-title"><strong>Change Password</strong> <img src="img/jquery.easytree/loading.gif" id="passimage" style="display:none"/></h3>
									</div>
									<div class="modal-body">
									<div class="form-horizontal form-bordered">
									<div class="form-group">
									<div class="col-md-12">
									<div id="passdiv" style="display:none"></div>
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">Password</label>
									<div class="col-md-9">
									<input type="text" name="password" id="password" value="" class="form-control">
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">New Password</label>
									<div class="col-md-9">
									<input type="text" name="rpassword" id="rpassword" value="" class="form-control">
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">Repeat New Password</label>
									<div class="col-md-9">
									<input type="text" name="npassword" id="npassword" value="" class="form-control">
									</div>
									</div>
									<input type="hidden" id="userpass" name="userpass" value="<?php echo $_SESSION['username']; ?>"  />
									<input type="hidden" id="idpass" name="idpass" value="<?php echo $_SESSION['ID']; ?>"  />
									<div class="form-group">
									<div class="col-md-12">
									<button type="submit" onclick="pass()" class="btn btn-effect-ripple btn-primary btn-block">Change Password</button>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a class="btn btn-effect-ripple btn-danger btn-block" data-dismiss="modal" aria-hidden="true" >Back</a>
									</div>
									</div>
									</div>
									</div>							
									</div>
									</div>
						</div>
						<div id="modal-code" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog">
									<div class="modal-content">
									<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h3 class="modal-title"><strong>Change Security Code</strong> <img src="img/jquery.easytree/loading.gif" id="codeimage" style="display:none"/></h3>
									</div>
									<div class="modal-body">
									<div class="form-horizontal form-bordered">
									<div class="form-group">
									<div class="col-md-12">
									<div id="codediv" style="display:none"></div>
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">Security Code</label>
									<div class="col-md-9">
									<input type="text" id="code" name="code" value="" class="form-control">
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">Your Password</label>
									<div class="col-md-9">
									<input type="text" id="codepass" name="codepass" value="" class="form-control">
									</div>
									</div>
									<div class="form-group">
									<label class="col-md-3 control-label">New SCode</label>
									<div class="col-md-9">
									<input type="text" id="ncode" name="ncode" value="" class="form-control">
									</div>
									</div>
									<input type="hidden" id="idcode" name="idcode" value="<?php echo $_SESSION['ID']; ?>"  />
									<div class="form-group">
									<div class="col-md-12">
									<button type="submit" onclick="code()" class="btn btn-effect-ripple btn-primary btn-block" data-toggle="modal">Change Security Code</button>
									</div>
									</div>
									<div class="form-group">
									<div class="col-md-12">
									<a class="btn btn-effect-ripple btn-danger btn-block" data-dismiss="modal" aria-hidden="true" >Back</a>
									</div>
									</div>
									</div>
									</div>							
									</div>
									</div>
						</div>
						<div id="modal-logs" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog">
									<div class="modal-content">
									<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h3 class="modal-title"><strong>Logs</strong></h3>
									</div>
									<div class="modal-body">
									<div class="form-horizontal form-bordered">
									<div class="form-group">
									
									
									<ul class="nav nav-tabs nav-justified">
											<li class="active"><a href="#tab9" data-toggle="tab"><font color=red>Login History</a></li></font>
											<li><a href="#tab10" data-toggle="tab"><font color=red> Tests History</a></li></font>
										</ul>
									 <div class="block-content tab-content">
											<div class="tab-pane active" id="tab9">
												<p>
											<table class="table table-striped">
											<tr>
												<th>IP Address</th><th>Country</th><th>Date</th>
											</tr>
											<tr>
	<?php
	$SQLGetLogs = $odb -> query("SELECT * FROM `loginlogs` WHERE `username`='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 0, 13");
	while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
	{
	 $IP = $getInfo['ip'];
	 $country = $getInfo['country'];
	 $date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
	 echo '<tr><td>'.htmlspecialchars($IP).'</td><td>'.$country.'</td><td>'.$date.'</td></tr>';
	}
	?>
											</tr>                                       
										</table>
												</p>
											</div>
											<div class="tab-pane" id="tab10">
												<p>
											<table class="table table-striped">
											<tr>
												<th>Host</th><th>Port</th><th>Time</th><th>Method</th><th>Date</th>
											</tr>
											<tr>
	<?php
	$SQLGetLogs = $odb -> query("SELECT * FROM `logs` WHERE user='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 0, 13");
	while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC))
	{
	 $IP = $getInfo['ip'];
	 $port = $getInfo['port'];
	 $time = $getInfo['time'];
	 $method = $odb->query("SELECT `fullname` FROM `methods` WHERE `name` = '{$getInfo['method']}'")->fetchColumn(0);
	 $date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
	 echo '<tr><td>'.htmlspecialchars($IP).'</td><td>'.$port.'</td><td>'.$time.' seconds</td><td>'.htmlspecialchars($method).'</td><td>'.$date.'</td></tr>';
	}
	?>
											</tr>                                       
										</table>
												</p>
											</div>                        
										</div>
									<div class="form-group">
									<div class="col-md-12">
									<a class="btn btn-effect-ripple btn-danger btn-block" data-dismiss="modal" aria-hidden="true" >Back</a>
									</div>
									</div>
									</div>
									</div>							
									</div>
									</div>
									</div>
						</div>
							<!--<div class="bugme bugmebar-animated bugmebar-bounceInDown bugme-fixed" style="text-align: center; z-index: 99999; display: block; width: 100%; position: relative; float: left; clear: both; padding: 2px 8px; background: #3498db; color: #fff; font-size: 17px; line-height: 1.4; font-family: " Helvetica Neue",Helvetica,Arial,Verdana,sans-serif; font-weight: 400; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box;"">.</div>-->

                    </header>