<?php
/* 
-----------------
Language: Spanish
-----------------
*/

$lang = array();

$lang['MENU_HOME'] = '<span class="sidebar-nav-mini-hide">Inicio</span>';
?>