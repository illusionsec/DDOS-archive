<?php

$paginaname = 'VIP API-Access';

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php include("@/header.php"); 
					
			
			if (!($user->hasMembership($odb))) 
			{
				header('location: index.php');
				die();
			}
				
				
			?>
                    <div id="page-content">
                     
                        <div class="row">
							                            <div class="col-sm-20 col-lg-18">

            

                        <div class="block">
                            <!-- Normal Pricing Tables Title -->
                            <div class="block-title">
                            </div>
                            <!-- END Normal Pricing Tables Title -->
                          <!-- Normal Pricing Tables Content -->
                            <div class="row">
                             <center>   <h2>VIP API Manager</h2></center>
                          <div class="panel-body">
                        <center>

                         <?php
                                
                                if(!isset($_POST['keyBtn']))
                                {
                                    $SQLGetKey = $odb -> prepare("SELECT `apikey` FROM `users` WHERE `ID` = :id");
                                    $SQLGetKey -> execute(array(':id' => $_SESSION['ID']));
                                    $userKey = $SQLGetKey -> fetchColumn(0);
                                }
                                else
                                {
                                    function generateRandomKey($length = 15) 
                                    {
                                        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
                                        $randomString = '';
                                        for ($i = 0; $i < $length; $i++) {
                                            $randomString .= $characters[rand(0, strlen($characters) - 1)];
                                        }
                                        return $randomString;
                                    }
                                    
                                    $userKey = generateRandomKey();
                                    
                                    $SQLNewKey = $odb -> prepare("UPDATE `users` SET `apikey` = :newkey WHERE `ID` = :id");
                                    $SQLNewKey -> execute(array(':newkey' => $userKey, ':id' => $_SESSION['ID']));
                                    
                                    echo '<div class="alert alert-success" id="not-theme">Your API key has been changed.</div>';
                                }
                            ?>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="state-danger">Api Key</label>
                                            <div class="col-md-8">
                                                <input type="text" id="state-danger" name="state-danger" class="form-control" placeholder="No Api Key" value="<?php echo $userKey; ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="state-danger">Api Link</label>
                                            <div class="col-md-8">
                                                <input type="text" id="state-danger" name="state-danger" class="form-control" placeholder="No Api" value="<?php echo $siteurl; ?>api/vip-api.php?key=<?php echo $userKey; ?>&host=[host]&port=[port]&time=[time]&method=[method]" readonly>
                                            </div>
                                        </div>
							<form action="" method="POST">
                                <button class="btn btn-primary" name="keyBtn" type="submit" style="width: 150px; height: 30px;">Generate New Key</button>
                            </form>
                        </center>
                                  
                            </div>
                            <!-- END Normal Pricing Tables Content -->
                        </div>
                        <!-- END Normal Pricing Tables Block -->
						
                    </div></br>
<center> <a href="<?php echo $siteurl; ?>api/vip-api.php?key=<?php echo $userKey; ?>&host=1.1.1.2&port=80&time=1&method=showmethods"> <h4> Show all methods </h4></a> </center>



</center> </h4>

                        <h4><i class="fa fa-question-circle"></i> FAQ</h4>
						
						<div class="panel-group accordion collapse in" id="accordion" aria-expanded="true" style="">
				<div class="panel panel-default plain" id="dash_0">
				
							<div id="3" class="panel-collapse collapse in" aria-expanded="true" style="">
						</div><div class="panel panel-default plain" id="dash_2">
							<div class="panel-heading">
								<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#5" aria-expanded="false"><b><font color=White>How can I use this API?</font></b><i class="fa fa-plus s14"></i></a></h4>
							</div>
							<div id="5" class="panel-collapse collapse" aria-expanded="false">
								<div class="panel-body">You can make your own tool.
							</div>
				</div>
				
						</div><div class="panel panel-default plain" id="dash_3">
							<div class="panel-heading">
								<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#6" aria-expanded="false"><b><font color=White>Can I share this API?</font></b><i class="fa fa-plus s14"></i></a></h4>
							</div>
							<div id="6" class="panel-collapse collapse" aria-expanded="false">
								<div class="panel-body">No, you can't share or resell.<br></div>
							</div>
						</div><div class="panel panel-default plain" id="dash_4">
							<div class="panel-heading">
								<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#7" aria-expanded="false"><b><font color=white>Which is the power of this API?</b><i class="fa fa-plus s14"></i></a></h4>
							</div>
							<div id="7" class="panel-collapse collapse" aria-expanded="false">
								<div class="panel-body">It is the same of your current plan.<br></div>
							</div>
				</div>
				
                     <? // NO BORRAR LOS TRES DIVS! ?>
               </div>
               </div>
          </div>





<script>
$(document).ready(function(){

	$("#modal1").modal();

});
</script>







		<?php include("@/script.php"); ?>
    </body>
</html>