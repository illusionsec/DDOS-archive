<?php  
  include("header.php");
  $page = "API System";
?>
    <title><?php echo htmlspecialchars($BooterName['bootername']);?> - <?php echo htmlspecialchars($page);?></title>
<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- DataTables -->
        <link href="assets/plugins/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <!-- MetisMenu CSS -->
        <link href="assets/css/metisMenu.min.css" rel="stylesheet">
        <!-- Icons CSS -->
        <link href="assets/css/icons.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="assets/css/style.css" rel="stylesheet">
    </head>
    <body>
                <div id="page-right-content">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-16">
                                <h4 class="m-t-0 header-title"> L7 API System</h4>
                                <div class="m-b-20">
                                    <p class="text-muted font-13 m-b-30">
                                        API System to control the power output for Stress Panel.
                                    </p>
				                    <div class="col-md-7">
                                    <form role="form" method="POST">
									
			<?php
			if (isset($_POST['addBtn']))
				{
					$handler1 = htmlspecialchars($_POST['handler']);
					$api2 = html_entity_decode($_POST['api'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
					$slots = htmlspecialchars($_POST['slots']);

					if (empty($handler1) || empty($api2) || empty($slots))
					{
					echo '<div class="alert alert-icon alert-danger alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><i class="mdi mdi-check-all"></i>Fill in all fields</div>';
					}
					else
					{
						$SQLinsert = $odb -> prepare("INSERT INTO `apil7` VALUES(NULL, :handler, :api, :slots, UNIX_TIMESTAMP(NOW()), :active)");
						$SQLinsert -> execute(array(':handler' => $handler1, ':api' => $api2, ':slots' => $slots, ':active' => 1));
					echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><i class="mdi mdi-check-all"></i>API L7 has been added!</div>';
					}
				}
				?>

										<div class="card-box">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                    <input type="text" class="form-control" name="handler" placeholder="Server Name">
                                                </div>
												<div class="input-group m-t-10">
                                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                    <input type="text" class="form-control" name="api" placeholder="API URI">
                                                </div>
												<div class="input-group m-t-10">
                                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                    <input type="text" class="form-control" name="slots" placeholder="Max API Slots" >
                                                </div>
												<div class="input-group m-t-10">
												<button type="submit" name="addBtn" class="btn btn-success btn-bordered" >Add API</button>
                                                </div>
                                            </div>
                                            </div>
                                        </form>
                                     </div>
							     </div>
                            <div class="col-sm-12">
                                <h4 class="m-t-0 header-title">API Listing</h4>
                                    <p class="text-muted font-13 m-b-30">
                                        Control, Delete and Edit, API's for Stress Panel.
                                    </p>
							<form action="" method="POST" class="form-horizontal">
                            <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
						  <th width="1%">ID</th>
						  <th>Handler</th>
						  <th>API</th>
						  <th width="15%">Max Slots</th>
						  <th width="3%">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
				  <?php
				  $SQLSelect = $odb -> query("SELECT * FROM `apil7` ORDER BY `ID` DESC");
				  while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
				  {
					$ids = htmlspecialchars($show['ID']);
					$handler = htmlspecialchars($show['handler']);
					$api = htmlspecialchars($show['api']);
					$slots = htmlspecialchars($show['slots']);
					echo '<tr><td>'.htmlspecialchars($ids).'</td><td>'.htmlspecialchars($handler).'</td><td>'.html_entity_decode($api, ENT_QUOTES | ENT_HTML5, 'UTF-8').'</td><td>'.htmlspecialchars($slots).'</td><td><a class="btn btn-success btn-bordered"  href="editapil7.php?id='.htmlspecialchars($ids).'">Edit</a></td></tr>';
				  }
				  ?>
                                        </tbody>
                                    </table>
								</form>
                            </div>
                        </div>
					<?php include htmlspecialchars('../footer.php'); ?>
                </div>
                <div class="clearfix"></div>
        <!-- js placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery-2.1.4.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.min.js"></script>
        <!-- Datatable js -->
        <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
        <script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/plugins/datatables/buttons.bootstrap.min.js"></script>
        <script src="assets/plugins/datatables/jszip.min.js"></script>
        <script src="assets/plugins/datatables/pdfmake.min.js"></script>
        <script src="assets/plugins/datatables/vfs_fonts.js"></script>
        <script src="assets/plugins/datatables/buttons.html5.min.js"></script>
        <script src="assets/plugins/datatables/buttons.print.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/plugins/datatables/responsive.bootstrap.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.scroller.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.colVis.js"></script>
        <script src="assets/plugins/datatables/dataTables.fixedColumns.min.js"></script>
        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>
        <!-- App Js -->
        <script src="assets/js/jquery.app.js"></script>
    </body>
</html>