<?php
  ob_start();
  require_once('../includes/db.php');
  require_once('../includes/init.php');

  include("header.php");
  $page = "Attack Logs";
?>
    <title><?php echo htmlspecialchars($BooterName['bootername']);?> - <?php echo htmlspecialchars($page);?></title>
<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- DataTables -->
        <link href="assets/plugins/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/plugins/datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <!-- MetisMenu CSS -->
        <link href="assets/css/metisMenu.min.css" rel="stylesheet">
        <!-- Icons CSS -->
        <link href="assets/css/icons.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="assets/css/style.css" rel="stylesheet">
    </head>
    <body>
                <div id="page-right-content">
                    <div class="container">
                          <div class="row">
                            <div class="col-sm-17">
                                <h4 class="m-t-0 header-title">Attack Logs</h4>
                                <div class="table-responsive m-b-20">
                                    <p class="text-muted font-13 m-b-30">
                                        Attack logging system to manage and track all attacks.
                                    </p>
                                    <table id="datatable-buttons" class="table table-striped table-bordered">
                                <thead>
								<tr>
									<th style="font-size: 12px;">Name</th>
									<th style="font-size: 12px;">Host</th>
									<th style="font-size: 12px;">Time</th>
									<th style="font-size: 12px;">Date</th>
								</tr>
                                        </thead>
                                        <tbody>
							<?php
							$SQLGetLogs = $odb -> query("SELECT * FROM `logs` ORDER BY `date` DESC LIMIT 12600");
							while($getInfo = $SQLGetLogs -> fetch(PDO::FETCH_ASSOC)){
								$user = htmlspecialchars($getInfo['user']);
								$host = htmlspecialchars($getInfo['ip']);
								if (filter_var($host, FILTER_VALIDATE_URL)) {$port='';} else {$port=':'.htmlspecialchars($getInfo['port']);}
								$time = htmlspecialchars($getInfo['time']);
								$method = htmlspecialchars($getInfo['method']);
								$date = htmlspecialchars(date("m-d-Y, h:i:s a" ,$getInfo['date']));
								echo '<tr>
										<td>'.htmlspecialchars($user).'</td>
										<td>'.htmlspecialchars($host).htmlspecialchars($port).'</td>
										<td>'.htmlspecialchars($time).' ('.htmlspecialchars($method).')<br></td>
										<td>'.htmlspecialchars($date).'</td>
									  </tr>';
							}
							?>	
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>							
				<?php include htmlspecialchars('../footer.php'); ?>
                </div>
                <div class="clearfix"></div>
        <!-- Datatable js -->
        <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
        <script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/plugins/datatables/buttons.bootstrap.min.js"></script>
        <script src="assets/plugins/datatables/jszip.min.js"></script>
        <script src="assets/plugins/datatables/pdfmake.min.js"></script>
        <script src="assets/plugins/datatables/vfs_fonts.js"></script>
        <script src="assets/plugins/datatables/buttons.html5.min.js"></script>
        <script src="assets/plugins/datatables/buttons.print.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/plugins/datatables/responsive.bootstrap.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.scroller.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.colVis.js"></script>
        <script src="assets/plugins/datatables/dataTables.fixedColumns.min.js"></script>
        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>
        <!-- App Js -->
        <script src="assets/js/jquery.app.js"></script>
    </body>
</html>