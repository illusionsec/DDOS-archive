<?php

$paginaname = 'Servers';


?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php 
			
			include("@/header.php");

			?>
			<div id="page-content">
<div class="panel-heading">
<h4 class="panel-title"><i class="fa fa-send"></i> Server stats </h4>
<div class="panel-controls">
</div>
</div>
<center>
<div class="panel-body">
 <div class="table-responsive">   
<div id="serversTable" style="overflow: hidden; width: 720px; height: auto;">
<div class="table-responsive" style="overflow: hidden; outline: none;" tabindex="0"><table class="table table-striped table-bordered">
<tbody>
<tr>
<th><center>Name</center></th>
<th><center>Type</center></th>
<th><center>Status</center></th>
</tr>
<tr>
</tr>
<tr>
<td><center><b>Server-1</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-2</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-3</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-4</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-5</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-6</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-7</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-8</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
 <td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
<td><center><b>Server-9</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>
<tr>
 <td><center><b>Server-10</b></center></td>
<td><center><span class="label label-primary">Layer 4</span></center></td>
<td><center><span class="label label-success">Online</span></center></td>
</tr>  
</tbody>
</table>
</div>
</div>
</div>
</center>
</div>
</div>

</div>
</div>
</div>

 <? // NO BORRAR LOS TRES DIVS! ?>
               </div>
               </div>
             
          </div>

		<?php include("@/script.php"); ?>
    </body>
</html>