<?php

$paginaname = 'Buy Plan';

	ob_start();
	session_start();
	require_once("@/config.php");
	require_once("@/init.php");
	
		if($_GET['id'] == "")
	{ 
		header("Location: index.php");
	} else {
			
	if(isset($_GET['id']) && Is_Numeric($_GET['id']) && $user -> LoggedIn())
	{
	$id = (int)$_GET['id'];
	$row = $odb -> query("SELECT * FROM `plans` WHERE `ID` = '$id'") -> fetch();
	if($row == "")
	{
	 header("Location: index.php");
	} else {

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<meta charset="utf-8">

        <title><?php echo htmlspecialchars($sitename); ?> - <?php echo $paginaname; ?></title>

        <meta name="description" content="<?php echo htmlspecialchars($description); ?>">
        <meta name="author" content="Booter.rip">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="shortcut icon" href="img/favicon.png">
        <link rel="apple-touch-icon" href="img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="img/icon152.png" sizes="152x152">
        <link rel="apple-touch-icon" href="img/icon180.png" sizes="180x180">
        <link rel="stylesheet" href="css/bootstrap.min-black-new4.css">
        <link rel="stylesheet" href="css/plugins.css">
        <link rel="stylesheet" href="css/azuremain8.css">
		<link rel="stylesheet" href="css/themes/azure11.css" id="theme-link">
        <link rel="stylesheet" href="css/themesdark2.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
  <body>
        <div id="page-wrapper" class="page-loading">
            <div class="preloader">
                <div class="inner">
                    <!-- Animation spinner for all modern browsers -->
                    <div class="preloader-spinner themed-background hidden-lt-ie10"></div>

                    <!-- Text for IE9 -->
                    <h3 class="text-primary visible-lt-ie10"><strong>Loading..</strong></h3>
                </div>
            </div>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                <div id="sidebar-alt" tabindex="-1" aria-hidden="true">
                    <a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>

                    <div id="sidebar-scroll-alt">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Profile -->
                         
                        </div>
                      
                    </div>
                   
                </div>
                
			
				
                <div id="sidebar">
                 
                    <div id="sidebar-brand" class="themed-background">
					
                        <a href="index.php" class="sidebar-title" >
						
                             <img src="booterrip.png" style="height:30px; margin-top:13px; margin-bottom:0px; margin-left:0px;

animation: pulse 3s infinite; ">
                        </a>

                    </div>
            
 <div id="sidebar-scroll">
        
                 
                       <div class="sidebar-content">
                    
                            <ul class="sidebar-nav" style="margin-left:20px; padding:3px; margin-top:20px;">
                                <li>
                                <li class="sidebar-separator">
                                </li>
						<li>
                                    <a href="purchase.php" ><i class="fa fa-undo sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Return</span></a>
                                </li>
								<li>
                                    <a href="tickets.php" ><i class="fa fa-envelope sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Support</span></a>
                                </li>
                            </ul>

                        </div>
                 
                    </div>
                 

               
                  
                   <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="push-bit">
                            <span class="pull-right">
                                <a href="javascript:void(0)" class="text-light"></a>
                             <a href="javascript:void(0)" class="text-light"><i class="fa fa-plus"></i></a>
                            </span>
                           <small><strong class="text-light"><?php echo $stats -> runningboots($odb) ?></strong> Running Tests</small>
                        </div>
                        <div class="progress progress-mini push-bit">
                            <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="20" aria-valuemin="20" aria-valuemax="20" style="width:<?php echo $stats -> runningboots($odb) ?>%"></div>
                        </div>
                        <div class="text-center">
                           
                            
                        </div>
                    </div>
         
                </div>
					<div id="main-container">
				<header class="navbar navbar-inverse navbar-fixed-top">
                       
                        <ul class="nav navbar-nav-custom">


                        	<li style="margin-top:50%">
                                <a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');">
                                    <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
                                    <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>
                                </a>
                            </li>


                          
                            
                           

                      
                         
                        </ul>
               
			   
			   
                        <ul class="nav navbar-nav-custom pull-right">

                        	

                            <li class="dropdown" style="margin-top:8%;">
                                <a href="#modal-cp" data-toggle="modal" >
                                            <i class="fa fa-cogs fa-fw "></i>
                                            Settings
                                        </a>

                                <a href="logout.php">
                                            <i class="fa fa-power-off fa-fw "></i>
                                           Logout
                                        </a>

                                                             </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    
									
								
	
									
                                    <li style="display:inline-block;">
							
                                        <a href="#modal-cp" data-toggle="modal" style="display:inline-block;">
                                            <i class="fa fa-user fa-fw pull-right"></i>
                                            UserCP
                                        </a>
                                    
							
                                        <a href="logout.php" style="display:inline-block;">
                                            <i class="fa fa-unlock fa-fw pull-right"></i>
                                           Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                          
                        </ul>
						
						
                       
                    </header>
			  <div id="page-content">


                        <div class="row">
                        <center>
                        	<img height="75" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/PayPal.svg/2000px-PayPal.svg.png"></img>
                        	<br/><br/><br/>

                        <div class="row">	
<div class="col-lg-3"></div>						
<center><div class="col-lg-6">






                                <div class="card-box">
                                    <h4 class="text-dark  header-title m-t-0">PayPal Checkout</h4>
                                    <p class="text-muted m-b-25 font-13">
                                        
                                    </p>

                                    <div class="table-responsive">
                                        Please send <b>money</b> to <input class="form-control" id="host" style="margin-top: 10px;" value="<?php echo $paypal; ?>" type="text" readonly> <br/> <b>Send as friends and family only, </b>and after open a ticket with payment informations (paypal name, email and amount you paid)
										<br/>
										<br/>
										
									Thanks
                                    </div>
									<br/>
								
                                </div>
                            </div>
							
							</center>
						</div>
					</center>
				</div>
							

<br/><br/><br/>
							                        <div class="row">
                        <center>
                        	<img height="75" src="https://www.inlea.com/web/wp-content/uploads/2017/06/bitcoin_how_to-earn_Inlea.png"></img>
                        	<br/><br/><br/>

                        <div class="row">	
<div class="col-lg-3"></div>						
<center><div class="col-lg-6">






                                <div class="card-box">
                                    <h4 class="text-dark  header-title m-t-0">Bitcoin Checkout</h4>
                                    <p class="text-muted m-b-25 font-13">
                                        
                                    </p>

                                    <div class="table-responsive">
                                        Please send <b>money</b> to <input class="form-control" id="host" style="margin-top: 10px;" value="<?php echo $bitcoin; ?>" type="text" readonly> <br/> <b>TAX INCLUDED ONLY </b>and after open a ticket with bitcoin transation link or screenshot of payment
										<br/>
										<br/>
										
									Thanks
                                    </div>
									<br/>
								
                                </div>
                            </div>
							
							</center>
						</div>
					</center>
				</div>

							
                        </div>


                        </center>
                        </div>

					
					</div>

					
				</div>
		
<?php
	}
	}
	}
?>
			
                    <? // NO BORRAR LOS TRES DIVS! ?>
               </div>         
          </div>
	</div>

		<?php include("@/script.php"); ?>
    </body>
</html>
                       <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c0c12bd7a79fc1bddf0137a/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->