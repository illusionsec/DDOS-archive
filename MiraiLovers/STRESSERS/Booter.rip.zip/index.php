
<!doctype html>

<html lang="en">

  <head> 


      <!-- CHARSET -->
      <meta charset="utf-8">
      
      <!-- META -->
      <meta name="robots" content="noodp" />
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">
      <meta name="Keywords" content="ip booter, ip stresser, stresser, booter, best ip stresser 2018">
      <meta name="description" content="Powerful IP Stress Testing Service!">
      
      
      <!-- PAGE TITLE -->
      <title>Booter.rip </title>
      
      
      <!-- FAVICON -->
      <link rel="shortcut icon" href="">
      
      
      <!-- GOOGLE FONTS -->
      <link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800|Open+Sans:300,400,600,700,800" rel="stylesheet">
      
      
      <!-- STYLESHEETS CORE -->
      <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
      
      
      <!-- STYLESHEETS TEMPLATE -->
      <link rel="stylesheet" type="text/css" href="assets/css/layout.css">
      <link rel="stylesheet" type="text/css" href="assets/css/hero.css">
      <link rel="stylesheet" type="text/css" href="assets/css/blocks.css">
      <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
      
      
      <!-- STYLESHEET TEMPLATE COLOR -->
      <link rel="stylesheet" type="text/css" href="assets/css/color/default.css">
      
            
  </head>
  
  
  <body>
  
  
  		
      <!-- PAGE LOADER -->
      <div id="page-loader">
          
          
          <!-- CONTAINER MID -->
          <div class="container-mid">
          
          
              <img src="main/logo.png" class="img-responsive" alt="image">
              
              
              <!-- SPINNER CONTAINER -->
              <div class="spinner-container">
              
                  <div class="css-spinner"></div>
                  
              </div>
              <!-- /SPINNER CONTAINER -->
          
          
          </div>
          <!-- /CONTAINER MID -->
      
      
      </div>
      <!-- /PAGE LOADER -->
      
      
      
      <!-- MAIN -->
      <div id="main">
      
      
      
          <!-- HERO -->
          <section id="hero" class="hero hero-2">
          
          
              <!-- FRONT CONTENT -->
              <div class="front-content page-enter-animated">
              
              
                  <!-- CONTAINER MID -->
                  <div class="container-mid">
                  
                  
                      <!-- INNER FRONT CONTENT -->
                      <div class="inner 3d-hover">
                      
                          <img class="img-responsive logo" src="main/logo.png" alt="logo">
                          <p>The best ip booter is back. </p>
                        
                       <a href="/panel/"><button type="button" class="btn btn-default">LOGIN</button></a>
                       <br/><br/>
                       <a href="/panel/register.php"><button type="button" class="btn btn-default">REGISTER</button></a>
                          
                      </div>
                      <!-- /INNER FRONT CONTENT -->
                      
                  
                  </div>
                  <!-- /CONTAINER MID -->
                  
                  
                  <div class="scroll-down"></div>
                  
                  
                  <!-- CONTROLS -->
                  <div class="controls">
                  
                      <i class="volume-button fa fa-volume-up"></i>
                      <i class="pause-button ti-control-pause"></i>   
                  
                  </div>
                  <!--/ CONTROLS -->
                  
              
              
              </div>
              <!-- /FRONT CONTENT -->
              
              
              <!-- BACKGROUND CONTENT -->
              <div class="background-content page-enter-animated">
              
                  
                  <!-- LEVEL 1 -->
                  <div class="level-1">
                  
                  
                      <div class="bg-overlay"></div>
                      <div class="bg-pattern"></div>
                      <div id="canvas"><canvas class="bg-effect layer" data-depth="0.2"></canvas></div>
                  
                  
                  </div>
                  <!-- /LEVEL 1 -->
                  
                  
                  <!-- LEVEL 2 -->
                  <div class="level-2">
                  
                  
                      <!-- PARALLAX BACKGROUND -->
                      <div class="dzsparallaxer auto-init allbody" data-options="{  mode_scroll: 'fromtop', animation_duration: '2' , direction: 'reverse' }">
                      
                      
                          <!-- PARALLAX TARGET -->
                          <div class="dzsparallaxer--target">
                         
                         
                              <div class="bg-image layer" data-depth="0.04"></div>
                              <div class="bg-video layer" data-depth="0.04"></div>
                              <div class="bg-color layer" data-depth="0.04"></div>
                          
                          
                          </div>
                          <!-- /PARALLAX TARGET -->
                          
                          
                      </div>
                      <!-- /PARALLAX BACKGROUND -->
                  
                  
                  </div>
                  <!-- /LEVEL 2 -->
              
              
              </div>
              <!-- /BACKGROUND CONTENT -->
          
          
          </section>
          <!-- /HERO -->
          
          
          

 
 
        
      <!-- JAVASCRIPTS CORE-->
      <script type="text/javascript" src="assets/js/plugins/plugins.js"></script>
      
      
      <!-- JAVASCRIPTS TEMPLATE CONFIG -->
      <script type="text/javascript" src="config.js"></script>
      
      
      <!-- JAVASCRIPTS TEMPLATE -->
      <script type="text/javascript" src="assets/js/scripts.js"></script>
      <script type="text/javascript" src="assets/js/hero.js"></script>
      <script type="text/javascript" src="assets/js/blocks.js"></script>
      <script type="text/javascript" src="assets/js/custom.js"></script>
      
      
      
  </body>


</html>