import re
import sys

def extract_ips(input_file_path):
    ips = []
    ip_pattern = re.compile(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b')

    with open(input_file_path, 'r') as file:
        content = file.read()
        ips = ip_pattern.findall(content)

    return ips

def write_to_file(output_file_path, data):
    with open(output_file_path, 'w') as output_file:
        for item in data:
            output_file.write(f"{item}\n")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python script.py <input_file> <output_file>")
        sys.exit(1)

    input_file_path = sys.argv[1]
    output_file_path = sys.argv[2]

    result = extract_ips(input_file_path)

    # Print the extracted IPs
    for ip in result:
        print(ip)

    # Write the extracted IPs to the output file
    write_to_file(output_file_path, result)
    print(f"IPs written to {output_file_path}")
