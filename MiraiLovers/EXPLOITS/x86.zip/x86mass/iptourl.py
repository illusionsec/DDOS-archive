import socket
import sys
def get_url_from_ip(ip_address):
    try:
        # Get the hostname using gethostbyaddr
        hostname, _, _ = socket.gethostbyaddr(ip_address)
        
        # Create a URL using the obtained hostname
        url = f"https://{hostname}/"
        return url
    except (socket.herror, socket.gaierror):
        # Handle errors when resolving the hostname
        return None

def main(input_file_path, output_file_path):
    with open(input_file_path, 'r') as input_file, open(output_file_path, 'w') as output_file:
        for line in input_file:
            ip_address = line.strip()
            url = get_url_from_ip(ip_address)
            print(url)
            if url is not None:
                # Write the URL to the output file
                output_file.write(url + '\n')

if __name__ == "__main__":
    input_file_path = sys.argv[1]  # Replace with the path to your input file
    output_file_path = "url.txt"   # Replace with the desired output file path
    
    main(input_file_path, output_file_path)
