import os
import subprocess
import sys 
import time
import threading
# Dateipfad ersetzen
timer = []
threads = []
with open(sys.argv[1], 'r') as file:
    lines = file.readlines()
    for i, line in enumerate(lines):
        time.sleep(0.55)     
        def run():
            os.system(f"""python3 https.py {line.strip()}""")

        r = threading.Thread(target=run)
        r.start()
        threads.append(r)
        timer1 = threading.Timer(10, r._stop)
        timer1.start()
        timer.append(timer1)
